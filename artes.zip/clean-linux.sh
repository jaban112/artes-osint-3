#!/usr/bin/env bash
# clean-linux.sh — 크롬북 리눅스(Crostini) 램·정크·캐시 안전 정리
# 절대 안 건드림: ~/artes 소스, .venv, Dolphin 모델(*.gguf), ~/.local/bin 단축키, 개인 문서
# 사용법:  bash clean-linux.sh          (안전 정리)
#          bash clean-linux.sh --deep   (venv/빌드 캐시까지 더 비움)
set -u
DEEP=0; [ "${1:-}" = "--deep" ] && DEEP=1
C_G="\033[1;32m"; C_Y="\033[1;33m"; C_B="\033[1;34m"; C_R="\033[1;31m"; C_0="\033[0m"
say(){ echo -e "${C_B}▸${C_0} $*"; }
ok(){  echo -e "  ${C_G}✔${C_0} $*"; }
warn(){ echo -e "  ${C_Y}!${C_0} $*"; }

human(){ numfmt --to=iec 2>/dev/null <<<"${1:-0}" || echo "${1:-0}B"; }
disk_free(){ df --output=avail -B1 "$HOME" 2>/dev/null | tail -1 | tr -d ' '; }
mem_avail(){ awk '/MemAvailable/{print $2*1024}' /proc/meminfo 2>/dev/null; }

D0=$(disk_free); M0=$(mem_avail)
echo -e "${C_G}=== ARTES 리눅스 정리 시작 ===${C_0}"
echo "  시작 디스크 여유: $(human "$D0")   |   시작 램 여유: $(human "$M0")"
echo

# ── 0) 램 잡아먹는 유휴 프로세스 정리(로컬 AI 서버) ──
say "램 회수: 유휴 llama-server(로컬 AI) 종료"
if pgrep -x llama-server >/dev/null 2>&1; then
  pkill -x llama-server 2>/dev/null && ok "llama-server 종료(모델 언로드) — 다음에 llama-ai로 재기동됨"
else
  ok "실행 중인 llama-server 없음"
fi

# ── 1) 패키지 관리자 캐시(pacman/CachyOS) ──
say "패키지 캐시 정리"
if command -v paccache >/dev/null 2>&1; then
  sudo paccache -rk1 2>/dev/null && ok "오래된 패키지 버전 삭제(최신1개 보존)"
  sudo paccache -ruk0 2>/dev/null && ok "제거된 패키지 캐시 삭제"
elif command -v pacman >/dev/null 2>&1; then
  sudo pacman -Sc --noconfirm >/dev/null 2>&1 && ok "pacman -Sc 완료"
else
  warn "pacman 없음(건너뜀)"
fi

# ── 2) 파이썬/uv/pip 캐시 ──
say "파이썬 빌드·다운로드 캐시 정리"
command -v uv  >/dev/null 2>&1 && { uv cache clean  >/dev/null 2>&1 && ok "uv 캐시 비움"; }
command -v pip >/dev/null 2>&1 && { pip cache purge  >/dev/null 2>&1 && ok "pip 캐시 비움"; }
rm -rf "$HOME"/.cache/pip "$HOME"/.cache/uv 2>/dev/null && ok "~/.cache/pip·uv 삭제"

# ── 3) __pycache__ / .pytest_cache (홈 전역, .venv 제외) ──
say "파이썬 임시물(__pycache__·.pytest_cache) 정리"
find "$HOME" -type d \( -name '__pycache__' -o -name '.pytest_cache' \) \
     -not -path '*/.venv/*' -prune -exec rm -rf {} + 2>/dev/null
ok "완료(.venv 안은 보존)"

# ── 4) 기타 개발 캐시(있으면) ──
say "개발 도구 캐시 정리"
rm -rf "$HOME"/.cargo/registry/cache "$HOME"/.cargo/registry/src 2>/dev/null && ok "cargo 레지스트리 캐시"
command -v go  >/dev/null 2>&1 && { go clean -cache -modcache >/dev/null 2>&1 && ok "go 빌드·모듈 캐시"; }
command -v npm >/dev/null 2>&1 && { npm cache clean --force  >/dev/null 2>&1 && ok "npm 캐시"; }

# ── 5) 시스템 로그·코어덤프·썸네일·휴지통 ──
say "로그·코어덤프·썸네일·휴지통 정리"
command -v journalctl >/dev/null 2>&1 && { sudo journalctl --vacuum-size=50M >/dev/null 2>&1 && ok "systemd 저널 50M로 축소"; }
sudo rm -rf /var/lib/systemd/coredump/* 2>/dev/null && ok "코어덤프 삭제"
rm -rf "$HOME"/.cache/thumbnails/* "$HOME"/.thumbnails/* 2>/dev/null && ok "썸네일 캐시"
rm -rf "$HOME"/.local/share/Trash/* 2>/dev/null && ok "휴지통 비움"

# ── 6) 임시 파일(내 소유만) ──
say "임시 파일(/tmp, 내 소유) 정리"
find /tmp -maxdepth 1 -user "$(id -u)" -mtime +0 -exec rm -rf {} + 2>/dev/null
rm -f /tmp/artes-new.zip 2>/dev/null
ok "완료"

# ── 7) (--deep) venv·빌드 산출물까지 ──
if [ "$DEEP" = "1" ]; then
  say "[deep] 더 깊은 정리 — 재설치 필요할 수 있음"
  rm -rf "$HOME"/.cache/* 2>/dev/null && ok "~/.cache 전체 비움"
  [ -d "$HOME/llama.cpp/build" ] && warn "llama.cpp/build 있음 — 재빌드 원하면 수동 삭제(모델은 보존됨)"
  warn "deep 후 artes 가상환경 문제 시: cd ~/artes && uv venv && uv pip install -e ."
fi

# ── 8) 램 캐시 드롭 ──
say "리눅스 페이지 캐시 드롭(램 여유 확보)"
sync
if echo 3 | sudo tee /proc/sys/vm/drop_caches >/dev/null 2>&1; then ok "drop_caches=3 완료"; else warn "권한 없음(sudo 필요) — 건너뜀"; fi

# ── 결과 ──
D1=$(disk_free); M1=$(mem_avail)
DD=$(( ${D1:-0} - ${D0:-0} )); MM=$(( ${M1:-0} - ${M0:-0} ))
echo
echo -e "${C_G}=== 정리 완료 ===${C_0}"
echo "  디스크 여유: $(human "$D0") → $(human "$D1")   (+$(human "$DD" ) 확보)"
echo "  램   여유: $(human "$M0") → $(human "$M1")   (+$(human "$MM" ) 확보)"
echo
echo "  보존됨: ~/artes 소스 · .venv · Dolphin 모델(*.gguf) · ~/.local/bin 단축키"
echo "  더 비우려면:  bash clean-linux.sh --deep"
