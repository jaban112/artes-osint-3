"""안전 필터 — 정규식 1차 방어 + 해시DB 훅."""
import tempfile, os

from artes.core.safety import ContentFilter, HashDB


def test_regex_first_line():
    f = ContentFilter()
    assert f.is_blocked("free csam pack") is True
    assert f.is_blocked("normal profile") is False


def test_hashdb_exact_and_phash():
    with tempfile.TemporaryDirectory() as td:
        p = os.path.join(td, "bad.txt")
        with open(p, "w") as fh:
            fh.write("# 알려진 불법 해시셋\n")
            fh.write("aabbccddeeff0011\n")           # 정확 해시
            fh.write("p:ffffffffffffffff\n")         # 지각해시
        db = HashDB()
        assert db.load(p) == 2
        assert db.blocks_hash("aabbccddeeff0011") is True
        assert db.blocks_hash("0000") is False
        assert db.blocks_image("fffffffffffffffe", max_hamming=4) is True   # 해밍 1
        assert db.blocks_image("0000000000000000", max_hamming=4) is False


def test_content_filter_media():
    f = ContentFilter()
    f.hashdb.exact.add("deadbeef")
    assert f.is_blocked_media(exact_hash="deadbeef") is True
    assert f.is_blocked_media(exact_hash="cafe") is False
