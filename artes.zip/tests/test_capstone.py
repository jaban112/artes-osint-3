"""캡스톤 — mock 스캔부터 해석·리포트·전 내보내기까지 전 파이프라인 회귀."""
import asyncio
import json
import xml.etree.ElementTree as ET

from artes.core.engine import Engine
from artes.core.cache import Cache
from artes.collectors import mock
from artes.ai.interpret import interpret
from artes.ai.runtime import Runtime
from artes.ai.backend import StubBackend
from artes.core.report import build_profile, render_html
from artes.core import export
import tempfile


def _scan():
    async def go():
        eng = Engine(mock.DEFAULTS, cache=Cache(root=tempfile.mkdtemp()),
                     depth=2, use_bandit=False)
        [x async for x in eng.run(["김지완", "jiwan@gmail.com", "jiwan123"])]
        return eng.graph
    return asyncio.run(go())


def test_full_pipeline():
    g = _scan()
    assert g.stats()["entities"] > 3

    # 해석층(코드 사실 종합 + 스텁 서술)
    r = interpret(g, runtime=Runtime(backend=StubBackend()))
    assert "footprint" in r.facts and "top_selectors" in r.facts
    assert "timeline" in r.facts and r.used_ai

    # 리포트
    prof = build_profile(g, ["김지완", "jiwan@gmail.com", "jiwan123"])
    html = render_html(prof)
    assert "ARTES 프로파일" in html and prof["footprint"]["present"] >= 1

    # 전 내보내기 형식 유효
    ET.fromstring(export.to_graphml(g))                 # GraphML 유효 XML
    assert "," in export.to_maltego_csv(g)
    bundle = json.loads(export.to_stix(g))
    assert bundle["type"] == "bundle" and bundle["objects"]

    # AI 호출은 해석에서만(수집 0회)
    assert g.stats()["entities"] == len(g.entities)
