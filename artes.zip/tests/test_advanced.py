"""고급 추론층 — 출처추적·부정정보·타임라인·셀렉터·자기검증."""
from artes.core.model import Graph, Entity, Edge, EntityType, Certainty, Evidence
from artes.core import provenance, negative, timeline, selectors
from artes.ai.verify import verify_claim, verify_same_person
from artes.ai.runtime import Runtime
from artes.ai.backend import StubBackend


def _chain():
    g = Graph()
    s = g.add(Entity(EntityType.EMAIL, "seed@x.com", Certainty.CONFIRMED,
                     evidence=[Evidence("입력", "")]))
    a = g.add(Entity(EntityType.USERNAME, "seeduser", Certainty.CONFIRMED,
                     evidence=[Evidence("t", "")]))
    b = g.add(Entity(EntityType.ACCOUNT, "gh/seeduser", Certainty.CONFIRMED,
                     evidence=[Evidence("t", "")]))
    c = g.add(Entity(EntityType.BREACH, "dump/seed@x.com", Certainty.CONFIRMED,
                     evidence=[Evidence("t", "")]))
    g.link(Edge(s.key, a.key, "추정 아이디", Certainty.CONFIRMED, evidence=[Evidence("t", "")]))
    g.link(Edge(a.key, b.key, "가진 계정", Certainty.CONFIRMED, evidence=[Evidence("t", "")]))
    g.link(Edge(s.key, c.key, "유출 노출", Certainty.CONFIRMED, evidence=[Evidence("t", "")]))
    return g, s, a, b, c


def test_provenance_dependents_and_taint():
    g, s, a, b, c = _chain()
    deps = provenance.dependents(g, s.key)
    assert a.key in deps and b.key in deps and c.key in deps
    chain = provenance.derivation_chain(g, b.key)
    assert chain[0] == s.key and chain[-1] == b.key
    affected = provenance.taint(g, s.key, "유출 오염")
    assert b.key in affected
    assert g.get(b.key).certainty is Certainty.UNCONFIRMED   # 하위 강등


def test_negative_footprint_and_absence():
    small = negative.footprint_size({"a", "b"}, {"a", "b", "c", "d", "e"})
    assert small["bucket"].startswith("극소")
    big = negative.footprint_size(set(f"s{i}" for i in range(150)),
                                  set(f"s{i}" for i in range(200)))
    assert big["bucket"].startswith("대")
    same = negative.absence_similarity({"x", "y", "z"}, {"x", "y", "z"})
    assert same["applicable"] and same["lower"] > 0.8


def test_timeline_and_timezone():
    g = Graph()
    g.add(Entity(EntityType.DOMAIN, "x.com", Certainty.CONFIRMED,
                 attrs={"registration": "2019-03-01"}, evidence=[Evidence("t", "")]))
    g.add(Entity(EntityType.URL, "http://x.com/old", Certainty.CONFIRMED,
                 attrs={"timestamp": "20210615120000"}, evidence=[Evidence("t", "")]))
    tl = timeline.build_timeline(g)
    assert len(tl) == 2 and tl[0]["date"] <= tl[1]["date"]
    tz = timeline.activity_timezone([13, 14, 15, 20, 21, 22, 13, 14, 21])  # UTC 낮~밤 활발
    assert tz["applicable"] and -12 <= tz["utc_offset_est"] <= 12


def test_selectors_extract():
    g = Graph()
    g.add(Entity(EntityType.PHONE, "+821012345678", Certainty.CONFIRMED, evidence=[Evidence("t", "")]))
    g.add(Entity(EntityType.EMAIL, "a@b.com", Certainty.CONFIRMED, evidence=[Evidence("t", "")]))
    g.add(Entity(EntityType.ACCOUNT, "site/x", Certainty.CONFIRMED,
                 attrs={"bio": "btc 1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa"},
                 evidence=[Evidence("t", "")]))
    sels = selectors.extract_selectors(g)
    kinds = {s["kind"] for s in sels}
    assert "phone" in kinds and "email" in kinds and "crypto" in kinds
    assert sels[0]["pivot_value"] >= sels[-1]["pivot_value"]     # 랭크 정렬


def test_verify_refutes_and_downgrades():
    rt = Runtime(backend=StubBackend(
        lambda p: '{"verdict":"반증 있음","reason":"두 계정의 이메일이 다르다"}'))
    r = verify_claim(rt, "A=B 동일인", "데이터...")
    assert not r.upheld and "반증 있음" == r.verdict

    g = Graph()
    a = g.add(Entity(EntityType.USERNAME, "aaa", Certainty.CONFIRMED, evidence=[Evidence("t", "")]))
    b = g.add(Entity(EntityType.USERNAME, "bbb", Certainty.CONFIRMED, evidence=[Evidence("t", "")]))
    edge = g.link(Edge(a.key, b.key, "동일인?", Certainty.UNCONFIRMED, 0.8,
                       evidence=[Evidence("동일인해소", "약신호")]))
    verify_same_person(rt, g, edge)
    assert edge.confidence == 0.4                               # 반박 → 절반 강등
