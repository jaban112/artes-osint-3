"""증분 25 — start.me·awesome-osint 무키 소스 대량확장 파서 단위검증.

합성 응답으로 파서만 검증(네트워크 없이). 실 페치는 사용자 환경.
검증: 계정/실명/위치/교차링크, 학술 이름피벗, 이메일 품질·IP 위협 보강.
"""
from artes.collectors.social5_c import (Minecraft, JikanMAL, AniList, Kitsu, TetrIO,
                                        Scratch, Discogs, SourceForge, Hashnode,
                                        Packagist, Bitbucket, Telegram)
from artes.collectors.scholar_c import Crossref, SemanticScholar, OpenLibrary, OpenSanctions
from artes.collectors.verify_c import (KickboxOpen, Disify, IPWhois, GreyNoiseCommunity, SANSISC)
from artes.core.model import EntityType, Certainty
from artes.collectors.registry import default_collectors


def _kinds(res):
    return {(e.type, e.value) for e in res.entities}


# ══════════ social5 ══════════
def test_minecraft_uuid():
    res = Minecraft().parse({"id": "069a79f4...", "name": "Notch"}, "notch")
    acc = [e for e in res.entities if e.type == EntityType.ACCOUNT][0]
    assert acc.value == "minecraft/Notch"
    assert acc.attrs["uuid"].startswith("069a")


def test_jikan_location():
    u = {"username": "amy", "location": "Seoul", "joined": "2015-01-01",
         "url": "https://myanimelist.net/profile/amy", "about": "blog https://amy.dev"}
    res = JikanMAL().parse(u, "amy")
    k = _kinds(res)
    assert (EntityType.ACCOUNT, "myanimelist/amy") in k
    assert (EntityType.GEO, "Seoul") in k
    assert (EntityType.URL, "https://amy.dev") in k


def test_anilist_links():
    u = {"id": 5, "name": "Bob", "siteUrl": "https://anilist.co/user/Bob",
         "about": "portfolio https://bob.art", "createdAt": 1600000000}
    res = AniList().parse(u, "bob")
    k = _kinds(res)
    assert (EntityType.ACCOUNT, "anilist/Bob") in k
    assert (EntityType.URL, "https://bob.art") in k


def test_kitsu_name_geo():
    item = {"attributes": {"slug": "carol", "name": "Carol Lee", "location": "Busan",
                           "about": "site https://carol.io", "createdAt": "2016"}}
    res = Kitsu().parse(item, "carol")
    k = _kinds(res)
    assert (EntityType.NAME, "Carol Lee") in k
    assert (EntityType.GEO, "Busan") in k


def test_tetrio_country():
    u = {"username": "dave", "country": "KR", "xp": 12345, "gamesplayed": 200}
    res = TetrIO().parse(u, "dave")
    k = _kinds(res)
    assert (EntityType.ACCOUNT, "tetrio/dave") in k
    assert (EntityType.GEO, "KR") in k


def test_scratch_country_join():
    d = {"username": "eve", "history": {"joined": "2014-05-01"},
         "profile": {"country": "United States", "bio": "hi https://eve.me", "status": ""}}
    res = Scratch().parse(d, "eve")
    k = _kinds(res)
    assert (EntityType.ACCOUNT, "scratch/eve") in k
    assert (EntityType.GEO, "United States") in k
    assert (EntityType.URL, "https://eve.me") in k


def test_discogs_realname_home():
    d = {"username": "dj", "name": "DJ Real", "location": "London",
         "home_page": "https://dj.fm", "uri": "https://www.discogs.com/user/dj"}
    res = Discogs().parse(d, "dj")
    k = _kinds(res)
    assert (EntityType.NAME, "DJ Real") in k
    assert (EntityType.GEO, "London") in k
    assert (EntityType.URL, "https://dj.fm") in k


def test_sourceforge_socials():
    d = {"username": "sam", "name": "Sam Park", "joined": "2010",
         "socialnetworks": [{"socialnetwork": "Twitter", "accounturl": "https://twitter.com/sam"}]}
    res = SourceForge().parse(d, "sam")
    k = _kinds(res)
    assert (EntityType.NAME, "Sam Park") in k
    assert (EntityType.URL, "https://twitter.com/sam") in k


def test_hashnode_social_links():
    u = {"name": "Ada L", "location": "Berlin", "followersCount": 900,
         "socialMediaLinks": {"github": "https://github.com/ada", "twitter": "https://twitter.com/ada",
                              "website": "https://ada.dev", "linkedin": None}}
    res = Hashnode().parse(u, "ada")
    k = _kinds(res)
    assert (EntityType.NAME, "Ada L") in k
    assert (EntityType.GEO, "Berlin") in k
    assert (EntityType.URL, "https://github.com/ada") in k
    assert (EntityType.URL, "https://ada.dev") in k


def test_packagist_packages():
    pkgs = [{"name": "acme/foo"}, {"name": "acme/bar"}]
    res = Packagist().parse(pkgs, "acme")
    acc = [e for e in res.entities if e.type == EntityType.ACCOUNT][0]
    assert acc.value == "packagist/acme"
    assert "acme/foo" in acc.attrs["packages"]


def test_bitbucket_workspace():
    d = {"values": [{"name": "repo1", "owner": {"display_name": "Team X"}}, {"name": "repo2"}]}
    res = Bitbucket().parse(d, "teamx")
    k = _kinds(res)
    assert (EntityType.ACCOUNT, "bitbucket/teamx") in k
    assert (EntityType.NAME, "Team X") in k


def test_telegram_public_preview():
    html = ('<meta property="og:title" content="Cool Channel">'
            '<meta property="og:description" content="news and https://t.me/joinchat/x">'
            '<div class="tgme_page_extra">12 345 subscribers</div>')
    res = Telegram().parse(html, "coolchannel")
    acc = [e for e in res.entities if e.type == EntityType.ACCOUNT][0]
    assert acc.value == "telegram/coolchannel"
    assert acc.attrs["kind"] == "channel/group"


def test_telegram_generic_rejected():
    res = Telegram().parse('<meta property="og:title" content="Telegram">', "nobody")
    assert not res.ok


# ══════════ scholar (이름 피벗) ══════════
def test_crossref_orcid_affiliation():
    items = [{"author": [{"ORCID": "https://orcid.org/0000-0002-1", "given": "Jane",
                          "affiliation": [{"name": "MIT"}]}]}]
    res = Crossref().parse(items, "jane doe")
    k = _kinds(res)
    assert (EntityType.ACCOUNT, "orcid/0000-0002-1") in k
    assert (EntityType.ORG, "MIT") in k


def test_crossref_requires_fullname():
    # 공백 없는 단일 토큰은 조용히 빈결과(소음 방지)
    import asyncio
    res = asyncio.run(Crossref().collect("jane", EntityType.NAME, {}))
    assert res.ok and not res.entities


def test_semanticscholar_author():
    data = [{"authorId": "1741101", "name": "Jane Doe", "paperCount": 30,
             "homepage": "https://jane.edu", "affiliations": ["MIT"]}]
    res = SemanticScholar().parse(data, "jane doe")
    k = _kinds(res)
    assert (EntityType.ACCOUNT, "semanticscholar/1741101") in k
    assert (EntityType.URL, "https://jane.edu") in k


def test_openlibrary_author():
    docs = [{"key": "OL1A", "name": "Jane Doe", "work_count": 12, "top_work": "A Book"}]
    res = OpenLibrary().parse(docs, "jane doe")
    acc = [e for e in res.entities if e.type == EntityType.ACCOUNT][0]
    assert acc.value == "openlibrary/OL1A"
    assert acc.attrs["top_work"] == "A Book"


def test_opensanctions_strong_match_only():
    results = [{"id": "abc", "caption": "John Bad", "schema": "Person", "score": 0.92,
                "datasets": ["us_ofac"]},
               {"id": "def", "caption": "John Weak", "schema": "Person", "score": 0.3,
                "datasets": ["x"]}]
    res = OpenSanctions().parse(results, "john bad")
    breaches = [e for e in res.entities if e.type == EntityType.BREACH]
    assert len(breaches) == 1                    # 약매칭(0.3)은 제외
    assert "John Bad" in breaches[0].value


# ══════════ verify (이메일·IP 보강) ══════════
def test_kickbox_deliverable_and_typo():
    d = {"result": "deliverable", "disposable": False, "role": False, "free": True,
         "mx_found": True, "did_you_mean": "a@gmail.com"}
    res = KickboxOpen().parse(d, "a@gmial.com")
    em = [e for e in res.entities if e.type == EntityType.EMAIL and e.value == "a@gmial.com"][0]
    assert em.attrs["deliverable"] == "deliverable"
    # 오타 교정 후보 별도 엔티티
    assert any(e.type == EntityType.EMAIL and e.value == "a@gmail.com" for e in res.entities)


def test_disify_disposable():
    res = Disify().parse({"format": True, "dns": True, "disposable": True, "domain": "x.com"},
                         "a@x.com")
    em = [e for e in res.entities if e.type == EntityType.EMAIL][0]
    assert em.attrs["disposable"] is True


def test_ipwhois_asn():
    d = {"success": True, "city": "Seoul", "region": "Seoul", "country": "South Korea",
         "connection": {"asn": 4766, "org": "KT", "isp": "KT", "domain": "kt.com"}}
    res = IPWhois().parse(d, "1.2.3.4")
    k = _kinds(res)
    assert (EntityType.ASN, "AS4766") in k
    assert any(e.type == EntityType.GEO for e in res.entities)


def test_greynoise_malicious():
    res = GreyNoiseCommunity().parse({"noise": True, "riot": False, "classification": "malicious",
                                      "name": "unknown", "link": "https://x"}, "9.9.9.9")
    assert any(e.type == EntityType.MALWARE for e in res.entities)
    ip = [e for e in res.entities if e.type == EntityType.IP][0]
    assert ip.attrs["gn_classification"] == "malicious"


def test_greynoise_benign_no_malware():
    res = GreyNoiseCommunity().parse({"noise": True, "riot": True, "classification": "benign"}, "8.8.8.8")
    assert not any(e.type == EntityType.MALWARE for e in res.entities)


def test_sans_isc_reports():
    res = SANSISC().parse({"count": 42, "asname": "EVIL"}, "6.6.6.6")
    ip = [e for e in res.entities if e.type == EntityType.IP][0]
    assert ip.attrs["isc_reports"] == 42
    assert any(e.type == EntityType.MALWARE for e in res.entities)


# ══════════ 레지스트리 배선(증분25) ══════════
def test_increment25_registered():
    names = {c.name for c in default_collectors(real=True)}
    expected = {"minecraft", "myanimelist", "anilist", "kitsu", "tetrio", "scratch",
                "discogs", "sourceforge", "hashnode", "packagist", "bitbucket", "telegram",
                "crossref", "semanticscholar", "openlibrary", "opensanctions",
                "kickbox-open", "disify", "ipwhois", "greynoise-community", "sans-isc"}
    assert expected <= names


def test_increment25_accepts():
    for C in (Minecraft, JikanMAL, AniList, Kitsu, TetrIO, Scratch, Discogs, SourceForge,
              Hashnode, Packagist, Bitbucket, Telegram):
        assert EntityType.USERNAME in C().accepts
    for C in (Crossref, SemanticScholar, OpenLibrary, OpenSanctions):
        assert EntityType.NAME in C().accepts
    for C in (KickboxOpen, Disify):
        assert EntityType.EMAIL in C().accepts
    for C in (IPWhois, GreyNoiseCommunity, SANSISC):
        assert EntityType.IP in C().accepts
