from artes.core.types import detect
from artes.core.model import EntityType as T


def test_detect():
    assert detect("hong@gmail.com") is T.EMAIL
    assert detect("+821012345678") is T.PHONE
    assert detect("010-1234-5678") is T.PHONE
    assert detect("192.168.0.1") is T.IP
    assert detect("999.1.1.1") is not T.IP          # 범위 초과
    assert detect("example.com") is T.DOMAIN
    assert detect("https://example.com/x") is T.URL
    assert detect("홍길동") is T.NAME
    assert detect("John Smith") is T.NAME
    assert detect("hong123") is T.USERNAME
    assert detect("") is T.UNKNOWN
