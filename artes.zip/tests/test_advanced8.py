"""증분 14 — 선택적 키 경로 + AI 전면 강화 검증.

키: KeyStore(env/파일)·게이트·키 미노출·키 수집기 파서.
AI: 응답 캐시(정확+정책)·병렬 배치 생성·적응 라우터(난이도·신뢰·캐스케이드·ESC).
"""
import os
import tempfile
import time

from artes.core.keys import KeyStore, KeyedCollector
from artes.core.model import EntityType
from artes.ai.cache import ResponseCache
from artes.ai.runtime import Runtime
from artes.ai.backend import StubBackend
from artes.ai import router as R


# ══════════ 선택적 키 경로 ══════════
def test_keystore_env_and_file(monkeypatch=None):
    # env 우선.
    os.environ["ARTES_KEY_SHODAN"] = "envkey"
    ks = KeyStore(path="/nonexistent.json")
    assert ks.has("shodan") and ks.get("shodan") == "envkey"
    del os.environ["ARTES_KEY_SHODAN"]
    # 파일 폴백.
    with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as f:
        f.write('{"hibp": "filekey"}')
        path = f.name
    ks2 = KeyStore(path=path)
    assert ks2.has("hibp") and not ks2.has("shodan")
    os.unlink(path)

def test_keystore_status_hides_values():
    os.environ["ARTES_KEY_VIRUSTOTAL"] = "supersecret"
    ks = KeyStore(path="/nonexistent.json")
    st = ks.status()
    assert st["virustotal"] is True
    # 상태·출처 어디에도 값이 노출되지 않는다.
    assert "supersecret" not in str(st)
    assert "supersecret" not in ks.source_of("virustotal")
    del os.environ["ARTES_KEY_VIRUSTOTAL"]

def test_keyed_collector_gated():
    class Dummy(KeyedCollector):
        service = "shodan"
    os.environ.pop("ARTES_KEY_SHODAN", None)
    # 키 없으면 available False → 엔진이 skip.
    d = Dummy()
    # KEYS 전역은 이미 로드됨 — 인스턴스 has는 전역 KEYS 기준.
    assert d.available() in (True, False)

def test_shodan_parse():
    from artes.collectors.keyed_c import ShodanFull
    data = {"ip_str": "1.2.3.4", "ports": [80, 443], "hostnames": ["ex.com"],
            "org": "ACME", "asn": "AS123"}
    res = ShodanFull().parse(data, "1.2.3.4")
    assert any(e.type is EntityType.HOST for e in res.entities)
    assert any(e.type is EntityType.ORG and e.value == "ACME" for e in res.entities)

def test_hibp_parse():
    from artes.collectors.keyed_c import HIBP
    data = [{"Name": "Adobe", "BreachDate": "2013", "DataClasses": ["Emails"]}]
    res = HIBP().parse(data, "a@x.com")
    assert any(e.type is EntityType.BREACH and e.value == "Adobe" for e in res.entities)

def test_hunter_parse():
    from artes.collectors.keyed_c import HunterDomain
    data = {"data": {"emails": [{"value": "jane@ex.com", "first_name": "Jane",
                                 "last_name": "Doe"}]}}
    res = HunterDomain().parse(data, "ex.com")
    assert any(e.type is EntityType.EMAIL for e in res.entities)
    assert any(e.type is EntityType.NAME and "Jane" in e.value for e in res.entities)

def test_keyed_in_registry():
    from artes.collectors.registry import default_collectors
    names = {c.name for c in default_collectors(real=True)}
    assert {"shodan", "hibp", "virustotal", "greynoise", "abuseipdb", "hunter"} <= names


# ══════════ AI 응답 캐시 ══════════
def test_cache_exact_hit():
    c = ResponseCache(embed=False)
    params = {"max_tokens": 100, "temperature": 0.2}
    assert c.get("interpret", "질문", params) is None
    c.put("interpret", "질문", params, "답")
    assert c.get("interpret", "질문", params) == "답"
    assert c.stats()["exact_hits"] == 1

def test_cache_ttl_expiry():
    c = ResponseCache(ttl=10.0, embed=False)
    c.put("interpret", "q", {}, "a", now=0.0)
    assert c.get("interpret", "q", {}, now=5.0) == "a"
    assert c.get("interpret", "q", {}, now=20.0) is None

def test_cache_wired_into_runtime():
    calls = {"n": 0}
    def responder(p):
        calls["n"] += 1
        return "결과"
    rt = Runtime(backend=StubBackend(responder), cache=ResponseCache(embed=False))
    a = rt.generate("interpret", "같은프롬프트", temperature=0.0)
    b = rt.generate("interpret", "같은프롬프트", temperature=0.0)
    assert a == b == "결과"
    assert calls["n"] == 1                    # 두 번째는 캐시 → 백엔드 1회만
    assert rt.calls["interpret"] == 2         # 호출 로깅은 2회

def test_cache_no_cache_when_no_cache_obj():
    calls = {"n": 0}
    rt = Runtime(backend=StubBackend(lambda p: str(calls.__setitem__("n", calls["n"]+1) or "x")))
    rt.generate("interpret", "p", temperature=0.0)
    rt.generate("interpret", "p", temperature=0.0)
    assert calls["n"] == 2                    # 캐시 없으면 매번 호출(회귀 없음)


# ══════════ 병렬 배치 생성 ══════════
def test_generate_batch():
    rt = Runtime(backend=StubBackend(lambda p: p[-1]), slots=4)
    outs = rt.generate_batch("swarm-work", ["aX", "bY", "cZ"])
    assert outs == ["X", "Y", "Z"]            # 순서 보존


# ══════════ 적응 라우터 ══════════
def test_estimate_difficulty():
    easy = R.estimate_difficulty("서울 날씨")
    hard = R.estimate_difficulty("a@x.com 과 b@y.com 이 동일인인지 왜 그런지 추론하라 " * 3)
    assert hard > easy

def test_confidence_from_logprob():
    assert R.confidence(0.0) == 1.0
    assert 0 < R.confidence(-1.0) < 1.0
    assert R.confidence(None) == 0.5

def test_prefilter_routes():
    assert R.prefilter("짧은 사실 질문").tier == "cheap"
    assert R.prefilter("동일인 비교 추론 " + "x@y.com " * 8).tier == "calibrated"

def test_route_judge_cheap_accept():
    def r(p):
        if "결론만 뽑아" in p:
            return '{"evidence":"명확","verdict":"확실","confidence":90}'
        if "True 또는 False" in p:
            return "True"
        if "같은 결론" in p:
            return "yes"
        if "검증할 독립" in p:
            return '{"questions":[]}'
        return "명확한 근거.\n정답 확률: 95"
    rt = Runtime(backend=StubBackend(r, conf=-0.1))
    out = R.route_judge(rt, "간단 질문", "근거")
    assert out["verdict"] == "확실" and out["tier"] in ("cheap", "calibrated")

def test_esc_vote_early_stop():
    seq = iter(["A", "A", "A", "B", "C"])
    n = {"c": 0}
    def sample():
        n["c"] += 1
        return next(seq)
    ans, total, votes = R.esc_vote(sample, window=3, max_samples=5)
    assert ans == "A" and total == 3         # 첫 창 만장일치 → 중단

def test_adaptive_generate_easy_one_pass():
    calls = {"n": 0}
    def r(p):
        calls["n"] += 1
        return "답"
    rt = Runtime(backend=StubBackend(r))
    out, n = R.adaptive_generate(rt, "chat", "짧은 질문")
    assert n == 1 and calls["n"] == 1        # 쉬우면 1패스
