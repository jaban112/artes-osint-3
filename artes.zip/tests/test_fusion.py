"""베이지안 신호 융합 — 약신호 여럿이 강신호가 되는지(§2)."""
from artes.core.fusion import fuse, graded_lr, DEFAULT_LR


def test_single_weak_signal_stays_low():
    r = fuse([("timezone", DEFAULT_LR["timezone"])])
    assert r["posterior"] < 0.1                       # 약신호 하나는 바닥


def test_weak_signals_accumulate():
    weak = [("name_sim", 4.0), ("timezone", 2.0), ("geo", 3.0), ("follower", 5.0)]
    r = fuse(weak)
    # 개별론 다 바닥이지만 결합하면 확신이 오른다
    single = fuse([("name_sim", 4.0)])["posterior"]
    assert r["posterior"] > single
    assert r["posterior"] > 0.5                        # 약신호 넷 → 과반 확신


def test_graded_lr_monotone():
    lo = graded_lr("name_sim", 0.3)
    mid = graded_lr("name_sim", 0.6)
    hi = graded_lr("name_sim", 0.95)
    assert lo <= mid <= hi
    assert graded_lr("name_sim", 0.0) == 1.0           # 무정보 → LR 1


def test_more_evidence_higher_posterior():
    p2 = fuse([("name_sim", 4.0), ("handle", 6.0)])["posterior"]
    p3 = fuse([("name_sim", 4.0), ("handle", 6.0), ("stylometry", 8.0)])["posterior"]
    assert p3 > p2
