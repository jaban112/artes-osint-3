"""증분 24 — 소스 대량 확장(SNS·유출·사람피벗) 파서 단위검증.

합성 응답으로 파서만 검증(네트워크 없이). 실제 페치는 사용자 환경.
검증 초점: 계정/실명/위치 추출, 교차연결, 유출 메타(평문 비번 미저장), 이름→신원 피벗.
"""
from artes.collectors.social4_c import (ArtStation, StackExchange, WikimediaGlobal,
                                        Steam, Mixcloud, CratesIo, Lemmy, Duolingo,
                                        Codewars, Roblox, SpeedrunCom, Launchpad)
from artes.collectors.breach2_c import LeakCheckPublic, HudsonRock, XposedAnalytics
from artes.collectors.enrich3_c import GravatarJSON, GitHubCommitEmail, ORCID, OpenAlex
from artes.core.model import EntityType, Certainty
from artes.collectors.registry import default_collectors


def _kinds(res):
    return {(e.type, e.value) for e in res.entities}


# ══════════ social4 ══════════
def test_artstation_name_geo_socials():
    d = {"id": 7, "username": "picasso", "full_name": "Pablo Ruiz", "city": "Málaga",
         "country": "Spain", "headline": "artist", "permalink": "https://artstation.com/picasso",
         "social_profiles": [{"url": "https://twitter.com/picasso"}]}
    res = ArtStation().parse(d, "picasso")
    k = _kinds(res)
    assert (EntityType.ACCOUNT, "artstation/picasso") in k
    assert (EntityType.NAME, "Pablo Ruiz") in k
    assert any(t == EntityType.GEO for t, _ in k)
    assert (EntityType.URL, "https://twitter.com/picasso") in k


def test_stackexchange_name_location():
    u = {"display_name": "Jon Skeet", "location": "Reading, UK", "reputation": 1400000,
         "link": "https://stackoverflow.com/users/22656", "website_url": "https://csharpindepth.com"}
    res = StackExchange().parse(u, "jon")
    k = _kinds(res)
    assert (EntityType.ACCOUNT, "stackoverflow/jon") in k
    assert (EntityType.NAME, "Jon Skeet") in k
    assert (EntityType.URL, "https://csharpindepth.com") in k


def test_wikimedia_global_merged():
    gu = {"name": "Alice", "home": "enwiki", "editcount": 5000,
          "merged": [{"wiki": "enwiki"}, {"wiki": "commonswiki"}, {"wiki": "dewiki"}]}
    res = WikimediaGlobal().parse(gu, "Alice")
    acc = [e for e in res.entities if e.type == EntityType.ACCOUNT][0]
    assert acc.value == "wikimedia/Alice"
    assert acc.attrs["edits"] == 5000
    assert "commonswiki" in acc.attrs["wikis"]


def test_steam_xml_realname():
    body = ("<profile><steamID64>7656119</steamID64><steamID>Gaben</steamID>"
            "<realname>Gabe N</realname><location>WA, USA</location>"
            "<memberSince>2003</memberSince></profile>")
    res = Steam().parse(body, "gaben")
    k = _kinds(res)
    assert (EntityType.ACCOUNT, "steam/Gaben") in k
    assert (EntityType.NAME, "Gabe N") in k
    acc = [e for e in res.entities if e.type == EntityType.ACCOUNT][0]
    assert acc.attrs["steamid64"] == "7656119"


def test_cratesio_github_xlink():
    u = {"login": "dtolnay", "name": "David Tolnay", "url": "https://github.com/dtolnay"}
    res = CratesIo().parse(u, "dtolnay")
    k = _kinds(res)
    assert (EntityType.ACCOUNT, "crates.io/dtolnay") in k
    assert (EntityType.NAME, "David Tolnay") in k
    # github 교차연결 = 확실
    gh = [e for e in res.entities if e.type == EntityType.USERNAME and e.value == "dtolnay"]
    assert gh and gh[0].certainty is Certainty.CONFIRMED


def test_lemmy_matrix_xlink():
    p = {"name": "carol", "display_name": "Carol", "actor_id": "https://lemmy.ml/u/carol",
         "bio": "see https://carol.dev", "matrix_user_id": "@carol:matrix.org"}
    res = Lemmy().parse(p, "carol")
    k = _kinds(res)
    assert (EntityType.ACCOUNT, "lemmy/carol") in k
    assert (EntityType.ACCOUNT, "matrix/@carol:matrix.org") in k
    assert (EntityType.URL, "https://carol.dev") in k


def test_roblox_display():
    d = {"id": 261, "name": "builderman", "displayName": "builderman",
         "created": "2006-02-27", "description": "founder"}
    res = Roblox().parse(d, "builderman")
    acc = [e for e in res.entities if e.type == EntityType.ACCOUNT][0]
    assert acc.value == "roblox/builderman"
    assert acc.attrs["created"] == "2006-02-27"


def test_duolingo_courses():
    u = {"username": "amy", "name": "Amy P", "streak": 200,
         "courses": [{"title": "Spanish"}, {"title": "French"}]}
    res = Duolingo().parse(u, "amy")
    k = _kinds(res)
    assert (EntityType.NAME, "Amy P") in k
    acc = [e for e in res.entities if e.type == EntityType.ACCOUNT][0]
    assert "Spanish" in acc.attrs["courses"]


def test_minimal_no_crash():
    # 빈/최소 응답에서도 계정만 나오고 실명은 안 나옴(안전)
    for C, d, v in [
        (Mixcloud, {"username": "x", "url": "u"}, "x"),
        (Codewars, {"username": "x"}, "x"),
        (Launchpad, {"name": "x"}, "x"),
    ]:
        res = C().parse(d, v)
        assert any(e.type == EntityType.ACCOUNT for e in res.entities)
        assert not any(e.type == EntityType.NAME for e in res.entities)


# ══════════ breach2 (평문 비번 절대 미저장) ══════════
def test_leakcheck_sources_only():
    d = {"success": True, "found": 2, "fields": ["email", "password", "username"],
         "sources": [{"name": "Collection1", "date": "2019-01"}, {"name": "LinkedIn", "date": "2012"}]}
    res = LeakCheckPublic().parse(d, "a@b.com", EntityType.EMAIL)
    breaches = [e for e in res.entities if e.type == EntityType.BREACH]
    assert len(breaches) == 2
    assert any("Collection1" in e.value for e in breaches)
    # 노출된 '필드 유형'은 메타로 저장되나 평문 값은 없음
    txt = str([e.attrs for e in res.entities])
    assert "password" in txt          # 필드 '유형' 이름은 허용
    # 실제 비밀번호 값이 저장되지 않음(합성엔 값 자체가 없음) — 구조상 sources/fields만 읽음


def test_hudsonrock_infostealer():
    d = {"stealers": [{"stealer_family": "RedLine", "date_compromised": "2023-05"}]}
    res = HudsonRock().parse(d, "a@b.com", EntityType.EMAIL)
    breaches = [e for e in res.entities if e.type == EntityType.BREACH]
    assert breaches and "RedLine" in breaches[0].value


def test_hudsonrock_clean_empty():
    res = HudsonRock().parse({"message": "not found", "stealers": []}, "a@b.com", EntityType.EMAIL)
    assert not any(e.type == EntityType.BREACH for e in res.entities)


def test_xposed_analytics_categories():
    d = {"BreachMetrics": {"risk": [{"risk_label": "High"}]},
         "ExposedBreaches": {"breaches_details": [
             {"breach": "Adobe", "xposed_data": "Email;Password"}]}}
    res = XposedAnalytics().parse(d, "a@b.com")
    breaches = [e for e in res.entities if e.type == EntityType.BREACH]
    assert breaches and breaches[0].value == "Adobe"


# ══════════ enrich3 (사람 피벗) ══════════
def test_gravatar_json_pivot():
    e = {"displayName": "Bob Kim", "preferredUsername": "bobk",
         "profileUrl": "https://gravatar.com/bobk",
         "accounts": [{"url": "https://github.com/bobk", "shortname": "github", "verified": True}],
         "urls": [{"value": "https://bob.dev"}]}
    res = GravatarJSON().parse(e, "bob@x.com")
    k = _kinds(res)
    assert (EntityType.NAME, "Bob Kim") in k
    assert (EntityType.USERNAME, "bobk") in k
    # 검증된 연결계정 = 확실
    gh = [x for x in res.entities if x.type == EntityType.URL and "github.com/bobk" in x.value]
    assert gh and gh[0].certainty is Certainty.CONFIRMED
    assert (EntityType.URL, "https://bob.dev") in k


def test_github_commit_email():
    items = [{"commit": {"author": {"name": "Jane Doe"}},
              "author": {"login": "janedoe"}}]
    res = GitHubCommitEmail().parse(items, "jane@x.com")
    k = _kinds(res)
    assert (EntityType.NAME, "Jane Doe") in k
    gh = [e for e in res.entities if e.type == EntityType.USERNAME and e.value == "janedoe"]
    assert gh and gh[0].certainty is Certainty.CONFIRMED


def test_orcid_researcher():
    results = [{"orcid-id": "0000-0002-1825-0097", "institution-name": ["MIT"]}]
    res = ORCID().parse(results, "josiah carberry")
    acc = [e for e in res.entities if e.type == EntityType.ACCOUNT][0]
    assert "orcid/" in acc.value
    assert acc.attrs["institution"] == "MIT"
    assert acc.certainty is Certainty.UNCONFIRMED   # 이름 피벗은 불확실


def test_openalex_author():
    results = [{"id": "https://openalex.org/A123", "works_count": 42,
                "last_known_institution": {"display_name": "Stanford"},
                "orcid": "https://orcid.org/0000-0001"}]
    res = OpenAlex().parse(results, "jane smith")
    acc = [e for e in res.entities if e.type == EntityType.ACCOUNT][0]
    assert acc.value == "openalex/A123"
    assert acc.attrs["institution"] == "Stanford"


# ══════════ 레지스트리 배선(증분24) ══════════
def test_new_sources_registered():
    names = {c.name for c in default_collectors(real=True)}
    expected = {"artstation", "stackexchange", "wikimedia-global", "steam", "mixcloud",
                "launchpad", "cratesio", "speedruncom", "lemmy", "duolingo", "codewars",
                "roblox", "gravatar-json", "github-commit-email", "orcid", "openalex",
                "leakcheck", "hudsonrock", "xposed-analytics"}
    assert expected <= names


def test_accept_types():
    for C in (ArtStation, StackExchange, WikimediaGlobal, Steam, Mixcloud, CratesIo,
              Lemmy, Duolingo, Codewars, Roblox, SpeedrunCom, Launchpad):
        assert EntityType.USERNAME in C().accepts
    assert EntityType.EMAIL in LeakCheckPublic().accepts
    assert EntityType.USERNAME in HudsonRock().accepts
    assert EntityType.EMAIL in GravatarJSON().accepts
    assert EntityType.NAME in ORCID().accepts
