"""증분 30 — 검색엔진 풀(100+ 커버) · 200라운드 벤치마크 · 병렬 인스턴스 팬아웃."""
import asyncio
import json

from artes.core import searchpool as sp


def test_instance_pool_size():
    # SearXNG 인스턴스 다수(각 인스턴스=수십 upstream 엔진 → 실질 100+ 엔진 커버)
    assert len(set(sp.SEARX_INSTANCES)) >= 30

def test_benchmark_ranks_by_score(monkeypatch):
    async def fake_probe(inst, queries, timeout):
        n = abs(hash(inst)) % 12
        ok = n > 2
        return {"source": inst, "reachable": ok, "unique": n if ok else 0,
                "leak_hits": (n // 3) if ok else 0, "latency": 0.1,
                "score": (n + (n // 3) * 3) if ok else 0}
    monkeypatch.setattr(sp, "_probe", fake_probe)
    r = asyncio.run(sp.benchmark(max_rounds=200))
    assert r and all(r[i]["score"] >= r[i + 1]["score"] for i in range(len(r) - 1))

def test_benchmark_round_budget(monkeypatch):
    # 인스턴스 수가 많으면 쿼리 수를 줄여 max_rounds를 넘지 않음
    seen = {}
    async def fake_probe(inst, queries, timeout):
        seen["nq"] = len(queries)
        return {"source": inst, "reachable": False, "unique": 0, "leak_hits": 0,
                "latency": 0.0, "score": 0}
    monkeypatch.setattr(sp, "_probe", fake_probe)
    asyncio.run(sp.benchmark(max_rounds=40))            # 39 인스턴스 → 쿼리 1개로 제한
    assert seen["nq"] == 1

def test_save_and_load_ranked(monkeypatch, tmp_path):
    f = tmp_path / "se.json"
    monkeypatch.setattr(sp, "_RANK_FILE", f)
    ranked = [{"source": "https://a.searx", "reachable": True, "score": 50},
              {"source": "https://b.searx", "reachable": True, "score": 10},
              {"source": "https://dead.searx", "reachable": False, "score": 0}]
    sp.save_ranked(ranked, top_k=12)
    loaded = sp.load_ranked()
    assert loaded == ["https://a.searx", "https://b.searx"]   # 살아있고 점수>0만, 순위대로
    assert "dead.searx" not in loaded

def test_load_ranked_default_when_absent(monkeypatch, tmp_path):
    monkeypatch.setattr(sp, "_RANK_FILE", tmp_path / "missing.json")
    got = sp.load_ranked(default_k=8)
    assert len(got) == 8 and all(u.startswith("http") for u in got)

def test_searx_engine_fans_out_parallel(monkeypatch):
    # _engine_searx는 랭킹된 여러 인스턴스를 동시에 조회해 합집합(중복제거)
    import artes.collectors.websearch_c as ws
    monkeypatch.setattr("artes.core.searchpool.load_ranked",
                        lambda default_k=10: ["https://i1", "https://i2", "https://i3"])
    async def fake_one(inst, q, t, l):
        return [{"url": f"{inst}/dup", "title": "d", "snippet": ""},
                {"url": f"{inst}/x", "title": "x", "snippet": ""}]
    monkeypatch.setattr(ws, "_one_searx", fake_one)
    out = asyncio.run(ws._engine_searx("q", 5, 12))
    urls = {o["url"] for o in out}
    assert len(urls) == 6                     # 3 인스턴스 × 2 고유 URL
    assert "https://i2/x" in urls

def test_probe_scoring_leak_weight():
    # 유출 힌트가 스니펫/URL에 있으면 leak_hits 가중(×3)
    import re
    assert sp._LEAK_HINT.search("this is a pastebin dump")
    assert sp._LEAK_HINT.search("데이터 유출 combolist")
    assert not sp._LEAK_HINT.search("normal profile page")
