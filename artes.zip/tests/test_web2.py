"""security.txt·robots.txt 파서."""
from artes.core.model import EntityType
from artes.collectors.web2_c import SiteFiles, CollectorResult


def test_security_txt_parse():
    sf = SiteFiles()
    res = CollectorResult(source="sitefiles")
    sf.parse_security(res, "example.com",
                      "Contact: mailto:security@example.com\nContact: https://x/report\n"
                      "Contact: abuse@example.com")
    emails = {e.value for e in res.entities if e.type is EntityType.EMAIL}
    assert "security@example.com" in emails and "abuse@example.com" in emails


def test_robots_parse():
    sf = SiteFiles()
    res = CollectorResult(source="sitefiles")
    sf.parse_robots(res, "example.com",
                    "User-agent: *\nDisallow: /admin\nDisallow: /secret\nAllow: /\n")
    urls = {e.value for e in res.entities}
    assert "https://example.com/admin" in urls and "https://example.com/secret" in urls
    assert "https://example.com/" not in urls              # 루트는 제외
