"""증분 15 — 역할별 다중 AI(판정·코더·대화) + 6권 서빙 정책 검증."""
from artes.ai import models as M
from artes.ai.serving import ModelManager, ROLE_PORTS, model_path, draft_path


# ══════════ 역할 모델 레지스트리 ══════════
def test_roles_present():
    assert set(M.ROLE_MODELS) == {"judge", "coder", "chat"}
    for role, spec in M.ROLE_MODELS.items():
        assert spec["default"] in spec["tiers"]

def test_recommend_by_ram():
    # RAM 적으면 작은 모델, 크면 초거대.
    small = M.recommend("chat", ram_gb=12)
    big = M.recommend("chat", ram_gb=130)
    assert M.ROLE_MODELS["chat"]["tiers"][small]["approx_gb"] < \
           M.ROLE_MODELS["chat"]["tiers"][big]["approx_gb"]
    # 130GB면 235B(최대 지식)까지.
    assert M.ROLE_MODELS["chat"]["tiers"][big]["approx_gb"] >= 80

def test_recommend_tiny_ram_fallback():
    # 2GB면 가장 작은 것이라도 반환(빈 문자열 아님).
    r = M.recommend("coder", ram_gb=2)
    assert r in M.ROLE_MODELS["coder"]["tiers"]

def test_model_spec_lookup():
    s = M.model_spec("coder", "qwen2.5-coder-7b")
    assert s and s["role"] == "coder" and s["fim"] is True
    assert M.model_spec("chat")["role"] == "chat"     # default
    assert M.model_spec("nope") is None

def test_uncensored_tiers_exist():
    # 무검열(abliterated/Dolphin) 티어가 코더·대화에 있어야 한다.
    coder = M.ROLE_MODELS["coder"]["tiers"]
    chat = M.ROLE_MODELS["chat"]["tiers"]
    assert any("uncensored" in k or "abliterated" in str(v.get("repo","")).lower()
               for k, v in coder.items())
    assert any("abliterated" in str(v.get("repo","")).lower() or "dolphin" in k
               for k, v in chat.items())


# ══════════ 6권 서빙 정책 ══════════
def test_server_flags_speculative_and_flashattn():
    spec = M.model_spec("judge", "dolphin3-qwen2.5-3b")
    flags = M.server_flags("judge", "/m/model.gguf", spec,
                           draft_path="/m/draft.gguf", threads=4)
    assert "-md" in flags and "/m/draft.gguf" in flags       # 투기 디코딩(무손실)
    assert "--flash-attn" in flags

def test_server_flags_kv_policy():
    # 대화(casual)만 KV 양자화(손실), 판정/코더는 f16 페이징(무손실).
    chat = M.server_flags("chat", "/m/big.gguf", M.model_spec("chat"), threads=4)
    judge = M.server_flags("judge", "/m/j.gguf", M.model_spec("judge"), threads=4)
    assert "--cache-type-k" in chat                          # chat=q8_0 허용
    assert "--cache-type-k" not in judge                     # judge=무손실 페이징

def test_server_flags_moe_offload():
    spec = M.model_spec("chat", "qwen3-235b-uncensored")
    flags = M.server_flags("chat", "/m/moe.gguf", spec, threads=8)
    assert "--n-cpu-moe" in flags                            # MoE 전문가 CPU 오프로드
    non_moe = M.server_flags("judge", "/m/j.gguf",
                             M.model_spec("judge"), threads=8)
    assert "--n-cpu-moe" not in non_moe

def test_detect_ram_positive():
    assert M.detect_ram_gb() > 0


# ══════════ 다중 서버 매니저 ══════════
def test_manager_plan():
    mgr = ModelManager(ram_gb=64)
    p = mgr.plan("chat")
    assert p and p["role"] == "chat" and "path" in p
    assert p["port"] == ROLE_PORTS["chat"]
    assert p["present"] in (True, False)                     # 여기선 대개 False

def test_manager_fallback_no_model():
    # 모델·바이너리 없으면 start_role False, runtime_for는 공유 폴백.
    mgr = ModelManager(ram_gb=8)
    assert mgr.start_role("coder") is False                  # 컨테이너에 모델 없음
    rt = mgr.runtime_for("coder")
    assert rt is not None                                     # 폴백 Runtime(Stub)
    # 같은 역할 재요청은 캐시된 폴백.
    assert mgr.runtime_for("coder") is rt

def test_ports_distinct():
    assert len(set(ROLE_PORTS.values())) == 3                # 역할별 포트 충돌 없음
