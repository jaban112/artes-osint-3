"""능동 확장·이미지해시·유사도 CI 단위검증."""
from artes.core.enrich import (username_variants, email_candidates,
                               infer_name_from_email, gravatar_url, gravatar_hash)
from artes.core.imagehash import hamming_hex
from artes.core.similarity import MinHash, jaccard_ci, char_ngrams


def test_username_variants():
    v = username_variants("jiwan123")
    assert "jiwan123" in v
    assert "jiwan" in v                        # 끝숫자 제거
    assert len(v) <= 20 and all(2 <= len(x) <= 30 for x in v)


def test_email_candidates():
    c = email_candidates("김지완 Kim", "gmail.com")   # 한글은 토큰화 약함 → 라틴 위주
    c2 = email_candidates("Jiwan Kim", "corp.com")
    assert "jiwan.kim@corp.com" in c2 or "jiwankim@corp.com" in c2
    assert all("@corp.com" in x for x in c2)


def test_infer_name_from_email():
    assert infer_name_from_email("j.kim") == "J Kim"
    assert infer_name_from_email("jiwan_kim99") == "Jiwan Kim"
    assert infer_name_from_email("x") is None


def test_gravatar():
    assert gravatar_hash("Test@Example.com ") == gravatar_hash("test@example.com")
    assert "gravatar.com/avatar/" in gravatar_url("a@b.com")


def test_hamming_hex():
    assert hamming_hex("ffff", "ffff") == 0
    assert hamming_hex("ffff", "fffe") == 1
    assert hamming_hex("00", "ff") == 8
    assert hamming_hex("zz", "00") == 999      # 잘못된 hex는 큰 거리


def test_jaccard_ci_bounds_similarity():
    mh = MinHash(num_perm=128)
    a = mh.sign_tokens(char_ngrams("the quick brown fox jumps", 3))
    b = mh.sign_tokens(char_ngrams("the quick brown fox jumps", 3))
    ci = jaccard_ci(a, b)
    assert ci["point"] == 1.0 and ci["lower"] > 0.9      # 동일 → 하한 높음
    c = mh.sign_tokens(char_ngrams("완전히 다른 한국어 문장입니다", 3))
    ci2 = jaccard_ci(a, c)
    assert ci2["upper"] < 0.4                            # 다름 → 상한 낮음
