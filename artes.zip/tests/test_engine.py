import asyncio
import tempfile

from artes.core.engine import Engine
from artes.core.cache import Cache
from artes.core.model import EntityType
from artes.collectors import mock


def _run(inputs, **kw):
    async def go():
        cache = Cache(root=tempfile.mkdtemp())
        eng = Engine(mock.DEFAULTS, cache=cache, depth=1, **kw)
        events = [ev async for ev in eng.run(inputs)]
        return eng, events
    return asyncio.run(go())


def test_engine_expands_email_to_accounts():
    eng, events = _run(["hong@gmail.com"])
    types = {e.type for e in eng.graph.entities}
    # 이메일 → (추정)아이디 → 계정 으로 확장됐는지.
    assert EntityType.EMAIL in types
    assert EntityType.USERNAME in types
    assert EntityType.ACCOUNT in types
    # 확장 이벤트와 완료 이벤트가 있다.
    assert any(ev["type"] == "expand" for ev in events)
    done = [ev for ev in events if ev["type"] == "done"][-1]
    assert done["stats"]["ai_calls"] == 0            # 수집 단계 AI 0회


def test_ai_calls_zero_and_edges_have_evidence():
    eng, _ = _run(["hong123"])
    assert eng.stats.ai_calls == 0
    assert eng.graph.edges                            # 간선이 생겼고
    assert all(e.evidence for e in eng.graph.edges)   # 전부 근거를 가진다


def test_cache_second_run_is_free():
    # 네트워크 수집기만 캐시된다 — 그걸 흉내내는 카운팅 수집기로 검증.
    from artes.collectors.base import Collector, CollectorResult
    from artes.core.model import Entity, Certainty, Evidence

    class Counting(Collector):
        name = "counting"
        accepts = {EntityType.USERNAME}
        needs_network = True
        calls = 0

        async def collect(self, value, entity_type, ctx):
            Counting.calls += 1
            return CollectorResult(source=self.name, entities=[
                Entity(EntityType.ACCOUNT, f"x/{value}", Certainty.CONFIRMED,
                       evidence=[Evidence(self.name, "hit")])])

    async def go():
        cache = Cache(root=tempfile.mkdtemp())
        col = Counting()
        e1 = Engine([col], cache=cache, depth=0)
        [x async for x in e1.run(["hong123"])]
        after_first = Counting.calls
        e2 = Engine([Counting()], cache=cache, depth=0)
        [x async for x in e2.run(["hong123"])]
        return after_first, Counting.calls, cache.hits

    after_first, after_second, hits = asyncio.run(go())
    assert after_first == 1
    assert after_second == 1          # 두 번째 실행은 수집기를 다시 안 부른다
    assert hits > 0
