"""증분 12 — AI 대화·코딩·병렬 심화 검증.

코딩: 안전실행·정적검사·수복루프·best-of-N·테스트생성.
병렬: DAG 웨이브·슬롯 세마포어·재시도·적응 조기종료·트리 리듀스·RRF.
대화: 요약버퍼·토큰예산·엔티티·ReAct 도구사용·대화상태.
"""
import time

from artes.ai import coder as CO
from artes.ai import orchestrator as OR
from artes.ai.orchestrator import Node, SlotSemaphore
from artes.ai.chat import Chat, ConversationMemory, DialogueState
from artes.ai.swarm import run_swarm, saturation_workers
from artes.ai.runtime import Runtime
from artes.ai.backend import StubBackend


# ══════════ 코딩 에이전트 ══════════
def test_extract_code_fence():
    assert CO.extract_code("설명\n```python\nx=1\n```\n끝") == "x=1"
    assert CO.extract_code("x=2") == "x=2"

def test_static_check_catches_syntax():
    assert CO.static_check("def f(:\n  pass")           # 문법 오류 잡음
    assert CO.static_check("x = 1\n") == []              # 정상은 빈 리스트

def test_safe_exec_runs_and_times_out():
    ok = CO.safe_exec("print(2+2)")
    assert ok.ok and "4" in ok.stdout
    bad = CO.safe_exec("raise ValueError('boom')")
    assert not bad.ok and "ValueError" in bad.stderr
    to = CO.safe_exec("while True: pass", timeout=1.0)
    assert to.timed_out and not to.ok

def test_run_tests_pass_fail():
    good = CO.run_tests("def add(a,b): return a+b", "assert add(2,3)==5")
    assert good.ok
    bad = CO.run_tests("def add(a,b): return a-b", "assert add(2,3)==5")
    assert not bad.ok

def test_repair_loop_fixes_from_error():
    # 첫 생성은 버그(빼기), 수복 요청엔 올바른 코드.
    def responder(p):
        if "수정된 코드" in p:
            return "```python\ndef add(a,b):\n    return a+b\n```"
        if "[코드]" in p and "구현" in p:
            return "```python\ndef add(a,b):\n    return a-b\n```"
        return "x=1"
    rt = Runtime(backend=StubBackend(responder))
    cr = CO.repair_loop(rt, "add(a,b) 구현", tests="assert add(2,3)==5", max_attempts=3)
    assert cr.passed and cr.attempts >= 1
    assert any(s["stage"] == "test" and s["ok"] for s in cr.log)

def test_best_of_n_selects_passing():
    calls = {"n": 0}
    def responder(p):
        calls["n"] += 1
        if "수정된 코드" in p:
            return "```python\ndef f():\n    return 42\n```"
        # 홀수 호출은 통과, 짝수는 실패 코드(다양성 시뮬).
        if "[코드]" in p:
            return "```python\ndef f():\n    return 42\n```"
        return "x=1"
    rt = Runtime(backend=StubBackend(responder))
    cr = CO.best_of_n(rt, "f() 구현", tests="assert f()==42", n=3, max_attempts=1)
    assert cr.passed


# ══════════ 병렬 오케스트레이션 ══════════
def test_topological_waves_order():
    nodes = [Node("a", None), Node("b", None, ["a"]), Node("c", None, ["a"]),
             Node("d", None, ["b", "c"])]
    waves = OR.topological_waves(nodes, {n.id: n.depends_on for n in nodes})
    assert waves[0] == ["a"]
    assert set(waves[1]) == {"b", "c"}
    assert waves[2] == ["d"]

def test_topological_cycle_detected():
    nodes = [Node("a", None, ["b"]), Node("b", None, ["a"])]
    try:
        OR.topological_waves(nodes, {n.id: n.depends_on for n in nodes})
        assert False
    except ValueError:
        pass

def test_run_dag_passes_dependencies():
    nodes = [Node("a", 1), Node("b", 2, ["a"])]
    def worker(node, results):
        if node.id == "b":
            return results["a"]["result"] + node.payload   # a결과(1)+2
        return node.payload
    res = OR.run_dag(nodes, worker)
    assert res["a"]["result"] == 1 and res["b"]["result"] == 3

def test_slot_semaphore_caps_concurrency():
    import threading
    slots = SlotSemaphore(2)
    seen_peak = {"v": 0}
    def task():
        with slots:
            time.sleep(0.02)
    threads = [threading.Thread(target=task) for _ in range(6)]
    for t in threads: t.start()
    for t in threads: t.join()
    assert slots.peak <= 2                               # 동시 2 초과 없음

def test_with_retry_recovers():
    state = {"n": 0}
    def flaky():
        state["n"] += 1
        if state["n"] < 3:
            raise RuntimeError("transient")
        return "ok"
    assert OR.with_retry(flaky, retries=3) == "ok"

def test_adaptive_stop_confident():
    assert OR.adaptive_stop([8, 1]) is True              # 8:1 확정
    assert OR.adaptive_stop([2, 2]) is False             # 동률 미확정

def test_best_of_n_vote_early_stop():
    seq = iter(["A", "A", "A", "A", "A"])
    n = {"c": 0}
    def sample():
        n["c"] += 1
        return next(seq)
    ans, samples, votes = OR.best_of_n_vote(sample, n_max=5, n_min=2)
    assert ans == "A" and len(samples) < 5                # 조기 종료

def test_reduce_tree():
    merged = OR.reduce_tree([1, 2, 3, 4, 5], lambda g: sum(g), fanin=2)
    assert merged == 15

def test_rrf_fusion():
    fused = OR.rrf([["x", "y", "z"], ["y", "x"]])
    assert fused[0] in ("x", "y")                        # 두 목록 상위가 앞


# ══════════ 대화 AI ══════════
def test_chat_memory_fold():
    rt = Runtime(backend=StubBackend(lambda p: "요약됨" if "갱신 요약" in p else "답"))
    c = Chat(rt)
    c.memory.keep_recent = 2
    for i in range(8):
        c.say(f"메시지{i}")
    assert c.memory.summary == "요약됨"                  # 오래된 턴이 요약으로 접힘
    assert len(c.memory.recent) <= 4

def test_chat_token_budget_assembly():
    rt = Runtime(backend=StubBackend(lambda p: "답"))
    c = Chat(rt, n_ctx=500, max_tokens=100)
    c.memory.entities = {"이름": "지완"}
    c.memory.recent = [("user", "x" * 3000)]             # 예산 초과 큰 턴
    prompt = c._assemble("질문")
    assert "이름=지완" in prompt and "질문" in prompt     # 사실·현재질문은 항상 포함

def test_chat_react_tool_use():
    def responder(p):
        if "[관측" in p:                                  # 관측 후 → 답
            return '{"action":"answer","answer":"결과는 4"}'
        if "action='tool'" in p or "사용 가능한 도구" in p:
            return '{"action":"tool","tool":"calc","args":{"expr":"2+2"}}'
        return "일반답"
    rt = Runtime(backend=StubBackend(responder))
    c = Chat(rt, tools={"calc": lambda a: str(eval(a["expr"]))})
    out = c.say_agentic("2+2 계산해줘")
    assert "4" in out

def test_dialogue_state_render():
    st = DialogueState(goal="CSV 파서", open_threads=["에러 처리"])
    r = st.render()
    assert "CSV 파서" in r and "에러 처리" in r


# ══════════ 스웜 하위호환 ══════════
def test_swarm_backward_compatible():
    def responder(p):
        if "하위작업" in p or "JSON" in p and "작업]" in p:
            return "1. 파서 작성\n2. 테스트 작성\n3. 문서화"
        return "print('ok')"
    rt = Runtime(backend=StubBackend(responder))
    res = run_swarm(rt, "CSV 파서 만들기", max_subtasks=3, requested_workers=8,
                    server_parallel=2, verify=False)
    assert len(res.plan) == 3 and len(res.pieces) == 3
    assert res.workers_used <= 2
