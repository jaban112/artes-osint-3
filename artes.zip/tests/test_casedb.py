"""지속 케이스 저장소(SQLite)."""
import tempfile, os

from artes.core.casedb import CaseDB
from artes.core.model import Graph, Entity, Edge, EntityType, Certainty, Evidence


def _g(extra=None):
    g = Graph()
    g.add(Entity(EntityType.EMAIL, "a@b.com", Certainty.CONFIRMED, evidence=[Evidence("t", "")]))
    if extra:
        g.add(Entity(EntityType.ACCOUNT, extra, Certainty.CONFIRMED, evidence=[Evidence("t", "")]))
    return g


def test_save_load_merge():
    with tempfile.TemporaryDirectory() as td:
        db = CaseDB(os.path.join(td, "c.db"))
        db.save("case1", _g())
        loaded = db.load("case1")
        assert loaded and any(e.value == "a@b.com" for e in loaded.entities)
        db.merge("case1", _g("gh/x"))
        assert any(e.value == "gh/x" for e in db.load("case1").entities)
        assert db.load("missing") is None


def test_list_and_search():
    with tempfile.TemporaryDirectory() as td:
        db = CaseDB(os.path.join(td, "c.db"))
        db.save("c1", _g("insta/hong"))
        db.save("c2", _g())
        names = {c["name"] for c in db.list_cases()}
        assert names == {"c1", "c2"}
        hits = db.search("insta")
        assert any(h["value"] == "insta/hong" for h in hits)


def test_history_and_diff():
    with tempfile.TemporaryDirectory() as td:
        db = CaseDB(os.path.join(td, "c.db"))
        db.save("c", _g())
        db.save("c", _g("gh/new"))          # 두 번째 스냅샷
        assert len(db.history("c")) == 2
        d = db.diff_latest("c")
        assert d and any(e["value"] == "gh/new" for e in d["added_entities"])
