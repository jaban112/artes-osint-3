"""증분 35 — 쿠키 심층 수집기(본인 인증계정) 파서·게이팅 단위검증."""
from artes.collectors.deepsocial_c import (TikTokAuth, TwitterAuth, FacebookAuth,
                                           LinkedInAuth, NaverAuth, RedditAuth, _cookie_val)
from artes.core.model import EntityType
from artes.collectors.registry import default_collectors


def _k(res):
    return {(e.type, e.value) for e in res.entities}


def test_cookie_val_parse():
    assert _cookie_val("auth_token=abc; ct0=xyz123", "ct0") == "xyz123"
    assert _cookie_val("a=1; b=2", "missing") == ""


def test_tiktok_auth_parse():
    info = {"user": {"uniqueId": "jiwan", "nickname": "지완", "signature": "dev https://ji.dev",
                     "verified": True, "region": "KR", "id": "999", "bioLink": {"link": "https://ji.link"}},
            "stats": {"followerCount": 1000, "followingCount": 50, "heartCount": 5000, "videoCount": 12}}
    res = TikTokAuth().parse(info, "jiwan")
    acc = [e for e in res.entities if e.type == EntityType.ACCOUNT][0]
    assert acc.value == "tiktok/jiwan"
    assert acc.attrs["followers"] == 1000 and acc.attrs["verified"] is True
    k = _k(res)
    assert (EntityType.NAME, "지완") in k
    assert (EntityType.GEO, "KR") in k
    assert (EntityType.URL, "https://ji.link") in k


def test_twitter_auth_parse():
    user = {"rest_id": "123", "is_blue_verified": True,
            "legacy": {"screen_name": "jiwan", "name": "Jiwan Kim", "description": "hi https://j.io",
                       "followers_count": 300, "friends_count": 100, "statuses_count": 999,
                       "location": "Seoul", "created_at": "2015",
                       "entities": {"url": {"urls": [{"expanded_url": "https://jiwan.dev"}]}}}}
    res = TwitterAuth().parse(user, "jiwan")
    acc = [e for e in res.entities if e.type == EntityType.ACCOUNT][0]
    assert acc.value == "twitter/jiwan"
    assert acc.attrs["followers"] == 300
    k = _k(res)
    assert (EntityType.NAME, "Jiwan Kim") in k
    assert (EntityType.GEO, "Seoul") in k
    assert (EntityType.URL, "https://jiwan.dev") in k       # entities.url 확장링크


def test_facebook_auth_parse():
    html = '<meta property="og:title" content="Hong Gildong | Facebook"><title>Hong Gildong</title>'
    res = FacebookAuth().parse(html, "hong")
    acc = [e for e in res.entities if e.type == EntityType.ACCOUNT][0]
    assert acc.value == "facebook/hong"
    assert acc.attrs["display"] == "Hong Gildong"


def test_linkedin_auth_parse():
    html = ('<meta property="og:title" content="Jiwan Kim - Security Engineer at ACME | LinkedIn">'
            '<meta property="og:description" content="Seoul · 500+ connections">')
    res = LinkedInAuth().parse(html, "jiwankim", "Jiwan Kim - Security Engineer at ACME | LinkedIn")
    acc = [e for e in res.entities if e.type == EntityType.ACCOUNT][0]
    assert acc.attrs["display"] == "Jiwan Kim"
    assert "Security Engineer" in acc.attrs["headline"]


def test_naver_auth_parse():
    html = '<meta property="og:title" content="지완의 블로그"><meta property="og:description" content="일상">'
    res = NaverAuth().parse(html, "jiwan", "지완의 블로그")
    acc = [e for e in res.entities if e.type == EntityType.ACCOUNT][0]
    assert acc.value == "naver/jiwan" and acc.attrs["blog"] == "지완의 블로그"


def test_reddit_auth_parse():
    data = {"name": "jiwan", "total_karma": 4200, "link_karma": 1000, "comment_karma": 3200,
            "created_utc": 1500000000, "verified": True,
            "subreddit": {"public_description": "dev, see https://ji.dev"}}
    res = RedditAuth().parse(data, "jiwan")
    acc = [e for e in res.entities if e.type == EntityType.ACCOUNT][0]
    assert acc.value == "reddit/jiwan"
    assert acc.attrs["total_karma"] == 4200
    assert any(e.type == EntityType.URL and "ji.dev" in e.value for e in res.entities)


def test_all_deep_registered_and_gated():
    from artes.core.cookies import CookieCollector
    cs = default_collectors(real=True)
    names = {c.name for c in cs}
    assert {"tiktok-auth", "twitter-auth", "facebook-auth", "linkedin-auth",
            "naver-auth", "reddit-auth"} <= names
    # 쿠키 없으면 전부 skip(available False) → 일반 스캔 영향 0
    for c in cs:
        if isinstance(c, CookieCollector):
            assert c.available() is False
