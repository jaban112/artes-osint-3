"""내보내기·모니터링 — GraphML/CSV/STIX, 그래프 diff."""
import json
import xml.etree.ElementTree as ET

from artes.core.model import Graph, Entity, Edge, EntityType, Certainty, Evidence
from artes.core import export, monitor


def _g():
    g = Graph()
    a = g.add(Entity(EntityType.EMAIL, "a@b.com", Certainty.CONFIRMED, evidence=[Evidence("t", "")]))
    u = g.add(Entity(EntityType.USERNAME, "a", Certainty.UNCONFIRMED, 0.6, evidence=[Evidence("t", "")]))
    g.link(Edge(a.key, u.key, "추정 아이디", Certainty.UNCONFIRMED, 0.6, evidence=[Evidence("t", "")]))
    return g


def test_graphml_valid_xml():
    xml = export.to_graphml(_g())
    root = ET.fromstring(xml)                      # 파싱되면 유효
    assert root.tag.endswith("graphml")
    assert xml.count("<node") == 2 and xml.count("<edge") == 1


def test_maltego_csv():
    csv_text = export.to_maltego_csv(_g())
    assert "a@b.com" in csv_text and "추정 아이디" in csv_text


def test_stix_bundle():
    bundle = json.loads(export.to_stix(_g()))
    assert bundle["type"] == "bundle"
    types = {o["type"] for o in bundle["objects"]}
    assert "email-addr" in types and "relationship" in types


def test_monitor_diff():
    old = _g()
    new = _g()
    new.add(Entity(EntityType.ACCOUNT, "gh/a", Certainty.CONFIRMED, evidence=[Evidence("t", "")]))
    # 확실성 변화
    u = [e for e in new.entities if e.type is EntityType.USERNAME][0]
    u.certainty = Certainty.CONFIRMED
    d = monitor.diff(old, new)
    assert d["changed"]
    assert any(e["value"] == "gh/a" for e in d["added_entities"])
    assert any(c["value"] == "a" for c in d["certainty_changes"])
    assert "새 엔티티" in monitor.render_diff(d)


def test_monitor_no_change():
    d = monitor.diff(_g(), _g())
    assert not d["changed"] and monitor.render_diff(d) == "변화 없음."
