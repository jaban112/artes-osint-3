"""증분 20 — SNS 확장(Bluesky·Mastodon·Chess.com) 파서 단위검증.

공개 API 응답을 합성해 파서만 검증(네트워크 없이). 실제 페치는 사용자 환경.
검증 초점: 계정 엔티티·교차연결 간선·실명/지역/링크 추출·확실성 등급.
"""
from artes.collectors.social3_c import Bluesky, Mastodon, ChessCom
from artes.core.model import EntityType, Certainty
from artes.collectors.registry import default_collectors


def _kinds(res):
    return [(e.type, e.value) for e in res.entities]


# ══════════ Bluesky ══════════
def test_bluesky_parse_rich():
    data = {"did": "did:plc:abc", "handle": "alice.bsky.social",
            "displayName": "Alice Kim", "description": "dev · https://alice.dev",
            "followersCount": 1200, "postsCount": 340}
    res = Bluesky().parse(data, "alice")
    kinds = _kinds(res)
    assert (EntityType.ACCOUNT, "bluesky/alice.bsky.social") in kinds
    assert (EntityType.NAME, "Alice Kim") in kinds          # 표시이름=실명 후보
    assert (EntityType.URL, "https://alice.dev") in kinds   # bio 링크 추출
    acc = [e for e in res.entities if e.type == EntityType.ACCOUNT][0]
    assert acc.certainty is Certainty.CONFIRMED
    assert acc.attrs["followers"] == 1200
    # username → account 간선
    assert any(e.dst == "account:bluesky/alice.bsky.social" or "bluesky" in e.dst
               for e in res.edges)

def test_bluesky_missing():
    res = Bluesky().parse({"did": "did:plc:x", "handle": "bob"}, "bob")
    # 계정은 있고, 표시이름/링크는 없음(안전)
    assert any(e.type == EntityType.ACCOUNT for e in res.entities)
    assert not any(e.type == EntityType.NAME for e in res.entities)


# ══════════ Mastodon ══════════
def test_mastodon_verified_links_confirmed():
    data = {"id": "1", "username": "carol", "display_name": "Carol",
            "url": "https://mastodon.social/@carol",
            "note": "<p>hi <a href='https://blog.example'>blog</a></p>",
            "followers_count": 50,
            "fields": [{"name": "web", "value": "<a href=\"https://carol.me\">carol.me</a>",
                        "verified_at": "2026-01-01T00:00:00Z"},
                       {"name": "x", "value": "<a href=\"https://unverified.example\">x</a>"}]}
    res = Mastodon().parse(data, "carol")
    # 검증(rel=me) 링크는 확실
    verified = [e for e in res.entities if e.type == EntityType.URL and e.value == "https://carol.me"]
    assert verified and verified[0].certainty is Certainty.CONFIRMED
    # 미검증 링크는 불확실
    unv = [e for e in res.entities if e.value == "https://unverified.example"]
    assert unv and unv[0].certainty is Certainty.UNCONFIRMED
    # bio HTML 제거됨
    acc = [e for e in res.entities if e.type == EntityType.ACCOUNT][0]
    assert "<" not in acc.attrs["bio"]


# ══════════ Chess.com ══════════
def test_chesscom_name_location():
    data = {"player_id": 123, "username": "dave", "name": "Dave Lee",
            "location": "Seoul", "country": "https://api.chess.com/pub/country/KR",
            "url": "https://www.chess.com/member/dave"}
    res = ChessCom().parse(data, "Dave")
    kinds = _kinds(res)
    assert (EntityType.NAME, "Dave Lee") in kinds
    assert (EntityType.GEO, "Seoul") in kinds
    acc = [e for e in res.entities if e.type == EntityType.ACCOUNT][0]
    assert acc.attrs["country"] == "KR"                     # country URL → 코드만

def test_chesscom_minimal():
    res = ChessCom().parse({"player_id": 1, "username": "e", "url": "u"}, "e")
    assert any(x.type == EntityType.ACCOUNT for x in res.entities)
    assert not any(x.type == EntityType.NAME for x in res.entities)


# ══════════ 레지스트리 배선(증분 20·23) ══════════
def test_registered_in_defaults():
    names = {c.name for c in default_collectors(real=True)}
    assert {"bluesky", "chesscom", "lichess", "devto", "dockerhub",
            "wikipedia", "codeberg"} <= names
    # 죽은 소스는 제외됨
    assert "reddit" not in names and "mastodon" not in names

def test_accept_username():
    from artes.collectors.social3_c import Lichess, DevTo, DockerHub, Wikipedia, Codeberg
    for C in (Bluesky, ChessCom, Lichess, DevTo, DockerHub, Wikipedia, Codeberg):
        assert EntityType.USERNAME in C().accepts


# ══════════ 신규 수집기 파서(증분 23) ══════════
def test_devto_cross_links():
    from artes.collectors.social3_c import DevTo
    d = {"id": 1, "username": "amy", "name": "Amy Park", "location": "Busan",
         "summary": "dev", "twitter_username": "amytw", "github_username": "amygh",
         "website_url": "https://amy.dev"}
    res = DevTo().parse(d, "amy")
    kinds = {(e.type, e.value) for e in res.entities}
    assert (EntityType.ACCOUNT, "devto/amy") in kinds
    assert (EntityType.NAME, "Amy Park") in kinds
    assert (EntityType.GEO, "Busan") in kinds
    assert (EntityType.USERNAME, "amytw") in kinds   # 트위터 교차연결
    assert (EntityType.USERNAME, "amygh") in kinds   # 깃허브 교차연결
    assert (EntityType.URL, "https://amy.dev") in kinds

def test_codeberg_public_email():
    from artes.collectors.social3_c import Codeberg
    d = {"id": 5, "login": "bob", "full_name": "Bob Lee", "email": "bob@x.org",
         "location": "Seoul", "html_url": "https://codeberg.org/bob", "website": "https://bob.io"}
    res = Codeberg().parse(d, "bob")
    kinds = {(e.type, e.value) for e in res.entities}
    assert (EntityType.EMAIL, "bob@x.org") in kinds       # 공개 이메일 = 강한 단서
    assert (EntityType.NAME, "Bob Lee") in kinds
    em = [e for e in res.entities if e.type == EntityType.EMAIL][0]
    assert em.certainty is Certainty.CONFIRMED

def test_wikipedia_activity():
    from artes.collectors.social3_c import Wikipedia
    res = Wikipedia().parse({"name": "Carol", "editcount": 4210,
                             "registration": "2015-01-01T00:00:00Z"}, "Carol")
    acc = [e for e in res.entities if e.type == EntityType.ACCOUNT][0]
    assert acc.attrs["edits"] == 4210

def test_lichess_minimal():
    from artes.collectors.social3_c import Lichess
    res = Lichess().parse({"id": "dave", "username": "dave",
                           "profile": {"country": "KR", "bio": "hi https://d.gg"}}, "dave")
    assert any(e.type == EntityType.ACCOUNT for e in res.entities)
    assert any(e.type == EntityType.URL and e.value == "https://d.gg" for e in res.entities)
