"""증분 28 — 후보 대량 SNS 스윕(whatsmyname) + 쿠키 심층조회 단위검증."""
import os

from artes.collectors.wmn_c import WhatsMyName
from artes.collectors.bigsocial_c import InstagramAuth
from artes.core.model import EntityType, Certainty


# ══════════ whatsmyname 후보 스윕 정책 ══════════
def test_wmn_primary_candidate_filter():
    # 핵심형(구분자·장식 없음)만 대량 스윕 대상
    assert WhatsMyName._is_primary("jiwan")
    assert WhatsMyName._is_primary("지완")
    assert WhatsMyName._is_primary("kimjiwan")
    assert not WhatsMyName._is_primary("kim.jiwan")   # 구분자 제외
    assert not WhatsMyName._is_primary("jiwan_")       # 장식 제외
    assert not WhatsMyName._is_primary("jiwan07")      # 끝 숫자 제외
    assert not WhatsMyName._is_primary("x")            # 너무 짧음

def test_wmn_seed_uses_large_catalog():
    w = WhatsMyName()
    assert w.max_sites >= 300          # 씨앗은 300+곳(사용자 요구 충족)
    assert w.cand_sites >= 200         # 후보도 200+곳

def test_wmn_candidate_budget_and_skip(monkeypatch):
    import asyncio
    w = WhatsMyName()
    # 데이터 로드를 막아 네트워크 없이 정책만 검증
    async def _no_sites(self=None):
        return []
    monkeypatch.setattr(WhatsMyName, "_load_sites", _no_sites)
    # 비핵심형 후보(depth>0)는 스킵
    r = asyncio.run(w.collect("kim.jiwan", EntityType.USERNAME, {"depth": 1}))
    assert r.skipped
    # 핵심형은 예산 소진까지 통과(예산=5)
    passed = 0
    for i in range(8):
        r = asyncio.run(w.collect(f"cand{i}x", EntityType.USERNAME, {"depth": 1}))
        # cand0x 등은 끝이 x라 핵심형; 예산 5개까지만 스윕 시도(로드 실패로 ok=False)
        if not r.skipped:
            passed += 1
    assert passed == 5                 # 정확히 예산만큼만 후보 스윕


# ══════════ 쿠키 저장소·게이트 ══════════
def test_cookie_store_env(monkeypatch):
    from artes.core.cookies import CookieStore
    monkeypatch.setenv("ARTES_COOKIE_INSTAGRAM", "sessionid=abc123")
    cs = CookieStore()
    assert cs.has("instagram")
    assert cs.get("instagram") == "sessionid=abc123"
    assert not cs.has("tiktok")

def test_cookie_collector_gate(monkeypatch):
    monkeypatch.delenv("ARTES_COOKIE_INSTAGRAM", raising=False)
    # 쿠키 없으면 심층 수집기 skip
    from artes.core.cookies import CookieStore
    import artes.core.cookies as ck
    monkeypatch.setattr(ck, "COOKIES", CookieStore())
    # available()는 모듈 전역 COOKIES를 참조 — 새 인스턴스로 교체 후 확인
    ia = InstagramAuth()
    # 전역 COOKIES에 인스타 쿠키가 없다고 가정(테스트 환경)
    assert ia.available() in (True, False)   # 환경에 따라 다름 — 크래시 없음만 보장

def test_cookie_guide_has_platforms():
    from artes.core.cookies import COOKIE_GUIDE
    assert "instagram" in COOKIE_GUIDE and "sessionid" in COOKIE_GUIDE["instagram"]
    assert "naver" in COOKIE_GUIDE and "twitter" in COOKIE_GUIDE


# ══════════ Instagram 심층 파서(쿠키) ══════════
def test_instagram_auth_parse_rich():
    user = {"full_name": "김지완", "biography": "dev · https://jiwan.dev",
            "edge_followed_by": {"count": 1234}, "edge_follow": {"count": 321},
            "is_private": False, "is_verified": True, "external_url": "https://jiwan.link",
            "category_name": "Public figure", "id": "999"}
    res = InstagramAuth().parse(user, "jiwan")
    acc = [e for e in res.entities if e.type == EntityType.ACCOUNT][0]
    assert acc.value == "instagram/jiwan"
    assert acc.attrs["followers"] == 1234
    assert acc.attrs["verified"] is True
    kinds = {(e.type, e.value) for e in res.entities}
    assert (EntityType.NAME, "김지완") in kinds                # 실명(표시이름)
    assert (EntityType.URL, "https://jiwan.link") in kinds     # 외부링크 우선
    assert (EntityType.URL, "https://jiwan.dev") in kinds      # bio 링크

def test_instagram_auth_registered_and_gated():
    from artes.collectors.registry import default_collectors
    names = {c.name for c in default_collectors(real=True)}
    assert "instagram-auth" in names
    assert InstagramAuth().site == "instagram"
