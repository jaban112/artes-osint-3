"""증분 16 — 원격 큰 두뇌(GLM API) + 온디바이스 + 도메인 양자화 검증."""
import io
import json
import os
import tempfile

from artes.ai.backend import OpenAICompatBackend
from artes.ai import models as M
from artes.ai import quantize as Q


class _FakeResp(io.BytesIO):
    status = 200
    def __enter__(self): return self
    def __exit__(self, *a): return False


def _patch_urlopen(monkey_payload):
    """urlopen을 가짜 응답으로 교체하고 마지막 요청을 캡처."""
    import urllib.request as u
    captured = {}
    def fake(req, timeout=0):
        captured["url"] = req.full_url
        captured["headers"] = dict(req.header_items())
        captured["body"] = json.loads(req.data.decode())
        return _FakeResp(json.dumps(monkey_payload).encode())
    orig = u.urlopen
    u.urlopen = fake
    return captured, (lambda: setattr(u, "urlopen", orig))


# ══════════ OpenAI 호환 백엔드(GLM 등) ══════════
def test_openai_backend_request_and_parse():
    payload = {"choices": [{"message": {"content": "안녕 GLM"}}]}
    cap, restore = _patch_urlopen(payload)
    try:
        be = OpenAICompatBackend("https://openrouter.ai/api/v1", api_key="sk-test",
                                 model="z-ai/glm-5.3-flash")
        out = be.generate("안녕?", max_tokens=32)
    finally:
        restore()
    assert out == "안녕 GLM"
    assert cap["url"].endswith("/chat/completions")
    assert cap["body"]["model"] == "z-ai/glm-5.3-flash"
    assert cap["headers"].get("Authorization") == "Bearer sk-test"

def test_openai_backend_json_schema_mode():
    payload = {"choices": [{"message": {"content": '{"x":1}'}}]}
    cap, restore = _patch_urlopen(payload)
    try:
        be = OpenAICompatBackend("http://vm:8082/v1", model="local")
        be.generate("q", json_schema={"type": "object"})
    finally:
        restore()
    assert cap["body"]["response_format"]["type"] == "json_object"
    # 스키마가 시스템 메시지에 지시로 들어간다.
    assert any("schema" in m["content"] for m in cap["body"]["messages"])

def test_openai_backend_logprob_parse():
    payload = {"choices": [{"message": {"content": "ok"},
               "logprobs": {"content": [{"logprob": -0.2}, {"logprob": -0.4}]}}]}
    cap, restore = _patch_urlopen(payload)
    try:
        be = OpenAICompatBackend("http://x/v1", model="m")
        out, lp = be.generate_conf("q")
    finally:
        restore()
    assert out == "ok" and abs(lp + 0.3) < 1e-9

def test_openai_backend_no_key_no_auth_header():
    payload = {"choices": [{"message": {"content": "hi"}}]}
    cap, restore = _patch_urlopen(payload)
    try:
        OpenAICompatBackend("http://vm/v1", model="m").generate("q")
    finally:
        restore()
    assert "Authorization" not in cap["headers"]     # 키 없으면 인증 헤더 없음


# ══════════ 원격 라우팅 ══════════
def test_remote_backend_from_env():
    os.environ["ARTES_CHAT_URL"] = "http://myvm:8082/v1"
    os.environ["ARTES_CHAT_MODEL"] = "z-ai/glm-5.3-flash"
    try:
        from artes.ai.serving import remote_backend_for
        be = remote_backend_for("chat")
        assert be is not None and be.base_url == "http://myvm:8082/v1"
        assert be.model == "z-ai/glm-5.3-flash"
    finally:
        del os.environ["ARTES_CHAT_URL"]; del os.environ["ARTES_CHAT_MODEL"]

def test_remote_backend_from_provider_key():
    os.environ["ARTES_KEY_OPENROUTER"] = "sk-or-test"
    try:
        from artes.ai.serving import remote_backend_for
        from artes.core import keys as K
        K.KEYS = K.KeyStore(path="/nonexistent.json")   # env만 보게 리로드
        be = remote_backend_for("chat")
        assert be is not None and "openrouter" in be.base_url
        assert be.model == M.REMOTE_MODELS["chat"]["best"]
    finally:
        del os.environ["ARTES_KEY_OPENROUTER"]
        from artes.core import keys as K
        K.KEYS = K.KeyStore()

def test_remote_free_flag():
    os.environ["ARTES_KEY_ZAI"] = "z-test"
    os.environ["ARTES_AI_FREE"] = "1"
    try:
        from artes.core import keys as K
        K.KEYS = K.KeyStore(path="/nonexistent.json")
        from artes.ai.serving import remote_backend_for
        be = remote_backend_for("chat")
        assert be.model == M.REMOTE_MODELS["chat"]["free"]   # 무료 모델
    finally:
        del os.environ["ARTES_KEY_ZAI"]; del os.environ["ARTES_AI_FREE"]
        from artes.core import keys as K
        K.KEYS = K.KeyStore()


# ══════════ 모델 레지스트리(원격·온디바이스) ══════════
def test_remote_models_have_glm():
    assert "glm-5.3-flash" in M.REMOTE_MODELS["chat"]["best"]
    assert M.REMOTE_MODELS["chat"]["free"].endswith(":free")
    assert M.remote_model("chat") == M.REMOTE_MODELS["chat"]["best"]
    assert M.remote_model("chat", free_only=True).endswith(":free")

def test_ondevice_tiers_for_chromebook():
    # 8GB 크롬북에 맞는 소형(≤6GB RAM 요구) 존재.
    assert any(m["min_ram_gb"] <= 6 for m in M.ONDEVICE_TIERS.values())
    assert "qwen3-4b" in M.ONDEVICE_TIERS

def test_providers():
    assert set(M.REMOTE_PROVIDERS) >= {"openrouter", "zai"}
    assert M.REMOTE_PROVIDERS["openrouter"]["base_url"].startswith("https://")


# ══════════ 도메인 양자화 파이프라인 ══════════
def test_build_calibration_writes_our_domain():
    with tempfile.TemporaryDirectory() as td:
        path = os.path.join(td, "calib.txt")
        n = Q.build_calibration(path, repeats=3)
        assert n > 0
        text = open(path, encoding="utf-8").read()
        # 우리 작업(동일인 판정·엔티티추출)이 코퍼스에 반영됐는지.
        assert "동일인" in text and "JSON" in text

def test_quantize_plan_commands():
    plan = Q.quantize_plan("/m/base.gguf", "/m/out.gguf", quant="IQ2_M")
    imat = " ".join(plan["imatrix_cmd"])
    quant = " ".join(plan["quantize_cmd"])
    assert "llama-imatrix" in imat and "base.gguf" in imat
    assert "llama-quantize" in quant and "--imatrix" in quant and "IQ2_M" in quant


def test_keys_have_providers():
    from artes.core.keys import KeyStore
    ks = KeyStore(path="/nonexistent.json")
    st = ks.status()
    assert "openrouter" in st and "zai" in st
