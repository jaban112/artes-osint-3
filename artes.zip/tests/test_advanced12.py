"""증분 18 — 대규모 API 키 자동 인식 + 제공처 레지스트리 검증.

수천 종의 AI(제공처×모델)를 키 하나로 인식·연결하는 경로를 단위검증한다.
네트워크 없이(이 컨테이너는 외부망 제한) 로직만 확인.
"""
import re

import pytest

from artes.ai import providers as P


# ══════════ 레지스트리 무결성 ══════════
def test_registry_shape():
    assert len(P.ALL_PROVIDERS) >= 30                 # 30+ 제공처
    for name, c in P.ALL_PROVIDERS.items():
        assert c["base_url"].startswith(("https://", "http://"))
        assert "key" in c and c["key"]
        assert "signup" in c and c["signup"].startswith("http")
        assert "prefixes" in c and isinstance(c["prefixes"], list)
        assert "openai" in c
        for pat in c["prefixes"]:                     # 접두사는 유효 정규식
            re.compile(pat)

def test_local_providers_are_http_localhost():
    for name in ("ollama", "lmstudio", "localai"):
        assert P.ALL_PROVIDERS[name]["base_url"].startswith("http://")
        assert "localhost" in P.ALL_PROVIDERS[name]["base_url"]

def test_gateways_present():
    # 게이트웨이 하나로 수백 모델 — 이게 '수천 종' 커버의 핵심.
    assert "openrouter" in P.ALL_PROVIDERS
    assert "400+" in P.ALL_PROVIDERS["openrouter"]["note"]


# ══════════ 키 접두사 자동 인식 ══════════
@pytest.mark.parametrize("key,prov", [
    ("sk-ant-api03-abcdef", "anthropic"),
    ("sk-or-v1-deadbeef", "openrouter"),
    ("gsk_ABCDEFG123456", "groq"),
    ("csk-abcdef123", "cerebras"),
    ("xai-abcdef123", "xai"),
    ("pplx-abcdef123", "perplexity"),
    ("fw_abcdef123", "fireworks"),
    ("nvapi-abcdef123", "nvidia"),
    ("r8_abcdef123", "replicate"),
    ("hf_abcdefGHIJ", "huggingface"),
    ("AIzaSyABCDEFG_hijklmnop-qrstuv123456", "gemini"),
    ("tgp_v1_abcdef", "together"),
    ("ghp_abcdef1234567890", "github"),
    ("github_pat_abcdef", "github"),
])
def test_detect_distinct_prefixes(key, prov):
    d = P.detect_provider(key)
    assert d["provider"] == prov
    assert d["confident"] is True
    assert d["candidates"] == [prov]

def test_detect_ambiguous_sk():
    # sk-... 은 openai·deepseek·moonshot 등이 공유 → 확신 낮음 + 후보.
    d = P.detect_provider("sk-abcdef1234567890ABCDEF")
    assert d["provider"] == "openai"
    assert d["confident"] is False
    assert "deepseek" in d["candidates"] and "moonshot" in d["candidates"]

def test_detect_empty_and_unknown():
    assert P.detect_provider("")["provider"] is None
    assert P.detect_provider("   ")["provider"] is None
    unk = P.detect_provider("weirdtoken12345")
    assert unk["provider"] is None
    assert unk["candidates"]                         # 후보(고유 접두사 없는 곳들) 제시

def test_anthropic_not_confused_with_openai():
    # sk-ant- 은 anthropic 이지 openai 아님(순서 중요).
    assert P.detect_provider("sk-ant-xyz")["provider"] == "anthropic"
    assert P.detect_provider("sk-ant-xyz")["provider"] != "openai"

def test_novita_sk_underscore_before_openai():
    # sk_ (밑줄) = novita, sk- (하이픈) = openai 계열. 혼동 없어야.
    assert P.detect_provider("sk_abcdef123")["provider"] == "novita"
    assert P.detect_provider("sk-abcdef123")["provider"] == "openai"


def test_provider_base():
    assert P.provider_base("openrouter") == "https://openrouter.ai/api/v1"
    assert P.provider_base("nonexistent") is None


# ══════════ 키 → 백엔드 팩토리 ══════════
def test_backend_from_key_openai_compat():
    from artes.ai.serving import backend_from_key
    from artes.ai.backend import OpenAICompatBackend
    be = backend_from_key("sk-or-v1-deadbeef", role="chat")
    assert isinstance(be, OpenAICompatBackend)
    assert "openrouter" in be.base_url
    assert be.api_key == "sk-or-v1-deadbeef"          # 헤더용으로만 보관

def test_backend_from_key_anthropic_native():
    from artes.ai.serving import backend_from_key
    from artes.ai.backend import AnthropicBackend
    be = backend_from_key("sk-ant-api03-xyz", role="chat")
    assert isinstance(be, AnthropicBackend)
    assert "anthropic.com" in be.base_url
    assert be.model.startswith("claude")

def test_backend_from_key_ambiguous_returns_openai():
    # 확신 낮아도 provider(openai)가 있으면 백엔드는 만든다.
    from artes.ai.serving import backend_from_key
    from artes.ai.backend import OpenAICompatBackend
    be = backend_from_key("sk-abcdef1234567890ABCDEF")
    assert isinstance(be, OpenAICompatBackend)
    assert "openai.com" in be.base_url

def test_backend_from_key_unknown_none():
    from artes.ai.serving import backend_from_key
    assert backend_from_key("totally-weird-xyz") is None

def test_backend_for_provider_explicit_model():
    from artes.ai.serving import backend_for_provider
    be = backend_for_provider("groq", "gsk_x", role="chat", model="my-model")
    assert "groq" in be.base_url and be.model == "my-model"

def test_backend_for_provider_glm_gateway_default_model():
    from artes.ai.serving import backend_for_provider
    be = backend_for_provider("openrouter", "sk-or-x", role="chat")
    assert be.model.startswith("z-ai/")               # GLM 게이트웨이 추천 모델


# ══════════ keys.py 표준 env 확장 ══════════
def test_keys_recognizes_new_std_envs(monkeypatch):
    from artes.core.keys import KeyStore, _STD_ENV
    for svc in ("anthropic", "openai", "xai", "mistral", "deepseek",
                "together", "fireworks", "nvidia", "perplexity", "huggingface"):
        assert svc in _STD_ENV
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-envtest")
    ks = KeyStore(path="/nonexistent.json")
    assert ks.get("anthropic") == "sk-ant-envtest"
    assert "env(ANTHROPIC_API_KEY)" == ks.source_of("anthropic")


# ══════════ AnthropicBackend 형태 ══════════
def test_anthropic_backend_headers():
    from artes.ai.backend import AnthropicBackend
    be = AnthropicBackend(api_key="sk-ant-x")
    h = be._headers()
    assert h["x-api-key"] == "sk-ant-x"
    assert "anthropic-version" in h
    assert "Authorization" not in h                   # 네이티브는 x-api-key만
    assert be.available() is True

def test_list_models_bad_provider_empty():
    assert P.list_models("nonexistent-provider") == []
