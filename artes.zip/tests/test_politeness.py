"""매너/반밴 계층 — rate-limit·재시도·프록시 로테이션."""
import asyncio
import time

from artes.core.politeness import RateLimiter, Policy, with_retry, POLICY, host_of


def test_rate_limiter_spacing():
    async def go():
        rl = RateLimiter(min_interval=0.1)
        t0 = time.monotonic()
        for _ in range(3):
            await rl.acquire("api.example.com")
        return time.monotonic() - t0
    elapsed = asyncio.run(go())
    assert elapsed >= 0.2 - 0.02          # 3회 = 최소 2간격

def test_rate_limiter_per_host_independent():
    async def go():
        rl = RateLimiter(min_interval=0.2)
        t0 = time.monotonic()
        await rl.acquire("a.com"); await rl.acquire("b.com")   # 다른 호스트 → 대기 없음
        return time.monotonic() - t0
    assert asyncio.run(go()) < 0.1


def test_with_retry_succeeds_after_failures():
    calls = {"n": 0}
    async def factory():
        calls["n"] += 1
        return "ok" if calls["n"] >= 3 else None
    old = POLICY.base_delay, POLICY.max_delay
    POLICY.base_delay, POLICY.max_delay = 0.001, 0.005
    try:
        r = asyncio.run(with_retry(factory, retries=5))
    finally:
        POLICY.base_delay, POLICY.max_delay = old
    assert r == "ok" and calls["n"] == 3


def test_with_retry_gives_up():
    async def factory():
        return None
    POLICY.base_delay = 0.001
    assert asyncio.run(with_retry(factory, retries=2)) is None


def test_proxy_rotation_and_backoff():
    p = Policy(proxies=["http://a:1", "http://b:2"], base_delay=1.0, max_delay=100)
    assert p.next_proxy() == "http://a:1"
    assert p.next_proxy() == "http://b:2"
    assert p.next_proxy() == "http://a:1"        # 순환
    assert p.backoff(0) <= p.backoff(3) * 2       # 대략 증가(지터 감안)
    assert host_of("https://x.com/a/b") == "x.com"


def test_tor_takes_priority_over_proxies():
    p = Policy(proxies=["http://a:1"], tor_socks="socks5h://127.0.0.1:9050")
    assert p.next_proxy() == "socks5h://127.0.0.1:9050"
