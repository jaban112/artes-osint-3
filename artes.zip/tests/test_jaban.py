import math

from artes.core.warrant import cp_lower, cp_interval, betai, beta_ppf
from artes.core.resolve import MinHash, LSH, EntityResolver
from artes.core.model import Graph, Entity, Edge, EntityType, Certainty, Evidence


def test_incomplete_beta_sanity():
    assert abs(betai(1, 1, 0.5) - 0.5) < 1e-9        # 균등
    assert abs(beta_ppf(0.5, 1, 1) - 0.5) < 1e-6
    assert betai(2, 3, 0.0) == 0.0 and betai(2, 3, 1.0) == 1.0


def test_cp_lower_known_and_monotone():
    assert cp_lower(0, 10) == 0.0
    # k=n 이면 정확히 alpha^(1/n)
    assert abs(cp_lower(3, 3, 0.05) - 0.05 ** (1 / 3)) < 1e-9
    # 약한 신호 하나는 신뢰 하한이 바닥
    assert cp_lower(1, 4) < 0.1
    # 더 많이 일치할수록 하한이 오른다
    assert cp_lower(1, 4) < cp_lower(2, 4) < cp_lower(3, 4)
    lo, hi = cp_interval(2, 10)
    assert 0.0 < lo < 0.2 < hi < 0.6


def test_minhash_similarity():
    mh = MinHash(num_perm=128)
    a = mh.signature("johnsmith")
    b = mh.signature("johnsmith")
    c = mh.signature("완전히다른문자열xyz")
    assert MinHash.jaccard(a, b) == 1.0
    assert MinHash.jaccard(a, c) < 0.3


def test_resolver_shared_email_is_confirmed():
    g = Graph()
    acc1 = g.add(Entity(EntityType.ACCOUNT, "github/hong", Certainty.CONFIRMED,
                        attrs={"handle": "hong"}, evidence=[Evidence("s", "")]))
    acc2 = g.add(Entity(EntityType.ACCOUNT, "twitter/hongkd", Certainty.CONFIRMED,
                        attrs={"handle": "hongkd"}, evidence=[Evidence("s", "")]))
    email = g.add(Entity(EntityType.EMAIL, "hong@x.com", Certainty.CONFIRMED,
                         evidence=[Evidence("s", "")]))
    g.link(Edge(acc1.key, email.key, "이메일", Certainty.CONFIRMED, evidence=[Evidence("s", "")]))
    g.link(Edge(acc2.key, email.key, "이메일", Certainty.CONFIRMED, evidence=[Evidence("s", "")]))
    added = EntityResolver().correlate(g)
    same = [e for e in added if e.relation == "동일인"]
    assert same and same[0].certainty is Certainty.CONFIRMED


def test_resolver_weak_signal_low_confidence():
    g = Graph()
    g.add(Entity(EntityType.NAME, "Jonathan Smith", evidence=[Evidence("s", "")]))
    g.add(Entity(EntityType.NAME, "Jonathan Smith", evidence=[Evidence("s2", "")]))
    # 같은 이름 문자열은 병합되므로, 유사하지만 다른 이름으로 약신호 확인
    g.add(Entity(EntityType.USERNAME, "jonathansmith", evidence=[Evidence("s", "")]))
    added = EntityResolver(sim_threshold=0.4).correlate(g)
    weak = [e for e in added if e.relation == "동일인?"]
    for e in weak:
        assert e.certainty is Certainty.UNCONFIRMED
        assert 0.0 <= (e.confidence or 0) < 0.5     # 약신호 → 낮은 하한
