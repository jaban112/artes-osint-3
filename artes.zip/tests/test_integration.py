"""통합 — 다신호 동일인 해소 → 융합 신뢰도 → 리포트 end-to-end."""
import io
import pytest

from artes.core.model import Graph, Entity, Edge, EntityType, Certainty, Evidence
from artes.core.resolve import EntityResolver
from artes.core.report import build_profile, render_html
from artes.core import provenance

pytest.importorskip("PIL")
from PIL import Image
from artes.core.imagehash import phash_bytes


def _photo():
    img = Image.new("RGB", (96, 96))
    px = img.load()
    for y in range(96):
        for x in range(96):
            px[x, y] = ((x * 3) % 256, (y * 3) % 256, ((x * y) % 256))
    b = io.BytesIO(); img.save(b, "PNG")
    return phash_bytes(b.getvalue())


def test_end_to_end_same_person_and_report():
    ph = _photo()
    g = Graph()
    email = g.add(Entity(EntityType.EMAIL, "jiwan@x.com", Certainty.CONFIRMED, evidence=[Evidence("입력", "")]))
    # A·B: 같은 사진 + 같은 bio → 하드(확실 동일인)
    a = g.add(Entity(EntityType.ACCOUNT, "github/jiwan", Certainty.CONFIRMED,
                     attrs={"handle": "jiwan", "bio": "hiking coffee open source",
                            "image_phash": ph}, evidence=[Evidence("t", "")]))
    b = g.add(Entity(EntityType.ACCOUNT, "gitlab/jiwankim", Certainty.CONFIRMED,
                     attrs={"handle": "jiwankim", "bio": "hiking coffee open source",
                            "image_phash": ph}, evidence=[Evidence("t", "")]))
    # C: 이름만 유사, 하드 없음 → 등급 불확실
    c = g.add(Entity(EntityType.USERNAME, "jiwan", Certainty.CONFIRMED, evidence=[Evidence("t", "")]))
    g.link(Edge(email.key, a.key, "가진 계정", Certainty.CONFIRMED, evidence=[Evidence("t", "")]))

    added = EntityResolver().correlate(g)
    confirmed = [e for e in added if e.relation == "동일인"]
    graded = [e for e in added if e.relation == "동일인?"]
    assert confirmed, "같은 사진+bio는 확실 동일인"
    assert all(e.certainty is Certainty.CONFIRMED for e in confirmed)
    # 등급 불확실이 있으면 신뢰도는 0~1 범위의 융합 사후확률
    for e in graded:
        assert 0.0 <= (e.confidence or 0) <= 1.0

    # 출처 오염 전파: 이메일 오염 → 하위 강등
    provenance.taint(g, email.key, "테스트 오염")
    assert g.get(a.key).attrs.get("tainted")

    # 리포트 종합
    prof = build_profile(g, ["jiwan@x.com", "jiwan123"])
    assert prof["same_person"]
    assert prof["footprint"]["present"] >= 2
    html = render_html(prof)
    assert "ARTES 프로파일" in html and "동일인" in html
