"""증분 10 — 융합 수학·AI 판정 대규모 업그레이드 검증.

Fellegi–Sunter m/u · 다단계 · 희소성 보정 · EM · Platt · Beta-이항 가드 ·
전역 군집화(PIVOT/연결요소) · 의미 엔트로피 · 컨포멀 · 로지스틱 융합 · ECE/AUROC ·
p(True) · GenRM · 체크리스트 근거인용 · judge_calibrated.
"""
import math

from artes.core import linkage as L
from artes.core import cluster as CL
from artes.core.cluster import SignedGraph
from artes.ai import calibrate as C
from artes.ai import verify as V
from artes.ai.runtime import Runtime
from artes.ai.backend import StubBackend
from artes.core.model import Graph, Entity, Edge, EntityType, Certainty, Evidence


# ───────── Fellegi–Sunter 융합 수학 ─────────
def test_fs_weight_signs():
    # m>u → 일치 가중 양수, 불일치 가중 음수.
    assert L.weight_agree(0.9, 0.01) > 0
    assert L.weight_disagree(0.9, 0.01) < 0

def test_fs_prob_from_weight():
    assert L.prob_from_weight(0.0) == 0.5
    assert L.prob_from_weight(80) == 1.0
    assert L.prob_from_weight(-80) == 0.0
    # W=log2(oz): P=oz/(1+oz).
    assert abs(L.prob_from_weight(math.log2(3)) - 0.75) < 1e-9

def test_fs_levels():
    # name_sim 0.96 → 최상단계(0), 0.86 → 1, 0.72 → 2, 0.5 → 불일치.
    assert L.level_of("name_sim", 0.96) == 0
    assert L.level_of("name_sim", 0.86) == 1
    assert L.level_of("name_sim", 0.50) == 3        # 모든 단계 미달
    w_hi = L.signal_weight("name_sim", 0.96)
    w_lo = L.signal_weight("name_sim", 0.72)
    assert w_hi > w_lo > 0                            # 강할수록 큰 양의 가중

def test_fs_tf_rarity_boost():
    base = L.signal_weight("handle")
    rare = L.tf_adjust(base, u_avg=0.02, u_value=0.0002)   # 희귀 핸들
    common = L.tf_adjust(base, u_avg=0.02, u_value=0.02)   # 흔한 핸들
    assert rare > base >= common                     # 희귀 일치가 훨씬 강함

def test_fs_fuse_and_independence_guard():
    # 상관 신호(image+face)는 한 그룹 → 독립신호 1로 축약.
    groups = {"visual": ["image", "face"]}
    fr = L.fuse_fs([("image",), ("face",)], independent_groups=groups)
    assert fr.n_independent == 1
    assert fr.posterior > 0.5
    # 독립 신호 두 개면 n_independent=2.
    fr2 = L.fuse_fs([("image",), ("handle",)])
    assert fr2.n_independent == 2

def test_fs_disagreement_lowers():
    # 유사도 낮은 name_sim은 불일치 가중(음)이라 확률을 낮춘다.
    hi = L.fuse_fs([("name_sim", 0.96)]).posterior
    lo = L.fuse_fs([("name_sim", 0.30)]).posterior
    assert hi > lo

def test_em_recovers_mu():
    # 합성: 매치쌍은 신호0이 자주 1, 비매치는 드물게 1.
    import random
    random.seed(0)
    vecs = []
    for _ in range(300):                             # 매치(약 40%)
        vecs.append([1 if random.random() < 0.9 else 0,
                     1 if random.random() < 0.8 else 0])
    for _ in range(700):                             # 비매치
        vecs.append([1 if random.random() < 0.1 else 0,
                     1 if random.random() < 0.05 else 0])
    est = L.estimate_mu(vecs, n_iter=60)
    # 신호0의 m은 크고(≳0.7) u는 작아야(≲0.3) 한다.
    assert est["m"][0] > 0.6 and est["u"][0] < 0.35
    assert 0.15 < est["lambda"] < 0.6

def test_platt_calibrator():
    # 큰 양의 W는 1로, 큰 음의 W는 0으로 매핑되게 학습.
    xs = [-4, -3, -2, 2, 3, 4]
    ys = [0, 0, 0, 1, 1, 1]
    cal = L.PlattCalibrator().fit(xs, ys, epochs=3000)
    assert cal.predict(4) > 0.8 and cal.predict(-4) < 0.2
    d = cal.to_dict(); assert L.PlattCalibrator.from_dict(d).predict(4) > 0.8


# ───────── 전역 군집화 ─────────
def test_connected_components_transitive():
    g = SignedGraph()
    for n in "abcd":
        g.add_node(n)
    g.add_edge("a", "b", 5.0)
    g.add_edge("b", "c", 5.0)                         # a~b~c 전이 → 한 군집
    comps = CL.connected_components(g)
    big = max(comps, key=len)
    assert big == {"a", "b", "c"}
    assert {"d"} in comps

def test_pivot_respects_cannot_link():
    g = SignedGraph()
    g.add_edge("x", "y", 3.0)
    g.cannot_link("x", "z")                           # x와 z는 절대 같은 군집 아님
    g.add_edge("y", "z", 1.0)
    clusters = CL.pivot_cluster(g)
    for c in clusters:
        assert not ({"x", "z"} <= c)                 # cannot-link 위배 없음

def test_cluster_identities_from_graph():
    g = Graph()
    for h in ("x", "y", "z"):
        g.add(Entity(EntityType.ACCOUNT, f"s/{h}", Certainty.CONFIRMED,
                     attrs={"handle": h}, evidence=[Evidence("t", "")]))
    g.link(Edge("account:s/x", "account:s/y", "동일인", Certainty.CONFIRMED,
               evidence=[Evidence("t", "")]))
    g.link(Edge("account:s/y", "account:s/z", "동일인", Certainty.CONFIRMED,
               evidence=[Evidence("t", "")]))
    clusters = CL.cluster_identities(g)
    assert any(len(c) == 3 for c in clusters)         # x~y~z 전이 병합


# ───────── AI 신뢰도 교정 ─────────
def test_semantic_entropy_and_agreement():
    same = ["서울 개발자", "서울 개발자", "서울 개발자"]
    diff = ["서울 개발자", "부산 디자이너", "제주 교사"]
    assert C.semantic_entropy(same) == 0.0
    assert C.semantic_entropy(diff) > 0.9
    assert C.agreement_rate(same) == 1.0
    assert C.agreement_rate(diff) < 0.5

def test_conformal_guarantee():
    # 교정 비적합점수, alpha=0.2 → 임계는 상위 80% 분위수 근방.
    cal = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]
    q = C.conformal_threshold(cal, alpha=0.2)
    assert 0.8 <= q <= 1.0
    assert C.conformal_decide(0.5, q) is True         # 점수 낮음 → 확실
    assert C.conformal_decide(0.95, q) is False       # 높음 → 기권

def test_ece_and_auroc():
    # 완벽 분리 → AUROC 1.0.
    assert C.auroc([0.9, 0.8, 0.2, 0.1], [1, 1, 0, 0]) == 1.0
    # 신뢰도=정확도면 ECE 낮음.
    e = C.ece([0.0, 1.0, 0.0, 1.0], [0, 1, 0, 1])
    assert e < 0.05

def test_logistic_fuser_beats_average_direction():
    # 신호0만 라벨과 상관, 신호1은 잡음 → 융합이 신호0에 큰 가중.
    import random
    random.seed(1)
    X, y = [], []
    for _ in range(200):
        lab = random.randint(0, 1)
        X.append([0.9 if lab else 0.1, random.random()])
        y.append(lab)
    f = C.LogisticFuser().fit(X, y, epochs=2000)
    assert f.fitted and abs(f.weights[0]) > abs(f.weights[1])
    # 미적합 융합기는 평균 폴백.
    assert abs(C.LogisticFuser().predict([0.4, 0.6]) - 0.5) < 1e-9


# ───────── 모델 신호(StubBackend) ─────────
def test_p_true_reads_verdict():
    rt_t = Runtime(backend=StubBackend(lambda p: "True", conf=-0.1))
    rt_f = Runtime(backend=StubBackend(lambda p: "False", conf=-0.1))
    assert C.p_true(rt_t, "q", "a", "ctx") > 0.5
    assert C.p_true(rt_f, "q", "a", "ctx") < 0.5

def test_genrm_pyes_ratio():
    rt = Runtime(backend=StubBackend(lambda p: '{"reasoning":"ok","verdict":"yes"}'))
    assert C.genrm_pyes(rt, "주장", "근거", k=6) == 1.0
    rt2 = Runtime(backend=StubBackend(lambda p: '{"reasoning":"no","verdict":"no"}'))
    assert C.genrm_pyes(rt2, "주장", "근거", k=6) == 0.0


# ───────── 판정 파이프라인 ─────────
def test_judge_calibrated_certain():
    def r(p):
        if "결론만 뽑아" in p:
            return '{"evidence":"github bio 일치","verdict":"확실","confidence":85}'
        if "True 또는 False" in p:
            return "True"
        if "같은 결론을 말하는가" in p:
            return "yes"
        return "단계 분석.\n정답 확률: 88"          # 일관된 추론(의미 동일)
    rt = Runtime(backend=StubBackend(r, conf=-0.15))
    j = V.judge_calibrated(rt, "동일인?", "[근거] github bio", n_samples=4)
    assert j.verdict == "확실"
    assert j.signals["semantic_entropy"] == 0.0 and j.signals["p_true"] > 0.5

def test_judge_calibrated_conformal_abstains():
    def r(p):
        if "결론만 뽑아" in p:
            return '{"evidence":"약함","verdict":"불확실","confidence":40}'
        if "True 또는 False" in p:
            return "False"
        return "불확실.\n정답 확률: 20"
    rt = Runtime(backend=StubBackend(r, conf=-2.0))
    # 낮은 신호 → 높은 비적합점수 → 엄격 임계(0.2)에서 기권(불확실).
    j = V.judge_calibrated(rt, "동일인?", "근거", n_samples=3,
                           conformal_threshold=0.2)
    assert j.verdict == "불확실" and "nonconformity" in j.signals

def test_checklist_citation_enforcement():
    def r(p):
        # 첫 조건은 유효 인용(0), 둘째는 없는 근거(9) → 무효.
        if "조건] 같은 이메일" in p:
            return '{"reasoning":"근거0","present":true,"evidence_id":0}'
        return '{"reasoning":"추정","present":true,"evidence_id":9}'
    rt = Runtime(backend=StubBackend(r))
    out = V.checklist_verify(rt, "동일인", ["같은 이메일 관측"],
                             ["같은 이메일?", "같은 얼굴?"])
    assert out["supported"] == 1                       # 인용 유효한 것만
    assert out["items"][0]["valid"] and not out["items"][1]["valid"]


# ───────── 리졸버 FS 모드(비파괴 옵션) ─────────
def test_resolver_fs_mode_smoke():
    from artes.core.resolve import EntityResolver
    g = Graph()
    g.add(Entity(EntityType.ACCOUNT, "github/jiwan", Certainty.CONFIRMED,
                 attrs={"handle": "jiwan", "bio": "seoul python dev building osint"},
                 evidence=[Evidence("t", "")]))
    g.add(Entity(EntityType.ACCOUNT, "twitter/jiwan", Certainty.CONFIRMED,
                 attrs={"handle": "jiwan", "bio": "seoul python dev building osint"},
                 evidence=[Evidence("t", "")]))
    added = EntityResolver(use_fs=True).correlate(g)
    # 동일 핸들+bio 재사용 → 간선 생성(확실 또는 융합). 에러 없이 동작하면 통과.
    assert isinstance(added, list)
