"""증분 19 — 10만+ 모델 인식/지원(HF GGUF 우주 + 원격 카탈로그 합집합) 검증.

정직: 하드코딩 10만 줄이 아니라 '임의 GGUF 실행 + 라이브 카탈로그 집계'. 네트워크 없이
순수 로직(집계 합집합·판별·검색·통계·URL/캐시)을 주입 데이터로 단위검증.
"""
import json

from artes.ai import catalog as C


# ══════════ HF repo 판별 ══════════
def test_looks_like_hf_repo():
    assert C.looks_like_hf_repo("Qwen/Qwen3-4B-Instruct-2507-GGUF")
    assert C.looks_like_hf_repo("bartowski/Dolphin3.0-Llama3.1-8B-GGUF")
    assert C.looks_like_hf_repo("meta-llama/Llama-3.3-70B-Instruct")
    assert not C.looks_like_hf_repo("gpt-4o-mini")          # 슬래시 없음
    assert not C.looks_like_hf_repo("")
    assert not C.looks_like_hf_repo("a/b/c")                # 이중 슬래시

def test_hf_gguf_url():
    u = C.hf_gguf_url("bartowski/X-GGUF", "X-Q4_K_M.gguf")
    assert u == "https://huggingface.co/bartowski/X-GGUF/resolve/main/X-Q4_K_M.gguf"


# ══════════ resolve_model ══════════
def test_resolve_local_gguf_repo():
    r = C.resolve_model("Qwen/Qwen3-4B-Instruct-2507-GGUF", catalog={})
    assert r["local_gguf"] is True
    assert r["runnable"] is True
    # HF식 id는 호스팅 제공처 후보도 붙는다.
    assert "together" in r["remote_providers"] or "openrouter" in r["remote_providers"]

def test_resolve_remote_only():
    cat = {"gpt-4o-mini": ["openai", "openrouter"]}
    r = C.resolve_model("gpt-4o-mini", catalog=cat)
    assert r["local_gguf"] is False
    assert r["runnable"] is True
    assert set(r["remote_providers"]) == {"openai", "openrouter"}

def test_resolve_unknown_not_runnable():
    r = C.resolve_model("some-random-model-name", catalog={})
    assert r["local_gguf"] is False
    assert r["remote_providers"] == []
    assert r["runnable"] is False


# ══════════ aggregate_remote_catalogs (합집합) ══════════
def test_aggregate_union(monkeypatch):
    # list_models를 제공처별 고정 목록으로 대체 → 합집합/중복표시 검증.
    fake = {"openrouter": ["z-ai/glm-5.3-flash", "meta-llama/llama-3.3-70b"],
            "together": ["meta-llama/llama-3.3-70b", "Qwen/Qwen2.5-72B"],
            "groq": ["llama-3.3-70b-versatile"]}
    monkeypatch.setattr(C, "list_models", lambda prov, key=None: fake.get(prov, []))
    cat = C.aggregate_remote_catalogs(keyfn=lambda s: None,
                                      providers=["openrouter", "together", "groq"],
                                      save=False)
    # 공유 모델은 두 제공처가 붙는다.
    assert set(cat["meta-llama/llama-3.3-70b"]) == {"openrouter", "together"}
    assert cat["llama-3.3-70b-versatile"] == ["groq"]
    assert len(cat) == 4                                    # 고유 4개

def test_aggregate_empty_providers_graceful(monkeypatch):
    monkeypatch.setattr(C, "list_models", lambda prov, key=None: [])
    cat = C.aggregate_remote_catalogs(keyfn=lambda s: None,
                                      providers=["openrouter"], save=False)
    assert cat == {}


# ══════════ search_models (통합) ══════════
def test_search_remote_cache(monkeypatch):
    monkeypatch.setattr(C, "hf_search_gguf", lambda *a, **k: [])   # HF 네트워크 차단 흉내
    cat = {"z-ai/glm-5.3-flash": ["openrouter"],
           "meta-llama/llama-3.3-70b": ["together"],
           "gpt-4o": ["openai"]}
    res = C.search_models("llama", catalog=cat, hf=True)
    ids = [m["id"] for m in res["remote"]]
    assert "meta-llama/llama-3.3-70b" in ids
    assert "gpt-4o" not in ids
    assert res["hf_gguf"] == []

def test_search_hf_merges(monkeypatch):
    monkeypatch.setattr(C, "hf_search_gguf",
                        lambda q, **k: [{"id": "bartowski/Qwen-GGUF", "downloads": 5, "likes": 1, "gated": False}])
    res = C.search_models("qwen", catalog={}, hf=True)
    assert res["hf_gguf"][0]["id"] == "bartowski/Qwen-GGUF"


# ══════════ 캐시 저장·로드 ══════════
def test_catalog_cache_roundtrip(tmp_path, monkeypatch):
    p = tmp_path / "cat.json"
    monkeypatch.setattr(C, "CATALOG_CACHE", str(p))
    monkeypatch.setattr(C, "list_models",
                        lambda prov, key=None: ["m1"] if prov == "openrouter" else [])
    C.aggregate_remote_catalogs(keyfn=lambda s: None, providers=["openrouter"], save=True)
    assert p.exists()
    loaded = C.load_catalog()
    assert loaded == {"m1": ["openrouter"]}

def test_load_catalog_missing(tmp_path, monkeypatch):
    monkeypatch.setattr(C, "CATALOG_CACHE", str(tmp_path / "nope.json"))
    assert C.load_catalog() == {}


# ══════════ 통계(지원 규모) ══════════
def test_catalog_stats():
    cat = {"a": ["openrouter"], "b": ["openrouter", "together"], "c": ["groq"]}
    s = C.catalog_stats(catalog=cat)
    assert s["remote_cached"] == 3
    assert s["remote_by_provider"]["openrouter"] == 2
    assert s["local_hf_gguf_estimate"] >= 100000            # 10만+ 지원 근거
    assert s["providers_known"] >= 30


# ══════════ 네트워크 함수 오프라인 폴백 ══════════
def test_hf_search_offline_returns_list():
    # 외부망 제한 컨테이너 → [] (예외 없이).
    out = C.hf_search_gguf("qwen", limit=3)
    assert isinstance(out, list)

def test_hf_gguf_files_offline():
    out = C.hf_gguf_files("bartowski/nonexistent-xyz")
    assert isinstance(out, list)
