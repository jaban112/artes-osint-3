"""오타 도메인 생성기."""
from artes.core.typosquat import generate_variants


def test_generates_common_variants():
    v = set(generate_variants("google.com", max_variants=200))
    assert "gogle.com" in v            # 문자 생략
    assert "google.net" in v or "google.org" in v   # TLD 스왑
    assert "google.com" not in v       # 원본 제외
    assert all("." in d for d in v)


def test_homoglyph_and_hyphen():
    v = set(generate_variants("paypal.com", max_variants=300))
    assert any(c in d for d in v for c in ("0", "1"))   # 동형글자
    assert any("-" in d.split(".")[0] for d in v)        # 하이픈 삽입
