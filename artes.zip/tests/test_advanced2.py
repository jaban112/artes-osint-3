"""⑤⑥⑦ — RAG·얼굴매칭·에이전트 수사관."""
import asyncio
import tempfile

from artes.core.model import Graph, Entity, Edge, EntityType, Certainty, Evidence
from artes.core.face import distance, same_face
from artes.core.resolve import EntityResolver
from artes.ai.rag import RagIndex, index_graph, rag_answer
from artes.ai.agent import Investigator
from artes.ai.runtime import Runtime
from artes.ai.backend import StubBackend
from artes.core.cache import Cache
from artes.collectors import mock


# ---- ⑦ RAG ----
def test_rag_tfidf_search():
    idx = RagIndex()
    assert idx.backend == "tfidf"                  # 모델 없음 → 폴백
    idx.add("d1", "김지완 서울 개발자 파이썬")
    idx.add("d2", "고양이 강아지 반려동물")
    hits = idx.search("서울 개발자", k=1)
    assert hits and hits[0][0] == "d1"


def test_rag_answer_structured():
    g = Graph()
    g.add(Entity(EntityType.ACCOUNT, "github/jiwan", Certainty.CONFIRMED,
                 attrs={"bio": "seoul python developer"}, evidence=[Evidence("t", "")]))
    rt = Runtime(backend=StubBackend(lambda p: '{"answer":"개발자","certainty":"불확실"}'))
    r = rag_answer(rt, g, "seoul python developer")     # 어휘 겹침 → 검색 히트
    assert r["backend"] == "tfidf" and r["sources"]
    assert r["answer"] == "개발자"


# ---- ⑥ 얼굴 매칭 ----
def test_face_distance_and_match():
    a = [0.10] * 128
    b = [0.11] * 128
    c = [0.90] * 128
    assert same_face(a, b) and not same_face(a, c)
    assert distance(a, c) > distance(a, b)


def test_resolver_same_face_confirmed():
    g = Graph()
    x = g.add(Entity(EntityType.ACCOUNT, "github/x", Certainty.CONFIRMED,
                     attrs={"handle": "x", "face_encoding": [0.1] * 128},
                     evidence=[Evidence("t", "")]))
    y = g.add(Entity(EntityType.ACCOUNT, "twitter/y", Certainty.CONFIRMED,
                     attrs={"handle": "y", "face_encoding": [0.12] * 128},
                     evidence=[Evidence("t", "")]))
    added = EntityResolver().correlate(g)
    same = [e for e in added if e.relation == "동일인" and e.certainty is Certainty.CONFIRMED]
    assert same, "가까운 얼굴 임베딩 → 확실 동일인"


# ---- ⑤ 에이전트 ----
def test_agent_investigate():
    calls = {"n": 0}
    def responder(p):
        calls["n"] += 1
        # 첫 결정은 pivot, 이후 stop
        if calls["n"] == 1:
            return '{"action":"pivot","targets":["extra@x.com"],"hypothesis":"연결 이메일 조회"}'
        return '{"action":"stop","targets":[],"hypothesis":"충분"}'
    rt = Runtime(backend=StubBackend(responder))
    async def go():
        inv = Investigator(rt, mock.DEFAULTS, cache=Cache(root=tempfile.mkdtemp()),
                           max_steps=3, engine_kw={"depth": 1})
        return await inv.investigate(["hong@gmail.com"])
    g, log = asyncio.run(go())
    assert g.stats()["entities"] >= 3
    assert log and log[0]["action"] == "pivot"
    assert any(s["action"] == "stop" for s in log)     # 스스로 멈춤
