"""도구 파서 단위검증 — 실도구·네트워크 없이 합성 출력으로 파싱 로직만.

이 컨테이너는 실사이트가 차단이라 live 교정이 불가하므로, 각 도구의
'출력 형식'을 합성해 파서가 올바로 뽑는지 확인한다(최종 실측 교정은 사용자 VM).
"""
from artes.core.model import EntityType, Certainty
from artes.collectors.maigret_c import Maigret
from artes.collectors.net_c import Nmap
from artes.collectors.theharvester_c import TheHarvester
from artes.collectors.holehe_c import _HIT as HOLEHE_HIT
from artes.collectors.sherlock_c import _HIT as SHERLOCK_HIT


def test_maigret_parse_report():
    data = {
        "GitHub": {"status": "Claimed", "url_user": "https://github.com/x",
                   "http_status": 200, "ids": {"fullname": "Hong Kim",
                                               "email": ["h@x.com"]}},
        "NotUsed": {"status": "Available"},
        "Weird": {"status": "Unknown"},
    }
    res = Maigret().parse_report(data, "x")
    accts = [e for e in res.entities if e.type is EntityType.ACCOUNT]
    assert len(accts) == 1 and accts[0].certainty is Certainty.CONFIRMED
    assert any(e.type is EntityType.EMAIL and e.value == "h@x.com" for e in res.entities)
    assert any(e.type is EntityType.NAME and e.value == "Hong Kim" for e in res.entities)


def test_nmap_parse_xml():
    xml = ('<?xml version="1.0"?><nmaprun><host>'
           '<address addr="1.2.3.4" addrtype="ipv4"/><ports>'
           '<port protocol="tcp" portid="22"><state state="open"/>'
           '<service name="ssh" product="OpenSSH" version="8.9"/></port>'
           '<port protocol="tcp" portid="80"><state state="closed"/></port>'
           '</ports></host></nmaprun>')
    res = Nmap().parse_xml(xml, "1.2.3.4", EntityType.IP)
    hosts = [e for e in res.entities if e.type is EntityType.HOST]
    assert len(hosts) == 1                        # 열린 22만, 닫힌 80 제외
    assert hosts[0].attrs["port"] == "22" and "ssh" in hosts[0].attrs["service"]


def test_nmap_bad_xml_is_error_not_crash():
    res = Nmap().parse_xml("not xml <<", "x", EntityType.IP)
    assert not res.ok and "xml parse" in res.error


def test_theharvester_read_json(tmp_path):
    p = tmp_path / "out.json"
    p.write_text('{"emails":["a@b.com"],"hosts":["h.b.com:1.2.3.4"]}', encoding="utf-8")
    data = TheHarvester._read_json(str(p)[:-5])   # base(확장자 제거) 전달
    assert data and data["emails"] == ["a@b.com"]


def test_holehe_and_sherlock_regex():
    assert HOLEHE_HIT.match("[+] twitter.com").group(1) == "twitter.com"
    assert HOLEHE_HIT.match("[-] not.used") is None
    m = SHERLOCK_HIT.match("[+] GitHub: https://github.com/user")
    assert m.group(1) == "GitHub" and m.group(2) == "https://github.com/user"
