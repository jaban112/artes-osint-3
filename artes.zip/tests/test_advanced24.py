"""증분 33 — 전화 인텔 대폭 강화(libphonenumber: 지역·통신사·회선·표기·역검색) 검증."""
import asyncio

from artes.collectors.phone2_c import PhoneInfo
from artes.collectors.websearch_c import _phone_formats, WebMentions
from artes.core.model import EntityType


def _has(lib):
    try:
        __import__(lib); return True
    except Exception:
        return False


def test_phoneinfo_rich_attrs_and_geo():
    if not _has("phonenumbers"):
        return
    res = asyncio.run(PhoneInfo().collect("+821012345678", EntityType.PHONE, {}))
    ph = [e for e in res.entities if e.type == EntityType.PHONE][0]
    a = ph.attrs
    assert a["region_code"] == "KR"
    assert a["line_type"] == "휴대폰"
    assert a["national"] == "010-1234-5678"
    assert a["international"].startswith("+82")
    assert "Asia/Seoul" in a["timezones"]
    # 지역 → GEO 엔티티(위치 상관)
    assert any(e.type == EntityType.GEO for e in res.entities)

def test_phoneinfo_invalid_number():
    if not _has("phonenumbers"):
        return
    res = asyncio.run(PhoneInfo().collect("12345", EntityType.PHONE, {}))
    assert res.skipped or not res.ok

def test_phone_formats_multi():
    if not _has("phonenumbers"):
        return
    fmts = _phone_formats("+821012345678")
    assert "+821012345678" in fmts
    assert any("-" in f for f in fmts)          # 국내/국제 하이픈 표기 포함
    assert len(fmts) >= 3

def test_webmentions_phone_multi_format_queries():
    if not _has("phonenumbers"):
        return
    qs = WebMentions()._queries("+821012345678", EntityType.PHONE)
    assert len(qs) >= 2
    assert all(q.startswith('"') and q.endswith('"') for q in qs)   # 정확일치 검색
    # E164와 국내표기가 서로 다른 검색어로 포함
    joined = " ".join(qs)
    assert "+821012345678" in joined and "010-1234-5678" in joined

def test_phone_carrier_emitted_when_known():
    # 통신사 정보가 있으면 ORG 엔티티로(같은 통신사 신호). 없으면 GEO만.
    if not _has("phonenumbers"):
        return
    res = asyncio.run(PhoneInfo().collect("+14155552671", EntityType.PHONE, {}))
    # 유효하면 최소 PHONE 엔티티는 나옴
    assert any(e.type == EntityType.PHONE for e in res.entities)
