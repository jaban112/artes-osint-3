"""증분 38 — gap2·3·4 확장: 신원 강화 · 관계망/게시물 · 한국 공공기록.

전부 파서(parse*)를 합성 응답으로 오프라인 단위검증(실사이트 없이). live 페치는 사용자 환경.
"""
from artes.core.model import EntityType, Certainty
from artes.collectors.identity_c import EmailRepIO, GitHubUserSearch
from artes.collectors.socialgraph_c import (GitHubSocial, GitHubActivity,
                                            BlueskyGraph, BlueskyFeed)
from artes.collectors.korea_c import OpenDartCompany, KoreanWikipedia


def _types(res):
    return {e.type for e in res.entities}


def _rels(res):
    return {e.relation for e in res.edges}


# ══════════ gap2: 신원 강화 ══════════
def test_emailrep_profiles_and_name():
    d = {"email": "a@b.com", "reputation": "high",
         "details": {"name": "Jiwan Kim", "profiles": ["twitter", "github", "gravatar"],
                     "credentials_leaked": True, "data_breach": True,
                     "first_seen": "01/2010", "last_seen": "05/2020"}}
    res = EmailRepIO().parse(d, "a@b.com")
    assert any(e.type == EntityType.NAME and e.value == "Jiwan Kim" for e in res.entities)
    # 가입 플랫폼 3개가 계정(핸들미상) 후보로
    accs = [e for e in res.entities if e.type == EntityType.ACCOUNT]
    assert len(accs) == 3 and all(a.attrs.get("handle") == "" for a in accs)
    assert all(a.attrs.get("variant") for a in accs)     # 비확장(폭발 방지)
    # 유출은 메타만(BREACH), 평문·해시 없음
    br = [e for e in res.entities if e.type == EntityType.BREACH]
    assert br and "password" not in str(br[0].attrs) and "hash" not in str(br[0].attrs)

def test_emailrep_no_plaintext_even_if_given():
    d = {"email": "a@b.com", "details": {"password": "hunter2", "credentials_leaked": True}}
    res = EmailRepIO().parse(d, "a@b.com")
    assert "hunter2" not in str([e.attrs for e in res.entities])   # 평문 절대 미저장

def test_github_user_search_candidates_weak():
    items = [{"login": "jiwan", "html_url": "https://github.com/jiwan",
              "avatar_url": "https://a/x.png"}]
    res = GitHubUserSearch().parse(items, "Jiwan Kim")
    a = res.entities[0]
    assert a.type == EntityType.ACCOUNT and a.certainty is Certainty.UNCONFIRMED  # 동명이인=약함
    assert a.attrs.get("avatar")                                  # 아바타→pHash 자동대조
    assert a.attrs.get("variant")                                 # 비확장

def test_github_user_search_needs_fullname():
    import asyncio
    # 공백 없는 단일 토큰은 조용히 빈 결과(소음 억제)
    res = asyncio.run(GitHubUserSearch().collect("jiwan", EntityType.NAME, {}))
    assert res.ok and not res.entities


# ══════════ gap3: 관계망·게시물 ══════════
def test_github_social_edges_direction():
    res = GitHubSocial().parse("target",
        followers=[{"login": "fan1", "avatar_url": "", "html_url": ""}],
        following=[{"login": "idol1", "avatar_url": "", "html_url": ""}])
    rels = _rels(res)
    assert "팔로워" in rels and "팔로잉" in rels
    # 팔로워는 fan1→target, 팔로잉은 target→idol1
    fol = next(e for e in res.edges if e.relation == "팔로워")
    fng = next(e for e in res.edges if e.relation == "팔로잉")
    assert fol.dst == "account:github/target" and fol.src == "account:github/fan1"
    assert fng.src == "account:github/target" and fng.dst == "account:github/idol1"

def test_github_social_cap():
    many = [{"login": f"u{i}"} for i in range(200)]
    res = GitHubSocial().parse("t", followers=many, following=[])
    fol = [e for e in res.edges if e.relation == "팔로워"]
    assert len(fol) <= 50                                          # 상한

def test_github_activity_repos():
    events = [{"type": "PushEvent", "repo": {"name": "target/proj"}, "created_at": "2026-01-01"},
              {"type": "PushEvent", "repo": {"name": "target/proj"}, "created_at": "2026-01-02"},
              {"type": "WatchEvent", "repo": {"name": "other/lib"}, "created_at": "2026-01-03"}]
    res = GitHubActivity().parse("target", events)
    urls = [e.value for e in res.entities if e.type == EntityType.URL]
    assert "https://github.com/target/proj" in urls
    assert len(urls) == 2                                          # 중복 저장소 제거

def test_bluesky_graph_edges():
    res = BlueskyGraph().parse("alice.bsky.social",
        followers=[{"handle": "bob.bsky.social", "avatar": ""}],
        follows=[{"handle": "carol.bsky.social", "avatar": ""}])
    assert "팔로워" in _rels(res) and "팔로잉" in _rels(res)
    assert any(e.value == "bluesky/bob.bsky.social" for e in res.entities)

def test_bluesky_feed_posts():
    feed = [{"post": {"uri": "at://did:plc:xxx/app.bsky.feed.post/abc123",
                      "record": {"text": "안녕 세계", "createdAt": "2026-01-01T00:00:00Z"},
                      "likeCount": 5, "repostCount": 1}}]
    res = BlueskyFeed().parse("alice.bsky.social", feed)
    p = res.entities[0]
    assert p.type == EntityType.URL and p.value.endswith("/post/abc123")
    assert p.attrs.get("kind") == "post" and p.attrs.get("text") == "안녕 세계"
    assert "게시물" in _rels(res)


# ══════════ gap4: 한국 공공기록 ══════════
def test_opendart_company_parse():
    d = {"status": "000", "message": "정상", "corp_name": "테스트전자",
         "ceo_nm": "김대표", "phn_no": "02-1234-5678",
         "adres": "서울특별시 강남구 테헤란로 1", "hm_url": "http://test.co.kr",
         "bizr_no": "1234567890", "jurir_no": "110111-1234567",
         "induty_code": "264", "est_dt": "20010203", "corp_cls": "Y", "stock_code": "005930"}
    res = OpenDartCompany().parse_company(d, "테스트전자")
    t = _types(res)
    assert EntityType.NAME in t and EntityType.PHONE in t
    assert EntityType.GEO in t and EntityType.DOMAIN in t and EntityType.ORG in t
    assert "대표자" in _rels(res)
    org = next(e for e in res.entities if e.type == EntityType.ORG)
    assert org.attrs.get("biz_no") == "1234567890"
    dom = next(e for e in res.entities if e.type == EntityType.DOMAIN)
    assert dom.value == "test.co.kr"

def test_opendart_joint_ceos():
    d = {"status": "000", "corp_name": "공동", "ceo_nm": "김철수, 이영희"}
    res = OpenDartCompany().parse_company(d, "공동")
    names = {e.value for e in res.entities if e.type == EntityType.NAME}
    assert "김철수" in names and "이영희" in names          # 공동대표 분리

def test_opendart_skips_without_key():
    import asyncio
    res = asyncio.run(OpenDartCompany().collect("삼성전자", EntityType.ORG, {}))
    assert res.skipped                                     # 키 없으면 skip

def test_wikipedia_ko_exact_confirmed():
    hits = [{"title": "홍길동", "snippet": "<b>홍길동</b>은 조선의 인물이다"}]
    res = KoreanWikipedia().parse(hits, "홍길동")
    e = res.entities[0]
    assert e.certainty is Certainty.CONFIRMED              # 제목=이름 정확일치
    assert e.attrs.get("title") == "홍길동" and "<b>" not in e.attrs.get("snippet", "")

def test_wikipedia_ko_inexact_unconfirmed():
    hits = [{"title": "김철수 (야구선수)", "snippet": "야구"}]
    res = KoreanWikipedia().parse(hits, "김철수")
    e = res.entities[0]
    assert e.certainty is Certainty.CONFIRMED   # 괄호 주석 제거 후 '김철수'=정확
    hits2 = [{"title": "다른문서", "snippet": "x"}]
    res2 = KoreanWikipedia().parse(hits2, "김철수")
    assert res2.entities[0].certainty is Certainty.UNCONFIRMED   # 불일치=후보
