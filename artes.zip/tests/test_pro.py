"""pro 기법 모듈 — Keybase·dorking·orgrecon·workflow."""
import tempfile

from artes.core.model import EntityType, Certainty
from artes.collectors.keybase_c import Keybase
from artes.core import dorking, orgrecon
from artes.core.workflow import WorkflowStore, Workflow


def test_keybase_parse_verified_links():
    data = {"status": {"code": 0}, "them": [{
        "basics": {"username": "hong"},
        "profile": {"full_name": "Hong Kim"},
        "proofs_summary": {"all": [
            {"proof_type": "twitter", "nametag": "hong_t", "service_url": "https://twitter.com/hong_t"},
            {"proof_type": "github", "nametag": "hongdev", "service_url": "https://github.com/hongdev"}]}}]}
    res = Keybase().parse(data, "hong", EntityType.USERNAME)
    accts = {e.value for e in res.entities if e.type is EntityType.ACCOUNT}
    assert "keybase/hong" in accts and "twitter/hong_t" in accts and "github/hongdev" in accts
    # 검증된 연결은 확실
    assert all(e.certainty is Certainty.CONFIRMED for e in res.edges if e.relation == "검증된 연결")
    assert any(e.type is EntityType.NAME and e.value == "Hong Kim" for e in res.entities)


def test_dorking_multi_engine():
    d = dorking.generate_dorks("김지완", "name", engines=["google", "yandex"])
    assert d and all("q=" in x["url"] or "text=" in x["url"] for x in d)
    engines = {x["engine"] for x in d}
    assert engines == {"google", "yandex"}
    dd = dorking.generate_dorks("example.com", "domain", engines=["duckduckgo"])
    assert any("site:example.com" in x["query"] for x in dd)


def test_orgrecon_convention():
    known = [("Jiwan Kim", "jiwan.kim@corp.com"), ("Alice Park", "alice.park@corp.com")]
    pat = orgrecon.infer_convention(known)
    assert pat == "first.last"
    emails = orgrecon.generate_org_emails(["Bob Lee", "Carol Han"], "corp.com", pat)
    assert "bob.lee@corp.com" in emails and "carol.han@corp.com" in emails


def test_orgrecon_flast():
    known = [("Jiwan Kim", "jkim@corp.com")]
    assert orgrecon.infer_convention(known) == "flast"


def test_workflow_store():
    with tempfile.TemporaryDirectory() as td:
        st = WorkflowStore(root=td)
        assert "person" in st.list() and "fraud" in st.list()
        st.save(Workflow("custom", "내 절차", depth=4))
        assert st.get("custom").depth == 4
        wf = st.record_run("custom", ["email", "username"], 42)
        assert wf.runs == 1 and wf.avg_entities() == 42.0
        assert "email" in wf.effective_types
