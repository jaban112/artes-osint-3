"""문서 메타데이터 — 합성 docx(office zip)에서 작성자·회사·소프트웨어."""
import io
import zipfile

from artes.core import docmeta

CORE = ('<?xml version="1.0"?>'
        '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties"'
        ' xmlns:dc="http://purl.org/dc/elements/1.1/"'
        ' xmlns:dcterms="http://purl.org/dc/terms/">'
        '<dc:creator>Jiwan Kim</dc:creator>'
        '<cp:lastModifiedBy>jkim</cp:lastModifiedBy>'
        '<dcterms:created>2021-03-01T09:00:00Z</dcterms:created></cp:coreProperties>')
APP = ('<?xml version="1.0"?>'
       '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties">'
       '<Application>Microsoft Word</Application><Company>ACME Corp</Company></Properties>')


def _make_docx(path):
    with zipfile.ZipFile(path, "w") as z:
        z.writestr("docProps/core.xml", CORE)
        z.writestr("docProps/app.xml", APP)
        z.writestr("word/document.xml", "<x/>")


def test_office_metadata(tmp_path):
    p = tmp_path / "doc.docx"
    _make_docx(str(p))
    meta = docmeta.extract(str(p))
    assert meta["creator"] == "Jiwan Kim"
    assert meta["last_modified_by"] == "jkim"
    assert meta["application"] == "Microsoft Word"
    assert meta["company"] == "ACME Corp"


def test_unsupported_returns_empty(tmp_path):
    p = tmp_path / "x.txt"
    p.write_text("hi")
    assert docmeta.extract(str(p)) == {}
