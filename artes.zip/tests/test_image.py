"""지각 해시 실경로 — 같은 사진 pHash 근접 + resolve 동일인 확실."""
import io

import pytest

from artes.core.imagehash import phash_bytes, hamming_hex
from artes.core.model import Graph, Entity, Edge, EntityType, Certainty, Evidence
from artes.core.resolve import EntityResolver

PIL = pytest.importorskip("PIL")
from PIL import Image


def _img_bytes(seed=0, size=(128, 128), fmt="PNG"):
    img = Image.new("RGB", size)
    px = img.load()
    for y in range(size[1]):
        for x in range(size[0]):
            px[x, y] = ((x * 2 + seed) % 256, (y * 2) % 256, ((x + y) % 256))
    buf = io.BytesIO(); img.save(buf, fmt)
    return buf.getvalue()


def test_same_image_phash_close():
    a = phash_bytes(_img_bytes(0, fmt="PNG"))
    # 같은 이미지 JPEG 재압축·다른 크기 → 지각적으로 동일
    b = phash_bytes(_img_bytes(0, size=(100, 100), fmt="JPEG"))
    c = phash_bytes(_img_bytes(90))                       # 다른 이미지
    assert a and b and c
    assert hamming_hex(a, b) <= 8                          # 같은 사진 → 근접
    assert hamming_hex(a, c) >= hamming_hex(a, b)          # 다른 사진 → 더 멂


def test_resolver_same_photo_is_confirmed():
    ph = phash_bytes(_img_bytes(0))
    g = Graph()
    a = g.add(Entity(EntityType.ACCOUNT, "github/x", Certainty.CONFIRMED,
                     attrs={"handle": "x", "image_phash": ph}, evidence=[Evidence("t", "")]))
    b = g.add(Entity(EntityType.ACCOUNT, "twitter/y", Certainty.CONFIRMED,
                     attrs={"handle": "y", "image_phash": ph}, evidence=[Evidence("t", "")]))
    added = EntityResolver().correlate(g)
    same = [e for e in added if e.relation == "동일인"]
    assert same and same[0].certainty is Certainty.CONFIRMED   # 같은 사진 = 하드
