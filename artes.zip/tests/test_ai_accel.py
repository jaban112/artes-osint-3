"""6권 추론 가속 — 투기 디코딩 출력불변, 문법 강제 무결성, 구조화 추출."""
import random

from artes.ai.speculative import (greedy_speculative, greedy_direct,
                                   speculative_sample, identity_residual_holds)
from artes.ai.grammar import (json_number_dfa, generate_constrained,
                              certainty_grammar, answer_schema, parse_json_lenient)
from artes.ai.backend import StubBackend
from artes.ai.runtime import Runtime
from artes.ai.extract import extract_entities
from artes.core.model import EntityType


# ---- 투기 디코딩 (정리 A1·A2) ----
def test_greedy_speculative_bit_identical():
    V = 17
    def verifier(seq): return (seq[-1] * 7 + 3) % V          # 결정적 argmax
    # 현실적 초안: 대체로 검증기와 일치, 가끔 빗나감(수락률 < 1).
    def draft(seq): return verifier(seq) if (seq[-1] % 5) else (verifier(seq) + 1) % V
    total_calls = 0
    for start in range(1, 10):
        spec, calls = greedy_speculative([start], draft, verifier, k=4, steps=30)
        direct = greedy_direct([start], verifier, steps=30)
        assert spec == direct                                # 비트 동일(정확성은 무손실)
        assert calls <= 30                                   # 결코 더 나쁘지 않음
        total_calls += calls
    assert total_calls < 9 * 30                              # 순 검증기 호출 감소(이득)


def test_sampling_identity_min_plus_residual():
    rng = random.Random(0)
    for _ in range(200):
        n = 6
        p = [rng.random() for _ in range(n)]; sp = sum(p); p = [x/sp for x in p]
        q = [rng.random() for _ in range(n)]; sq = sum(q); q = [x/sq for x in q]
        assert identity_residual_holds(p, q)                 # min(p,q)+(p−q)₊=p


def test_speculative_sample_matches_verifier_distribution():
    rng = random.Random(1)
    p = [0.5, 0.3, 0.15, 0.05]
    q = [0.25, 0.25, 0.25, 0.25]
    N = 40000
    emp = [0, 0, 0, 0]
    for _ in range(N):
        emp[speculative_sample(p, q, rng)] += 1
    emp = [e / N for e in emp]
    tv = 0.5 * sum(abs(a - b) for a, b in zip(emp, p))
    assert tv < 0.01                                         # 검증기 분포와 동일(유한표본 잡음)


# ---- 문법 강제 (정리 A4) ----
def test_grammar_constrained_zero_violations():
    dfa = json_number_dfa()
    rng = random.Random(2)
    violations = 0
    for _ in range(3000):
        def logit(prefix, ch, _r=rng): return _r.uniform(-1, 1)
        s = generate_constrained(dfa, logit, max_len=30)
        if not dfa.accepts(s):
            violations += 1
    assert violations == 0                                   # 구조적 무결성: 위반 0

    # 대조: 같은 문자집합의 무작위 문자열은 대부분 수용 안 됨(비자명성)
    charset = "0123456789.eE+-abc"
    rng2 = random.Random(3); bad = 0
    for _ in range(3000):
        s = "".join(rng2.choice(charset) for _ in range(rng2.randint(1, 8)))
        if not dfa.accepts(s):
            bad += 1
    assert bad > 1500


def test_stub_json_schema_valid():
    b = StubBackend()
    out = b.generate("q", json_schema=answer_schema())
    obj = parse_json_lenient(out)
    assert obj is not None and "answer" in obj and "certainty" in obj


def test_certainty_grammar_string():
    g = certainty_grammar()
    assert "확실" in g and "불확실" in g and g.startswith("root ::=")


# ---- 구조화 추출 (§5) ----
def test_extract_entities_format_validated():
    def responder(p):
        return ('{"emails":["a@b.com","bogus"],"usernames":["hong"],'
                '"phones":["+821012345678"],"names":["김지완"]}')
    rt = Runtime(backend=StubBackend(responder))
    ents = extract_entities(rt, "아무 텍스트")
    emails = [e.value for e in ents if e.type is EntityType.EMAIL]
    assert "a@b.com" in emails and "bogus" not in emails      # 형식 검증으로 헛것 차단
    assert any(e.type is EntityType.NAME and e.value == "김지완" for e in ents)
