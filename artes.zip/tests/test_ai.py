from artes.ai.runtime import Runtime
from artes.ai.backend import StubBackend
from artes.ai import qa, interpret
from artes.ai.swarm import run_swarm, saturation_workers
from artes.core.model import Graph, Entity, Edge, EntityType, Certainty, Evidence


def _person_graph():
    g = Graph()
    name = g.add(Entity(EntityType.NAME, "김지완", Certainty.CONFIRMED,
                        evidence=[Evidence("입력", "")]))
    phone = g.add(Entity(EntityType.PHONE, "+821012345678", Certainty.CONFIRMED,
                         evidence=[Evidence("phoneinfoga", "")]))
    g.link(Edge(name.key, phone.key, "전화", Certainty.CONFIRMED,
                evidence=[Evidence("s", "확인")]))
    return g


def test_qa_structured_from_graph_no_ai():
    g = _person_graph()
    a = qa.answer(g, "김지완 전화번호 뭐야?")
    assert not a.used_ai                     # 코드로 답(AI 0회)
    assert "+821012345678" in a.text
    assert a.certainty == "confirmed"


def test_qa_missing_is_unknown():
    g = _person_graph()
    a = qa.answer(g, "김지완 이메일 뭐야?")
    assert not a.used_ai
    assert "확인 안 됨" in a.text


def test_qa_open_ended_hallucination_downgraded():
    g = _person_graph()
    rt = Runtime(backend=StubBackend(lambda p: "그의 이메일은 fake@evil.com 이다."))
    a = qa.answer(g, "이 사람에 대해 알려줘", runtime=rt)
    # 컨텍스트에 없는 이메일을 지어냄 → 확인 안 됨으로 강등
    assert a.used_ai and "확인 안 됨" in a.text


def test_interpret_reads_same_person_and_verifies():
    g = Graph()
    a1 = g.add(Entity(EntityType.ACCOUNT, "github/hong", Certainty.CONFIRMED,
                      attrs={"handle": "hong"}, evidence=[Evidence("s", "")]))
    a2 = g.add(Entity(EntityType.ACCOUNT, "twitter/hong2", Certainty.CONFIRMED,
                      attrs={"handle": "hong2"}, evidence=[Evidence("s", "")]))
    em = g.add(Entity(EntityType.EMAIL, "hong@x.com", Certainty.CONFIRMED,
                      evidence=[Evidence("s", "")]))
    g.link(Edge(a1.key, em.key, "이메일", Certainty.CONFIRMED, evidence=[Evidence("s", "")]))
    g.link(Edge(a2.key, em.key, "이메일", Certainty.CONFIRMED, evidence=[Evidence("s", "")]))
    rt = Runtime(backend=StubBackend(lambda p: "두 계정이 같은 이메일을 공유한다."))
    r = interpret.interpret(g, runtime=rt)
    assert r.facts["summary"]["entities"] == 3
    assert any(s["relation"] == "동일인" for s in r.same_person)
    assert r.used_ai and rt.calls.get("interpret") == 1


def test_swarm_saturation_bound():
    assert saturation_workers(50, server_parallel=4) <= (__import__("os").cpu_count() or 1)
    assert saturation_workers(50, server_parallel=4) <= 4

    calls = {"n": 0}
    def responder(p):
        if "하위작업" in p and "[작업]" in p:
            return "1. 파서 작성\n2. 테스트 작성\n3. 문서화"
        return "print('ok')"
    rt = Runtime(backend=StubBackend(responder))
    res = run_swarm(rt, "CSV 파서 만들기", max_subtasks=3, requested_workers=8,
                    server_parallel=2)
    assert len(res.plan) == 3
    assert len(res.pieces) == 3
    assert res.workers_used <= 2


def test_runtime_logs_calls():
    rt = Runtime(backend=StubBackend())
    rt.generate("chat", "안녕")
    rt.generate("chat", "또")
    assert rt.total_calls() == 2 and rt.is_stub
    assert rt.stats()["by_purpose"]["chat"] == 2
