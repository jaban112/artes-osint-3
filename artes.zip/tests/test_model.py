from artes.core.model import (Entity, Edge, EntityType, Certainty, Evidence, Graph)


def test_dedup_and_normalize():
    g = Graph()
    g.add(Entity(EntityType.EMAIL, "Hong@Gmail.com",
                 evidence=[Evidence("a", "x")]))
    g.add(Entity(EntityType.EMAIL, "hong@gmail.com",
                 evidence=[Evidence("b", "y")]))
    assert len(g.entities) == 1                     # 대소문자 정규화로 병합
    assert len(g.entities[0].evidence) == 2         # 근거는 합쳐진다


def test_certainty_wins():
    g = Graph()
    g.add(Entity(EntityType.USERNAME, "hong123", Certainty.UNCONFIRMED, 0.5,
                 evidence=[Evidence("a", "추정")]))
    g.add(Entity(EntityType.USERNAME, "hong123", Certainty.CONFIRMED,
                 evidence=[Evidence("b", "확인")]))
    e = g.entities[0]
    assert e.certainty is Certainty.CONFIRMED
    assert e.confidence == 1.0


def test_edge_needs_evidence():
    g = Graph()
    a = g.add(Entity(EntityType.EMAIL, "a@b.com", evidence=[Evidence("s", "")]))
    b = g.add(Entity(EntityType.USERNAME, "a", evidence=[Evidence("s", "")]))
    # 근거 없는 간선은 거부.
    assert g.link(Edge(a.key, b.key, "추정 아이디")) is None
    assert len(g.edges) == 0
    # 근거 있으면 통과.
    ok = g.link(Edge(a.key, b.key, "추정 아이디",
                     evidence=[Evidence("s", "로컬파트")]))
    assert ok is not None
    assert len(g.edges) == 1


def test_phone_normalize():
    g = Graph()
    g.add(Entity(EntityType.PHONE, "+82 10-1234-5678", evidence=[Evidence("s", "")]))
    g.add(Entity(EntityType.PHONE, "+821012345678", evidence=[Evidence("s", "")]))
    assert len(g.entities) == 1


def test_roundtrip():
    e = Entity(EntityType.ACCOUNT, "github/hong",
               certainty=Certainty.CONFIRMED,
               evidence=[Evidence("maigret", "found", url="http://x")])
    assert Entity.from_dict(e.to_dict()).key == e.key
