"""증분 27 — 이름→아이디 생성기 · 큰 SNS 존재확인 · 생년월일(DOB) 단위검증.

핵심 회귀 방지: '김지완'에서 인스타 아이디 '지완'/'jiwan'을 반드시 생성한다.
"""
from artes.core.namegen import name_handles, romanize, korean_name_handles, latin_name_handles
from artes.core.types import detect, normalize_dob
from artes.core.model import EntityType, Certainty
from artes.collectors.bigsocial_c import (TikTokProfile, YouTubeHandle, InstagramProfile,
                                          NaverBlog, GoogleAccountHint, Linktree)
from artes.collectors.registry import default_collectors


# ══════════ 이름→아이디 생성기 (핵심) ══════════
def test_korean_name_extracts_given_name_handle():
    # 사용자가 지적한 바로 그 케이스: 김지완 → 인스타 '지완'
    h = name_handles("김지완")
    assert "지완" in h            # 한글 이름만
    assert "jiwan" in h           # 로마자 이름만 ★
    assert "kimjiwan" in h        # 성+이름
    assert "김지완" in h          # 풀네임

def test_romanize_revised():
    assert romanize("지완") == "jiwan"
    assert romanize("아인") == "ain"

def test_korean_surname_variants():
    h = korean_name_handles("이서연")
    # 이 = lee/yi, 서연 = seoyeon
    assert "서연" in h
    assert any(x.startswith("lee") or x == "seoyeon" or "yi" in x for x in h)

def test_latin_name_handles():
    h = latin_name_handles("John Smith")
    assert "john" in h and "jsmith" in h and "johnsmith" in h and "john.smith" in h

def test_single_token_name():
    assert name_handles("madonna")           # 크래시 없이 후보 생성


# ══════════ 생년월일(DOB) ══════════
def test_dob_detection_various():
    assert detect("1998-03-15") is EntityType.DOB
    assert detect("19980315") is EntityType.DOB
    assert detect("15.03.1998") is EntityType.DOB

def test_dob_normalization_iso():
    assert normalize_dob("19980315") == "1998-03-15"
    assert normalize_dob("15/03/1998") == "1998-03-15"
    assert normalize_dob("1990-01-01T00:00:00+00:00") == "1990-01-01"

def test_dob_not_phone_or_year():
    # 전화·연도 오인 방지
    assert detect("01012345678") is EntityType.PHONE
    assert normalize_dob("1998") is None            # 연도 단독은 DOB 아님
    assert normalize_dob("20250230") is None        # 2월 30일 무효

def test_dob_in_shared_identifier_correlation():
    from artes.core.resolve import EntityResolver
    import inspect
    src = inspect.getsource(EntityResolver._shared_identifier_pairs)
    assert "DOB" in src                             # 생년월일이 동일인 상관 앵커에 포함

def test_dob_emitted_from_profile_birthday():
    from artes.collectors.social5_c import JikanMAL
    u = {"username": "amy", "birthday": "1995-07-20T00:00:00+00:00",
         "url": "https://myanimelist.net/profile/amy", "location": "Seoul"}
    res = JikanMAL().parse(u, "amy")
    dobs = [e for e in res.entities if e.type == EntityType.DOB]
    assert dobs and dobs[0].value == "1995-07-20"


# ══════════ 큰 SNS 존재확인 ══════════
def test_tiktok_oembed():
    d = {"author_name": "Jane", "author_unique_id": "jane", "thumbnail_url": "x"}
    res = TikTokProfile().parse(d, "jane")
    acc = [e for e in res.entities if e.type == EntityType.ACCOUNT][0]
    assert acc.value == "tiktok/jane"
    assert acc.attrs["display"] == "Jane"

def test_youtube_channel():
    html = '<meta property="og:title" content="Jane Channel"><meta property="og:description" content="hi https://jane.com">'
    res = YouTubeHandle().parse(html, "jane", "Jane Channel")
    kinds = {(e.type, e.value) for e in res.entities}
    assert (EntityType.ACCOUNT, "youtube/jane") in kinds
    assert (EntityType.URL, "https://jane.com") in kinds

def test_instagram_public_preview():
    html = ('<html>instagram.com<meta property="og:title" content="Jane (@jane)">'
            '<meta property="og:description" content="dev · https://jane.dev">')
    res = InstagramProfile().parse(html, "jane", "Jane (@jane)")
    acc = [e for e in res.entities if e.type == EntityType.ACCOUNT][0]
    assert acc.value == "instagram/jane"
    assert "소유자 확인" in acc.attrs["note"]

def test_naver_blog():
    html = '<meta property="og:title" content="지완의 블로그"><div id="blogView">x</div>'
    res = NaverBlog().parse(html, "jiwan", "지완의 블로그")
    acc = [e for e in res.entities if e.type == EntityType.ACCOUNT][0]
    assert acc.value == "naver-blog/jiwan"

def test_google_hint_only_gmail():
    import asyncio
    # 비-gmail은 신호 없음
    r = asyncio.run(GoogleAccountHint().collect("a@company.com", EntityType.EMAIL, {}))
    assert r.ok and not r.entities
    # gmail은 시사(불확실)
    res = GoogleAccountHint().parse("victim@gmail.com")
    acc = [e for e in res.entities if e.type == EntityType.ACCOUNT][0]
    assert acc.certainty is Certainty.UNCONFIRMED and "google" in acc.value

def test_linktree_link_aggregation():
    html = '<meta property="og:title" content="jiwan"><a>x</a>"url":"https://instagram.com/jiwan""url":"https://twitter.com/jiwan"'
    res = Linktree().parse(html, "jiwan")
    urls = {e.value for e in res.entities if e.type == EntityType.URL}
    assert "https://instagram.com/jiwan" in urls


# ══════════ 배선 · 후보 검증 경로 ══════════
def test_bigsocial_registered():
    names = {c.name for c in default_collectors(real=True)}
    assert {"instagram", "tiktok", "youtube", "threads", "pinterest", "snapchat",
            "naver-blog", "linktree", "google-account-hint"} <= names

def test_bigsocial_runs_on_candidates_not_seed_skipped():
    # 큰 SNS 확인기는 whatsmyname처럼 씨앗-한정 skip이 없어야 한다(후보에도 돌아야 함)
    import inspect
    for C in (InstagramProfile, TikTokProfile, YouTubeHandle, NaverBlog):
        src = inspect.getsource(C.collect)
        assert 'ctx' not in src or 'depth' not in src   # depth 기반 skip 없음

def test_permute_uses_namegen_for_name():
    from artes.collectors.enrich_c import PermuteUsernames
    import asyncio
    res = asyncio.run(PermuteUsernames().collect("김지완", EntityType.NAME, {"depth": 0}))
    vals = {e.value for e in res.entities}
    assert "지완" in vals and "jiwan" in vals        # 이름 생성기 경유 확인
