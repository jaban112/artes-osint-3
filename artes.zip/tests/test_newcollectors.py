"""신규 수집기 — PhoneInfo(순수)·소셜·IP·개발자 파서."""
import asyncio

from artes.core.model import EntityType
from artes.collectors.phone2_c import PhoneInfo
from artes.collectors.social_c import Reddit, HackerNews, GitLab, WebFinger
from artes.collectors.net2_c import ASNLookup, IPGeo, HTTPHeaders
from artes.collectors.dev2_c import GitHubGists, NpmMaintainer, _ssh_fingerprint


def test_phoneinfo_offline():
    res = asyncio.run(PhoneInfo().collect("+821012345678", EntityType.PHONE, {}))
    assert res.ok and res.entities
    a = res.entities[0].attrs
    assert a["country_code"] == "82"
    assert a["timezones"] and "line_type" in a


def test_reddit_parse():
    data = {"data": {"created_utc": 1500000000, "total_karma": 4200,
                     "subreddit": {"public_description": "hi"}}}
    res = Reddit().parse(data, "hong")
    assert any(e.value == "reddit/hong" for e in res.entities)
    acc = [e for e in res.entities if e.type is EntityType.ACCOUNT][0]
    assert acc.attrs["created_at"].startswith("2017")


def test_hackernews_parse():
    res = HackerNews().parse({"id": "hong", "created": 1400000000, "karma": 99, "about": "dev"}, "hong")
    assert any(e.value == "hackernews/hong" for e in res.entities)


def test_gitlab_parse():
    res = GitLab().parse([{"username": "hong", "name": "Hong Kim",
                           "web_url": "https://gitlab.com/hong", "bio": "x"}], "hong")
    assert any(e.value == "gitlab/hong" for e in res.entities)
    assert any(e.type is EntityType.NAME and e.value == "Hong Kim" for e in res.entities)


def test_webfinger_parse():
    data = {"links": [{"rel": "self", "href": "https://mastodon.social/users/hong"},
                      {"rel": "http://webfinger.net/rel/avatar", "href": "https://x/a.png"}]}
    res = WebFinger().parse(data, "hong@mastodon.social")
    urls = {e.value for e in res.entities}
    assert "https://mastodon.social/users/hong" in urls
    assert "https://x/a.png" not in urls          # avatar rel 제외


def test_asn_parse():
    data = {"status": "ok", "data": {"prefixes": [
        {"prefix": "1.2.0.0/16", "asn": {"asn": 4766, "name": "KT"}}]}}
    res = ASNLookup().parse(data, "1.2.3.4")
    assert res.entities and res.entities[0].attrs["asn"] == "AS4766"


def test_ipgeo_parse():
    data = {"status": "success", "country": "South Korea", "city": "Seoul",
            "isp": "KT", "org": "KT", "lat": 37.5, "lon": 127.0}
    res = IPGeo().parse(data, "1.2.3.4")
    assert res.entities[0].attrs["country"] == "South Korea"


def test_httphdr_parse():
    res = HTTPHeaders().parse({"Server": "nginx", "X-Powered-By": "PHP/8.1",
                               "Content-Type": "text/html"}, "example.com")
    tech = res.entities[0].attrs["tech"]
    assert tech.get("server") == "nginx" and "x-powered-by" in tech


def test_ssh_fingerprint():
    import base64
    blob = b"\x00\x00\x00\x0bssh-ed25519\x00\x00\x00 " + b"\x11" * 32
    line = "ssh-ed25519 " + base64.b64encode(blob).decode() + " user@host"
    fp = _ssh_fingerprint(line)
    assert fp and fp.startswith("SHA256:")
    assert _ssh_fingerprint("not a key") is None


def test_gists_email_extraction():
    data = [{"html_url": "https://gist.github.com/abc", "description": "config real@dev.com",
             "files": {"a.py": {}}}]
    res = GitHubGists().parse(data, "hong")
    assert any(e.type is EntityType.EMAIL and e.value == "real@dev.com" for e in res.entities)


def test_npm_parse():
    data = {"objects": [{"package": {"name": "cool-lib",
                                     "links": {"npm": "https://npmjs.com/package/cool-lib"},
                                     "author": {"email": "dev@x.com"}}}]}
    res = NpmMaintainer().parse(data, "hong")
    assert any("cool-lib" in (e.attrs.get("package") or "") for e in res.entities)
    assert any(e.type is EntityType.EMAIL and e.value == "dev@x.com" for e in res.entities)
