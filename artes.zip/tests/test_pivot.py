"""자동 피벗 — 셀렉터 승격·공유 셀렉터 하드 신호·investigate."""
import asyncio
import tempfile

from artes.core.model import Graph, Entity, Edge, EntityType, Certainty, Evidence
from artes.core.pivot import promote_selectors, AutoPivot
from artes.core.resolve import EntityResolver
from artes.core.cache import Cache
from artes.collectors import mock

BTC = "1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa"


def test_promote_selectors():
    g = Graph()
    g.add(Entity(EntityType.ACCOUNT, "github/x", Certainty.CONFIRMED,
                 attrs={"handle": "x", "bio": f"donate {BTC} thanks"},
                 evidence=[Evidence("t", "")]))
    n = promote_selectors(g)
    assert n >= 1
    assert any(e.type is EntityType.TRACKER and e.value == f"crypto:{BTC}" for e in g.entities)


def test_shared_crypto_is_same_person():
    g = Graph()
    a = g.add(Entity(EntityType.ACCOUNT, "github/aaa", Certainty.CONFIRMED,
                     attrs={"handle": "aaa", "bio": f"tips {BTC}"}, evidence=[Evidence("t", "")]))
    b = g.add(Entity(EntityType.ACCOUNT, "twitter/bbb", Certainty.CONFIRMED,
                     attrs={"handle": "bbb", "bio": f"wallet {BTC}"}, evidence=[Evidence("t", "")]))
    promote_selectors(g)
    added = EntityResolver().correlate(g)
    same = [e for e in added if e.relation == "동일인" and e.certainty is Certainty.CONFIRMED]
    assert same, "같은 암호화폐 주소 공유 → 확실 동일인"


def test_autopivot_investigate_runs():
    async def go():
        ap = AutoPivot(mock.DEFAULTS, cache=Cache(root=tempfile.mkdtemp()),
                       max_rounds=2, depth=1)
        g = await ap.investigate(["hong@gmail.com"])
        return g, ap.rounds_log
    g, log = asyncio.run(go())
    assert g.stats()["entities"] >= 3
    assert isinstance(log, list)
