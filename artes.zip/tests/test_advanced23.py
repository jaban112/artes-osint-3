"""증분 32 — 확장 프론티어 우선순위·상한(병목) + clearnet 다크웹(무키) 검증."""
from artes.core.model import Entity, EntityType, Certainty
from artes.collectors.darkweb2_c import RansomwareLive, RansomLook, Ahmia
from artes.collectors.registry import default_collectors


# ══════════ 엔진 프론티어 우선순위·상한 ══════════
def _mk(t, v, cert=Certainty.UNCONFIRMED, variant=False, conf=0.0):
    return Entity(t, v, cert, confidence=conf, attrs={"variant": True} if variant else {})

def test_frontier_cap_and_priority():
    from artes.core.engine import Engine
    eng = Engine([], use_bandit=False, max_frontier=3)
    ents = [
        _mk(EntityType.NAME, "순열1", variant=True),
        _mk(EntityType.NAME, "순열2", variant=True),
        _mk(EntityType.EMAIL, "a@b.com", cert=Certainty.CONFIRMED),   # 강한 단서=최상
        _mk(EntityType.USERNAME, "jiwan", cert=Certainty.CONFIRMED),
        _mk(EntityType.DOMAIN, "x.com"),
    ]
    out = eng._prioritize_frontier(ents)
    assert len(out) == 3                                  # 상한 적용
    assert out[0].value == "a@b.com"                      # 확인된 이메일 최우선
    assert all((e.attrs or {}).get("variant") is not True for e in out)  # 순열은 밀림

def test_frontier_default_cap_exists():
    from artes.core.engine import Engine
    assert Engine([], use_bandit=False).max_frontier >= 24


# ══════════ 랜섬웨어 clearnet(무키·Tor불필요) ══════════
def test_ransomware_live_parse():
    rows = [{"victim": "Acme Corp", "group": "LockBit", "discovered": "2026-01-15T00:00:00",
             "url": "http://leak.onion/acme"}]
    res = RansomwareLive().parse(rows, "acme.com")
    b = [e for e in res.entities if e.type == EntityType.BREACH][0]
    assert "Acme Corp" in b.value and "LockBit" in b.value
    assert b.attrs["kind"] == "ransomware"
    assert b.attrs["date"] == "2026-01-15"

def test_ransomlook_parse():
    rows = [{"post_title": "Victim Inc", "group": "BlackCat", "date": "2026-02",
             "link": "http://x.onion"}]
    res = RansomLook().parse(rows, "victim inc")
    assert any(e.type == EntityType.BREACH and "Victim Inc" in e.value for e in res.entities)


# ══════════ Ahmia clearnet(.onion 검색, 안전필터) ══════════
def test_ahmia_extracts_onion_urls():
    html = ('results: <a href="http://juhanurmihxlp77nkq76byazcldy2hlmovfu2epvl5ankdibsot4csyd.onion/x">r1</a> '
            'redirect_url=https://abcdefghij234567.onion/leak')
    res = Ahmia().parse(html, "target", EntityType.NAME)
    urls = [e for e in res.entities if e.type == EntityType.URL]
    assert urls and all(".onion" in u.value for u in urls)
    assert all(u.attrs.get("darkweb") for u in urls)

def test_ahmia_seed_only():
    import asyncio
    r = asyncio.run(Ahmia().collect("target", EntityType.NAME, {"depth": 1}))
    assert r.skipped

def test_ahmia_safety_filter_applied(monkeypatch):
    import artes.collectors.darkweb2_c as dw
    # FILTER가 차단하면 그 URL은 결과에 안 들어감
    monkeypatch.setattr(dw.FILTER, "is_blocked", lambda s: "bad" in s)
    html = 'http://gooddddddddddddd23.onion/x http://baddddddddddddd234.onion/y'
    res = dw.Ahmia().parse(html, "t", EntityType.NAME)
    vals = [e.value for e in res.entities if e.type == EntityType.URL]
    assert any("good" in v for v in vals) and not any("bad" in v for v in vals)


# ══════════ 배선 ══════════
def test_darkweb_wiring():
    default = {c.name for c in default_collectors(real=True)}
    assert {"ransomware-live", "ransomlook"} <= default      # clearnet=기본 축
    assert "ahmia" not in default                            # Ahmia=다크웹 축 전용
    dw = {c.name for c in default_collectors(real=True, enable_darkweb=True)}
    assert "ahmia" in dw
