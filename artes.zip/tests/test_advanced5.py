"""증분 11 — 더 빠르게·더 깊이·더 강하게 검증.

속도: AIMD 적응형 동시성·토큰버킷·요청합류·TTL캐시.
심층: 시드 PPR·매개중심성·집합적 ER·링크예측·k-core·이분투영·경로·피벗랭킹.
견고성: 진실발견·독립성·봇점수·동형이의어·신선도감쇠·Dempster-Shafer·SybilRank·게이트.
"""
import asyncio
import time

from artes.core import adaptive as A
from artes.core import graphx as GX
from artes.core import trust as T
from artes.core.model import Graph, Entity, Edge, EntityType, Certainty, Evidence


# ══════════ 더 빠르게 ══════════
def test_aimd_limiter_adjusts():
    lim = A.AdaptiveLimiter(start=4, min_limit=1, max_limit=16)
    async def go():
        await lim.acquire(); lim.release(ok=True)       # 포화 아니라 유지~증가
        base = lim.limit
        await lim.acquire(); lim.release(throttled=True)  # 429 → 승법 감소
        return base
    base = asyncio.run(go())
    assert lim.limit < base or lim.limit <= 4            # throttle이 한계를 낮춤

def test_token_bucket_refill():
    tb = A.TokenBucket(rate=10.0, capacity=2.0)
    tb.tokens = 0.0
    assert tb._refill_take(now=tb.updated) is False       # 토큰 없음
    assert tb._refill_take(now=tb.updated + 1.0) is True   # 1초 뒤 리필

def test_single_flight_coalesces():
    sf = A.SingleFlight()
    calls = {"n": 0}
    async def factory():
        calls["n"] += 1
        await asyncio.sleep(0.02)
        return "R"
    async def go():
        # 동일 키 5 동시 요청 → 네트워크 1회.
        res = await asyncio.gather(*[sf.do("k", factory) for _ in range(5)])
        return res
    res = asyncio.run(go())
    assert res == ["R"] * 5
    assert calls["n"] == 1 and sf.coalesced == 4

def test_ttl_cache_expiry_and_lru():
    c = A.TTLCache(maxsize=2, ttl=10.0)
    c.put("a", 1, now=0.0)
    assert c.get("a", now=1.0) == 1                       # 유효
    assert c.get("a", now=20.0) is None                  # 만료
    c.put("x", 1, now=0); c.put("y", 2, now=0); c.put("z", 3, now=0)
    assert c.get("x", now=0) is None                     # LRU 축출


# ══════════ 더 깊이 ══════════
def _chain_graph():
    g = Graph()
    for h in ("a", "b", "c", "d"):
        g.add(Entity(EntityType.ACCOUNT, f"s/{h}", Certainty.CONFIRMED,
                     attrs={"handle": h}, evidence=[Evidence("t", "")]))
    g.link(Edge("account:s/a", "account:s/b", "관련", Certainty.CONFIRMED,
               evidence=[Evidence("t", "")]))
    g.link(Edge("account:s/b", "account:s/c", "관련", Certainty.CONFIRMED,
               evidence=[Evidence("t", "")]))
    g.link(Edge("account:s/c", "account:s/d", "관련", Certainty.CONFIRMED,
               evidence=[Evidence("t", "")]))
    return g

def test_personalized_pagerank_seed_bias():
    adj = GX.build_adj(_chain_graph())
    ppr = GX.personalized_pagerank(adj, ["account:s/a"])
    # 시드 a에서 가까운 b가 먼 d보다 높은 점수.
    assert ppr["account:s/b"] > ppr["account:s/d"]

def test_betweenness_finds_broker():
    adj = GX.build_adj(_chain_graph())
    btw = GX.betweenness(adj)
    # 사슬 a-b-c-d에서 b,c가 매개중심(브로커) 상위.
    top = list(btw.keys())[0]
    assert top in ("account:s/b", "account:s/c")

def test_propagate_identity_transitive():
    adj = GX.build_adj(_chain_graph())
    labels = GX.propagate_identity(adj, {"account:s/a": "P1"})
    # a에 고정된 라벨이 사슬로 전파.
    assert labels["account:s/b"] == "P1"

def test_link_prediction_common_neighbor():
    g = Graph()
    for h in ("hub", "x", "y"):
        g.add(Entity(EntityType.ACCOUNT, f"s/{h}", Certainty.CONFIRMED,
                     attrs={"handle": h}, evidence=[Evidence("t", "")]))
    g.link(Edge("account:s/hub", "account:s/x", "r", Certainty.CONFIRMED,
               evidence=[Evidence("t", "")]))
    g.link(Edge("account:s/hub", "account:s/y", "r", Certainty.CONFIRMED,
               evidence=[Evidence("t", "")]))
    adj = GX.build_adj(g)
    preds = GX.link_prediction(adj, method="common")
    pair = {preds[0][0], preds[0][1]}
    assert pair == {"account:s/x", "account:s/y"}         # 공통이웃 hub

def test_core_numbers_triangle():
    g = Graph()
    for h in ("a", "b", "c", "d"):
        g.add(Entity(EntityType.ACCOUNT, f"s/{h}", Certainty.CONFIRMED,
                     attrs={"handle": h}, evidence=[Evidence("t", "")]))
    # 삼각형 a-b-c(코어2) + 꼬리 d.
    for u, v in [("a", "b"), ("b", "c"), ("a", "c"), ("c", "d")]:
        g.link(Edge(f"account:s/{u}", f"account:s/{v}", "r", Certainty.CONFIRMED,
                   evidence=[Evidence("t", "")]))
    core = GX.core_numbers(GX.build_adj(g))
    assert core["account:s/a"] == 2 and core["account:s/d"] == 1

def test_bipartite_cooccur_shared_tracker():
    g = Graph()
    g.add(Entity(EntityType.DOMAIN, "x.com", Certainty.CONFIRMED, evidence=[Evidence("t", "")]))
    g.add(Entity(EntityType.DOMAIN, "y.com", Certainty.CONFIRMED, evidence=[Evidence("t", "")]))
    tk = g.add(Entity(EntityType.TRACKER, "ga/UA-1", Certainty.CONFIRMED,
                      attrs={"kind": "ga"}, evidence=[Evidence("t", "")]))
    g.link(Edge("domain:x.com", tk.key, "추적ID", Certainty.CONFIRMED,
               evidence=[Evidence("t", "")]))
    g.link(Edge("domain:y.com", tk.key, "추적ID", Certainty.CONFIRMED,
               evidence=[Evidence("t", "")]))
    pairs = GX.bipartite_cooccur(g, {"domain"}, {"tracker"})
    assert pairs and {pairs[0][0], pairs[0][1]} == {"domain:x.com", "domain:y.com"}

def test_shortest_and_simple_paths():
    adj = GX.build_adj(_chain_graph())
    sp = GX.shortest_path(adj, "account:s/a", "account:s/d")
    assert sp[0] == "account:s/a" and sp[-1] == "account:s/d" and len(sp) == 4
    paths = GX.all_simple_paths(adj, "account:s/a", "account:s/c", cutoff=4)
    assert any(p[-1] == "account:s/c" for p in paths)

def test_rank_pivots_smoke():
    g = _chain_graph()
    ranked = GX.rank_pivots(g, ["account:s/a"])
    assert ranked and all(len(t) == 2 for t in ranked)
    assert "account:s/a" not in [k for k, _ in ranked]    # 시드 제외


# ══════════ 더 강하게 ══════════
def test_truth_discovery_reliability():
    # 신뢰 소스 다수가 '값A', 잡음 소스 하나가 '값B' → A 믿음↑.
    claims = [("s1", "A"), ("s2", "A"), ("s3", "A"), ("spam", "B"),
              ("spam", "C"), ("spam", "D")]
    out = T.truth_discovery(claims)
    assert out["belief"]["A"] > out["belief"]["B"]
    assert out["trust"]["s1"] >= out["trust"]["spam"]     # 다작 스팸 감쇠

def test_independence_grouping():
    # s2,s3가 s1의 재게시(상관) → 독립 원천 2(그룹{s1,s2,s3}+s4).
    n = T.independent_count(["s1", "s2", "s3", "s4"],
                            [("s1", "s2"), ("s2", "s3")])
    assert n == 2

def test_bot_score_features():
    human = T.bot_score({"age_days": 800, "statuses": 400, "followers": 300,
                         "following": 280, "handle": "jiwan_kim"})
    bot = T.bot_score({"age_days": 5, "statuses": 5000, "followers": 2,
                      "following": 4000, "default_avatar": True,
                      "handle": "x7bk93qz8f"})
    assert bot > human

def test_confusable_and_mixed_script():
    assert T.is_confusable("pаypal", "paypal")            # 키릴 а
    assert not T.is_confusable("paypal", "paypal")        # 동일은 제외
    assert T.mixed_script("pаypal")                       # 라틴+키릴 혼용

def test_decay_weight():
    assert T.decay_weight(0, "account") == 1.0
    fresh = T.decay_weight(30, "ip")                      # ip 반감기 30일 → 0.5
    assert abs(fresh - 0.5) < 0.01
    assert T.decay_weight(3650, "dob") > 0.9              # dob 거의 안 감쇠

def test_dempster_shafer_yager():
    # 두 소스 모두 same 강함 → belief_same 높음.
    out = T.ds_combine([{"same": 0.8, "both": 0.2}, {"same": 0.7, "both": 0.3}])
    assert out["belief_same"] > 0.5 and out["plausibility_same"] >= out["belief_same"]
    # 고충돌(한 쪽 same, 다른 쪽 different) → Yager는 both로 흡수(거짓확신 방지).
    conf = T.ds_combine([{"same": 0.9, "both": 0.1}, {"different": 0.9, "both": 0.1}],
                        rule="yager")
    assert conf["both"] > 0.5 and conf["conflict"] > 0.5

def test_sybil_rank_demotes_outsiders():
    g = Graph()
    for h in ("t1", "t2", "sybil"):
        g.add(Entity(EntityType.ACCOUNT, f"s/{h}", Certainty.CONFIRMED,
                     attrs={"handle": h}, evidence=[Evidence("t", "")]))
    # 신뢰 t1-t2 강결합, sybil은 t1에 얇은 간선 하나.
    g.link(Edge("account:s/t1", "account:s/t2", "r", Certainty.CONFIRMED,
               evidence=[Evidence("t", "")]))
    g.link(Edge("account:s/t1", "account:s/sybil", "r", Certainty.UNCONFIRMED, 0.3,
               evidence=[Evidence("t", "")]))
    adj = GX.build_adj(g)
    ranks = T.sybil_rank(adj, ["account:s/t1", "account:s/t2"])
    assert ranks["account:s/sybil"] <= ranks["account:s/t2"]

def test_defense_in_depth_gate():
    # 믿음 높아도 독립원천 1개면 확정 불가.
    assert T.classify_confidence(0.95, independent_origins=1, modality_classes=1) == "불확실"
    assert T.classify_confidence(0.95, independent_origins=2, modality_classes=2) == "확실"
    assert T.classify_confidence(0.1, independent_origins=3, modality_classes=3) == "insufficient_evidence"
