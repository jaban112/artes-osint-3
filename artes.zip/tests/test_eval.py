"""평가 하네스 + LR 교정."""
from artes.evaluation import build_eval_graph, evaluate, sweep, calibrate_lr, predicted_pairs


def test_gold_and_evaluate():
    g, gold = build_eval_graph(n_people=8, seed=0)
    assert gold                                   # 정답 쌍 존재
    r = evaluate(g, gold, threshold=0.5)
    assert r["precision"] >= 0.7                   # 타인 오결합 적음
    assert 0.0 < r["recall"] <= 1.0                # 하네스가 재현율을 실측(값 자체는 개선 대상)
    assert 0.0 <= r["f1"] <= 1.0
    assert r["tp"] + r["fp"] + r["fn"] > 0         # 실제로 측정됨


def test_sweep_recall_monotone():
    s = sweep(n_people=8, seed=0, thresholds=(0.1, 0.5, 0.9))
    recalls = [x["recall"] for x in s]
    assert recalls[0] >= recalls[-1]              # 임계 높을수록 재현율 ↓(또는 동일)


def test_calibrate_lr_gt_one():
    c = calibrate_lr(n_people=20, seed=1)
    assert c["empirical_lr"] is not None
    assert c["empirical_lr"] > 1.0                 # 이름유사는 동일인에서 더 흔함
