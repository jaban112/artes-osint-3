"""오프라인 쇼케이스 그래프 — 전 신호가 실제로 발화하는지."""
from artes.core.demo import build_demo_graph
from artes.core.resolve import EntityResolver, correlate_owners
from artes.core.model import Certainty
from artes.core import selectors, timeline


def test_demo_signals_fire():
    g = build_demo_graph()
    added = EntityResolver().correlate(g)
    owners = correlate_owners(g)

    same_confirmed = [e for e in added if e.relation == "동일인"
                      and e.certainty is Certainty.CONFIRMED]
    same_graded = [e for e in added if e.relation == "동일인?"]
    assert same_confirmed, "같은 사진+bio+공유 이메일 → 확실 동일인"
    assert owners, "같은 추적 ID → 동일 운영자"

    # 셀렉터에 암호화폐·이메일·전화
    kinds = {s["kind"] for s in selectors.extract_selectors(g)}
    assert "crypto" in kinds and "email" in kinds and "phone" in kinds

    # 타임라인에 여러 날짜
    tl = timeline.build_timeline(g)
    assert len(tl) >= 3
    assert tl == sorted(tl, key=lambda x: x["date"])
