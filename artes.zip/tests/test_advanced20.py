"""증분 29 — 실시간 웹 검색 수집(DuckDuckGo) 파서·엔티티 추출 단위검증."""
from artes.collectors.websearch_c import WebMentions, LeakMentions, parse_ddg, _decode_ddg
from artes.core.model import EntityType
from artes.collectors.registry import default_collectors

_HTML = '''
<a class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fwww.instagram.com%2Fjiwan">Jiwan (@jiwan)</a>
<a class="result__snippet">reach me at jiwan@gmail.com</a>
<a class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fgithub.com%2Fjiwan">jiwan GitHub</a>
<a class="result__snippet">developer</a>
<a class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Ftwitter.com%2Fjiwan_official">jiwan on X</a>
<a class="result__snippet">hi</a>
'''


def test_ddg_decode_redirect():
    href = "//duckduckgo.com/l/?uddg=https%3A%2F%2Fexample.com%2Fx"
    assert _decode_ddg(href) == "https://example.com/x"

def test_ddg_parse_results():
    r = parse_ddg(_HTML)
    assert len(r) == 3
    assert r[0]["url"] == "https://www.instagram.com/jiwan"
    assert "jiwan@gmail.com" in r[0]["snippet"]

def test_webmentions_extracts_socials_and_email():
    res = WebMentions().parse(_HTML, "김지완", EntityType.NAME)
    kinds = {(e.type, e.value) for e in res.entities}
    assert (EntityType.ACCOUNT, "instagram/jiwan") in kinds     # 검색서 인스타 발견
    assert (EntityType.ACCOUNT, "github/jiwan") in kinds
    assert (EntityType.ACCOUNT, "twitter/jiwan_official") in kinds
    assert (EntityType.USERNAME, "jiwan") in kinds              # 아이디 추출
    assert (EntityType.EMAIL, "jiwan@gmail.com") in kinds       # 스니펫 이메일
    assert (EntityType.URL, "https://www.instagram.com/jiwan") in kinds

def test_webmentions_seed_only():
    import asyncio
    res = asyncio.run(WebMentions().collect("김지완", EntityType.NAME, {"depth": 1}))
    assert res.skipped                                          # 후보엔 검색 안 함

def test_webmentions_query_shapes():
    w = WebMentions()
    assert any("instagram" in q for q in w._queries("김지완", EntityType.NAME))
    assert w._queries("a@b.com", EntityType.EMAIL)[0] == '"a@b.com"'

def test_leak_mentions_urls_only_no_credentials():
    html = ('<a class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fpaste.ee%2Fx">'
            'combolist dump</a><a class="result__snippet">victim@x.com:password123</a>')
    res = LeakMentions().parse(html, "victim@x.com", EntityType.EMAIL)
    # URL(노출 참조)만 나오고, 스니펫의 평문 비번은 엔티티로 저장 안 됨
    urls = [e for e in res.entities if e.type == EntityType.URL]
    assert urls and urls[0].attrs.get("leak_reference") is True
    blob = str([(e.type.name, e.value, e.attrs) for e in res.entities])
    assert "password123" not in blob                            # 평문 미저장

def test_registered():
    names = {c.name for c in default_collectors(real=True)}
    assert {"web-mentions", "leak-mentions"} <= names


# ══════════ 증분29b — 다중 검색엔진 병렬 ══════════
def test_engine_parsers():
    from artes.collectors.websearch_c import parse_searx, parse_marginalia, parse_mojeek
    assert parse_searx({"results": [{"url": "https://a.com", "title": "A", "content": "s"}]})[0]["snippet"] == "s"
    assert parse_marginalia({"results": [{"url": "https://b.com", "title": "B", "description": "d"}]})[0]["url"] == "https://b.com"
    assert parse_mojeek('<a class="ob" href="https://c.com">C</a>')[0]["url"] == "https://c.com"

def test_multi_search_merges_and_dedupes(monkeypatch):
    import asyncio
    import artes.collectors.websearch_c as ws
    async def e_ddg(q, t, l): return [{"url": "https://dup.com/", "title": "d", "snippet": ""}]
    async def e_searx(q, t, l): return [{"url": "https://dup.com", "title": "d2", "snippet": ""},
                                        {"url": "https://uniq.com", "title": "u", "snippet": ""}]
    async def e_moj(q, t, l): raise RuntimeError("engine down")   # 한 엔진 실패해도 나머지 유지
    async def e_marg(q, t, l): return []
    monkeypatch.setattr(ws, "_engine_ddg", e_ddg)
    monkeypatch.setattr(ws, "_engine_searx", e_searx)
    monkeypatch.setattr(ws, "_engine_mojeek", e_moj)
    monkeypatch.setattr(ws, "_engine_marginalia", e_marg)
    out = asyncio.run(ws.multi_search("q", 5, 12))
    urls = {o["url"].rstrip("/") for o in out}
    assert urls == {"https://dup.com", "https://uniq.com"}       # 중복 접힘·실패 엔진 무시
