"""7권 대량검색 프리미티브 — 논문 검증치 재현(여기서 실제 실행)."""
import random

from artes.bigdata.aho import AhoCorasick
from artes.bigdata.bloom import BloomFilter
from artes.bigdata.sketch import HyperLogLog, CountMin
from artes.bigdata.bandit import Bandit


def test_aho_corasick_matches_bruteforce():
    patterns = ["hong@x.com", "jiwan", "010-1234", "kimjiwan", "seoul"]
    text = "연락 jiwan 아이디, 메일 hong@x.com, 번호 010-1234-5678, kimjiwan 서울 seoul 거주"
    ac = AhoCorasick(patterns)
    found = ac.found_patterns(text)
    brute = {p for p in patterns if p.casefold() in text.casefold()}
    assert found == brute                          # 위음성 0·위양성 0
    assert "jiwan" in found and "hong@x.com" in found


def test_aho_single_scan_all_positions():
    ac = AhoCorasick(["ab", "bc", "abc"])
    hits = ac.search("zabcz")
    got = {(p) for _, p, _ in hits}
    assert got == {"ab", "bc", "abc"}              # 한 스캔에 겹치는 패턴 전부


def test_bloom_no_false_negatives():
    bf = BloomFilter(capacity=20000, error_rate=0.01)
    keys = [f"user{i}@site{i%7}.com" for i in range(20000)]
    for k in keys:
        bf.add(k)
    assert all(k in bf for k in keys)              # 위음성 0 (구성)
    # 위양성률: 미삽입 키로 측정 → 목표 근방
    miss = [f"absent{i}" for i in range(20000)]
    fp = sum(1 for k in miss if k in bf) / len(miss)
    assert fp < 0.03                               # 목표 0.01의 3배 이내


def test_bloom_dedup():
    bf = BloomFilter(capacity=1000)
    assert bf.add_if_absent("a") is True
    assert bf.add_if_absent("a") is False          # 두 번째는 중복


def test_hyperloglog_relative_error():
    hll = HyperLogLog(p=14)                         # m=16384, rse≈0.008
    n = 50000
    for i in range(n):
        hll.add(f"item-{i}")
    est = hll.count()
    rel = abs(est - n) / n
    assert rel < 0.03                              # 약 3×rse 이내


def test_countmin_never_underestimates():
    cm = CountMin(epsilon=0.001, delta=0.01)
    truth = {}
    rnd = random.Random(1)
    for _ in range(200000):
        # 지프형: 소수 아이템이 자주.
        item = f"id{int(abs(rnd.gauss(0, 30)))}"
        cm.add(item); truth[item] = truth.get(item, 0) + 1
    bound = cm.error_bound()
    for item, c in list(truth.items())[:500]:
        est = cm.estimate(item)
        assert est >= c                            # 과대추정만(위축 0)
        assert est - c <= bound                    # εN 경계


def test_bandit_learns_best_arm():
    probs = {"a": 0.15, "b": 0.55, "c": 0.10}      # b가 최적
    b = Bandit(path="/tmp/_bandit_test.json", mode="ucb1")
    b.pulls.clear(); b.hits.clear()
    rnd = random.Random(0)
    regret = 0.0
    for _ in range(5000):
        arm = b.order(list(probs))[0]
        hit = rnd.random() < probs[arm]
        b.update(arm, hit)
        regret += (0.55 - probs[arm])
    assert b.pulls["b"] > b.pulls["a"] + b.pulls["c"]   # 최적 팔 최다
    uniform_regret = 5000 * (0.55 - sum(probs.values()) / 3)
    assert regret < uniform_regret                      # 균등보다 낮은 후회
