"""증분 34 — 회로차단기(죽은 호스트 즉시 차단) + gravatar-json 크래시 수정."""
import asyncio

import artes.collectors.proc as proc
from artes.collectors.enrich3_c import GravatarJSON
from artes.core.model import EntityType


def setup_function(_):
    proc._CB.clear()


def test_circuit_breaker_opens_after_threshold():
    h = "dead.example"
    for _ in range(proc._CB_THRESHOLD):
        assert not proc._cb_open(h)          # 임계 전엔 닫힘
        proc._cb_record(h, False)
    assert proc._cb_open(h)                   # 임계 도달 → 열림(즉시 차단)

def test_circuit_breaker_resets_on_success():
    h = "flaky.example"
    for _ in range(proc._CB_THRESHOLD):
        proc._cb_record(h, False)
    assert proc._cb_open(h)
    proc._cb_record(h, True)                  # 성공 한 번 → 회로 닫힘
    assert not proc._cb_open(h)

def test_get_text_short_circuits_open_host(monkeypatch):
    h = "blackhole.example"
    for _ in range(proc._CB_THRESHOLD):
        proc._cb_record(h, False)
    called = {"n": 0}
    async def _boom(*a, **k):
        called["n"] += 1
        return "should-not-happen"
    monkeypatch.setattr(proc, "_hx_text", _boom)
    # 회로 열린 호스트 URL → 네트워크 시도 없이 즉시 None
    r = asyncio.run(proc.get_text("https://blackhole.example/x", timeout=5.0, use_memcache=False))
    assert r is None and called["n"] == 0

def test_gravatar_non_dict_response_no_crash():
    # 예전 버그: 응답이 dict가 아니면 'str'.get AttributeError로 크래시
    async def fake_get_json(url, timeout, headers=None):
        return "user not found"               # dict 아님
    import artes.collectors.enrich3_c as e3
    orig = e3.get_json
    e3.get_json = fake_get_json
    try:
        r = asyncio.run(GravatarJSON().collect("a@b.com", EntityType.EMAIL, {}))
        assert not r.ok and not r.entities     # 크래시 없이 안전 종료
    finally:
        e3.get_json = orig
