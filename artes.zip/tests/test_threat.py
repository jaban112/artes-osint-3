"""위협인텔·Gravatar 프로필 파서."""
from artes.core.model import EntityType, Certainty
from artes.collectors.threat_c import ShodanInternetDB, URLScan, CertSpotter
from artes.collectors.enrich_c import GravatarProfile


def test_internetdb_parse():
    data = {"ip": "1.2.3.4", "ports": [22, 443], "hostnames": ["x.example.com"],
            "cpes": ["cpe:/a:nginx:nginx"], "vulns": ["CVE-2021-1234"], "tags": []}
    res = ShodanInternetDB().parse(data, "1.2.3.4")
    hosts = [e for e in res.entities if e.type is EntityType.HOST]
    assert len(hosts) == 2
    assert any(e.type is EntityType.DOMAIN and e.value == "x.example.com" for e in res.entities)
    assert any(e.attrs.get("vulns") == ["CVE-2021-1234"] for e in res.entities)


def test_urlscan_parse():
    data = {"results": [{"page": {"ip": "5.6.7.8", "domain": "x.com"}},
                        {"page": {"ip": "5.6.7.8"}},          # 중복 IP
                        {"page": {"ip": "9.9.9.9"}}]}
    res = URLScan().parse(data, "x.com")
    ips = {e.value for e in res.entities if e.type is EntityType.IP}
    assert ips == {"5.6.7.8", "9.9.9.9"}                      # 중복 제거


def test_certspotter_parse():
    data = [{"dns_names": ["*.example.com", "api.example.com", "other.org"]}]
    res = CertSpotter().parse(data, "example.com")
    subs = {e.value for e in res.entities}
    assert "api.example.com" in subs and "other.org" not in subs


def test_gravatar_profile_verified_accounts():
    data = {"entry": [{"displayName": "Hong Kim",
                       "accounts": [
                           {"shortname": "twitter", "username": "hong_t",
                            "url": "https://twitter.com/hong_t", "verified": "true"},
                           {"shortname": "github", "username": "hongdev",
                            "url": "https://github.com/hongdev", "verified": "false"}]}]}
    res = GravatarProfile().parse(data, "hong@x.com")
    verified = [e for e in res.edges if e.relation == "검증된 연결"]
    assert verified and verified[0].certainty is Certainty.CONFIRMED
    assert any(e.type is EntityType.NAME and e.value == "Hong Kim" for e in res.entities)
