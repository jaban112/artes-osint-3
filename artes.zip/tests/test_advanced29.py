"""증분 39 — 속도: '확정 부재' 무재시도(404는 즉시 종료, 일시실패만 재시도).

OSINT 최대 낭비였던 '대상이 그 사이트에 없음(404)'을 3번 재시도+백오프하던 것을 제거.
"""
import asyncio
import artes.collectors.proc as proc
from artes.core.politeness import POLICY


def test_retryable_status_classification():
    assert proc._retryable_status(404) is False      # 확정 부재 — 재시도 무의미
    assert proc._retryable_status(403) is False
    assert proc._retryable_status(410) is False
    assert proc._retryable_status(429) is True        # 레이트리밋 — 재시도 가치
    assert proc._retryable_status(500) is True
    assert proc._retryable_status(503) is True


def _run_get_text(monkeypatch, cls_result, host="unit-test.example"):
    proc._CB.pop(host, None)                           # 회로 초기화
    calls = {"n": 0}
    async def fake_cls(url, timeout, headers):
        calls["n"] += 1
        return cls_result
    monkeypatch.setattr(proc, "_hx_text_cls", fake_cls)
    monkeypatch.setattr(proc, "_use_httpx", lambda: True)
    monkeypatch.setattr(POLICY, "retries", 3)
    monkeypatch.setattr(POLICY, "backoff", lambda a: 0.0)   # 테스트서 실제 대기 0
    r = asyncio.run(proc.get_text(f"https://{host}/x", timeout=5.0, use_memcache=False))
    return r, calls["n"]


def test_absent_404_no_retry(monkeypatch):
    # 확정 부재 → 딱 1번만 시도(재시도 폭풍 제거 = 속도 핵심)
    r, n = _run_get_text(monkeypatch, (None, False))
    assert r is None and n == 1


def test_transient_retries(monkeypatch):
    # 일시 실패(429/5xx/타임아웃) → retries+1번까지 재시도
    r, n = _run_get_text(monkeypatch, (None, True))
    assert r is None and n == 4                        # 1 + retries(3)


def test_success_single_call(monkeypatch):
    r, n = _run_get_text(monkeypatch, ("BODY", False))
    assert r == "BODY" and n == 1


def test_rel_node_skipped_in_phash():
    from artes.core.model import Graph, Entity, EntityType, Certainty
    from artes.core.imagestep import hash_avatars
    g = Graph()
    g.add(Entity(EntityType.ACCOUNT, "github/follower1", Certainty.CONFIRMED,
                 attrs={"avatar": "https://a/f.png", "rel_node": True}))   # 관계망 노드
    # rel_node만 있으면 해시 대상 0 → 네트워크 호출 없이 0 반환
    n = asyncio.run(hash_avatars(g))
    assert n == 0
