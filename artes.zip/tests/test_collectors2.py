"""신축 수집기 파서 단위검증 — 합성 데이터(네트워크 없이)."""
from artes.core.model import EntityType
from artes.collectors.infra_c import RDAP, CrtSh
from artes.collectors.dev_c import GitHubDev
from artes.collectors.media_c import WebFingerprint


def test_rdap_parse():
    data = {
        "events": [{"eventAction": "registration", "eventDate": "2019-03-01"}],
        "nameservers": [{"ldhName": "ns1.example.com"}, {"ldhName": "ns2.example.com"}],
        "entities": [{"vcardArray": ["vcard", [
            ["version", {}, "text", "4.0"],
            ["fn", {}, "text", "Example Org"],
            ["email", {}, "text", "admin@example.com"]]]}],
    }
    res = RDAP().parse(data, "example.com", EntityType.DOMAIN)
    vals = {e.value for e in res.entities}
    assert "ns1.example.com" in vals and "admin@example.com" in vals


def test_crtsh_parse_subdomains():
    data = [{"name_value": "www.example.com\n*.example.com"},
            {"name_value": "api.example.com"},
            {"name_value": "other.org"}]
    res = CrtSh().parse(data, "example.com")
    subs = {e.value for e in res.entities}
    assert "www.example.com" in subs and "api.example.com" in subs
    assert "other.org" not in subs and "example.com" not in subs


def test_github_parse_user_and_commits():
    user = {"html_url": "https://github.com/hong", "name": "Hong Kim",
            "email": "hong@corp.com", "company": "@acme", "blog": "https://hong.dev",
            "location": "Seoul", "bio": "dev"}
    res = GitHubDev().parse_user(user, "hong")
    assert any(e.type is EntityType.NAME and e.value == "Hong Kim" for e in res.entities)
    assert any(e.type is EntityType.EMAIL and e.value == "hong@corp.com" for e in res.entities)
    events = [{"type": "PushEvent", "payload": {"commits": [
        {"author": {"email": "real.name@gmail.com"}},
        {"author": {"email": "12345+bot@users.noreply.github.com"}}]}}]
    GitHubDev().parse_events(res, events, "hong")
    emails = {e.value for e in res.entities if e.type is EntityType.EMAIL}
    assert "real.name@gmail.com" in emails
    assert "12345+bot@users.noreply.github.com" not in emails      # noreply 제외


def test_webfp_extracts_tracker_ids():
    html = ('<script>ga("create","UA-123456-1");</script>'
            '<script src="G-ABCDEF1234"></script>'
            'ca-pub-1234567890123456 GTM-ABCD12')
    res = WebFingerprint().parse_html(html, "example.com", EntityType.DOMAIN)
    ids = {e.value for e in res.entities if e.type is EntityType.TRACKER}
    assert "UA-123456-1" in ids and "ca-pub-1234567890123456" in ids
    assert "G-ABCDEF1234" in ids and "GTM-ABCD12" in ids
