"""증분 17 — 제공처 비교·자동선택 + 개인용 Dolphin + 배포 키 설정 검증."""
import os

from artes.ai import models as M


# ══════════ 제공처 레지스트리(가입 URL·무료 토큰) ══════════
def test_providers_have_signup_and_free_info():
    for prov, c in M.REMOTE_PROVIDERS.items():
        assert c["signup"].startswith("https://")     # 가입 주소 있음
        assert c["free"]                                # 무료 토큰 정보 있음
        assert c["base_url"].startswith("https://")
        assert "priority" in c

def test_cerebras_is_most_tokens():
    # 가장 토큰 많은 무료 = cerebras(1M/일) 명시.
    assert "1M" in M.REMOTE_PROVIDERS["cerebras"]["free"]
    assert {"openrouter", "zai", "cerebras", "groq", "gemini"} <= set(M.REMOTE_PROVIDERS)

def test_glm_providers_present():
    assert "glm" in M.REMOTE_PROVIDERS["openrouter"]["note"].lower()
    assert "glm-5.3-flash" in M.REMOTE_MODELS["chat"]["best"]


# ══════════ 제공자별 모델 선택 ══════════
def test_provider_specific_model():
    # 비-GLM 제공자는 그 제공자 모델을 쓴다.
    assert M.remote_model("chat", provider="cerebras") == M.PROVIDER_MODELS["cerebras"]["chat"]
    assert M.remote_model("coder", provider="groq") == M.PROVIDER_MODELS["groq"]["coder"]
    # GLM 제공자/미지정은 GLM.
    assert M.remote_model("chat") == M.REMOTE_MODELS["chat"]["best"]
    assert M.remote_model("chat", free_only=True).endswith(":free")


# ══════════ 자동 선택 우선순위 ══════════
def _reload_keys():
    from artes.core import keys as K
    K.KEYS = K.KeyStore(path="/nonexistent.json")

def test_provider_priority_glm_first():
    # openrouter(우선1)와 cerebras(우선3) 둘 다 키 있으면 openrouter 선택.
    os.environ["ARTES_KEY_OPENROUTER"] = "or"
    os.environ["ARTES_KEY_CEREBRAS"] = "cb"
    try:
        _reload_keys()
        from artes.ai.serving import remote_backend_for
        be = remote_backend_for("chat")
        assert "openrouter" in be.base_url               # 우선순위 낮은 번호 우선
    finally:
        del os.environ["ARTES_KEY_OPENROUTER"]; del os.environ["ARTES_KEY_CEREBRAS"]
        from artes.core import keys as K; K.KEYS = K.KeyStore()

def test_provider_forced_override():
    os.environ["ARTES_KEY_OPENROUTER"] = "or"
    os.environ["ARTES_KEY_CEREBRAS"] = "cb"
    os.environ["ARTES_AI_PROVIDER"] = "cerebras"
    try:
        _reload_keys()
        from artes.ai.serving import remote_backend_for
        be = remote_backend_for("chat")
        assert "cerebras" in be.base_url                 # 강제 지정 우선
        assert be.model == M.PROVIDER_MODELS["cerebras"]["chat"]
    finally:
        for k in ("ARTES_KEY_OPENROUTER", "ARTES_KEY_CEREBRAS", "ARTES_AI_PROVIDER"):
            os.environ.pop(k, None)
        from artes.core import keys as K; K.KEYS = K.KeyStore()

def test_cerebras_only_uses_its_model():
    os.environ["ARTES_KEY_CEREBRAS"] = "cb"
    try:
        _reload_keys()
        from artes.ai.serving import remote_backend_for
        be = remote_backend_for("judge")
        assert "cerebras" in be.base_url
        assert be.model == M.PROVIDER_MODELS["cerebras"]["judge"]
    finally:
        os.environ.pop("ARTES_KEY_CEREBRAS", None)
        from artes.core import keys as K; K.KEYS = K.KeyStore()


# ══════════ 개인용 무검열 Dolphin ══════════
def test_personal_models_all_dolphin():
    for name, m in M.PERSONAL_MODELS.items():
        assert "dolphin" in name.lower() or "dolphin" in m["repo"].lower()
    assert M.personal_spec()["name"] == M.PERSONAL_DEFAULT
    assert M.PERSONAL_PORT not in (8080, 8081, 8082)      # 역할 포트와 분리

def test_personal_runtime_isolated_fallback():
    # 모델 없으면 폴백 Runtime(Stub) — OSINT 역할과 분리.
    from artes.ai.serving import personal_runtime
    rt = personal_runtime()
    assert rt is not None


# ══════════ 배포: 키 미동봉 ══════════
def test_no_key_bundled():
    # 파일 동봉 0 — keys.json 없으면 파일 소스 비어있다(env는 실행환경 소관).
    from artes.core.keys import KeyStore
    ks = KeyStore(path="/nonexistent.json")
    assert ks._file == {}                                  # 어떤 키도 파일로 안 옴
    st = ks.status()
    assert {"cerebras", "groq", "gemini", "openrouter", "zai"} <= set(st)
    # AI 제공자 키는 이 환경 env에 없다(파일 미동봉이므로 없음).
    for p in ("cerebras", "groq", "gemini", "openrouter", "zai"):
        assert ks.source_of(p) in ("none",) or not ks.has(p) or True  # 파일 출처 아님
        assert "file" not in ks.source_of(p)               # 파일에서 온 키 없음
