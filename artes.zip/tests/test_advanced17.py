"""증분 26 — 유출 인텔 심화 파서 단위검증. 핵심: 평문 비밀번호 값 절대 미저장.

합성 응답으로 파서만 검증. 유출명→노출 카테고리 보강, 도메인 통계, 선택키(메타만).
"""
from artes.collectors.breach3_c import (HIBPBreachInfo, XposedBreachInfo, HudsonRockDomain,
                                        IntelXSearch, LeakCheckPro)
from artes.core.model import EntityType, Certainty
from artes.collectors.registry import default_collectors


# ══════════ 무키 유출 카탈로그 보강 ══════════
def test_hibp_breach_info_dataclasses():
    d = {"Name": "Adobe", "BreachDate": "2013-10-04", "PwnCount": 152000000,
         "DataClasses": ["Email addresses", "Password hints", "Passwords", "Usernames"],
         "IsVerified": True, "IsSensitive": False, "Domain": "adobe.com"}
    res = HIBPBreachInfo().parse(d, "Adobe")
    b = [e for e in res.entities if e.type == EntityType.BREACH][0]
    assert b.value == "Adobe"
    assert "Passwords" in b.attrs["data_classes"]     # '무슨 항목이 노출됐나'
    assert b.attrs["pwn_count"] == 152000000
    assert b.attrs["breach_date"] == "2013-10-04"


def test_hibp_skips_non_breach():
    # 인포스틸러/제재 등 유출 아닌 BREACH 엔티티는 조용히 통과
    import asyncio
    res = asyncio.run(HIBPBreachInfo().collect("인포스틸러 감염(RedLine)", EntityType.BREACH, {}))
    assert res.ok and not res.entities


def test_xposed_breach_info():
    hit = {"breach": "LinkedIn", "xposed_date": "2012", "xposed_data": "Email;Password",
           "industry": "Tech", "xposed_records": 164000000}
    res = XposedBreachInfo().parse(hit, "LinkedIn")
    b = [e for e in res.entities if e.type == EntityType.BREACH][0]
    assert b.attrs["xposed_data"] == "Email;Password"
    assert b.attrs["records"] == 164000000


def test_hudsonrock_domain_stats():
    d = {"data": {"employees": 12, "users": 340}}
    res = HudsonRockDomain().parse(d, "acme.com")
    b = [e for e in res.entities if e.type == EntityType.BREACH][0]
    assert b.attrs["employees_infected"] == 12
    assert b.attrs["users_infected"] == 340
    assert any(e.relation == "인포스틸러 노출" or e.label == "인포스틸러 노출" for e in res.edges)


def test_hudsonrock_domain_clean():
    res = HudsonRockDomain().parse({"data": {}}, "clean.com")
    assert not any(e.type == EntityType.BREACH for e in res.entities)


# ══════════ 선택 키 — 메타데이터만 ══════════
def test_intelx_reference_metadata_only():
    records = [{"name": "Collection1", "date": "2019-01-07T00:00:00", "bucket": "leaks"},
               {"name": "Collection1", "date": "2019-01-07T00:00:00", "bucket": "leaks"},  # 중복
               {"name": "LinkedInDump", "date": "2016-05-01T00:00:00", "bucket": "pastes",
                "systemid": "abc-secret-content-ref"}]
    res = IntelXSearch().parse(records, "a@b.com", EntityType.EMAIL)
    breaches = [e for e in res.entities if e.type == EntityType.BREACH]
    assert len(breaches) == 2                 # 중복 접힘
    # systemid(본문 참조)는 저장 안 함 — 어떤 attr에도 없음
    blob = str([e.attrs for e in res.entities])
    assert "abc-secret-content-ref" not in blob
    assert any("Collection1" in e.value for e in breaches)


def test_leakcheck_pro_never_stores_plaintext():
    # Pro 응답이 평문 비번·해시를 줘도 절대 저장하지 않고, '노출됐다'는 사실만 기록
    d = {"success": True, "found": 1, "result": [
        {"source": {"name": "Adobe", "breach_date": "2013-10"},
         "email": "victim@x.com", "password": "SuperSecret123!",
         "sha1": "aabbccdd", "username": "victim", "phone": "+1555"}]}
    res = LeakCheckPro().parse(d, "victim@x.com", EntityType.EMAIL)
    b = [e for e in res.entities if e.type == EntityType.BREACH][0]
    blob = str(res.__dict__) + str([(e.value, e.attrs) for e in res.entities])
    # 평문 비밀번호·해시 값은 결과 어디에도 없어야 함
    assert "SuperSecret123!" not in blob
    assert "aabbccdd" not in blob
    # 대신 '비밀번호가 노출됐다'는 사실과 노출 필드 종류는 기록
    assert b.attrs["password_exposed"] is True
    assert "username" in b.attrs["exposed_fields"]
    assert "password" not in b.attrs["exposed_fields"]   # 값도, 키도 필드목록에 안 넣음
    assert b.attrs["breach_date"] == "2013-10"


def test_keyed_skip_without_key():
    assert IntelXSearch().available() is False
    assert LeakCheckPro().available() is False


# ══════════ 배선 ══════════
def test_increment26_registered_keyless():
    names = {c.name for c in default_collectors(real=True)}
    assert {"hibp-breach-info", "xposed-breach-info", "hudsonrock-domain",
            "intelx", "leakcheck-pro"} <= names


def test_breach_is_expandable():
    from artes.core.engine import _EXPANDABLE
    assert EntityType.BREACH in _EXPANDABLE       # 발견된 유출명이 카탈로그로 보강됨
