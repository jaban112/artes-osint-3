"""증분 13 — Kali/GitHub 대량 수집기 검증(파서 분리, 네트워크 불필요).

인프라(RIPEstat·OTX·Anubis·Columbus·RapidDNS)·enrichment(Nominatim·Wikidata·SEC·GLEIF·
PGP)·위협/암호화폐/자격증명(Feodo·OpenPhish·BTC·COMB)·Kali CLI 래퍼·타입판정.
"""
from artes.core.types import detect
from artes.core.model import EntityType


# ══════════ 타입 판정(신규) ══════════
def test_detect_crypto():
    assert detect("1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa") is EntityType.CRYPTO   # BTC
    assert detect("bc1qar0srrr7xfkvy5l643lydnw9re59gtzzwf5mdq") is EntityType.CRYPTO
    assert detect("0x" + "a" * 40) is EntityType.CRYPTO                        # ETH
    assert detect("hong@gmail.com") is EntityType.EMAIL                        # 회귀 없음


# ══════════ 인프라 심화 ══════════
def test_ripestat_parse():
    from artes.collectors.infra2_c import RIPEstat
    ni = {"data": {"asns": ["15169"], "prefix": "8.8.8.0/24"}}
    ab = {"data": {"abuse_contacts": ["abuse@google.com"]}}
    res = RIPEstat().parse(ni, ab, "8.8.8.8", EntityType.IP)
    assert any(e.type is EntityType.ASN and e.value == "AS15169" for e in res.entities)
    assert any(e.type is EntityType.EMAIL for e in res.entities)

def test_otx_passive_dns_parse():
    from artes.collectors.infra2_c import OTXPassiveDNS
    data = {"passive_dns": [{"hostname": "mail.example.com", "address": "1.2.3.4",
                             "first": "2020", "last": "2024"}]}
    res = OTXPassiveDNS().parse(data, "example.com", EntityType.DOMAIN)
    assert any(e.value == "mail.example.com" for e in res.entities)
    assert any(e.type is EntityType.IP and e.value == "1.2.3.4" for e in res.entities)

def test_anubis_columbus_parse():
    from artes.collectors.infra2_c import AnubisSubs, ColumbusSubs
    a = AnubisSubs().parse(["www.example.com", "api.example.com", "other.net"], "example.com")
    subs = {e.value for e in a.entities}
    assert subs == {"www.example.com", "api.example.com"}
    c = ColumbusSubs().parse(["www", "api"], "example.com")
    assert {e.value for e in c.entities} == {"www.example.com", "api.example.com"}

def test_rapiddns_parse():
    from artes.collectors.infra2_c import RapidDNS
    html = "<td>sub.example.com</td><td>A</td><td>1.2.3.4</td><td>evil.com</td>"
    res = RapidDNS().parse(html, "example.com", EntityType.DOMAIN)
    assert any(e.value == "sub.example.com" for e in res.entities)


# ══════════ enrichment ══════════
def test_nominatim_parse():
    from artes.collectors.enrich2_c import Nominatim
    data = [{"lat": "37.5", "lon": "127.0", "display_name": "Seoul, Korea",
             "osm_type": "relation", "osm_id": "1"}]
    res = Nominatim().parse(data, "Seoul")
    e = res.entities[0]
    assert e.type is EntityType.GEO and e.attrs["lat"] == "37.5"

def test_wikidata_parse():
    from artes.collectors.enrich2_c import WikidataEnrich
    hit = {"id": "Q42", "label": "Douglas Adams", "description": "author"}
    ent = {"entities": {"Q42": {"claims": {
        "P856": [{"mainsnak": {"datavalue": {"value": "https://example.com"}}}],
        "P2037": [{"mainsnak": {"datavalue": {"value": "douglas"}}}]}}}}
    res = WikidataEnrich().parse(hit, ent, "Douglas Adams", EntityType.NAME, "Q42")
    assert any(e.type is EntityType.URL for e in res.entities)
    assert any(e.type is EntityType.ACCOUNT and "github" in e.value for e in res.entities)

def test_sec_edgar_parse():
    from artes.collectors.enrich2_c import SECEdgar
    tickers = {"0": {"cik_str": 320193, "ticker": "AAPL", "title": "Apple Inc."}}
    res = SECEdgar().parse_tickers(tickers, "Apple Inc.")
    assert any(e.type is EntityType.ORG and e.attrs["cik"] == "0000320193"
               for e in res.entities)

def test_gleif_parse():
    from artes.collectors.enrich2_c import GLEIF
    data = {"data": [{"id": "LEI123", "attributes": {"lei": "LEI123",
            "entity": {"legalName": {"name": "ACME Corp"},
                       "legalAddress": {"country": "US", "city": "NY"}}}}]}
    res = GLEIF().parse(data, "ACME Corp")
    assert res.entities[0].type is EntityType.ORG and res.entities[0].attrs["lei"] == "LEI123"

def test_openpgp_parse():
    from artes.collectors.enrich2_c import OpenPGPKeys
    res = OpenPGPKeys().parse("-----BEGIN PGP PUBLIC KEY-----\n...", "a@x.com")
    assert any(e.type is EntityType.TRACKER and e.attrs.get("kind") == "pgp"
               for e in res.entities)


# ══════════ 위협·암호화폐·자격증명 ══════════
def test_feodo_parse():
    from artes.collectors.threat2_c import FeodoTracker
    row = {"ip_address": "1.2.3.4", "malware": "Dridex", "status": "online",
           "first_seen": "2024"}
    res = FeodoTracker().parse(row, "1.2.3.4")
    assert any(e.type is EntityType.MALWARE for e in res.entities)
    assert FeodoTracker().parse(None, "1.2.3.4").entities == []   # 매칭 없음

def test_openphish_parse():
    from artes.collectors.threat2_c import OpenPhish
    feed = {"http://evil.com/login", "http://bad.net"}
    hit = OpenPhish().parse(feed, "http://evil.com/login", EntityType.URL)
    assert any(e.type is EntityType.MALWARE for e in hit.entities)
    miss = OpenPhish().parse(feed, "http://safe.com", EntityType.URL)
    assert miss.entities == []

def test_btc_parse():
    from artes.collectors.threat2_c import BitcoinAddress
    data = {"n_tx": 42, "final_balance": 100000, "total_received": 500000}
    res = BitcoinAddress().parse_bci(data, "1ABC")
    assert res.entities[0].type is EntityType.CRYPTO and res.entities[0].attrs["n_tx"] == 42
    mp = {"chain_stats": {"tx_count": 7, "funded_txo_sum": 10, "spent_txo_sum": 3}}
    r2 = BitcoinAddress().parse_mempool(mp, "1ABC")
    assert r2.entities[0].attrs["balance_sat"] == 7

def test_comb_no_password_stored():
    from artes.collectors.threat2_c import ProxyNovaCOMB
    data = {"count": 3, "lines": ["a@x.com:secret1", "a@x.com:secret2"]}
    res = ProxyNovaCOMB().parse(data, "a@x.com", EntityType.EMAIL)
    b = res.entities[0]
    assert b.type is EntityType.BREACH and b.attrs["exposures"] == 3
    # 안전: 평문 비밀번호가 어디에도 저장되지 않았는지 확인.
    blob = str(b.to_dict())
    assert "secret1" not in blob and "secret2" not in blob


# ══════════ Kali CLI 래퍼(파서 + available 게이트) ══════════
def test_subfinder_parse():
    from artes.collectors.kali_c import Subfinder
    out = "www.example.com\napi.example.com\nunrelated.net\n"
    res = Subfinder().parse(out, "example.com")
    assert {e.value for e in res.entities} == {"www.example.com", "api.example.com"}

def test_dnstwist_parse():
    from artes.collectors.kali_c import Dnstwist
    import json as _j
    out = _j.dumps([{"domain": "examp1e.com", "fuzzer": "replacement"},
                    {"domain": "example.com", "fuzzer": "original"}])
    res = Dnstwist().parse(out, "example.com")
    assert any(e.value == "examp1e.com" for e in res.entities)

def test_exiftool_parse_gps():
    from artes.collectors.kali_c import ExifToolMeta
    out = '[{"Author":"Jane Doe","GPSLatitude":37.5,"GPSLongitude":127.0}]'
    res = ExifToolMeta().parse(out, "photo.jpg")
    assert any(e.type is EntityType.NAME for e in res.entities)
    assert any(e.type is EntityType.GEO for e in res.entities)

def test_cli_tools_gated_when_absent():
    # 이 컨테이너엔 도구 없음 → available()=False(엔진이 skip).
    from artes.collectors.kali_c import Subfinder, Amass, WhatWeb
    assert Subfinder().available() in (True, False)      # which 결과(대개 False)
    # available False면 run()이 skip 반환.


def test_registry_has_new_collectors():
    from artes.collectors.registry import default_collectors
    names = {c.name for c in default_collectors(real=True)}
    expected = {"ripestat", "otx-pdns", "anubis", "columbus", "rapiddns",
                "nominatim", "wikidata", "sec-edgar", "gleif", "openpgp",
                "feodo", "openphish", "btc", "comb", "subfinder", "dnstwist",
                "exiftool", "gau", "whatweb"}
    assert expected <= names
    print("총 수집기:", len(default_collectors(real=True)))
