"""증분 31 — 속도 대개조(httpx 연결풀+HTTP/2, urllib 폴백) 검증."""
import asyncio

import artes.collectors.proc as proc


def test_httpx_accelerator_present_or_fallback():
    # httpx 있으면 가속 경로, 없으면 urllib 폴백 — 둘 다 정상
    assert isinstance(proc._HAS_HTTPX, bool)
    # 헬퍼 존재
    assert hasattr(proc, "_hx_text") and hasattr(proc, "_hx_post_json") and hasattr(proc, "_hx_bytes")

def test_use_httpx_falls_back_with_proxy(monkeypatch):
    from artes.core.politeness import POLICY
    # 프록시(Tor) 설정 시엔 httpx 대신 프록시-aware urllib 사용해야 함
    monkeypatch.setattr(POLICY, "proxies", ["socks5://127.0.0.1:9050"], raising=False)
    assert proc._use_httpx() is False
    monkeypatch.setattr(POLICY, "proxies", [], raising=False)
    # 프록시 없으면 httpx 있을 때만 True
    assert proc._use_httpx() == proc._HAS_HTTPX

def test_shared_client_is_reused(monkeypatch):
    if not proc._HAS_HTTPX:
        return
    async def go():
        c1 = proc._hx_client()
        c2 = proc._hx_client()
        return c1 is c2                 # 같은 루프 → 같은 클라이언트(연결풀 재사용)
    assert asyncio.run(go()) is True

def test_get_text_returns_none_gracefully_on_bad_host():
    # 존재하지 않는 호스트 → 크래시 없이 None(캐시·합류 경로 정상)
    r = asyncio.run(proc.get_text("https://nonexistent.invalid.artes.test/x", timeout=3.0))
    assert r is None
