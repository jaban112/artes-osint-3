"""증분 9 — AI 대폭 업그레이드(2026 SOTA) 단위검증.

reason-then-format · CoVe · 신뢰도 융합 · 하이브리드 RAG(BM25+RRF) · 문자 n-그램 문체 ·
키 없는 신규 수집기(XposedOrNot·WhatsMyName·WaybackCDX·HackerTarget·psbdmp).
"""
from artes.ai.backend import StubBackend, FACTUAL_SAMPLER, _mean_logprob
from artes.ai.runtime import Runtime
from artes.ai import verify
from artes.ai.grammar import verdict_schema
from artes.ai.rag import RagIndex, rrf
from artes.core import stylometry
from artes.core.model import EntityType


# ---- 샘플러 프리셋 + logprob 신뢰도 ----
def test_factual_sampler_preset():
    assert FACTUAL_SAMPLER["top_k"] == 0 and FACTUAL_SAMPLER["min_p"] > 0
    assert FACTUAL_SAMPLER["xtc_probability"] == 0.0        # 창의성 주입 off

def test_generate_conf_passthrough():
    rt = Runtime(backend=StubBackend(lambda p: "ok", conf=-0.2))
    out, lp = rt.generate_conf("t", "prompt")
    assert out == "ok" and abs(lp + 0.2) < 1e-9

def test_mean_logprob_parsing():
    obj = {"completion_probabilities": [{"logprob": -0.1}, {"logprob": -0.3}]}
    assert abs(_mean_logprob(obj) + 0.2) < 1e-9
    # prob(선형) 형태도 log로 변환.
    import math
    obj2 = {"completion_probabilities": [{"prob": math.e ** -0.5}]}
    assert abs(_mean_logprob(obj2) + 0.5) < 1e-6
    assert _mean_logprob({"completion_probabilities": []}) is None


# ---- verify: 서술적 확률 · logprob→p · 융합 ----
def test_verbalized_prob_extraction():
    assert verify._verbalized_prob("...분석...\n정답 확률: 85") == 0.85
    assert verify._verbalized_prob("probability: 30 maybe") == 0.30
    assert verify._verbalized_prob("근거 없음") is None

def test_p_from_logprob():
    assert verify._p_from_logprob(0.0) == 1.0
    assert 0.0 < verify._p_from_logprob(-1.0) < 1.0
    assert verify._p_from_logprob(None) is None

def test_fuse_confidence_rules():
    # 세 신호 모두 높음 → 확실.
    v, c, s = verify.fuse_confidence(0.8, 0.9, 1.0)
    assert v == "확실" and c > 0.6 and set(s) >= {"logprob", "verbalized", "cove"}
    # CoVe 강한 반증 → 확실 불가.
    v2, _, _ = verify.fuse_confidence(0.9, 0.9, 0.0)
    assert v2 == "불확실"
    # 분산 큼 → 확실 불가.
    v3, _, _ = verify.fuse_confidence(0.9, 0.9, None, spread=0.9)
    assert v3 == "불확실"
    # 신호 전무 → 기권.
    v4, c4, _ = verify.fuse_confidence(None, None, None)
    assert v4 == "insufficient_evidence" and c4 == 0.0


# ---- verify: 2패스 판정 파이프라인(StubBackend) ----
def _judge_responder(certain=True):
    def r(p):
        if "검증할 독립적인 사실확인 질문" in p:              # CoVe 계획
            return '{"questions":["질문1","질문2"]}'
        if "질문에 사실만 간단히 답하라" in p:                # CoVe 개별 답
            return "서울 거주로 확인됨" if certain else "모름"
        if "결론만 뽑아" in p:                                # 추출(패스2)
            return '{"evidence":"github bio 일치","verdict":"확실","confidence":80}'
        # 추론(패스1) — 서술적 확률 포함.
        return "확인 점 나열 후 근거 분석.\n정답 확률: 82"
    return r

def test_judge_certain_path():
    rt = Runtime(backend=StubBackend(_judge_responder(True), conf=-0.2))
    j = verify.judge(rt, "이 계정들은 동일인인가?", "[근거] github bio ...")
    assert j.verdict == "확실" and j.certain()
    assert j.signals["cove_detail"]["ratio"] == 1.0
    assert "verbalized" in j.signals and "logprob" in j.signals

def test_judge_uncertain_when_cove_fails():
    rt = Runtime(backend=StubBackend(_judge_responder(False), conf=-0.2))
    j = verify.judge(rt, "동일인?", "[근거] 약함")
    assert j.verdict == "불확실"                              # 검증 실패 → 확실 불가

def test_judge_abstains_on_insufficient():
    def r(p):
        if "결론만 뽑아" in p:
            return '{"evidence":"","verdict":"insufficient_evidence","confidence":0}'
        return "정답 확률: 10"
    rt = Runtime(backend=StubBackend(r))
    j = verify.judge(rt, "동일인?", "근거 없음")
    assert j.verdict == "insufficient_evidence"

def test_cove_isolated_checks():
    rt = Runtime(backend=StubBackend(_judge_responder(True)))
    out = verify.cove_verify(rt, "주장", "근거")
    assert out["n"] == 2 and out["supported"] == 2 and out["ratio"] == 1.0


def test_verdict_schema_shape():
    s = verdict_schema()
    props = list(s["properties"])
    assert props == ["evidence", "verdict", "confidence"]      # evidence 먼저
    assert "insufficient_evidence" in s["properties"]["verdict"]["enum"]


# ---- 하이브리드 RAG ----
def test_rrf_fusion():
    fused = rrf([["a", "b", "c"], ["b", "a"]])
    assert fused["a"] > 0 and fused["b"] > fused["c"]         # b가 두 목록 상위

def test_bm25_rare_token_hit():
    idx = RagIndex()
    idx.add("d1", "jiwan123 서울 파이썬 개발자")
    idx.add("d2", "고양이 강아지 반려동물 일상")
    idx.add("d3", "축구 야구 농구 스포츠")
    hits = idx.search("jiwan123", k=1)                        # 희귀 핸들 → BM25 강점
    assert hits and hits[0][0] == "d1"

def test_hybrid_describe():
    idx = RagIndex()
    d = idx.describe()
    assert d["sparse"] == "bm25" and "dense" in d


# ---- 문자 n-그램 문체 ----
def test_authorship_similarity():
    a = "just shipped a new feature, super excited!! more soon :)"
    b = "just fixed a nasty bug, super relieved!! more soon :)"
    c = "제품 출시 안내드립니다. 문의는 고객센터로 연락 바랍니다."
    assert stylometry.authorship_similarity(a, b) > stylometry.authorship_similarity(a, c)

def test_char_ngrams_basic():
    g = stylometry.char_ngrams("abcabc", 3, 3)
    assert g["abc"] == 2 and g["bca"] == 1


# ---- 신규 수집기 파서(네트워크 불필요) ----
def test_xposedornot_parse_shapes():
    from artes.collectors.breach_c import XposedOrNot
    r1 = XposedOrNot().parse({"breaches": [["Adobe", "Tumblr"]]}, "a@x.com")
    names = {e.value for e in r1.entities if e.type is EntityType.BREACH}
    assert names == {"Adobe", "Tumblr"}
    r2 = XposedOrNot().parse(
        {"ExposedBreaches": {"breaches_details": [{"breach": "LinkedIn"}]}}, "a@x.com")
    assert any(e.value == "LinkedIn" for e in r2.entities)

def test_whatsmyname_dataset_and_match():
    from artes.collectors.wmn_c import WhatsMyName
    ds = WhatsMyName.parse_dataset({"sites": [
        {"name": "GitHub", "uri_check": "https://github.com/{account}",
         "e_string": "profile", "e_code": 200},
        {"name": "Bad", "uri_check": "https://x.com/no-placeholder"},   # 제외됨
    ]})
    assert len(ds) == 1 and ds[0]["name"] == "GitHub"
    rule = ds[0]
    assert WhatsMyName.match(rule, 200, "...profile...") is True
    assert WhatsMyName.match(rule, 404, "profile") is False
    assert WhatsMyName.match(rule, 200, "no marker") is False

def test_wayback_cdx_parse():
    from artes.collectors.recon_c import WaybackCDX
    rows = [["original"], ["http://blog.example.com/a"], ["https://example.com/x"],
            ["http://shop.example.com/"]]
    res = WaybackCDX().parse(rows, "example.com")
    subs = {e.value for e in res.entities if e.type is EntityType.DOMAIN}
    assert subs == {"blog.example.com", "shop.example.com"}

def test_hackertarget_parse_and_budget():
    from artes.collectors.recon_c import HackerTargetRecon
    ok = HackerTargetRecon().parse("a.com\nb.com\nexample.com", "example.com",
                                   EntityType.DOMAIN)
    doms = {e.value for e in ok.entities if e.type is EntityType.DOMAIN}
    assert doms == {"a.com", "b.com"}
    over = HackerTargetRecon().parse("error: API count exceeded", "x",
                                     EntityType.DOMAIN)
    assert over.skipped is True

def test_psbdmp_parse():
    from artes.collectors.recon_c import Psbdmp
    res = Psbdmp().parse({"count": 1, "data": [{"id": "AbCd", "date": "2024"}]},
                         "a@x.com", EntityType.EMAIL)
    assert any(e.type is EntityType.BREACH and "AbCd" in e.value for e in res.entities)


def test_registry_includes_new_collectors():
    from artes.collectors.registry import default_collectors
    names = {c.name for c in default_collectors(real=True)}
    assert {"xposedornot", "whatsmyname", "wayback-cdx", "hackertarget",
            "psbdmp"} <= names
