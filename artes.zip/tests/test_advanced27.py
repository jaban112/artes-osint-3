"""증분 36 — 신뢰도 자동채점 · 아바타 pHash 매칭 · 디스크캐시 · 후보 확장상한."""
import asyncio

from artes.core.model import Graph, Entity, Edge, EntityType, Certainty, Evidence
_EV = [Evidence('test', 't')]
from artes.core.scoring import score_targets, promote_confident
from artes.core.imagestep import avatar_url, hash_avatars


def _find(ranked, val):
    return next((r for r in ranked if r["value"] == val), None)


# ══════════ 신뢰도 채점 ══════════
def test_score_shared_email_high():
    g = Graph()
    seed = g.add(Entity(EntityType.EMAIL, "a@b.com", Certainty.CONFIRMED))
    acc = g.add(Entity(EntityType.ACCOUNT, "instagram/jiwan", Certainty.CONFIRMED,
                       attrs={"site": "instagram"}))
    g.link(Edge(seed.key, acc.key, "가진 계정", Certainty.CONFIRMED, evidence=_EV))
    ranked = score_targets(g, [seed.key])
    r = _find(ranked, "instagram/jiwan")
    assert r and r["score"] >= 0.7                    # 씨앗 이메일 직결 → 고확신

def test_score_same_photo_boost():
    g = Graph()
    seed = g.add(Entity(EntityType.EMAIL, "a@b.com", Certainty.CONFIRMED))
    a1 = g.add(Entity(EntityType.ACCOUNT, "twitter/x", Certainty.CONFIRMED,
                      attrs={"image_phash": "abcd1234"}))
    g.link(Edge(seed.key, a1.key, "가진 계정", Certainty.CONFIRMED, evidence=_EV))
    a2 = g.add(Entity(EntityType.ACCOUNT, "tiktok/y", Certainty.UNCONFIRMED,
                      attrs={"image_phash": "abcd1234"}))       # 같은 사진
    g.link(Edge(a1.key, a2.key, "동일인", Certainty.CONFIRMED, evidence=_EV))
    r = _find(score_targets(g, [seed.key]), "tiktok/y")
    assert r and "같은 프로필 사진" in r["reasons"]
    assert r["score"] >= 0.6

def test_isolated_variant_not_ranked():
    # 씨앗과 강하게 안 이어진 순열 후보는 확신도 목록에 안 뜸
    g = Graph()
    seed = g.add(Entity(EntityType.NAME, "김지완", Certainty.CONFIRMED))
    v = g.add(Entity(EntityType.USERNAME, "randomxyz", Certainty.UNCONFIRMED,
                     attrs={"variant": True}))
    g.link(Edge(seed.key, v.key, "아이디 순열", Certainty.UNCONFIRMED, evidence=_EV))   # 약한 간선
    assert _find(score_targets(g, [seed.key]), "randomxyz") is None

def test_promote_confident_upgrades():
    g = Graph()
    seed = g.add(Entity(EntityType.EMAIL, "a@b.com", Certainty.CONFIRMED))
    acc = g.add(Entity(EntityType.ACCOUNT, "instagram/jiwan", Certainty.UNCONFIRMED))
    g.link(Edge(seed.key, acc.key, "가진 계정", Certainty.CONFIRMED, evidence=_EV))
    n = promote_confident(g, [seed.key], threshold=0.7)
    assert n >= 1 and g.get("account:instagram/jiwan").certainty is Certainty.CONFIRMED


# ══════════ 아바타 pHash ══════════
def test_avatar_url_keys():
    e = Entity(EntityType.ACCOUNT, "x", Certainty.CONFIRMED,
               attrs={"profile_pic_url": "https://a/p.jpg"})
    assert avatar_url(e) == "https://a/p.jpg"
    assert avatar_url(Entity(EntityType.ACCOUNT, "y", Certainty.CONFIRMED, attrs={})) is None

def test_hash_avatars_populates_phash(monkeypatch):
    import artes.collectors.proc as proc
    import artes.core.imagestep as istep
    async def fake_bytes(url, timeout=10.0, max_bytes=3_000_000):
        return b"IMGDATA"
    monkeypatch.setattr(proc, "get_bytes", fake_bytes)
    monkeypatch.setattr(istep, "phash_bytes", lambda data: "deadbeef")
    g = Graph()
    g.add(Entity(EntityType.ACCOUNT, "tiktok/j", Certainty.CONFIRMED,
                 attrs={"thumbnail_url": "https://cdn/x.jpg"}))
    n = asyncio.run(hash_avatars(g))
    assert n == 1
    assert g.get("account:tiktok/j").attrs["image_phash"] == "deadbeef"


# ══════════ 디스크 캐시(속도) ══════════
def test_disk_cache_roundtrip(monkeypatch, tmp_path):
    import artes.collectors.proc as proc
    monkeypatch.setattr(proc, "_DISK_ON", True)
    monkeypatch.setattr(proc, "_DISK_DIR", tmp_path / "hc")
    proc._disk_put("https://x.com/a", "hello-body")
    assert proc._disk_get("https://x.com/a") == "hello-body"
    assert proc._disk_get("https://x.com/other") is None

def test_disk_cache_off_by_default(monkeypatch, tmp_path):
    import artes.collectors.proc as proc
    monkeypatch.setattr(proc, "_DISK_ON", False)
    monkeypatch.setattr(proc, "_DISK_DIR", tmp_path / "hc2")
    proc._disk_put("https://x.com/a", "body")
    assert proc._disk_get("https://x.com/a") is None       # 꺼져 있으면 저장·조회 안 함


# ══════════ 후보 확장상한(속도) ══════════
def test_frontier_variant_cap():
    from artes.core.engine import Engine
    eng = Engine([], use_bandit=False, max_frontier=100)
    eng.max_variant_frontier = 2
    ents = [Entity(EntityType.USERNAME, f"v{i}", Certainty.UNCONFIRMED, attrs={"variant": True})
            for i in range(10)]
    ents.append(Entity(EntityType.EMAIL, "a@b.com", Certainty.CONFIRMED))
    out = eng._prioritize_frontier(ents)
    variants = [e for e in out if (e.attrs or {}).get("variant")]
    assert len(variants) == 2                              # 순열 후보는 상한까지만
    assert any(e.type == EntityType.EMAIL for e in out)    # 강한 단서는 유지
