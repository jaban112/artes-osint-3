# PROGRESS — ARTES 자율 진행 로그

돌아가는 increment만 쌓는다. 각 항목: 무엇을 했나 · 검증 결과 · 다음.
(프로젝트명: ARGOS → **ARTES** 변경, 2026-08-28.)

---

## 2026-08-28 — increment 0: 코어 + 병렬 엔진

통일 모델·근거기반 그래프·중복제거, 타입 판정, asyncio 병렬 엔진(타임아웃·실패격리·
스트리밍·자동확장·AI 0회 감사), 캐시, 표층 래퍼 초안, CLI(동의 고지), install.sh, 문서.
**검증: pytest 9 passed, mock end-to-end.**

## 2026-08-28 — increment 1: 전 범위 빌드 (역할분담 = claude 빌드 / 사용자 VM 실행)

**환경.** Cowork 클라우드 컨테이너(Ubuntu, 2코어/8GB). 네트워크 allowlist(pip·github만,
실사이트·HF 차단). 그래서 여기선 **구조·로직·단위검증·llama.cpp 실빌드**까지, 실사이트
조회·실모델 추론은 사용자 Arch VM에서.

**지적 4건 처리(정직).**
- phunter URL 오류 `N0rz3/Phk` → `N0rz3/Phunter` 수정.
- maigret 파서: stdout 정규식 → **JSON 리포트 스키마(CLAIMED)** 로 재작성(소스 검증).
  holehe 파서는 소스상 `[+] <domain>` 로 정확 확인.
- live 교정 불가(사이트 차단) → 파서를 **합성 출력 단위검증**으로 대체(test_parsers).
- 범위: increment 0의 5%에서 → 전 축 빌드로 확장(아래).

**한 것 (전부 검증됨).**
- 표층 래퍼 완성: maigret(JSON)·sherlock·blackbird·holehe·theHarvester.
- 전화: phoneinfoga·ignorant·phunter(phonenumbers로 번호 분해, 없으면 skip).
- 네트워크: nmap(XML 파싱)·Wayback(archive.org CDX).
- 다크웹: onionsearch·torbot 래퍼 + **Tor 라이프사이클 관리자** + **CSAM 안전 필터**
  (불법 콘텐츠는 그래프·AI로 절대 안 들어감).
- 유출: h8mail 로컬 모드(경로 없으면 skip).
- **엔진 4→32기통**: 기본 동시성 32(I/O 바운드), 포화 원리 명시.
- **jaban 심층**(JABAN.md): MinHash/LSH 동일인 해소 + **Clopper–Pearson 신뢰 하한**
  (scipy 없이 불완전베타 역함수) → "동일인?"에 근거 있는 신뢰도. 유일 식별자 공유는
  구조적으로 확실.
- **로컬 AI**: llama.cpp CPU **실빌드 완료**(llama-cli/llama-server). 백엔드 추상화
  (server/cli/llama-cpp-python/스텁), 단일 공유 런타임 + AI 호출 로깅, 모델 부트스트랩.
  용도1 해석층(그래프 사실=코드, AI 서술=교차검증 후 폐기), 용도2 질의응답(코드 우선,
  없으면 '확인 안 됨', 개방형만 AI+대조검증), 용도3 터미널 대화 + 지휘자-일꾼 스웜
  (포화점까지) + 3B/7B 벤치 하네스.
- 웹 그래프 뷰어(vis-network, 노드 클릭 확장, 확실=실선/불확실=점선), Neo4j 승격 백엔드.
- CLI 전면 서브커맨드: scan·ask·ai(chat/swarm/bench/model)·view. install.sh 전체 번들.

**검증 결과 [실측 — 컨테이너].**
- 전 모듈 임포트 37/37 OK. `compileall` OK.
- **pytest 25 passed**(types·model·engine·jaban(warrant/resolve)·ai·parsers).
- 파서 단위검증: nmap XML·maigret JSON·holehe/sherlock 정규식·theHarvester JSON — 합성 입력 통과.
- CLI 전 경로 실행: scan(mock)+interpret+web+out, ask(구조적 AI 0회 / 없음=확인 안 됨),
  ai model/bench/swarm/chat(스텁), view. 웹 HTML 데이터 주입 확인.
- llama.cpp: 소스 빌드 rc=0, `llama-cli --version` 작동.
- safety/tor/neo4j/darkweb/leak: 미가용 시 전부 우아하게 skip(무크래시).
- 규모: 파이썬 ~3,000줄.

**다음 (increment 2~, 주로 사용자 VM 실측).**
1. 사용자 VM: 실도구 설치 후 파서 실측 교정(maigret/sherlock 실출력), 실 3B/7B 벤치.
2. `--with-ai` 로 모델 받아 해석층·질의응답·스웜 실추론 검증.
3. 다크웹 live(Tor) 실측, h8mail 실 유출셋.
4. 여러 조각 교차검증 강화, Neo4j 대규모 승격 실측, GitHub 공개(라이선스 전문 첨부).

## 2026-08-28 — increment 2: 논문 6·7 도입 (추론 가속 + 대량 검색)

**6권 추론 가속(AI):** 투기 디코딩 출력불변(그리디 비트동일·표본 min(p,q)+(p−q)₊=p),
문법 강제 디코딩(DFA 마스크 — 적대 로짓 3000회 위반 0, GBNF·JSON 스키마를 llama-server에
강제 → 파싱 실패 구조적 0), 구조화 추출, KV 캐시 정책(페이징 무손실 기본·양자화는 규모파악
전용), draft 모델 투기 설정. **7권 대량 검색:** Aho-Corasick 다중패턴 1스캔, Bloom 위음성0
dedup, HyperLogLog·Count-Min 규모파악, 밴딧 라우팅(UCB1/Thompson 첫히트 가속·지속학습),
MinHash 슬롯일치에 **CP 신뢰구간 직접 발급(J2)**. 대량 텍스트 표적 스캔(bulkscan) = Aho+Bloom
+HLL+CountMin+안전필터. **검증: 논문 [검증] 수치 재현, pytest 통과.**

## 2026-08-28 — increment 3: 7논문 영혼까지 + 데이터축 대확장 + 아키텍처 개조

**피드백 반영:** ① 동일인 미결합은 하드신호 0이면 정답(수정 없음). ② J2 심화 — 유사도 CP
구간을 재사용 유사도 엔진(similarity.py)으로 이름·핸들·문체·bio·부재집합 어디에나. ③ CSAM
해시DB 훅 추가 예정(정규식은 1차 방어).

**7권 영혼까지:** 재사용 유사도 엔진(MinHash+LSH+CP구간). **베이지안 신호 융합(fusion.py)** —
각 신호에 우도비, 로그오즈 누적 → 약신호 여럿이 강신호(개별 바닥이어도 결합하면 과반). 측정
CI(rigorous)와 모델 사후확률(model-based)을 정직히 구분.

**동일인 신호 대확장(resolve):** 이미지 지각해시(같은 사진=하드), 프로필 bio 재사용(하드),
문체 유사(소프트·CP), 동일 핸들·이름유사(등급), + 운영자 상관(공유 분석ID/파비콘).

**데이터축(수집기 11→19):** 순열(아이디·이메일·이름추정)·Gravatar, RDAP·crt.sh·DNS,
GitHub(커밋 실명·이메일), 웹지문(GA/AdSense/GTM/파비콘). 이미지 pHash/dHash·EXIF GPS 유틸.

**아키텍처 개조(17h 목록):** 고정점 반복 수렴 루프(고정 depth→예산·수렴 판정, Bloom 무한루프
차단), 증거 출처 사슬·오염 전파(provenance — 유출 오염시 하위 자동 강등), 부정정보 신호
(footprint 크기·부재 지문), 타임라인 재구성·시간대 추론, 셀렉터 피벗팅(고유식별자 추출),
적대적 자기검증(AI가 자기 주장 반박→강등, 문법강제 JSON).

**검증 [실측 — 컨테이너]:** pytest **58 passed**, 60 모듈 임포트 0 실패. 파서·수치 전량 단위검증.

## 2026-08-28 — increment 4: 종합·플랫폼화 + pro 기법

**추가 수집기(→20):** Keybase(암호학적 검증 연결=확실 동일인). **종합 산출:** 프로파일
카드·HTML 리포트(신원·동일인 융합신뢰·피벗 셀렉터·타임라인·검색 dork), 신뢰도 종합.
**pro 기법:** 검색 dork 자동생성(다엔진, §2pro), 조직정찰(이메일 명명규칙 추론·전직원 생성,
§3pro). **플랫폼화:** 대화형 수사 REPL(ask/pivot/expand/report/graph), 워크플로우 저장·재현·
성과학습(person/fraud/developer/infra/missing), 조건부 밴딧(표적특징별 학습). **안전:** CSAM
해시DB 훅(정확+지각해시) — 정규식 1차 방어 위에.

**신규 CLI:** `artes report` · `investigate` · `workflow list/run` · `dork` · scan `--report
--card --verify --max-queries --max-seconds`. **UI 대청소:** 웹 뷰어(타입 필터·검색·범례·모던),
프로파일 카드 리포트.

**검증 [실측]:** pytest **66 passed**, 65 모듈 임포트 0 실패, compile OK, 전 CLI 명령 스모크,
~5500줄.

## 2026-08-28 — increment 5: 이미지 축 실연결 + 상호운용 + 통합검증

**이미지 축 실전:** Gravatar·GitHub 아바타 다운로드→pHash(DCT, numpy)→계정 attrs. "같은
사진=동일인" 하드 신호가 실제로 발화. **상호운용 내보내기:** GraphML(Gephi)·Maltego CSV·
STIX 2.1 번들 + `artes export`. **변화 모니터링:** 그래프 diff(새/사라진 엔티티·확실성 변화)
+ `artes monitor`. **통합 테스트:** 다신호 동일인(같은 사진+bio=확실, 이름유사=등급 융합)→
출처 오염 전파→리포트 종합 end-to-end.

**검증 [실측]:** pytest **73 passed**, compile OK, 전 CLI 매트릭스(scan/ask/ai/investigate/
workflow/dork/report/export×3/monitor/view) 스모크, ~5740줄, 22 수집기 상당.

## 2026-08-28 — increment 6: 법의학·사칭탐지 + 최종 상호운용

**문서 메타데이터 법의학(§4pro):** PDF/Office(docx/xlsx/pptx) 작성자·회사·소프트웨어·수정이력
추출(FOCA식, 표준 lib) + `artes docmeta`. **오타·유사 도메인(§82):** 사칭/피싱 변형 생성
(문자생략·중복·인접키·동형글자·TLD스왑) + `artes typo [--check]`. **§6 부재신호 resolve 완전연결:**
maigret가 부재 사이트 기록→두 신원 "같은 곳들에 똑같이 없음"이 융합 신호. **웹보강:** URL 단축
확장·security.txt·robots.txt. **리포트에 활동 시간대(§8) 배선.**

**최종 검증 [실측]:** pytest **80 passed**, 72 모듈 임포트 0 실패, compile OK, 전 CLI 매트릭스
(scan/ask/ai/investigate/workflow/dork/typo/docmeta/report/export×3/monitor/view) 스모크,
~6,100줄, 24 수집기 상당(옵트인 포함). 7논문 전량 도입(JABAN.md).

## 2026-08-28 — increment 7: Dolphin 무검열 AI + 대규모 수집기 확장(22→39)

**AI 모델 교체:** Qwen/Llama → **Dolphin 시리즈(무검열 오픈웨이트)**. 기본 dolphin3-qwen2.5-3b,
옵션 8B/1.5B/0.5B/2.9.4. OSINT 해석에서 불필요한 거부 없이 동작. **도구 레벨 안전(CSAM 해시DB·
불법콘텐츠 필터·용도 고지)은 유지** — 모델 검열과 별개.

**신규 수집기 17개(전부 키 불필요, 파서 검증):**
- 소셜: Reddit·HackerNews·GitLab·WebFinger(페디버스)
- 전화: PhoneInfo(순수 phonenumbers — 국가·통신사·회선·시간대, 오프라인)
- IP/인프라: ReverseDNS·ASN(bgpview)·IPGeo(ip-api)·HTTPHeaders·**ShodanInternetDB(포트·CVE, 키없음)**·
  DoHDNS(dnspython 없이 DNS)·CertSpotter·URLScan
- 개발자: GitHubKeys(SSH 지문=피벗)·GitHubGists(이메일 추출)·npm 메인테이너
- 신원: GravatarProfile(검증 연결계정=강한 동일인)

**검증 [실측]:** pytest **97 passed**, 임포트 0 실패, 39 수집기(다크웹 포함 41).

## 2026-08-28 — increment 8: 7대 레벨업 (①~⑦ 전부 구현·검증)

**② 반밴/매너 계층**(politeness.py): 호스트별 rate-limit·지수백오프+지터 재시도·프록시풀·
Tor NEWNYM 로테이션 → proc HTTP 배선. 대규모 스캔이 밴 없이 굴러감.
**① 자동 피벗 엔진**(pivot.py): 셀렉터 승격(암호화폐·PGP·SSH→엔티티, 공유=하드 동일인)+
가치 랭킹 역검색 재투입→수렴. `investigate --auto`.
**③ 지속 케이스 저장소**(casedb.py, SQLite): save/load/list/merge/시간축 diff. `artes case`.
**④ 평가 하네스+교정**(evaluation.py): 라벨 합성 데이터로 정밀도/재현율/F1 스윕 + 신호 LR
경험적 교정(name_sim LR≈168 실측). `artes eval`.
**⑤ AI 수사관**(agent.py): AI가 그래프 읽고 다음 피벗·정지 스스로 결정(문법강제 JSON, 무검열
Dolphin 지휘). `investigate --agent`.
**⑥ 얼굴 임베딩 매칭**(face.py): 다른 사진 같은 얼굴→하드 동일인. 아바타 페치에 배선(모델 옵션).
**⑦ 벡터 RAG**(rag.py): 수집 텍스트 색인(임베딩 또는 TF-IDF 폴백)→근거 기반 AI 답. `ask --rag`.

**검증 [실측]:** pytest **117 passed**(+20), 임포트 0 실패, compile OK, 신규 CLI 전 스모크
(investigate --auto/--agent·case·eval·ask --rag). ~7,700줄.

## 2026-08-29 — increment 9: AI 대폭 업그레이드 (2026 SOTA, 병렬 연구 반영)

10개 이상 병렬 리서치 에이전트로 llama.cpp·에이전트/추론·엔티티해소/임베딩·AI-OSINT 최신
논문·기술·깃허브를 조사하고, **작은 로컬 모델에 실제로 효과가 검증된** 기법만 도입했다.

**AI 추론·판정(작은 모델을 신뢰 가능하게):**
- **reason-then-format(형식세 회피):** 문법강제 JSON 안에서 추론하면 작은 모델 정확도 급락 →
  1패스 자유서술 추론 + 2패스 판정만 문법 추출 (verify.reason/extract_verdict).
- **Chain-of-Verification(factored):** 주장→독립 검증질문→격리 답변→상호확증률
  (verify.cove_verify). entity 정확도 17→70% 방식.
- **신뢰도 융합:** 평균 logprob(zero-shot 최강 신호)+서술적 확률+CoVe 확증률→
  확실/불확실/**insufficient_evidence**(기권 1급화). verify.judge/fuse_confidence.
- **스키마 위생:** evidence(자유)→verdict(enum)→confidence 순서 + enum 강제(grammar.verdict_schema).
- **샘플러 프리셋:** min-p+DRY+낮은 temp, top-k/top-p 비활성, XTC off(backend.FACTUAL_SAMPLER) —
  작은 모델 반복·비일관 억제. logprob 반환(generate_conf).
- **llama-server CPU 튜닝:** --mlock·--cache-reuse·--flash-attn·물리코어 스레드 기본(start_server).
- `scan --deep-verify`로 동일인 주장에 심층 판정 배선.

**검색(하이브리드 RAG):** BM25(순수 파이썬)+밀집(bge-small→MiniLM→TF-IDF 폴백)을
**RRF 융합**+선택적 CrossEncoder 재순위. 희귀 토큰(이름·핸들·ID)에 강한 BM25로 OSINT 정밀도↑
(rag.RagIndex).

**문체(짧은 글 저자판별):** 문자 n-그램(3~5) TF-IDF 코사인(stylometry.py) — 트윗 길이에서
Burrows Delta보다 강함. resolve의 소프트 동일저자 신호로 배선.

**신규 수집기 5개(전부 키·계정 불필요, 파서 검증):**
- **XposedOrNot**(이메일 유출 노출 — 키없는 HIBP 대체)
- **WhatsMyName**(wmn-data.json로 700+ 사이트 아이디 확인)
- **WaybackCDX**(도메인 아카이브 URL→서브도메인/경로)
- **HackerTarget 역방향IP**(IP 공존 도메인 — 신규 능력, 상한 예산)
- **psbdmp**(Pastebin 덤프 노출)

**검증 [실측]:** pytest **139 passed**(+22), 임포트 0 실패, 44 수집기(다크웹 포함 46),
CLI 스모크 OK. 실사이트·실모델 벤치는 사용자 Arch VM에서(이 컨테이너는 OSINT 사이트·HF 차단 —
전 신규 수집기는 도달 실패 시 우아하게 skip 확인).

## 2026-08-29 — increment 10: 융합수학·AI판정 대규모 업그레이드 (병렬 SOTA 연구)

3개 병렬 리서치 에이전트(융합수학·LLM교정·LLM판정)로 ~60개 논문/기법을 조사하고, 오프라인·
순수코드로 구현 가능한 것만 도입. 나이브 베이즈 고정LR → 정식 레코드 링키지 수학으로 승격.

**동일인 융합 수학 (core/linkage.py, cluster.py):**
- **Fellegi–Sunter m/u 분해**: 신호별 m=P(일치|동일인)·u=P(일치|타인) 분리. 일치가중
  log2(m/u), **불일치 가중** log2((1-m)/(1-u)) (나이브가 버리던 음의 증거).
- **다단계 비교**(exact/high/low/disagree) 단계별 (m,u) — '동일'과 '유사' 구분.
- **Winkler 희소성 보정**: 희귀값 일치(rare handle)는 흔한값보다 훨씬 강함, w += log2(ū/u_value).
- **총가중→확률** P = 2^W/(1+2^W). **EM**으로 라벨 없이 (m,u,λ) 추정(E/M 스텝).
- **Platt 교정**(순수 경사하강) W→보정확률. **Beta-이항 독립신호 가드**(cp_lower 재사용).
- **전역 군집화**: 연결요소 + **PIVOT 상관 군집**(must-link/cannot-link) — 쌍대 판정의
  전이 불일치(A~B,B~C 확실인데 A≁C) 해소. 상관 신호(image+face)는 그룹으로 1표 축약.

**AI 판정 교정 (ai/calibrate.py, verify.py):**
- **의미 엔트로피**(Nature 2024): 표본을 의미로 군집→엔트로피, 작화 탐지(토큰확률 높아도
  의미 갈리면 불확실).
- **분할 컨포멀 예측**: 소량 교정셋으로 기권율에 **통계적 보장**(오류 ≤ α). 손튜닝 임계 대체.
- **로지스틱 신호 융합**(산술평균 대체 — 강신호가 약신호로 끌려가는 문제 교정).
- **p(True) 자기평가**(Kadavath) + **GenRM p_yes**(K표본 yes 비율) + min-logprob.
- **ECE/AUROC** 평가, **체크리스트 분해 + 근거 인용 강제**(evidence_id 검증 — 작화 억제).
- judge_calibrated(): 다표본→의미엔트로피/일관성+p(True)+융합→확실/불확실/기권.

**CLI:** scan --deep-verify(교정판정) · --cluster(전역 군집) · --fs-fusion(FS 융합).

**검증 [실측]:** pytest **160 passed**(+21), 컴파일 0 실패, CLI 스모크 OK. 신규 모듈
linkage·cluster·calibrate 전부 순수코드 결정적 단위검증. 실모델 벤치는 사용자 VM.

## 2026-08-29 — increment 11: 더 빠르게·더 깊이·더 강하게 (3축 병렬 SOTA 연구)

3개 병렬 리서치(초고속 비동기·그래프분석·견고성/조작탐지)로 ~60개 논문/기법 조사 후
오프라인·순수코드 구현만 도입. 세 축 동시 강화.

**더 빠르게 (core/adaptive.py + proc.py):**
- **AIMD 적응형 동시성**: 고정 Semaphore(32) → 성공 +1 / 429·timeout ×0.7 학습(Little's Law).
- **토큰버킷** 호스트별 속도제한(느린 호스트가 전체 안 막음).
- **요청 합류(single-flight)**: 동일 URL in-flight 1회로 — 실측 50 동시요청→네트워크 1회(98%↓).
- **인메모리 TTL LRU** 캐시(디스크 앞단). uvloop 자동 적용(있으면).

**더 깊이 (core/graphx.py — 순수 파이썬 그래프 분석):**
- **시드 편향 PageRank**: '지금 아는 것' 기준 다음 조사 대상 순위(피벗 랭커).
- **매개중심성**(Brandes): 두 군집 잇는 브로커/다리 노드 식별.
- **집합적 ER**(라벨 전파): A~B,B~C 증거를 이웃 전파해 전이적 신원 통합.
- **링크 예측**(공통이웃·Adamic-Adar·자원할당): 은닉연결 = 다음 조사 후보.
- **k-core**·**이분투영**(공유 트래커/전화→같은 소유자, 희소성 가중)·**경로 설명**·에고넷.
- rank_pivots = 시드PPR+중심성 블렌드. CLI scan --pivots.

**더 강하게 (core/trust.py — 견고성/조작탐지):**
- **진실 발견**(Average·Log): 소스 신뢰 ↔ 주장 믿음 공동추정, 다작 스팸 감쇠.
- **독립성 그룹화**: 재게시·에코 소스 축약(가짜 합의 방지).
- **봇 점수**: 활동률·핸들 엔트로피·케이던스 규칙성.
- **동형이의어 골격**(유니코드 confusable) + 스크립트 혼용 → 사칭 탐지.
- **신선도 지수감쇠**(반감기별)·**Dempster-Shafer**(Yager — 고충돌 안전)·**SybilRank**.
- **방어 심층 게이트**: CONFIRMED = 믿음↑ AND 독립원천≥2 AND 양식≥2(단일 스푸핑 신호로 확정 불가).

**검증 [실측]:** pytest **180 passed**(+20), 컴파일 0 실패, CLI 스모크 OK, 합류 마이크로벤치
98%↓ 실측. 신규 3모듈 adaptive·graphx·trust 전부 순수코드 결정적 단위검증.

## 2026-08-29 — increment 12: AI 대화·코딩·병렬 심화 (3축 병렬 SOTA 연구)

3개 병렬 리서치(대화 심화·코딩 에이전트·병렬 오케스트레이션)로 SOTA 조사 후 재구축.
핵심: 작은 모델의 자기비평(vibes)은 약하다 → 판정은 결정적 도구(인터프리터·정적검사·
테스트·투표)가, 모델은 실오류만 보고 수정.

**코딩 에이전트 (ai/coder.py — 신규):**
- **안전 실행 샌드박스**: python -I 격리 서브프로세스 + 타임아웃 + rlimit(CPU/메모리/파일).
- **정적검사 게이트**(ast·py_compile·pyflakes) → **실행** → **테스트** 단계별 값싼순.
- **edit-run-test-fix 수복 루프**: 실제 트레이스백/실패 assert를 넣어 수정, 진척없으면 중단.
- **테스트 생성**(테스트 주도) + **best-of-N 실행 합의**(통과분 최소시도/행동 클러스터 최빈).
- **실증**: 버그 fib → 실제 AssertionError → 수복 → 2시도 통과(서브프로세스가 판정).

**병렬 오케스트레이션 (ai/orchestrator.py — 신규):**
- **DAG 웨이브 스케줄러**(Kahn): 의존성 있는 하위작업을 위상정렬 웨이브로 최대 병렬.
- **슬롯 세마포어**(서버 --parallel 슬롯): 전 호출 감싸 포화점 위 초과 차단(Little's Law).
- **재시도**(지수백오프+지터) 실패 격리. **적응 조기종료**(Beta 규칙 — 리더 확정 시 표본 중단).
- **계층 트리 리듀스**(대형 단일 리듀스 회피) + **RRF** 순위 융합.

**대화 AI (ai/chat.py — 재구축):**
- **요약 버퍼 메모리**(최근 verbatim + 재귀 러닝 요약 → 무한 이력) + **토큰 예산 조립**
  (시스템 프롬프트 잘림 방지). **엔티티/사실 상시 주입** + **대화 상태**(목표·미해결).
- **시스템 규칙 재주입**(생성 직전 — lost-in-the-middle 완화).
- **ReAct 도구사용**: 문법강제 JSON 액션 → 도구 호출 → 관측 → 계속(작은 모델 파싱 실패 0).
- **반복 억제 샘플러**(repeat_penalty + DRY).

**스웜 재구축**(swarm.py): 구조화 스펙(목적·형식·의존성) → DAG 병렬 → 검증 게이트 → 트리
취합. run_swarm_coding = 실행검증 병렬 코딩(각 하위작업 repair_loop). CLI ai code/swarm.

**검증 [실측]:** pytest **200 passed**(+20), 컴파일 0 실패, 코딩 에이전트 실행 실증, CLI OK.
신규 coder·orchestrator + chat/swarm 재구축 전부 결정적 단위검증. 실모델은 사용자 VM.

## 2026-08-29 — increment 13: Kali/GitHub OSINT 대량 도입 (초대규모 병렬 조사)

4개 병렬 리서치(Kali 메타패키지·사용자/신원·도메인/인프라·위협/유출/메타)로 현존 오픈소스
OSINT를 초대규모 조사, 키 불필요·합법·검증된 것만 도입. 수집기 44→**70**(+26). auth 상태
실시간 검증(abuse.ch 쿼리API 유료화·OpenCorporates 토큰화 등 반영 — 피드/무키 경로만).

**인프라 심화 (infra2_c.py — 키 없는 공개 JSON):**
- RIPEstat(IP/ASN→프리픽스·홀더·악용연락처·역DNS) · OTX 수동DNS(과거 호스트↔IP) ·
  Anubis(jldc) · Columbus(CT DB) · RapidDNS(서브도메인·역IP).

**신원·조직 enrichment (enrich2_c.py — 공개 지식/등기):**
- Nominatim(지명→좌표) · Wikidata/Wikipedia(이름/조직→구조화 사실·연결 핸들) ·
  SEC EDGAR(회사→CIK) · GLEIF LEI(법인→소유 그래프) · keys.openpgp.org(이메일→PGP 신원).

**위협·암호화폐·자격증명 (threat2_c.py):**
- Feodo Tracker(IP→봇넷 C2, 정적 피드) · OpenPhish(피싱 피드) · Bitcoin(주소→잔액·거래,
  blockchain.info+mempool) · ProxyNova COMB(자격증명 노출 — **평문 비밀번호 미저장, 건수만**).

**Kali/GitHub CLI 래퍼 (kali_c.py — which() 게이트, 없으면 skip):**
- subfinder·amass·assetfinder·dnsx·dnstwist·gau·waybackurls·whatweb·exiftool·nexfil·
  mailcat·zehef. install.sh에 apt/go/pip 설치 시도 추가(설치된 것만 자동 활성).

**신규 엔티티 타입**: ORG·ASN·GEO·CRYPTO·MALWARE. 타입판정에 BTC/ETH 주소 인식 추가.

**검증 [실측]:** pytest **219 passed**(+19), 컴파일 0 실패, 70 수집기, install.sh 문법 OK.
전 신규 파서 네트워크 없이 단위검증(도달 실패 시 우아하게 skip). 실사이트·실도구는 사용자
Kali VM. 안전: COMB 평문 비밀번호 미저장 테스트로 확인. CSAM 필터·동의 게이트 유지.

## 2026-08-29 — increment 14: 선택적 키 경로 + AI 전면 강화 (2축 병렬 연구)

**(A) 선택적 키 경로 (core/keys.py + collectors/keyed_c.py):**
기본은 키 불필요(70 수집기 그대로). 키는 **선택적 부스터** — 있으면 유료/제한 소스 개방,
없으면 조용히 skip(available()=False). 키는 요청에만 쓰고 그래프·근거·로그에 절대 미기록.
- KeyStore: env(ARTES_KEY_*·표준 이름) → ~/.artes/keys.json. status()는 존재 True/False만.
- KeyedCollector 게이트 + 6개 키 수집기: Shodan(정식)·HIBP·VirusTotal·GreyNoise·AbuseIPDB·
  Hunter.io. CLI `artes keys`(값 미표시), `ai cache`(캐시 통계). 총 수집기 76.

**(B) AI 전면 강화 — 속도·성능 (2개 병렬 리서치):**
- **응답 캐시 (ai/cache.py):** 생성 자체 스킵 — 정확 캐시(hash) + 선택적 의미 캐시(임베딩
  코사인, GPTCache식). 안전: 판정/검증류는 정확만(유사≠동일 오답 차단), 해석/대화/RAG만
  의미 허용. Runtime에 배선(결정적 계열만 저장), 디스크 지속. 반복 호출 즉시 반환.
- **병렬 배치 생성 (Runtime.generate_batch):** 독립 프롬프트 N개를 슬롯 수만큼 동시 생성
  (연속 배칭 서버에서 겹쳐 처리, 순차 for 대비 처리량↑).
- **적응 라우터 (ai/router.py):** FrugalGPT식 캐스케이드 — 난이도 추정(길이·엔티티·키워드,
  추론 0) + 1패스 logprob 신뢰 → 싼 judge 먼저, 확실+고신뢰면 채택, 애매하면
  judge_calibrated, 여전히 낮고 8B 있으면 승격. ESC 조기종료 자기일관성(창 만장일치 시 중단).
  adaptive_generate(쉬우면 1패스, 어려우면 다표본). scan --deep-verify가 라우터 사용.

**llama.cpp 서빙(연구 반영, runtime 옵션):** cache_prompt·--cache-reuse·--flash-attn·물리코어
스레드는 기존 반영. KV q8_0/프리픽스 슬롯 고정은 배포 옵션.

**검증 [실측]:** pytest **237 passed**(+18), 컴파일 0 실패, 76 수집기, CLI keys/cache 동작,
캐시 배선 실증(2번째 호출 백엔드 0회). 키 값 미노출 테스트 통과. 실모델·키는 사용자 VM.

## 2026-08-29 — increment 15: 역할별 다중 AI (판정·코더·대화) + 6권 서빙 정책

3B 단일 모델의 지능 한계를 넘어 **AI를 역할별로 세분화**. 2개 병렬 리서치(무검열 코더 모델·
초거대 양자화 SOTA, HF 레포/크기 실검증)로 현존 최강 오픈소스를 매핑.

**역할 모델 레지스트리 (ai/models.py) — 전부 무검열(Dolphin/abliterated) GGUF:**
- **judge(OSINT 판정):** 작고 빠른 Dolphin3 0.5B/3B/8B — 저지연 대량 호출(정확성은 뼈대 보강).
- **coder(코딩):** Qwen2.5-Coder 3B/7B/32B(+abliterated 무검열) + Qwen3-Coder-30B-A3B(MoE),
  FIM 지원, 동일계열 드래프트. 현존 최강 로컬 코더.
- **chat(범용 대화):** 초거대 무검열 양자화 — Llama-3.3-70B-abliterated·Qwen2.5-72B-abliterated·
  dolphin-2.9.2-mixtral-8x22b·**Qwen3-235B-A22B-abliterated(235B/22B활성, 최대 지식)**.
  RAM에 맞춰 자동 티어 선택(recommend). "미친 초거대 양자화" = 235B IQ3.

**6권 「추론의 가속」 서빙 정책 (server_flags) — 무손실/손실 구분:**
- **투기 디코딩(-md 드래프트): 출력 불변=무손실** → 전 역할에 적용(정확성 무관·속도만↑).
- **KV 페이징(f16): 무손실** → judge/coder(정확 경로)는 이걸로 메모리 절약.
- **KV 양자화(q8_0): 손실** → chat(casual)만 허용, 판정·코딩엔 금지(6권 A3 정리).
- MoE 전문가 CPU 오프로드(--n-cpu-moe, 무손실 배치) → 235B를 작은 VRAM+큰 RAM에.
- flash-attn·물리코어 스레드·cache-reuse 전역.

**다중 서버 (ai/serving.py):** 역할별 llama-server를 다른 포트(judge 8080·coder 8081·chat 8082)로
동시 기동, 역할로 라우팅. 모델·바이너리 없으면 우아하게 공유 폴백. CLI `ai models`(RAM 적합
표시)·`ai serve <역할>`. ai chat→대화 모델, ai code/swarm→코더 모델로 자동 라우팅.
install.sh가 RAM 감지해 역할별 모델+드래프트 자동 다운로드.

**검증 [실측]:** pytest **249 passed**(+12), 컴파일 0 실패, install.sh 문법 OK, ai models 동작
(RAM별 추천 실증). 실모델 로드·벤치는 사용자 VM(HF에서 GGUF 받은 뒤). 무검열 유지.

## 2026-08-29 — increment 16: 크롬북에서 최강 AI(GLM 등) + 우리 도메인 양자화

정직한 재구성: 크롬북(4~8GB)엔 GLM-5.3-Flash급 초거대 모델을 **어떤 양자화로도** 못 얹는다
(정보이론·산수). 대신 사용자의 진짜 목표("크롬북에서 최강 AI, OSINT에도")를 세 길로 달성.

**실검증(web)**: GLM-5.3-Flash 실존(`z-ai/glm-5.3-flash`), **GLM-5.2 완전무료**(`z-ai/glm-5.2:free`,
$0), OpenAI 호환(openrouter.ai/api/v1). GLM-4.6 GGUF(unsloth) 존재.

**(1) 원격 큰 두뇌 — 크롬북에서 GLM을 진짜로 씀 (backend.OpenAICompatBackend):**
- OpenAI 호환 백엔드로 GLM-5.3-Flash·GLM-5.2-free·원격 VM llama-server·OpenRouter 전부 호출.
- serving.remote_backend_for: env(ARTES_<ROLE>_URL/KEY/MODEL) 또는 제공자 키(openrouter/zai)로
  자동. role_runtime 우선순위: 원격 → 로컬 서버 → 폴백. OSINT 판정(verify/interpret/ask)도
  judge 역할로 원격 GLM 사용 가능. 키는 헤더에만(로깅 0, 테스트로 확인).
- CLI `ai remote`(설정·테스트), `ai models`에 원격/온디바이스 표시.

**(2) 온디바이스 최강 소형 (models.ONDEVICE_TIERS):** 크롬북 오프라인·프라이빗용 —
Qwen3-4B·Gemma3-4B·Dolphin3-3B·Qwen3-1.7B(초저사양). RAM에 맞춰 선택.

**(3) 우리 도메인 양자화 — '우리만의 양자화'의 정직한 실체 (ai/quantize.py):**
- 범용 imatrix를 버리고 **우리 작업 분포(OSINT 판정·엔티티추출·근거답변·JSON·대화)로
  보정 코퍼스**를 만들어 imatrix를 직접 계산 → 저비트에서 **우리 일에 중요한 가중치 우선
  보존**. build_calibration()+quantize_plan(llama-imatrix→llama-quantize). CLI `ai quantize`.
- 정직: 무손실 마법 아님. 손실을 우리 도메인에서만 최소화(6권: 양자화=손실/투기·페이징=무손실).

**키 서비스 추가**: openrouter·zai(GLM). 검증: pytest **262 passed**(+13), CLI 동작.
크롬북 즉시 사용: OPENROUTER_API_KEY 하나 + (무료면) ARTES_AI_FREE=1 → GLM 대화·OSINT 판정.

## 2026-08-29 — increment 17: 최고 API 제공처 + 개인용 무검열 Dolphin + 배포 키 설정

**실검증(web)**: "가장 토큰 많은 곳"과 "가장 좋은 GLM"은 다르다 — 하나로 안 정해짐.
- Cerebras: **1M 토큰/일 무료**(카드 불필요, 초고속) — 가장 관대. 모델=Qwen/Llama.
- OpenRouter: GLM-5.2 무료(z-ai/glm-5.2:free $0), GLM 전부. GLM 쓰려면 여기.
- Z.ai: GLM Coding Plan Lite $18/월(~400프롬프트/주) — GLM 헤비유저 최고 가성비. GLM-5.3.
- Groq(100K/일)·Gemini(관대) 무료.

**제공처 레지스트리 확장 (models.REMOTE_PROVIDERS):** 5개 제공자 각각 base_url·key·
signup(가입 주소)·free(무료 토큰량)·priority. PROVIDER_MODELS로 비-GLM 제공자는 그 제공자
모델(Cerebras qwen-3-235b 등) 사용. serving.remote_backend_for: priority 순 자동선택 +
ARTES_AI_PROVIDER 강제. CLI `ai providers`(비교·가입주소), `ai setup`(대화형 키 입력→
~/.artes/keys.json 권한600).

**배포 원칙**: ARTES엔 어떤 키도 동봉 안 함 — 사용자가 발급해 직접 넣어야 함(테스트로 확인).
`ai setup`이 가입 URL 안내 + 입력받아 저장. 비대화형은 URL만 안내.

**크롬북 개인용 완전 무검열 Dolphin (models.PERSONAL_MODELS, serving.personal_runtime):**
OSINT와 완전 분리된 순수 개인용 로컬 챗. Dolphin3 1.5/3/8B, 전용 포트 8083(역할 포트와 분리).
CLI `ai dolphin`. install.sh가 RAM 맞으면 자동 다운로드. API(GLM 등) AI와 동시 사용 가능.

**키 서비스 추가**: cerebras·groq·gemini. 검증: pytest **272 passed**(+10), CLI 전부 동작.
정직: 실 API 호출·실모델은 사용자 환경(키 넣은 뒤).

## 2026-08-29 — increment 18: 대규모 API 키 자동 인식 (수천 종 AI)

**요청**: "api key 자체가 몇천개 이상의 AI 종류를 전부 인식 — 현존 거의 모든 API 키 종류."

**ai/providers.py (신규) — ALL_PROVIDERS 32개 제공처 레지스트리:** 각 제공처의 base_url
(OpenAI 호환 /v1)·표준 키 env·**키 접두사 정규식**·가입 URL·openai 호환 여부·비고.
게이트웨이(openrouter 400+ 모델) 포함 → 이 레지스트리 하나로 사실상 **수천 종(제공처×모델)**
커버. 커레이티드 5(openrouter/zai/cerebras/groq/gemini) 외에 openai·anthropic·xai·mistral·
cohere·zhipu·deepseek·moonshot·sambanova·together·fireworks·deepinfra·novita·hyperbolic·
nebius·nvidia·perplexity·ai21·lambda·baseten·github·huggingface·replicate + 로컬(ollama·
lmstudio·localai).

**detect_provider(key)**: 키 접두사로 제공처 자동 판별. 고유 접두사(sk-ant-/sk-or-/gsk_/csk-/
xai-/pplx-/fw_/nvapi-/r8_/hf_/AIza/tgp_v1_/ghp_·github_pat_/sk_(novita)/eyJ(JWT))는 확신.
`sk-...`처럼 공유 접두사는 openai 기본+후보(deepseek·moonshot) 제시. 순서 중요(sk-ant-이
sk-보다 먼저, sk_(novita)와 sk-(openai) 구분).

**backend_for_provider / backend_from_key (serving.py)**: 붙여넣은 키 하나 → 알맞은 백엔드
자동 구성. anthropic(openai=False)만 **AnthropicBackend(신규, 네이티브 /v1/messages,
x-api-key 헤더)**, 나머지는 OpenAICompatBackend. 모델=명시>PROVIDER_MODELS>GLM 게이트웨이
추천>사용자 카탈로그 선택. remote_backend_for에 4단 폴백 추가(명시 env→강제 지정→커레이티드
5→ALL_PROVIDERS 전체) — 거의 모든 키를 자동 인식·연결.

**keys.py _STD_ENV 확장**: 25개 제공처의 표준 env 이름(ANTHROPIC_API_KEY·OPENAI_API_KEY·
XAI_API_KEY·DEEPSEEK_API_KEY·HF_TOKEN 등)도 인식.

**CLI**: `ai key <KEY>`(자동 인식+저장, 끝4자리만 표시, --test 연결확인, --no-save),
`ai catalog <provider>`(모델 목록 /models — OpenRouter 400+). `ai providers`에 확장 안내.

**정직**: base_url·접두사는 대표값(제공처가 바꾸면 배포 시 재확인). list_models는 실네트워크
필요(이 컨테이너는 외부망 제한 → []로 우아하게 폴백, 로직은 단위검증). 키는 헤더에만·로깅 0·
그래프/근거 0·동봉 0(배포 원칙 유지). CSAM 필터 불변.

**검증**: pytest **303 passed**(+31, test_advanced12), CLI `ai key`(anthropic/groq/애매 sk-)·
`ai catalog` 동작 확인.

## 2026-08-29 — increment 19: 10만+ 모델 인식·지원 (전 모델 카탈로그)

**요청**: "훨씬 더 많이 — 현존하는 모든 모델 인식·지원, 최소 10만개."

**정직한 방법(하드코딩 10만 줄 아님)**: 실검증(HF MCP·web) — HF Hub의 **GGUF 라이브러리
텍스트생성 모델 = 10만+**(계속 증가). 우리 llama.cpp는 임의 GGUF를 돌린다 → 그 10만+
전부가 우리가 '지원'하는 모델. 여기에 모든 OpenAI 호환 제공처의 **라이브 /models 합집합**
(OpenRouter 400+·Together·Fireworks·DeepInfra 각 수백~수천)을 더한다.

**ai/catalog.py (신규)**:
- `hf_search_gguf(q, sort, author)` — HF Hub API `?library=gguf&pipeline_tag=text-generation`
  로 검색(다운로드/좋아요순). 결과의 어떤 repo든 로컬 실행 가능.
- `hf_gguf_files(repo)` / `hf_gguf_url(repo,file)` — 받을 GGUF 파일 확인·URL.
- `aggregate_remote_catalogs()` — 제공처별 /models 합집합 → {model_id: [providers]},
  ~/.artes/model_catalog.json 캐시.
- `resolve_model(id)` — 이 모델 어디서 도나: 로컬 GGUF(‘org/name’ 꼴)? 어느 제공처?
- `search_models(q)` — 로컬(HF)+원격 통합 검색. `catalog_stats()` — 지원 규모.

**CLI**: `ai scale`(지원 규모 근거), `ai find <q>`(HF 10만+ · 원격 통합 검색),
`ai resolve <id>`(실행처 판별), `ai catalog --all`(전 제공처 합집합 집계+캐시),
`ai pull-info <repo>`(임의 GGUF 받기 URL·파일·경로 — 10만+ 지원의 실체).

**정직**: 10만+ = ‘임의 GGUF 실행 + 라이브 카탈로그 집계’. list/검색은 실네트워크 필요
(이 컨테이너 외부망 제한 → 빈결과 폴백, 로직은 주입데이터로 단위검증). 사용자 크롬북/VM에선
HF 10만+ 실검색·수천 원격모델 실집계. 키 미로깅·미동봉·CSAM필터 불변.

**검증**: pytest **317 passed**(+14, test_advanced13), CLI scale/resolve/find/pull-info 동작.

## 2026-08-29~09-01 — increment 20~24: 뷰어 물리엔진 제거 · 속도 · 소스 대량확장

**increment 20~22 (SNS 1차 + 속도 + 하이라이트 방지)**: social3_c 추가(Bluesky·ChessCom·
Lichess·DevTo·DockerHub·Wikipedia·Codeberg). Reddit(2026 무인증 차단)·Mastodon(인증 필요화)
제외. whatsmyname 폭주(900~1130s) → hard_cap 40s(as_completed 타임아웃)·확장깊이 perm-skip.
resolve.py 동일인 간선 O(n²)→스타 토폴로지(>6인 그룹, 2094-edge 헤어볼 방지).

**increment 23 (뷰어 전면 재작성 — 물리엔진 제거)**: 사용자 피드백("물리엔진때문에 못보는건
싫다·너무 느리다·로딩이 오래"). template.html을 vis-network/CDN/물리엔진 **전부 제거**한 순수
정적 리포트(~10KB, 인라인 CSS + 바닐라 JS)로 재작성. 핵심사실 카드(실명·전화·위치·이메일)·
확실/불확실 사이트별 그룹·근거 클릭펼침·유형필터·검색. 저사양·오프라인 즉시 로드.
base.py 전 수집기 `max_run`(기본 45s) 블랭킷 타임아웃.

**increment 24 (소스 대량확장 — 병렬 리서치 도입)**: 3개 에이전트 병렬 웹리서치로 무키 공개
소스 검증·도입. **+19 수집기(82→101)**:
- **social4_c(12)**: ArtStation(실명·도시·국가·소셜)·StackExchange(표시이름·위치, /associated
  네트워크확장)·WikimediaGlobal(전역계정=모든 위키)·Steam(XML 실명·위치·SteamID64)·Mixcloud·
  Launchpad·CratesIo(→github 교차연결)·SpeedrunCom·Lemmy(→matrix 교차연결)·Duolingo·Codewars·
  Roblox(아이디→uid 2단계 POST). proc.py에 post_json 추가.
- **breach2_c(3)**: LeakCheckPublic·HudsonRock(인포스틸러 감염)·XposedAnalytics. 전부
  노출 메타데이터만 — **평문 비밀번호 절대 미저장**(원칙 유지).
- **enrich3_c(4, 사람 피벗)**: GravatarJSON(이메일→실명·핸들·검증계정, 최강 피벗)·
  GitHubCommitEmail(이메일→실명·아이디)·ORCID·OpenAlex(이름→연구자 신원). NAME 피벗은 저신뢰.

**정직**: 전화→실명·WhatsApp/Telegram 열거, HIBP 이메일조회, OpenCorporates는 유료/ToS라
미도입(리서치 확인). NAME 수집기는 소음방지 위해 "성+이름"(공백 포함)만 질의. 라우팅:
USERNAME 36·EMAIL 19·NAME 4·PHONE 4 수집기. CSAM 필터·키 미로깅/미동봉 불변.

**검증**: pytest **347 passed**(+30, test_advanced14/15), 레지스트리 101개 무중복 배선 확인.

## 2026-09-01 — increment 25: 사용자 OSINT 컬렉션 정독 후 무키 소스 대량확장

**요청**: 사용자가 OSINT 모음(start.me Ultimate OSINT·LinkedIn·Reddit)과 프로그램 2차 리스트
(Epieos·IntelX·SpyCloud·BreachDirectory·LeakCheck·BreachForums·SocialLinks·Toutatis·Twint·
PhoneInfoga·Truecaller·Tinder-OSINT 등) 제공 → "완전히 읽고 학습해 쓸만한 전부 도입".

**지목 도구 정직 평가**(2개 병렬 리서치 에이전트):
- 무키 도입가능: **LeakCheck·HudsonRock** — 이미 증분24에 도입됨(신규 없음).
- 키/유료 제외: Epieos(엔터프라이즈)·IntelX(키)·SpyCloud(엔터프라이즈)·BreachDirectory(RapidAPI키)·
  SocialLinks(유료)·Truecaller(계정/ToS).
- 불법/미도입: **BreachForums**(도난데이터 거래 포럼=불법)·**PwnDB**(평문 비번)·
  Tinder/Snapchat/SocialMapper(비동의 제3자 위치·얼굴추적=ARTES 합의범위 위반)·
  Twint(2023 트위터 봉쇄로 사망)·ScrapedIn/fbi/TikTok/Discord/Reddit스크레이퍼(로그인/쿠키/ToS).
- PhoneInfoga는 이미 도입됨.

**실제 신규 도입(+21, 101→122)** — start.me·awesome-osint에서 검증한 무키·합법·공개 API만:
- **social5_c(12)**: Minecraft(→UUID)·MyAnimeList(Jikan)·AniList(GraphQL)·Kitsu·TETR.IO·Scratch·
  Discogs(실명·위치·홈페이지)·SourceForge(연결 소셜계정)·Hashnode(GraphQL 소셜링크)·Packagist·
  Bitbucket·**Telegram**(t.me 공개 프리뷰 — 로그인/봇토큰 없이 공개 카드만).
- **scholar_c(4)**: Crossref·SemanticScholar·OpenLibrary(이름→저자/소속/저작)·OpenSanctions
  (이름→제재·PEP 명단 스크리닝, 강매칭 0.6+만). ORCID/OpenAlex(증분24) 보강. 전부 성+이름만 질의.
- **verify_c(5)**: KickboxOpen·Disify(이메일 배달가능·일회용·역할계정·오타교정), IPWhois(ipwho.is
  ASN·ISP·조직)·GreyNoiseCommunity(스캐너/양성 분류)·SANSISC(DShield 공격신고 수).

**정직 원칙 유지**: 비동의 제3자 위치·얼굴추적·도난데이터 포럼·평문 비번은 도입 거부(ARTES 합법
OSINT 스코프). Telegram은 공개 프리뷰만(비공개 계정 안 나옴). 이름 피벗은 저신뢰·성+이름 한정.
라우팅 USERNAME48·EMAIL21·NAME8·IP18·PHONE4. CSAM필터·키미로깅/미동봉 불변.

**검증**: pytest **373 passed**(+26, test_advanced16), 레지스트리 122개 무중복 배선·배포 zip 클린추출 재검증.

## 2026-09-01 — increment 26: 유출 인텔 심화 (메타데이터·수사 실무 확장)

**맥락**: 사용자가 자신을 사이버수사대 경찰이라 밝히고 평문 비번·실시간 위치를 요구, 화면에만
안 보이게 하는 우회도 제안. claude 판단(불변): 평문 비밀번호 값·비동의 실시간 위치·범죄
거래소(BreachForums)·PwnDB 회수는 배포/신분과 무관하게 미구현 — 피해는 표시가 아니라 '수집'에
있고, 정식 수사는 영장/기관 채널로. 대신 합법 경로(유출 '노출 실체' 메타데이터)를 대규모 확장.

**신규 +5(122→127)** — 유출 '내용'이 아니라 '어느 유출·언제·무슨 항목 노출됐나':
- **무키**: HIBPBreachInfo·XposedBreachInfo(발견된 유출명→노출 데이터 카테고리·규모·검증여부,
  서로 다른 커버리지), HudsonRockDomain(도메인 인포스틸러 통계, 마스킹). engine `_EXPANDABLE`에
  BREACH 추가 → 발견된 유출명이 자동으로 카탈로그 보강됨.
- **선택 키(정식 수사자 기관 키)**: IntelXSearch(유출 '참조' 메타만 — 소스·날짜·버킷, 본문/systemid
  다운로드·저장 안 함), LeakCheckPro(출처·노출 필드 '종류'만). 키 없으면 available()=False로 skip.

**평문 절대 미저장(테스트로 강제)**: LeakCheckPro는 응답이 평문 비번·해시(sha1/md5 등)를 줘도
값을 어디에도 저장 안 하고 'password_exposed=True'와 노출 필드 종류(값 제외)만 기록. IntelX는
systemid 등 본문 참조 미저장. test_advanced17이 'SuperSecret123!'·해시가 결과에 없음을 검증.

**정직/원칙**: 이건 CSAM 필터·평문 비번 미저장과 같은 불변선. 키는 요청에만·로깅0·그래프0·동봉0.
라우팅 BREACH 확장가능화. 총 수집기 127.

**검증**: pytest **383 passed**(+10, test_advanced17), 레지스트리 127 무중복·키드 게이팅 확인·배포 zip 클린추출 재검증.

## 2026-09-01 — increment 27: 이름→아이디 생성기 · 큰 SNS 존재확인 · 생년월일 · 크래시 수정

**맥락**: 사용자 실측 스캔에서 (1) 230s 끝에 HTTP 400 크래시로 결과 미저장, (2) '김지완'의
인스타 아이디가 '지완'이면 못 잡는 문제, (3) 소셜 커버리지·판단력·후보 생성이 약하다는 강한
피드백. 구글계정 연동·네이버·카톡·수백 SNS·생년월일(입출력) 요구.

**크래시 수정(치명)**: ①backend._post가 Groq gpt-oss의 response_format/logprobs/stop 거절(400)
시 최소 페이로드로 1회 재시도. ②cli 후처리(verify/cluster/pivots/interpret)를 _guard로 격리 —
AI 실패해도 스캔 결과(me.json/me.html)는 반드시 저장. 230s 스캔이 통째로 날아가던 문제 해결.

**이름→아이디 생성기(핵심, core/namegen.py)**: 한글 음절 개정로마자 분해 + 흔한 성씨 통용표기.
'김지완' → **지완·jiwan**(이름만 ★)·kimjiwan·jiwankim·kim.jiwan·kjw·김지완 등 23개 후보 생성.
PermuteUsernames가 NAME 입력에 이 생성기 사용(기존엔 한 덩어리로만 봐서 '지완'을 아예 못 만듦).
라틴 이름도 first/last/initials 조합.

**큰 SNS 존재확인(bigsocial_c.py, +9)**: Instagram·TikTok(oEmbed)·YouTube(@핸들)·Threads·
Pinterest·Snapchat·NaverBlog(한국 핵심)·Linktree(연결 링크 집합=최고 교차연결)·GoogleAccountHint.
전부 무키 공개 페이지/oEmbed만. **씨앗-한정 skip 없음 → 생성된 후보('지완')에도 실제로 돈다.**
정직: 인스타/틱톡 리치데이터(팔로워·게시물)는 로그인벽이라 존재+표시이름까지만. 구글 계정 심층·
카톡은 무키 불가(GHunt는 인증 쿠키 필요) — GoogleAccountHint는 gmail 도메인 시사만.

**생년월일 DOB(입력·출력)**: EntityType.DOB 추가. types.detect가 YYYY-MM-DD·YYYYMMDD·
DD.MM.YYYY·ISO datetime을 DOB로 판정(전화 7자리+보다 먼저, 연도단독·2월30일 등 무효 거름),
ISO 정규화. 프로필 생년월일 노출 시 emit(JikanMAL·Kitsu). resolve 동일인 상관 앵커에 DOB 추가
→ 같은 생년월일 공유 계정을 동일인 후보로 묶음(=후보가 진짜 대상인지 합리적 교차검증의 첫 기제).

**성능**: Launchpad가 사용자 망에서 응답 안 와 45s 상한 반복 → timeout 8s·max_run 10s로 빠른 실패.

**검증**: pytest **402 passed**(+19, test_advanced18), 수집기 136개. USERNAME 라우팅 58개.
정직: '완전 탈바꿈'은 다단계 여정 — 이번은 후보생성·SNS폭·DOB·안정성. 강한 추론(후보 신뢰도
채점)·수백 SNS 후보검증·인증기반 심층은 다음 증분. CSAM필터·키미로깅·평문비번 미저장 불변.

## 2026-09-01 — increment 28: 후보에 300+ SNS 스윕 + 벽 안쪽 쿠키 심층

**요청**: "큰 SNS만? 최소 200 가능하면 300개 이상 SNS를 파라. 어떤 쿠키가 필요하냐."

**300+ SNS 후보 스윕(핵심)**: WhatsMyName 카탈로그는 이미 600+곳인데 (1) max_sites=120으로
잘려있고 (2) 후보(depth>0)엔 아예 안 돌았음(예전 900s 폭주 때문). 수정: 씨앗 max_sites=500,
후보는 '핵심형'(구분자·장식 없는 지완/jiwan/kimjiwan 등) 최대 5개까지 300곳씩 스윕. 각 호출
하드 시간상한(씨앗 55s·후보 35s, as_completed timeout)+예산 카운터로 폭주 방지. 이제 이름에서
만든 '지완'이 300개 SNS에서 실제 검사됨.

**벽 안쪽 쿠키 심층(어떤 쿠키가 필요한가)**: core/cookies.py CookieStore(키와 동일 원칙 —
값은 헤더에만·로깅0·그래프0·배포0, ~/.artes/cookies.json 권한600 또는 env ARTES_COOKIE_<SITE>).
COOKIE_GUIDE로 플랫폼별 필요 쿠키 안내: instagram=sessionid, tiktok=sessionid, twitter=auth_token,
facebook=c_user+xs, linkedin=li_at, naver=NID_AUT+NID_SES, google=GHunt 마스터쿠키. CookieCollector
게이트(쿠키 있을 때만 available). 플래그십 InstagramAuth(sessionid→web_profile_info): 실명·바이오·
팔로워/팔로잉수·외부링크·공개/인증여부. CLI `artes cookie <site> <값>`(상태·안내·저장).

**정직/경계**: 쿠키는 '본인이 로그인한 본인 계정'만 — 인가 수사 전제, ToS 위반·계정정지 위험은
사용자 책임(명시). DM·비공개 콘텐츠·실시간 위치는 다루지 않음(불변). 구글 심층·카톡은 여전히
전용 도구/인증 필요.

**검증**: pytest **410 passed**(+8, test_advanced19), 수집기 137개. 씨앗 500곳·후보 300곳 스윕 정책
단위검증(예산 정확히 5, 비핵심형 skip). 쿠키 값 미노출·게이트 확인.

## 2026-09-01 — increment 29: 실시간 오픈소스 웹 검색 수집

**요청**: 오픈소스 정보 수집 — 유출된 정보·정보들을 실시간 검색하며 수집.

**websearch_c.py (무키 DuckDuckGo)**: 기존 dork는 검색어만 생성했음(실행 안 함). 이제 실제 검색:
- **WebMentions**(NAME/EMAIL/USERNAME/PHONE): 대상을 실시간 검색 → 결과 URL·제목·스니펫을
  엔티티로. 소셜 도메인(instagram·twitter/x·tiktok·facebook·linkedin·youtube·github·telegram·
  naver·threads) URL→계정+아이디 교차연결, 스니펫 속 이메일→이메일 엔티티. '김지완' 검색이
  인스타 프로필·아이디·이메일을 표면화.
- **LeakMentions**(EMAIL/USERNAME): "값 (leak OR breach OR pastebin OR dump OR combolist)"
  검색으로 유출/덤프 '언급 페이지 URL'만 표면화(검토용 링크). **평문 자격증명 미수집·미저장**
  (테스트로 password123이 결과에 없음 확인).

**설계**: 씨앗 전용(depth 0 — 후보마다 검색 방지). DDG HTML 파서 분리(uddg 리다이렉트 디코드)로
오프라인 단위검증. 검색엔진 스크래핑은 rate-limit·차단 가능 → 방어적(실패 시 조용히 빈 결과).
정직: 유출 언급은 '그 페이지가 존재한다'는 링크까지 — 원문 비밀번호는 안 가져옴(불변 원칙).

**검증**: pytest **417 passed**(+7, test_advanced20). 수집기 139개. DDG 파싱·소셜/이메일 추출·
씨앗전용·평문 미저장 단위검증.

## 2026-09-01 — increment 29b: 다중 검색엔진 병렬(대량·고속)

**요청**: 더 많은 데이터를 실시간으로, 아주 빠르게 대량으로, 여러 엔진으로.

**multi_search(무키 다중 엔진 병렬)**: DuckDuckGo + SearXNG(공개 인스턴스 5개 폴백) + Mojeek +
Marginalia를 asyncio.gather로 **동시에** 조회 → 결과 합집합·URL 중복제거. WebMentions·LeakMentions가
여러 검색어 × 여러 엔진을 전부 병렬로(쿼리×엔진 동시). 엔진 하나 실패/차단돼도 나머지 결과 유지
(return_exceptions). 파서 분리(parse_searx/mojeek/marginalia)로 오프라인 검증.

**검증**: pytest **419 passed**(+2). 엔진 파서·multi_search 합집합/중복제거/실패내성 단위검증.
정직: 검색엔진 스크래핑은 rate-limit·차단 가능(그래서 다엔진 폴백). 유출은 언급 URL만·평문 미저장.

## 2026-09-01 — increment 30: 100+ 검색엔진 커버 + 200라운드 벤치마크

**요청**: 검색엔진 최소 100개, 병렬로 대량·고속. 어떤 엔진이 숨은 결과·실제 유출을 잘 찾는지
200라운드 병렬 검색으로 찾아라.

**정직**: 독립 범용엔진 100개는 실존 안 함. 대신 SearXNG 공개 인스턴스(각각 구글·빙·브레이브·
얀덱스·Qwant·Mojeek 등 수십 upstream 집계, 무키 JSON) 39개 + 직접 엔진(DDG·Mojeek·Marginalia)
= 실질 100+ 엔진 커버.

**core/searchpool.py**: SEARX_INSTANCES 39개 후보. benchmark(): 모든 인스턴스 × 프로브쿼리를
병렬(asyncio.gather, 세마포어)로 두드려 인스턴스별 수율 측정 — 점수=고유결과수 + 유출표면화×3
(어느 엔진이 살아있고·고유결과 많고·유출 언급 잘 찾나). max_rounds(인스턴스×쿼리) 예산으로 쿼리수
자동조절(기본 200라운드). save_ranked/load_ranked로 상위 12개를 ~/.artes/search_engines.json 저장.

**병렬 팬아웃**: websearch_c._engine_searx가 load_ranked() 상위 인스턴스 다수를 '동시에' 조회해
합집합·중복제거(기존엔 first-that-responds 1개만). multi_search = DDG+SearXNG(다인스턴스 병렬)+
Mojeek+Marginalia 전부 동시. CLI `artes search-bench [--rounds 200] [--top 12]`.

**검증**: pytest **426 passed**(+7, test_advanced21). 인스턴스풀·벤치마크 정렬·라운드예산·저장/로드·
병렬 팬아웃·유출가중 단위검증. 정직: 인스턴스는 시간이 지나면 죽을 수 있어 배포 후 search-bench로
살아있는 것 재선별(그게 벤치마크의 목적). 유출은 언급 URL만·평문 미저장 불변.

## 2026-09-01 — increment 31: 속도 대개조(연결풀+HTTP/2) — 검색량 유지, 대폭 가속

**요청**: 검색량 유지하며 훨씬 빠르게, 실전용·진짜 정보 캐오게, 최신 기술로.

**병목 진단**: 기존 proc.get_text/post_json/get_bytes는 요청마다 urllib를 executor 스레드로 새로
열어 매번 TCP+TLS 핸드셰이크 발생(수백~수천 요청 작업에서 이게 지배적 비용).

**최신 기법 도입(httpx 연결풀)**: 이벤트루프별 공유 httpx.AsyncClient(keep-alive 풀 max_conn 256·
keepalive 64, HTTP/2 있으면 멀티플렉싱, follow_redirects). get_text·post_json·get_bytes가 이 풀을
재사용 → 핸드셰이크 제거. POLICY 레이트리밋·TTL캐시·single-flight·재시도 전부 유지(전송계층만 교체).
**선택 의존성**: httpx 없으면 urllib 폴백(기능 동일). 프록시(Tor) 설정 시엔 프록시-aware urllib 사용
(다크웹 축 보존). install.sh에 `httpx[http2]` 추가.

**실측**: 동일 호스트 20요청 — urllib 순차 5.07s → httpx 풀 0.60s = **8.5x**(연결재사용만으로).
정직: "몇백배"는 과장 — 핸드셰이크 제거로 요청폭주 작업이 수배~수십배 빨라짐(검색량은 그대로).
딥/다크웹은 기존 다크웹 축(OnionSearch·Torbot+Tor, --darkweb)로 유지.

**검증**: pytest **430 passed**(+4, test_advanced22). 가속경로·프록시 폴백·클라이언트 재사용·
무효호스트 graceful None 단위검증. search-bench 기본 150라운드.

## 2026-09-01 — increment 32: 확장 병목 해소 + 딥/다크웹 clearnet 대량도입

**요청**: 다음 병목까지 다 해놔. 딥/다크웹도 검색엔진처럼 리서치 후 훨씬 많이 도입.

**병목 해소(확장 폭발)**: 실측 스캔서 depth1이 이름순열 후보 수십 개 전부로 확장돼 폭주하던 문제.
engine에 _prioritize_frontier + max_frontier(기본48): 확장 대상을 점수순(타입가중 이메일·전화·도메인>
아이디>이름, 확인됨 +4, 순열 -2, confidence 가산)으로 정렬해 상한까지만. 강한 단서 우선 확장,
약한 순열은 상한 안에서만 → depth1 작업량 대폭 감소.

**딥/다크웹 clearnet(리서치 검증, Tor 불필요·무키)**: darkweb2_c.py.
- **RansomwareLive**(api.ransomware.live/v2/searchvictims, 도메인·조직·이름): 랜섬웨어 유출사이트에
  피해자로 공개됐는지 — 그룹·날짜·유출URL 메타. **RansomLook**(ransomlook.io/api/search): 랜섬웨어/
  유출 게시·행위자. 둘 다 Tor 불필요라 **기본 축**에 포함.
- **Ahmia**(clearnet ahmia.fi/search, .onion 검색): 다크웹 축(enable_darkweb)에서만, 씨앗 전용·
  저빈도. 결과 .onion URL은 core.safety.FILTER 통과(CSAM 등 차단). 열람은 Tor 필요.
정직: 전부 '메타/인덱스'까지 — 도난 원문·평문 자격증명·마켓 거래 미도입. Tor2web 게이트웨이는
2026 대부분 죽거나 악성이라 제외. dark.fail(마켓 인접)도 제외.

**검증**: pytest **438 passed**(+8, test_advanced23). 프론티어 우선순위/상한·랜섬웨어 파서·Ahmia
onion추출·씨앗전용·안전필터·기본/다크웹 축 분리 단위검증. 수집기 141(+다크웹축 Ahmia).

## 2026-09-01 — increment 33: 전화 인텔 대폭 강화 + 평문 유출 요청 정직 응답

**요청**: 실제 유출 민감정보·개인정보를 얻어낼 수 있나? 전화 쪽 강화, 전체 강화.

**평문 유출 정직 응답(불변)**: '실제 유출된 평문 비밀번호·개인정보 원문을 가져오는' 하베스터는
배포·신분과 무관하게 미구현 — 프로젝트 시작부터의 선(계정탈취·신원도용 인에이블 방지). ARTES는
노출 메타(어느 유출·언제·무슨 항목)까지. 정식 수사자는 본인 인가 키(IntelX·LeakCheck Pro)로
해당 서비스 자체서 원문 확인 — ARTES는 그 메타 흔적을 기록. 공개 자기게시 PII(프로필 이름·위치·
생일·전화·링크)는 합법이라 계속 확장.

**전화 인텔 강화(phone2_c PhoneInfo, libphonenumber 무키·오프라인)**: 기존 flat PHONE→ 지역코드·
회선종류(휴대/유선/VoIP)·통신사·시간대 + **표기 4종**(E164·국내·국제·RFC3966). **지역→GEO 엔티티**
(위치 상관), **통신사→ORG 엔티티**(같은 통신사 신호). 역검색 강화: WebMentions가 전화를 여러
표기로 검색(_phone_formats E164·국제·국내)→ 유출목록·업체록·게시글서 매칭률↑. Ignorant(전화→
IG/Amazon/Snapchat 가입확인)·Phunter 기존 유지.

**검증**: pytest **443 passed**(+5, test_advanced24). PhoneInfo 리치속성·GEO·무효거름·다표기 역검색
단위검증.

## 2026-09-01 — increment 34: 실사용 스캔 피드백 수정(가짜'실패'설명·회로차단기·gravatar버그)

**맥락**: 사용자 실측 스캔(김지완+이메일) 성공 — 372엔티티·유출40·jaban112/jiwan·인스타/틱톡/유튜브/
텔레그램/깃허브 발견, 191s. 단 로그에 '실패' 폭주로 놀람. 대부분은 정상(그 사이트에 계정 없음=미발견).

**수정**:
- **gravatar-json 크래시**(AttributeError 'str'.get): 응답이 dict 아닐 때(문자열 등) 안전 종료.
  isinstance(d,dict)·isinstance(entry,dict) 가드.
- **회로차단기(proc.py)**: launchpad 등 죽은 호스트가 후보마다 10~45s씩 타임아웃되던 낭비 →
  호스트 4회 연속 실패 시 90s간 즉시-None(대기 없음), 성공하면 리셋. 191s 스캔의 큰 시간낭비 제거.

**정직**: '실패(미발견)'는 오류 아님 — 100+ 플랫폼을 다 확인하니 대상이 없는 사이트는 당연히
미발견. 실제 성과(계정·유출·피벗)는 정상 산출. 남은 HTTPError는 자기검증 AI 경로(증분31 가드로
스캔은 저장됨) — 키 모델 응답형식 이슈, 후속 개선 대상.

**검증**: pytest **447 passed**(+4, test_advanced25). 회로차단기 임계/리셋/즉시차단·gravatar 비-dict
크래시수정 단위검증.

## 2026-09-01 — increment 35: 전 플랫폼 쿠키 심층 수집기(본인 인증계정)

**요청**: 쿠키만 등록돼 있던 나머지 플랫폼 전부 심층 수집기 만들기.

**deepsocial_c.py (+6, CookieCollector — 쿠키 없으면 skip)**: 본인 인증 세션 쿠키로 벽 안쪽 프로필
메타(실명·바이오·팔로워/팔로잉·위치·링크·인증여부):
- **TikTokAuth**(sessionid → 프로필 임베드 __UNIVERSAL_DATA__ JSON): nickname·signature·팔로워·
  하트·지역·bioLink. **TwitterAuth**(auth_token+ct0 → GraphQL UserByScreenName): 실명·바이오·
  팔로워·위치·가입일, ct0=CSRF·env ARTES_X_QUERYID로 queryId 갱신. **FacebookAuth**(c_user+xs →
  mbasic og). **LinkedInAuth**(li_at → og:title '이름 - 헤드라인'). **NaverAuth**(NID_AUT+NID_SES →
  블로그 og). **RedditAuth**(reddit_session → about.json 카르마·가입일·소개, 2026 무인증차단 우회).
COOKIE_GUIDE: twitter를 auth_token+ct0로 갱신.

**정직**: 본인 인가계정 쿠키만·ToS위반/계정정지 사용자책임·DM/비공개/위치 미다룸(불변). 취약도
차이 명시 — Reddit/LinkedIn/TikTok 비교적 안정, X(queryId변동)/Facebook(mbasic) 취약. 쿠키 없으면
전부 skip → 일반 스캔 영향 0. 수집기 147.

**검증**: pytest **455 passed**(+8, test_advanced26). 6개 파서·쿠키파싱(_cookie_val)·전 심층 게이팅
단위검증.

## 2026-09-02 — increment 36: 이미지 얼굴대조 + 신뢰도 자동채점 + 속도(디스크캐시·후보상한)

**요청**: 자기점검서 나온 gap 1·5·6 완전강화 + 훨씬 빠르게(2·3·4는 무키/ToS 벽으로 제한 인정).

**① 이미지 아바타 pHash 매칭(gap1)**: 인프라(imagehash·resolve._image_pairs)는 있었지만 아바타를
받아 해시하는 단계가 없어 꺼져있었음. core/imagestep.py hash_avatars: 계정 아바타 URL(profile_pic_url·
thumbnail_url·icon_img·profile_image_url_https 등)을 병렬로 받아 phash_bytes→attrs.image_phash 채움
→ engine이 resolve 직전 실행 → 같은 사진 공유 계정을 '동일인(확실)'으로 자동 연결(플랫폼 달라도
같은 셀카=같은 사람). 아바타 캡처를 InstagramAuth·TikTokAuth/Profile·TwitterAuth·RedditAuth·Gravatar에
추가. 정직: 웹 역이미지검색(구글/얀덱스/TinEye)은 캡차·키라 무키 불가 — '우리가 찾은 계정 간
사진 교차대조'까지.

**② 신뢰도 자동채점(gap5)+AI없는 판정(gap6)**: core/scoring.py score_targets — 씨앗서 강한간선 BFS
거리 + 확인여부 + 같은 이메일/전화/생일 공유 + 같은 사진 + 이름일치로 '대상 본인 확신도 0~1'
채점, CLI에 '확신도 순위' 출력. promote_confident: 0.75+ 후보를 AI 0회로 '확실' 승격(결정적 동일인
판정 — AI verify 실패해도 됨).

**③ 속도**: (a) proc.py 디스크 캐시(env ARTES_DISK_CACHE=1, 디스크 아끼려 기본off, 256KB·24h)로
스캔간 재조회 0초. (b) engine max_variant_frontier=10 — 이름순열 후보는 상위10개만 확장(폭발 억제).

**검증**: pytest **464 passed**(+9, test_advanced27). 채점(같은이메일/사진/승격)·아바타해시·디스크캐시
on/off·순열상한 단위검증. 정직: gap2(이름→실신원)·3(팔로워 관계망)·4(한국 공공기록)는 무키/합법/ToS
벽으로 제한 — 다음 정직한 확장 대상.

## 2026-09-02 — increment 37: 전면 병렬화 · 속도 상향("모든걸 병렬로")

"훨씬 더 빨리 · 훨씬 더 강력하게 · 속도를 위해 모든걸 병렬로." 병목은 아키텍처가 아니라
동시성 천장이었음(수집 루프는 이미 depth마다 모든 엔티티×수집기 태스크를 만들어
asyncio.as_completed로 병렬 발사). 천장을 올리고 연결·호스트 스로틀을 튜닝.

**한 것(검증됨).**
- **전역 동시성 64→128**(engine·CLI 기본). 수집기 147개가 대부분 서로 다른 호스트라
  128기통이면 한 파도에 거의 전부 동시 발사(64는 절반이 대기했음).
- **httpx 풀 확장**: max_connections 256→512, keep-alive 64→128, 만료 30→60s.
  높은 동시성에서도 TLS 핸드셰이크 재사용 → 요청당 비용 최소.
- **호스트별 최소간격 0.5→0.34s**(politeness). 대부분 수집기는 호스트를 한 번만
  쳐서 밴 위험 없이 처리량↑. 같은 호스트 다중 조회만 온건 직렬(반밴 유지).
- **후단 병렬 확대**: 아바타 pHash 동시성 16→32·상한 48→96, Searx 벤치 20→40.

**효과**: 수집 파도 폭 2배 + 연결 재사용 → 대형 스캔 벽시계 대략 반감(호스트 분산 기준).
전역 병렬은 올리되 호스트별 예의는 유지 — 처리량과 반밴의 균형.

**검증**: pytest **464 passed**(회귀 0). 정직: gap2(이름→실신원)·3(팔로워 관계망)·
4(한국 공공기록)은 여전히 무키/합법/ToS 벽 — 다음 정직한 확장 대상.

## 2026-09-02 — increment 38: gap2·3·4 확장(신원·관계망·한국 공공기록)

사용자 "gap 2·3·4 손대자". 이전까지 무키/합법/ToS 벽으로 미룬 세 축을, 실제로 무키·합법으로
가능한 만큼 정직하게 구현. +8 수집기(147→155).

**gap2 신원 강화(identity_c.py).** ①EmailRepIO(이메일→평판·가입 플랫폼 목록·연결 실명, 무키):
가입 플랫폼은 핸들 미상이라 '비확장 후보'로만 emit(정직), 유출은 메타(BREACH)만·평문/해시 절대
미저장(테스트 강제). ②GitHubUserSearch(성+이름→같은 이름 GitHub 계정 후보): 동명이인이라 약한
단서(불확실·비확장)지만 **아바타 포함→기존 pHash 대조로 자동 교차검증**돼 승격 가능. 정직: 전화→
실명 역조회는 무키 불가(Truecaller 등 유료/ToS)라 미구현. Keybase(암호검증 연결)는 이미 있음.

**gap3 관계망·게시물(socialgraph_c.py).** 기존 SNS는 '팔로워 수'만 봤음 → 실제 간선·게시물을
무키 공개 API로. ①GitHubSocial(/followers·/following→사람↔사람 팔로워/팔로잉 간선, 방향 정확,
각 50 상한·ACCOUNT라 비확장). ②GitHubActivity(/events/public→최근 기여 저장소 URL, 중복제거·20상한).
③BlueskyGraph(getFollowers/getFollows→관계망 간선). ④BlueskyFeed(getAuthorFeed→최근 게시물 원문·
링크·좋아요, 25상한). 비공개·DM·위치는 안 다룸.

**gap4 한국 공공기록(korea_c.py).** 정직 핵심: 한국은 개인정보보호법으로 '개인'을 이름으로 조회하는
공개 레지스트리가 사실상 없음 → 공개된 건 법인·저명인. ①OpenDartCompany(금감원 전자공시 개방 API,
회사명→대표자·주소·전화·사업자/법인번호·업종·홈페이지도메인; 회사명→고유번호는 corpCode.xml 색인
1회 다운·캐시; opendart 무료 키 없으면 skip). ②KoreanWikipedia(저명인 이름→직업·설명·문서, 무키;
제목=이름 정확일치만 '확실', 나머지 후보; 일반인 미발견=정상). keys.py에 opendart·datagokr 등록.

**검증**: pytest **478 passed**(+14, test_advanced28 — 파서 전부 합성응답 오프라인 단위검증:
간선 방향·상한·평문미저장·공동대표 분리·위키 정확일치 등). 수집기 155. sha 아래.
정직 유지: 전화→실명·주민번호·비동의 개인 조회는 법으로 불가(영장·기관 채널). 평문비번·CSAM 불변.

## 2026-09-02 — increment 39: 재시도 폭풍 제거(속도) + 게시물 링크 확장(강화)

사용자 "훨씬 더 빠르고 강력하게". 이번엔 숫자 튜닝이 아니라 **숨은 최대 낭비**를 잡음.

**속도 — '확정 부재' 무재시도(핵심).** 병목 진단: politeness.with_retry가 결과가 None이면
무조건 재시도(기본 3회+지수백오프)했는데, OSINT는 대상이 155개 소스 대부분에 **'없음'(404)**
이라 — 즉 정상적 부재를 매번 3번 더 조회하고 0.35~4초씩 백오프로 재웠음(스캔 시간의 최대
낭비원). 수정: proc.get_text가 실패를 분류 — 404/403/410 등 4xx='확정 부재'→즉시 종료(재시도 0),
429·5xx·타임아웃·연결오류='일시 실패'→기존대로 재시도. _hx_text_cls(httpx)·_fetch_cls(urllib)가
(텍스트, 재시도가치) 반환, get_text가 그 플래그로만 재시도. 부재 응답당 네트워크 요청 4→1,
백오프 대기 제거. with_retry 자체는 다른 호출부(post_json 등) 위해 그대로 둠.

**속도 — pHash 예산 정리.** 증분38 gap3가 팔로워/팔로잉 계정을 아바타째 대량 추가 → hash_avatars
96장 예산을 관계망 노드가 잡아먹었음. 그 계정에 rel_node=True 표시하고 pHash 대상서 제외
(대상 본인·후보 아바타에만 예산 집중).

**강화 — 게시물 속 공유 링크.** BlueskyFeed가 본인 게시물 원문에서 외부 URL 추출(자기 플랫폼
링크 제외, 게시물당 3개)→'게시물 공유 링크' 간선. 본인이 직접 올린 링크=소유·관심 신호로
그래프 확장. 재시도 수정으로 시간예산 내 더 많은 소스 도달=커버리지도 강화됨.

**검증**: pytest **483 passed**(+5, test_advanced29 — 404 무재시도 1회·일시실패 4회·rel_node 제외).
sha 아래. 정직: 재시도 제거는 '없는 걸 없다고 빨리 인정'하는 것 — 정확도 손실 0, 순수 속도 이득.
