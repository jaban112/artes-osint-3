#!/usr/bin/env bash
# remove-local-ai.sh — 크롬북 리눅스에서 '로컬 AI'만 깨끗이 제거 + 정크 정리
# 지움: Dolphin GGUF 모델(*.gguf) · llama.cpp 빌드/레포 · llama-ai 단축키 · 관련 캐시
# 보존: ~/artes(소스·venv) · server-ai(원격 Groq) · artes/artes-update 단축키 · 개인문서
# 사용:  bash remove-local-ai.sh          (뭘 지울지 보여주고 바로 삭제)
#        bash remove-local-ai.sh --dry    (삭제 없이 목록·크기만)
set -u
DRY=0; [ "${1:-}" = "--dry" ] && DRY=1
G="\033[1;32m"; Y="\033[1;33m"; B="\033[1;34m"; R="\033[1;31m"; Z="\033[0m"
say(){ echo -e "${B}▸${Z} $*"; }
ok(){  echo -e "  ${G}✔${Z} $*"; }
warn(){ echo -e "  ${Y}!${Z} $*"; }
sz(){ du -sh "$1" 2>/dev/null | cut -f1; }
free_now(){ df --output=avail -B1 "$HOME" 2>/dev/null | tail -1 | tr -d ' '; }
human(){ numfmt --to=iec 2>/dev/null <<<"${1:-0}" || echo "${1:-0}B"; }

D0=$(free_now)
echo -e "${G}=== 로컬 AI 제거 ===${Z}   ($([ "$DRY" = 1 ] && echo '드라이런: 삭제 안 함' || echo '실제 삭제'))"
echo "  시작 디스크 여유: $(human "$D0")"
echo

# ── 0) 실행 중인 로컬 AI 서버 종료 ──
say "로컬 AI 서버(llama-server) 종료"
if pgrep -x llama-server >/dev/null 2>&1; then
  [ "$DRY" = 1 ] || pkill -x llama-server 2>/dev/null
  ok "llama-server 종료"
else
  ok "실행 중 아님"
fi

# ── 1) GGUF 모델 파일 찾기(홈 전역) ──
say "GGUF 모델 파일 검색(*.gguf)"
mapfile -t GGUFS < <(find "$HOME" -type f -name '*.gguf' 2>/dev/null)
if [ "${#GGUFS[@]}" -eq 0 ]; then
  warn "gguf 모델 없음"
else
  for f in "${GGUFS[@]}"; do
    echo "     $(sz "$f")  $f"
    [ "$DRY" = 1 ] || rm -f "$f"
  done
  ok "GGUF ${#GGUFS[@]}개 $([ "$DRY" = 1 ] && echo '(대상)' || echo '삭제')"
fi

# ── 2) llama.cpp 빌드/레포 ──
say "llama.cpp 빌드·레포 제거"
for d in "$HOME/llama.cpp" "$HOME/llamacpp" "$HOME/.local/share/llama.cpp"; do
  if [ -d "$d" ]; then
    echo "     $(sz "$d")  $d"
    [ "$DRY" = 1 ] || rm -rf "$d"
    ok "$d $([ "$DRY" = 1 ] && echo '(대상)' || echo '삭제')"
  fi
done

# ── 3) 모델 디렉터리(비면 삭제) ──
for d in "$HOME/models" "$HOME/.artes/models" "$HOME/.cache/huggingface"; do
  if [ -d "$d" ]; then
    say "모델/캐시 디렉터리: $d ($(sz "$d"))"
    [ "$DRY" = 1 ] || rm -rf "$d"
    ok "$([ "$DRY" = 1 ] && echo '대상' || echo '삭제')"
  fi
done

# ── 4) llama-ai 단축키만 제거(server-ai·artes·artes-update 보존) ──
say "단축키 정리 — llama-ai(로컬 AI)만 제거"
if [ -f "$HOME/.local/bin/llama-ai" ]; then
  [ "$DRY" = 1 ] || rm -f "$HOME/.local/bin/llama-ai"
  ok "llama-ai 제거 (server-ai·artes·artes-update는 보존)"
else
  warn "llama-ai 단축키 없음"
fi

# ── 5) 빌드 캐시(cmake/cargo/pip) 정리 ──
if [ "$DRY" = 0 ]; then
  say "관련 빌드 캐시 정리"
  rm -rf "$HOME"/.cache/pip "$HOME"/.cache/uv 2>/dev/null && ok "pip·uv 캐시"
  command -v pacman >/dev/null 2>&1 && { command -v paccache >/dev/null 2>&1 && sudo paccache -rk1 2>/dev/null; sudo pacman -Sc --noconfirm >/dev/null 2>&1; ok "패키지 캐시"; }
  sync; echo 3 | sudo tee /proc/sys/vm/drop_caches >/dev/null 2>&1 && ok "램 캐시 드롭"
fi

# ── 결과 ──
D1=$(free_now); DD=$(( ${D1:-0} - ${D0:-0} ))
echo
echo -e "${G}=== 완료 ===${Z}"
echo "  디스크 여유: $(human "$D0") → $(human "$D1")   ($([ "$DRY" = 1 ] && echo '드라이런—변화없음' || echo "+$(human "$DD") 확보"))"
echo "  보존됨: ~/artes · .venv · server-ai(원격 Groq) · artes/artes-update"
echo "  이제 AI는 원격만: server-ai (또는 OpenRouter/HF 키). 로컬 Dolphin은 제거됨."
