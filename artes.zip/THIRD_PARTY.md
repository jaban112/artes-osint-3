# 번들·연동 도구 라이선스·출처

ARTES는 아래 공개 도구를 래핑/번들한다. 각 도구는 **키·계정 불필요**로 공개 데이터를 조회하는
것만 채택한다(회원가입·토큰·API 키가 필요한 소스는 배제). 각 도구의 라이선스와 출처를 명시하며,
번들 시 원 라이선스 전문을 함께 배포한다.

| 도구 | 용도 | 라이선스 | 출처 |
|---|---|---|---|
| maigret | 아이디 → 계정 탐색 | MIT | github.com/soxoj/maigret |
| holehe | 이메일 → 가입 사이트 | GPL-3.0 | github.com/megadose/holehe |
| theHarvester | 도메인 → 이메일·호스트 | GPL-2.0 | github.com/laramies/theHarvester |
| sherlock | 아이디 → 계정 탐색 | MIT | github.com/sherlock-project/sherlock |
| blackbird | 아이디·이메일 탐색 | MIT | github.com/p1ngul1n0/blackbird |
| phoneinfoga | 전화번호 정보 | GPL-3.0 | github.com/sundowndev/phoneinfoga |
| ignorant | 전화 → 가입 사이트 | GPL-3.0 | github.com/megadose/ignorant |
| phunter | 전화번호 정보 | MIT | github.com/N0rz3/Phunter |
| torbot | 다크웹 크롤·분석 | GPL-3.0 | github.com/DedSecInside/torbot |
| onionsearch | onion 검색 수집 | GPL-3.0 | github.com/megadose/OnionSearch |
| h8mail | 로컬 유출 조회(로컬 모드) | BSD-3-Clause | github.com/khast3x/h8mail |
| nmap | 네트워크·포트 스캔 | NPSL(GPLv2 파생) | nmap.org |
| Tor | onion 라우팅 | BSD-3-Clause | torproject.org |
| llama.cpp | 로컬 AI 추론(CPU 빌드) | MIT | github.com/ggml-org/llama.cpp |
| Neo4j Community | 그래프 DB | GPL-3.0 | neo4j.com |

**배제(키/계정 필요):** ghunt, insto, Shodan, Have I Been Pwned 이메일 조회 — 옵션 슬롯만
남기고 기본 비활성.

**호환.** 번들에 GPL-3.0 도구가 포함되므로 ARTES 본체는 GPL-3.0으로 배포한다. 각 도구의 라이선스
전문은 번들 시 `third_party/<도구>/LICENSE` 로 보존한다.

> 표의 라이선스·URL은 배포 전 각 저장소에서 재확인해야 한다(업스트림 변경 가능). 이는
> 참조용 초안이다.
