#!/usr/bin/env bash
# get-artes.sh — GitHub artes-osint-3에서 최신 artes.zip 받아 sha256 검증 후 설치
# 파일 공유가 막힌 관리형 크롬북용: 브라우저로 repo에 zip 올린 뒤 리눅스에서 이 스크립트 실행
# 보존: ~/artes/.venv(가상환경) · Dolphin 모델(~/artes 밖) · 단축키
set -u
REPO="jaban112/artes-osint-3"
EXPECT_SHA="4f1c234b8e243d8b3213ac9bdc323df775d186678aa482e535e8a8faf450cf51"
DEST="$HOME/artes"
TMP="/tmp/artes-new.zip"
C_G="\033[1;32m"; C_Y="\033[1;33m"; C_R="\033[1;31m"; C_0="\033[0m"
ok(){ echo -e "${C_G}✔${C_0} $*"; }; warn(){ echo -e "${C_Y}!${C_0} $*"; }; die(){ echo -e "${C_R}✗ $*${C_0}"; exit 1; }

echo -e "${C_G}=== 새 ARTES 다운로드 ===${C_0}"
command -v curl  >/dev/null 2>&1 || die "curl 없음"
command -v unzip >/dev/null 2>&1 || die "unzip 없음 (sudo pacman -S unzip)"

# 1) 다운로드 (main→master 순으로 시도)
rm -f "$TMP"
DL=""
for BR in main master; do
  URL="https://raw.githubusercontent.com/$REPO/$BR/artes.zip"
  echo "  시도: $URL"
  if curl -fL --retry 3 -o "$TMP" "$URL" 2>/dev/null && [ -s "$TMP" ]; then DL="$BR"; break; fi
done
[ -n "$DL" ] || die "다운로드 실패 — repo에 artes.zip이 올라갔는지, 공개(public)인지 확인"
ok "다운로드 완료 (브랜치: $DL, 크기: $(du -h "$TMP" | cut -f1))"

# 2) sha256 검증
GOT=$(sha256sum "$TMP" | awk '{print $1}')
if [ "$GOT" != "$EXPECT_SHA" ]; then
  warn "sha256 불일치!"
  echo "   기대: $EXPECT_SHA"
  echo "   실제: $GOT"
  echo "   (내가 방금 준 zip과 다름 — repo의 zip이 최신인지 확인. 계속하려면 아래 주석 해제)"
  die "검증 실패로 중단"
fi
ok "sha256 검증 통과"

# 3) 기존 소스 백업(가상환경·모델은 그대로)
if [ -d "$DEST/artes" ]; then
  BK="$DEST/.src-backup-$(date +%Y%m%d-%H%M%S)"
  mkdir -p "$BK" && cp -r "$DEST/artes" "$DEST/tests" "$BK"/ 2>/dev/null
  ok "기존 소스 백업: $BK"
fi

# 4) 압축 해제(덮어쓰기). zip 루트=repo 루트라 ~/artes에 그대로 펼쳐짐. .venv는 zip에 없어 보존됨
mkdir -p "$DEST"
unzip -o -q "$TMP" -d "$DEST" || die "압축 해제 실패"
ok "~/artes에 새 소스 설치"

# 5) 검증 (가상환경 있으면 pytest)
cd "$DEST" || die "cd 실패"
if [ -f ".venv/bin/activate" ]; then
  # shellcheck disable=SC1091
  source .venv/bin/activate
  # 새 증분은 순수 표준라이브러리라 재설치 불필요. 혹시 몰라 -e 재설치는 생략.
  echo "  테스트 실행 중..."
  if python -m pytest -q 2>/dev/null | tail -1; then ok "테스트 통과"; else warn "일부 테스트 이슈 — 위 로그 확인"; fi
  N=$(python -c "from artes.collectors.registry import default_collectors as d; print(len(d(real=True)))" 2>/dev/null)
  [ -n "$N" ] && ok "수집기 $N개 로드됨(증분38 = 155 기대)"
else
  warn "가상환경(.venv) 없음 — 최초 설치라면: cd ~/artes && ./install.sh"
fi

rm -f "$TMP"
echo -e "${C_G}=== 완료 ===${C_0}  이제 바로 쓰면 돼:  artes scan --name \"...\" ..."
