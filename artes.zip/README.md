# ARTES

정보 조각(이름·전화·이메일·아이디·도메인·IP) 1~N개를 넣으면, 공개 OSINT 도구들을
**병렬로** 돌려 계정·연락처·인프라·다크웹 흔적을 모아 하나의 그래프로 엮고, **동일인
후보**를 근거 있는 신뢰도로 판정하는 통합 조회 엔진. 로컬 AI(우리가 빌드한 llama.cpp)가
결과를 해석·질의응답하고, 터미널 범용 AI로도 쓴다. Maltego/SpiderFoot의 자립형 오픈소스 대체.

> **용도 한정.** 본인 발자국 점검 / 대상의 동의·권한이 있는 조사 / 위협인텔 연구 전용.
> 동의 없는 제3자 추적·프로파일링은 다수 국가에서 위법이며 책임은 사용자에게 있다.
> 첫 실행 시 동의 고지에 동의해야 하고, 불법 콘텐츠(CSAM 등)는 자동 배제된다.

## 설계 원칙

- **확실/불확실 두 가지만.** 근거 없는 연결은 그래프에 안 넣는다. 추정엔 신뢰도(%),
  그것도 임의값이 아니라 **정확 신뢰 하한**(Clopper–Pearson)이다.
- **속도가 정체성.** 모든 조회 병렬(포화점까지), 도구별 타임아웃·실패 격리, 캐시로 재조회 0초.
- **AI는 꼭 필요할 때만.** 수집·파싱·그래프·확장·스캔·동일인 해소는 전부 일반 코드(AI 0회).
  AI는 해석·질의응답·대화에만 쓰고 호출 횟수를 감사한다. (자세히는 [JABAN.md](JABAN.md).)
- **만든 건 실제로 돌려 검증.** 안 되는 걸 된다고 안 한다.

## 설치

```bash
git clone <this-repo> artes && cd artes
./install.sh            # OS 감지, 3.11 venv, OSINT 도구, 시스템 의존, 검증
./install.sh --with-ai  # 위 + llama.cpp CPU 빌드 + 모델(GGUF) 내려받기
```

## 사용

```bash
source .venv/bin/activate
artes "홍길동" "+821012345678" "hong@gmail.com" "hong123"   # 여러 조각 동시 조회
artes scan --interpret --web out.html --out out.json "example.com"
artes ask "김지완 전화번호 뭐야?" "김지완"                    # 수집→질의응답(코드 우선, 없으면 '확인 안 됨')
artes ask "이 데이터 뭐야?" --load out.json
artes ai chat                                              # 터미널 대화
artes ai swarm "CSV 파서 만들어"                            # 지휘자-일꾼 병렬 코딩
artes ai bench                                             # 3B/7B 속도·정확 벤치
artes view out.json --web out.html                        # 저장 그래프 → 웹 뷰어
artes investigate "홍길동" "hong@gmail.com"                  # 대화형 수사(ask/pivot/expand)
artes report "hong123" --out card.html                     # 프로파일 카드 리포트
artes workflow run person "hong@gmail.com" --yes           # 저장된 수사 절차 실행
artes dork "홍길동"                                          # 검색 dork 생성(다엔진)
artes scan --verify --report r.html "example.com"          # 자기검증 + 리포트
```

출력: ①터미널 스트리밍(확실/불확실) ②JSON ③웹 그래프(Chrome, 노드 클릭 확장).

## 축

표층(maigret·sherlock·blackbird·holehe·theHarvester) · 전화(phoneinfoga·ignorant·phunter) ·
네트워크(nmap·Wayback) · 인프라(RDAP·crt.sh·DNS) · 개발자(GitHub 커밋→실명·이메일) ·
검증신원(Keybase) · 웹지문(GA/AdSense/파비콘→동일 운영자) · 능동확장(아이디·이메일 순열·
Gravatar·이름추정) · 다크웹(onionsearch·torbot + Tor 자동관리, `--darkweb`) ·
유출(h8mail 로컬). 도구가 없으면 해당 축은 자동으로 건너뛴다(크래시 없음).

## 로컬 AI (Ollama 미사용)

우리가 소스에서 빌드한 **llama.cpp**(CPU) 위 단일 런타임에서 세 용도:
내부 해석층(동일인·요약, 실데이터 교차검증 후 확실/불확실) · 수집 데이터 질의응답 ·
터미널 대화 + 지휘자-일꾼 병렬 코딩(자원 포화점까지만 스케일). 모델은 양자화 GGUF(Q4/Q5,
키·계정 불필요). 모델이 없으면 안전한 스텁으로 동작하고 실사용은 `--with-ai` 설치 후.

## 상태

핵심(모델·엔진·그래프·동일인 해소·AI 로직·CLI·웹뷰어) 구현·검증 완료(테스트 통과).
실사이트 조회·실모델 추론은 사용자 환경에서(빌드 환경은 네트워크 allowlist). 진행 로그
[`PROGRESS.md`](PROGRESS.md), 논문 적용 [`JABAN.md`](JABAN.md), 라이선스 [`THIRD_PARTY.md`](THIRD_PARTY.md).

## 라이선스

ARTES 본체 **GPLv3**(번들 도구 다수가 GPL 계열이라 호환 유지). 도구별 라이선스는 THIRD_PARTY.md.
