"""ARTES 명령줄 진입점.

  artes "홍길동" "+821012345678" "hong@gmail.com" "hong123"   # 조회(기본)
  artes scan --web out.html --interpret "example.com"
  artes ask "김지완 전화번호 뭐야?" "김지완"                    # 수집→질의응답
  artes ask "이 데이터 뭐야?" --load out.json
  artes ai chat                                              # 터미널 대화
  artes ai swarm "CSV 파서 만들어"                            # 지휘자-일꾼 병렬코딩
  artes ai bench                                             # 3B/7B 벤치
  artes ai model qwen2.5-3b                                  # 모델 상태
  artes view out.json --web out.html                        # 저장 그래프 뷰어
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import re
import sys

from .core.cache import Cache
from .core.engine import Engine
from .core.model import Graph
from .collectors import mock
from .collectors.registry import default_collectors

NOTICE = """\
─────────────────────────────────────────────────────────────
 ARTES — 합법·인가된 조사 전용 OSINT 도구
 본인 발자국 점검 / 대상의 동의·권한이 있는 조사 / 위협인텔 연구에만
 사용하십시오. 동의 없는 제3자 추적·프로파일링은 다수 국가에서 위법이며,
 그 책임은 사용자에게 있습니다. 불법 콘텐츠는 자동 배제됩니다.
─────────────────────────────────────────────────────────────"""

KNOWN = {"scan", "ask", "ai", "view", "report", "investigate", "workflow",
         "dork", "export", "monitor", "docmeta", "typo", "demo",
         "case", "eval", "keys"}


# ---------- 공용 ----------
def _acknowledged(yes: bool, mock_mode: bool) -> bool:
    if yes or os.environ.get("ARTES_ACK") == "1" or mock_mode:
        return True
    if not sys.stdin.isatty():
        return False
    try:
        return input("위 용도로만 사용함에 동의하십니까? [y/N] ").strip().lower() in ("y", "yes")
    except EOFError:
        return False


def _build_engine(args) -> Engine:
    collectors = mock.DEFAULTS if getattr(args, "mock", False) else default_collectors(
        real=True, include_mock=getattr(args, "include_mock", False),
        enable_darkweb=getattr(args, "darkweb", False))
    return Engine(collectors, cache=Cache(), concurrency=args.concurrency,
                  depth=args.depth, use_cache=not args.no_cache,
                  max_queries=getattr(args, "max_queries", 2000),
                  max_seconds=getattr(args, "max_seconds", 180.0),
                  use_fs=getattr(args, "fs_fusion", False))


def _fmt_event(ev):
    t = ev["type"]
    if t == "seed":
        e = ev["entity"]; return f"  ▸ 입력: [{e['type_ko']}] {e['value']}"
    if t == "result":
        if ev["skipped"]:
            return None
        mark = "✓" if ev["ok"] else "✗"
        add = f" (+{len(ev['added'])})" if ev["added"] else ""
        return f"  {mark} {ev['summary']}{add}"
    if t == "expand":
        return f"  ↳ 확장(반복 {ev['depth']}): {ev['count']}건 재조회"
    if t == "converged":
        return f"  ● 수렴/정지: {ev['reason']} (반복 {ev['iteration']})"
    if t == "correlate":
        return f"  ⚑ 동일인 해소: {ev['count']}개 연결(확실/불확실 근거 포함)"
    if t == "done":
        s, g = ev["stats"], ev["graph"]
        return (f"\n완료 · {s['elapsed_sec']}s · 엔티티 {g['entities']}"
                f"(확실 {g['confirmed']}/불확실 {g['unconfirmed']}) · 간선 {g['edges']}"
                f" · AI 호출 {s['ai_calls']}회 · 캐시 {s['cache']['hits']}적중")
    return None


async def _scan_to_graph(args, quiet=False) -> Engine:
    eng = _build_engine(args)
    async for ev in eng.run(args.inputs):
        if not quiet and not getattr(args, "json", False):
            line = _fmt_event(ev)
            if line:
                print(line, flush=True)
    return eng


# ---------- 명령: scan ----------
def cmd_scan(args) -> int:
    if not args.json:
        print(NOTICE)
    if not _acknowledged(args.yes, args.mock):
        print("동의가 없어 중단합니다. (--yes 또는 ARTES_ACK=1)", file=sys.stderr)
        return 2
    if not args.json:
        print(f"\nARTES 조회 시작 — 입력 {len(args.inputs)}개, 깊이 {args.depth}\n")
    eng = asyncio.run(_scan_to_graph(args))
    # AI/후처리 단계는 스캔 결과를 절대 날리지 않도록 각각 격리(실패해도 저장은 진행).
    def _guard(label, fn):
        try:
            fn()
        except Exception as ex:                 # noqa: BLE001 — 후처리 실패가 스캔을 죽이면 안 됨
            if not args.json:
                print(f"  ⚠ {label} 건너뜀(오류: {type(ex).__name__}) — 스캔 결과는 저장됩니다",
                      file=sys.stderr)
    if args.verify or getattr(args, "deep_verify", False):
        _guard("자기검증", lambda: _do_verify(eng.graph, args))
    if getattr(args, "cluster", False):
        _guard("동일인 군집화", lambda: _do_cluster(eng.graph, args))
    _guard("확신도 채점", lambda: _do_scoring(eng.graph, args))
    if getattr(args, "pivots", False):
        _guard("피벗 분석", lambda: _do_pivots(eng.graph, args))
    if args.interpret:
        _guard("AI 해석", lambda: _do_interpret(eng.graph, args))
    if args.web:
        from .viewer.web import export
        export(eng.graph, args.web)
        if not args.json:
            print(f"\n웹 그래프: {args.web} (Chrome에서 열기)")
    if args.report or args.card:
        from .core.report import build_profile, render_html, render_json
        prof = build_profile(eng.graph, args.inputs)
        if args.report:
            open(args.report, "w", encoding="utf-8").write(render_html(prof))
            if not args.json:
                print(f"프로파일 리포트: {args.report}")
        if args.card:
            open(args.card, "w", encoding="utf-8").write(render_json(prof))
    if args.out:
        open(args.out, "w", encoding="utf-8").write(eng.graph.to_json())
        if not args.json:
            print(f"JSON 저장: {args.out}")
    if args.json:
        print(eng.graph.to_json())
    return 0


def _seed_keys(inputs):
    from .core.model import Entity
    from .core.types import detect, normalize_dob
    keys = []
    for raw in inputs:
        et = detect(raw)
        val = normalize_dob(raw) or raw if et.name == "DOB" else raw
        keys.append(Entity(et, val, None).key)
    return keys


def _do_scoring(graph, args):
    """후보 신뢰도 자동 채점 — '대상 본인일 확신도' 순위 + 고확신 후보 확정 승격(AI 0회)."""
    from .core.scoring import promote_confident, score_targets
    seeds = _seed_keys(args.inputs)
    n = promote_confident(graph, seeds, threshold=0.75)     # 결정적 동일인 판정
    ranked = score_targets(graph, seeds, top=15)
    if args.json:
        return
    if ranked:
        print("\n── 대상 본인 확신도 순위 (코드 채점, AI 0회) ──")
        for r in ranked:
            if r["score"] < 0.25:
                continue
            why = ", ".join(r["reasons"][:3])
            print(f"  {r['score']:.0%}  [{r['type']}] {r['value']}"
                  + (f"   ← {why}" if why else ""))
        if n:
            print(f"  ↳ 고확신 후보 {n}건을 '확실'로 승격")


def _do_verify(graph, args):
    from .ai.verify import verify_same_person
    from .ai.serving import role_runtime
    rt = role_runtime("judge")                  # OSINT 판정=judge 역할(원격 GLM 가능)
    if rt.is_stub:
        return                                  # 모델 없으면 검증 스킵(조용히)
    deep = getattr(args, "deep_verify", False)
    n = 0
    for e in list(graph.edges):
        if e.relation != "동일인?":
            continue
        verify_same_person(rt, graph, e)        # 1) 적대적 반증(신뢰도 강등)
        if deep:                                # 2) 심층 판정(2패스+CoVe+융합)
            _deep_judge_edge(rt, graph, e)
        n += 1
    if not args.json and n:
        mode = "심층 판정" if deep else "적대 검증"
        print(f"  ⚖ 자기검증: 동일인 주장 {n}건 {mode}")


def _deep_judge_edge(rt, graph, edge) -> None:
    """동일인 간선을 적응 라우터로 판정(싼 판정→애매하면 교정→8B 승격). 캐스케이드."""
    from .ai.router import route_judge
    a, b = graph.get(edge.src), graph.get(edge.dst)
    if not a or not b:
        return
    ctx = []
    for ent in (a, b):
        ctx.append(f"[{ent.type.label_ko()}] {ent.value}")
        for nb in graph.neighbors(ent.key):
            ctx.append(f"  └ {nb.type.label_ko()}: {nb.value}")
    q = f"{a.value} 와 {b.value} 는 동일인인가?"
    r = route_judge(rt, q, "\n".join(ctx[:120]))
    from .core.model import Evidence
    edge.evidence.append(Evidence("심층판정",
        f"적응 판정[{r['tier']}]: {r['verdict']}(신뢰 {r['confidence']})"))


def _do_cluster(graph, args):
    """전역 동일인 군집화(PIVOT 상관 군집) — 전이 일관된 실신원 묶음 출력."""
    from .core.cluster import cluster_identities
    clusters = [c for c in cluster_identities(graph) if len(c) >= 2]
    if args.json:
        return
    if not clusters:
        print("\n── 동일인 군집 ── (묶인 다중계정 없음)")
        return
    print(f"\n── 동일인 군집 ── ({len(clusters)}개 실신원)")
    for i, c in enumerate(clusters, 1):
        vals = [graph.get(k).value if graph.get(k) else k for k in sorted(c)]
        print(f"  #{i}: " + " ≡ ".join(vals))


def _do_pivots(graph, args):
    """그래프 심층분석 — 시드 편향 PageRank + 매개중심성으로 다음 조사 대상 순위."""
    from .core.graphx import rank_pivots
    from .core.types import detect
    seeds = [f"{detect(v).value}:{v.strip().lower()}" for v in args.inputs]
    ranked = rank_pivots(graph, seeds, top=15)
    if args.json:
        return
    if not ranked:
        print("\n── 피벗 추천 ── (분석할 그래프 없음)")
        return
    print("\n── 피벗 추천 (심층 그래프 분석) ──")
    for key, score in ranked:
        ent = graph.get(key)
        label = f"{ent.type.label_ko()} {ent.value}" if ent else key
        print(f"  {score:.3f}  {label}")


def _do_interpret(graph, args):
    from .ai.interpret import interpret
    from .ai.serving import role_runtime
    rt = role_runtime("judge")
    r = interpret(graph, runtime=None if args.no_ai else rt)
    if args.json:
        return
    print("\n── 해석 ──")
    print(f"타입별: " + ", ".join(f"{k} {v}" for k, v in r.facts['by_type'].items()))
    if r.same_person:
        print("동일인 후보:")
        for s in r.same_person[:10]:
            c = "확실" if s["certainty"] == "confirmed" else f"불확실 {s['confidence']}"
            print(f"  · {s['a']} ~ {s['b']} [{c}] — {s['why']}")
    if r.narrative:
        print("요약(AI, 불확실):", r.narrative)
    elif not rt.is_stub:
        print("(AI 요약 없음)")
    else:
        print("(AI 모델 없음 — 사실만; 모델 설치 시 요약 생성)")


# ---------- 명령: ask ----------
def cmd_ask(args) -> int:
    from .ai.qa import answer
    from .ai.runtime import Runtime
    args.question = args.query[0]
    args.inputs = args.query[1:]
    if args.load:
        graph = Graph.load_json(open(args.load, encoding="utf-8").read())
    else:
        if not args.inputs:
            print("질문에 답하려면 조각 입력이나 --load 가 필요합니다.", file=sys.stderr)
            return 2
        if not _acknowledged(args.yes, args.mock):
            print("동의 필요(--yes).", file=sys.stderr); return 2
        graph = asyncio.run(_scan_to_graph(args, quiet=True)).graph
    from .ai.serving import role_runtime
    if args.rag:
        from .ai.rag import rag_answer
        r = rag_answer(role_runtime("judge"), graph, args.question)
        print(r["answer"])
        print(f"[{r['certainty']} · RAG({r['backend']}) · 근거 {len(r['sources'])}건]")
        return 0
    a = answer(graph, args.question, runtime=role_runtime("judge"))
    print(a.text)
    print(f"[{'확실' if a.certainty=='confirmed' else ('불확실' if a.certainty=='unconfirmed' else '확인 안 됨')}"
          f" · AI {'사용' if a.used_ai else '미사용'}]")
    return 0


# ---------- 명령: ai ----------
def cmd_ai(args) -> int:
    from .ai.runtime import Runtime, model_status
    if args.ai_cmd == "model":
        st = model_status(args.name) if args.name else None
        print(json.dumps(st or {"models": list(__import__('artes.ai.runtime',
              fromlist=['MODELS']).MODELS.keys())}, ensure_ascii=False, indent=2))
        return 0
    rt = Runtime.auto()
    if rt.is_stub:
        print("(주의: 로컬 모델이 없어 StubBackend로 동작 — 실사용은 모델 설치 후."
              " `artes ai model` 참고)\n")
    if args.ai_cmd == "chat":
        from .ai.chat import Chat
        from .ai.serving import role_runtime
        Chat(role_runtime("chat")).repl()          # 대화=초거대 모델(있으면), 없으면 폴백
        return 0
    if args.ai_cmd == "swarm":
        from .ai.swarm import run_swarm
        from .ai.serving import role_runtime
        rt = role_runtime("coder")                 # 병렬 코딩=코더 모델
        res = run_swarm(rt, args.task, requested_workers=args.workers)
        print(f"[계획 {len(res.plan)}개 · 일꾼 {res.workers_used}개 · "
              f"검증통과 {res.verified}/{len(res.pieces)} · 실패 {len(res.failed)}]")
        for p in res.plan:
            print("  -", p)
        print("\n[취합]\n" + res.assembled)
        print("\n" + json.dumps(rt.stats(), ensure_ascii=False))
        return 0
    if args.ai_cmd == "code":
        from .ai.coder import repair_loop, best_of_n
        from .ai.serving import role_runtime
        rt = role_runtime("coder")                 # 코딩=코더 모델(있으면), 없으면 폴백
        if args.n > 1:
            cr = best_of_n(rt, args.task, tests=args.tests, n=args.n)
        else:
            cr = repair_loop(rt, args.task, tests=args.tests)
        print(f"[통과 {cr.passed} · 시도 {cr.attempts}]")
        for s in cr.log:
            print("  ·", s)
        print("\n[코드]\n" + cr.code)
        return 0
    if args.ai_cmd == "bench":
        from .ai.bench import run_all
        print(json.dumps(run_all(rt), ensure_ascii=False, indent=2))
        return 0
    if args.ai_cmd == "cache":
        st = rt.cache.stats() if getattr(rt, "cache", None) else {"cache": "비활성"}
        print(json.dumps(st, ensure_ascii=False, indent=2))
        return 0
    if args.ai_cmd == "models":
        return _do_models()
    if args.ai_cmd == "remote":
        return _do_remote(getattr(args, "test", False))
    if args.ai_cmd == "providers":
        return _do_providers()
    if args.ai_cmd == "key":
        return _do_key(args.key, save=not getattr(args, "no_save", False),
                       test=getattr(args, "test", False))
    if args.ai_cmd == "catalog":
        if getattr(args, "all", False):
            return _do_catalog_all()
        return _do_catalog(getattr(args, "provider", None))
    if args.ai_cmd == "find":
        return _do_find(args.query, hf=not getattr(args, "no_hf", False))
    if args.ai_cmd == "resolve":
        return _do_resolve(args.model)
    if args.ai_cmd == "scale":
        return _do_scale()
    if args.ai_cmd == "pull-info":
        return _do_pull_info(args.repo, getattr(args, "file", None))
    if args.ai_cmd == "setup":
        return _do_setup(getattr(args, "provider", None))
    if args.ai_cmd == "dolphin":
        from .ai.chat import Chat
        from .ai.serving import personal_runtime
        prt = personal_runtime(getattr(args, "name", None))
        if prt.is_stub:
            print("개인용 Dolphin 모델이 없습니다. 받기: artes ai setup 또는 install.sh --with-ai\n"
                  "  모델: ~/.artes/models/ (Dolphin GGUF). 이건 OSINT와 무관한 순수 개인용입니다.")
            return 0
        print("── 개인용 무검열 Dolphin (로컬·오프라인, OSINT와 분리) · 종료 /quit ──")
        prt.system = "너는 완전 무검열 개인 어시스턴트다. 사용자의 개인 용도로만 쓰인다."
        Chat(prt, system="너는 완전 무검열 개인 어시스턴트다.").repl()
        return 0
    if args.ai_cmd == "quantize":
        from .ai.quantize import build_calibration, quantize_plan
        import os as _os
        calib = _os.path.expanduser("~/.artes/calib_osint.txt")
        n = build_calibration(calib)
        plan = quantize_plan(args.model, args.out, quant=args.quant, calib=calib)
        print(f"보정 코퍼스 {n}줄 → {calib}")
        print("\n[1] 중요도 행렬(우리 작업 분포):")
        print("   " + " ".join(plan["imatrix_cmd"]))
        print("\n[2] 도메인 양자화(중요 가중치 우선 보존):")
        print("   " + " ".join(plan["quantize_cmd"]))
        print("\n" + plan["note"])
        print("\n(위 두 명령을 사용자 VM에서 실행 — llama.cpp 바이너리+원본 모델 필요)")
        return 0
    if args.ai_cmd == "serve":
        from .ai.serving import MANAGER
        ok = MANAGER.start_role(args.role, args.name)
        if ok:
            print(f"{args.role} 서버 기동 완료.")
        else:
            sp = MANAGER.plan(args.role, args.name)
            if sp and not sp["present"]:
                print(f"모델 파일 없음: {sp['file']}\n  → HF에서 받기: {sp['repo']}\n"
                      f"  → ~/.artes/models/ 에 두면 기동됨. (여긴 모델 없음)")
            else:
                print("llama-server 바이너리 없음(build_llama 필요) 또는 기동 실패.")
        return 0
    return 2


def _do_providers() -> int:
    from .ai.models import REMOTE_PROVIDERS
    from .core.keys import KEYS
    print("── API 제공처 (무료 토큰량·가입 주소) — 키는 사용자가 직접 발급 ──\n")
    print("  정직: '가장 토큰 많은 곳'과 '가장 좋은 GLM'은 다르다. 용도로 골라라.\n")
    for prov, c in sorted(REMOTE_PROVIDERS.items(), key=lambda kv: kv[1].get("priority", 99)):
        on = "✓키있음" if KEYS.has(c["key"]) else "·키없음"
        print(f"[{prov}] {on}")
        print(f"   무료: {c['free']}")
        print(f"   설명: {c['note']}")
        print(f"   가입: {c['signup']}")
        print(f"   설정: export {'ARTES_KEY_' + prov.upper()}=<키>   (또는 artes ai setup)\n")
    print("추천:")
    print("  · GLM 최고품질(무료): openrouter + ARTES_AI_FREE=1 → GLM-5.2 ($0)")
    print("  · GLM 헤비유저 가성비: zai GLM Coding Plan Lite $18/월")
    print("  · 토큰 최다 무료(대량 OSINT): cerebras 1M/일 (Qwen/Llama)")
    print("  · 제공자 강제: export ARTES_AI_PROVIDER=cerebras 등")
    try:
        from .ai.providers import ALL_PROVIDERS
        print(f"\n  이 5곳은 '엄선'입니다. ARTES는 그 외 {len(ALL_PROVIDERS)}개 제공처의 키도 "
              "자동 인식합니다(OpenAI·Claude·Grok·Mistral·DeepSeek·Together·Fireworks·"
              "NVIDIA·HuggingFace·로컬 Ollama 등).")
        print("  아무 키나: artes ai key <키>   ·   모델 목록: artes ai catalog <제공처>")
    except Exception:
        pass
    return 0


def _do_key(key: str, save: bool = True, test: bool = False) -> int:
    """붙여넣은 API 키 → 제공처 자동 인식 + (선택) 저장 + (선택) 연결 테스트.

    증분 18: 현존 거의 모든 API 키 종류를 접두사로 판별한다. 애매하면 후보 제시.
    키 값은 화면에 다시 찍지 않는다(끝 4자리만).
    """
    from .ai.providers import detect_provider, ALL_PROVIDERS
    key = (key or "").strip()
    if not key:
        print("키가 비었습니다. 사용: artes ai key <API_KEY>"); return 2
    tail = key[-4:] if len(key) >= 4 else "****"
    det = detect_provider(key)
    prov = det["provider"]
    if prov and det["confident"]:
        p = ALL_PROVIDERS.get(prov, {})
        print(f"✓ 인식: [{prov}]  (…{tail})")
        print(f"   엔드포인트: {p.get('base_url','?')}")
        print(f"   비고: {p.get('note','')}")
    elif prov:
        print(f"~ 추정: [{prov}] (확신 낮음)  (…{tail})")
        print(f"   후보: {', '.join(det['candidates'])}")
        print("   제공처가 확실하면: artes ai key <키> 대신 keys.json에 정확한 이름으로 저장하거나")
        print("   export ARTES_AI_PROVIDER=<이름> 으로 강제 지정하세요.")
    else:
        print(f"✗ 접두사로 제공처를 특정하지 못했습니다  (…{tail})")
        if det["candidates"]:
            print(f"   가능 후보(고유 접두사 없는 곳): {', '.join(det['candidates'])}")
        print("   → keys.json에 정확한 제공처명으로 저장하거나 ARTES_AI_PROVIDER 지정.")
    if save and prov:
        import os as _os, json as _json
        path = _os.path.expanduser("~/.artes/keys.json")
        data = {}
        if _os.path.exists(path):
            try: data = _json.load(open(path, encoding="utf-8"))
            except Exception: data = {}
        svc = ALL_PROVIDERS.get(prov, {}).get("key", prov)
        data[svc] = key
        _os.makedirs(_os.path.dirname(path), exist_ok=True)
        _json.dump(data, open(path, "w", encoding="utf-8"))
        _os.chmod(path, 0o600)
        print(f"   저장: {path} (권한 600, 서비스명 '{svc}')")
    if test and prov:
        from .ai.serving import backend_from_key
        be = backend_from_key(key)
        if be is None:
            print("   [테스트] 백엔드 구성 실패."); return 0
        try:
            out = be.generate("한 단어로 답: 준비됐나?", max_tokens=8)
            print(f"   [테스트] {be.name} {be.model} → {out.strip()[:60]}")
        except Exception as e:
            print(f"   [테스트 실패] {e}")
    return 0


def _do_catalog(provider: str | None) -> int:
    """제공처 모델 카탈로그(/models) — OpenRouter는 400+ 반환. 키 있으면 인증해 조회."""
    from .ai.providers import list_models, ALL_PROVIDERS
    from .core.keys import KEYS
    if not provider:
        print("사용: artes ai catalog <provider>  (예: openrouter, groq, cerebras)")
        print("제공처 목록: " + ", ".join(sorted(ALL_PROVIDERS)))
        return 2
    if provider not in ALL_PROVIDERS:
        print(f"모르는 제공처: {provider}\n선택: " + ", ".join(sorted(ALL_PROVIDERS)))
        return 2
    svc = ALL_PROVIDERS[provider].get("key", provider)
    key = KEYS.get(svc)
    print(f"── [{provider}] 모델 카탈로그 ── ({'키 있음' if key else '키 없음 — 공개 목록만'})")
    ids = list_models(provider, key)
    if not ids:
        print("(모델을 가져오지 못함 — 네트워크/인증/엔드포인트 확인. 이 컨테이너는 외부망 제한)")
        print(f"엔드포인트: {ALL_PROVIDERS[provider]['base_url']}/models")
        return 0
    print(f"총 {len(ids)}개:")
    for m in ids[:200]:
        print("  ·", m)
    if len(ids) > 200:
        print(f"  … 외 {len(ids)-200}개")
    return 0


def _do_catalog_all() -> int:
    """모든 OpenAI 호환 제공처의 라이브 카탈로그 합집합 → 개수·캐시(수천 모델)."""
    from .ai.catalog import aggregate_remote_catalogs, CATALOG_CACHE
    print("── 전 제공처 모델 카탈로그 집계(/models 합집합) ──")
    print("(키 있는 제공처는 인증, 나머지는 공개 목록. 이 컨테이너는 외부망 제한)")
    cat = aggregate_remote_catalogs()
    if not cat:
        print("가져온 모델 0 — 네트워크 제한 환경. 사용자 크롬북/VM에서 실행하면 수천 개 집계됨.")
        return 0
    prov_count: dict = {}
    for provs in cat.values():
        for p in provs:
            prov_count[p] = prov_count.get(p, 0) + 1
    print(f"\n고유 모델 {len(cat)}개(원격 호스팅). 제공처별:")
    for p, n in sorted(prov_count.items(), key=lambda kv: -kv[1]):
        print(f"  {p:14s} {n}")
    print(f"\n캐시 저장: {CATALOG_CACHE}  (artes ai find <검색어>로 검색)")
    return 0


def _do_find(query: str, hf: bool = True) -> int:
    """로컬(HF GGUF 10만+) + 원격(제공처 카탈로그) 통합 모델 검색."""
    from .ai.catalog import search_models, resolve_model
    from .core.keys import KEYS
    res = search_models(query, hf=hf, hf_token=KEYS.get("huggingface"))
    hf_hits, remote = res["hf_gguf"], res["remote"]
    print(f"── 모델 검색: '{query}' ──")
    if hf_hits:
        print(f"\n[로컬 실행 가능 · HF GGUF] {len(hf_hits)}개(우리 llama.cpp로 실행):")
        for m in hf_hits[:25]:
            g = " (gated:키필요)" if m.get("gated") else ""
            print(f"  · {m['id']:52s} ↓{m['downloads']:>9} ♥{m['likes']}{g}")
        print(f"  받기: artes ai pull-info <repo>  또는 install.sh")
    else:
        print("\n[HF GGUF] (결과 없음 — 네트워크 제한이거나 매칭 없음. 사용자 환경에선 10만+ 검색)")
    if remote:
        print(f"\n[원격 호스팅] 캐시 카탈로그 매칭 {len(remote)}개:")
        for m in remote[:25]:
            print(f"  · {m['id']:52s} @ {', '.join(m['providers'])}")
    else:
        print("[원격] 캐시 없음 — 먼저 'artes ai catalog --all'로 집계.")
    return 0


def _do_resolve(model_id: str) -> int:
    """이 모델을 어디서 돌릴 수 있나(로컬 GGUF? 어느 제공처?)."""
    from .ai.catalog import resolve_model, hf_gguf_files
    from .core.keys import KEYS
    r = resolve_model(model_id)
    print(f"── 모델 실행처: {r['id']} ──")
    print(f"  실행 가능: {'예' if r['runnable'] else '불명(카탈로그 집계 후 재확인)'}")
    if r["local_gguf"]:
        print(f"  로컬(우리 llama.cpp): HF repo '{r['id']}'로 GGUF 실행 가능")
        files = hf_gguf_files(r["id"], KEYS.get("huggingface"))
        if files:
            print(f"    GGUF 파일 {len(files)}개, 예: {files[0]}")
    if r["remote_providers"]:
        print(f"  원격 제공처: {', '.join(r['remote_providers'])}")
        print(f"    설정: export ARTES_AI_PROVIDER=<제공처> ARTES_AI_MODEL={r['id']}")
    if not r["runnable"]:
        print("  → 'org/name' 꼴 HF repo이거나 'artes ai catalog --all' 후 다시 시도.")
    return 0


def _do_scale() -> int:
    """지원 규모(몇 개 모델을 인식/지원하나) — 정직한 근거."""
    from .ai.catalog import catalog_stats
    s = catalog_stats()
    print("── ARTES 모델 지원 규모 ──")
    print(f"  인식 제공처: {s['providers_known']}개(키 접두사 자동 판별)")
    print(f"  로컬 실행(HF GGUF, llama.cpp): ~{s['local_hf_gguf_estimate']:,}개+ "
          "— 임의 GGUF 실행이므로 사실상 HF의 전 GGUF 우주")
    print(f"  원격 카탈로그 캐시: {s['remote_cached']}개 "
          "(artes ai catalog --all로 갱신 — OpenRouter 400+ 등 합집합)")
    if s["remote_by_provider"]:
        print("  제공처별 캐시:")
        for p, n in sorted(s["remote_by_provider"].items(), key=lambda kv: -kv[1])[:10]:
            print(f"    {p:14s} {n}")
    print(f"\n  {s['note']}")
    print("  정직: 10만+는 하드코딩이 아니라 '임의 GGUF 실행 + 라이브 카탈로그 집계'로 실지원.")
    return 0


def _do_pull_info(repo: str, file: str | None) -> int:
    """임의 HF GGUF repo → 다운로드 URL·대상 경로 안내(이게 '10만+ 지원'의 실체).

    파일 미지정이면 repo의 .gguf 목록을 조회해 고르게 안내. 네트워크 되면 파일목록 표시.
    """
    from .ai.catalog import hf_gguf_files, hf_gguf_url, looks_like_hf_repo
    from .core.keys import KEYS
    import os as _os
    if not looks_like_hf_repo(repo):
        print(f"HF repo 형식이 아님(‘org/name’ 필요): {repo}"); return 2
    dst_dir = _os.path.expanduser("~/.artes/models")
    print(f"── HF GGUF 받기: {repo} ──")
    files = hf_gguf_files(repo, KEYS.get("huggingface"))
    if files and not file:
        print(f"GGUF 파일 {len(files)}개 — 하나 골라 --file 로 지정:")
        for f in files[:20]:
            print(f"  · {f}")
        # 기본 추천: Q4_K_M 있으면 그것.
        pick = next((f for f in files if "Q4_K_M" in f), files[0])
        print(f"\n추천: {pick}")
        file = pick
    if not file:
        stem = re.sub(r"-?GGUF$", "", repo.split("/")[-1], flags=re.I)
        file = f"{stem}-Q4_K_M.gguf"
        print(f"(파일목록 조회 실패 — 네트워크 제한. 예상 파일명: {file})")
    url = hf_gguf_url(repo, file)
    dst = _os.path.join(dst_dir, file)
    print(f"\n다운로드 URL: {url}")
    print(f"대상 경로:   {dst}")
    print("\n사용자 VM/크롬북에서 실행:")
    print(f"  mkdir -p {dst_dir} && curl -L -o '{dst}' '{url}'")
    print("  # (gated 모델이면 HF_TOKEN 필요)  이후: artes ai serve chat --name <...> 또는 llama-server")
    return 0


def _do_setup(only: str | None) -> int:
    import sys as _sys
    from .ai.models import REMOTE_PROVIDERS
    from .core.keys import KEYS
    import json as _json, os as _os
    print("── ARTES API 키 설정 (배포판) ──")
    print("ARTES에는 어떤 키도 들어있지 않습니다. 아래에서 직접 발급해 넣으세요.\n")
    provs = ([only] if only and only in REMOTE_PROVIDERS
             else sorted(REMOTE_PROVIDERS, key=lambda p: REMOTE_PROVIDERS[p].get("priority", 99)))
    path = _os.path.expanduser("~/.artes/keys.json")
    data = {}
    if _os.path.exists(path):
        try:
            data = _json.load(open(path, encoding="utf-8"))
        except Exception:
            data = {}
    if not _sys.stdin.isatty():
        print("(비대화형) 가입 주소만 안내합니다:")
        for p in provs:
            print(f"  {p}: {REMOTE_PROVIDERS[p]['signup']}")
        print("\n키 저장: ~/.artes/keys.json 에 {\"openrouter\":\"<키>\"} 형태로.")
        return 0
    for p in provs:
        c = REMOTE_PROVIDERS[p]
        print(f"\n[{p}] {c['free']}\n  가입: {c['signup']}")
        try:
            v = input(f"  {p} API 키 입력(건너뛰려면 Enter): ").strip()
        except EOFError:
            v = ""
        if v:
            data[p] = v
    if data:
        _os.makedirs(_os.path.dirname(path), exist_ok=True)
        _json.dump(data, open(path, "w", encoding="utf-8"))
        _os.chmod(path, 0o600)
        print(f"\n저장: {path} (권한 600). 이제 artes ai chat / scan --deep-verify 에서 쓰입니다.")
    else:
        print("\n입력된 키 없음. 나중에 다시: artes ai setup")
    return 0


def _do_remote(do_test: bool) -> int:
    from .ai.serving import remote_backend_for
    from .ai.models import REMOTE_PROVIDERS, REMOTE_MODELS
    from .core.keys import KEYS
    print("── 원격 큰 두뇌(GLM 등) — 크롬북에서 최강 AI 쓰기 ──")
    provs = [p for p, c in REMOTE_PROVIDERS.items() if KEYS.has(c["key"])]
    for role in ("chat", "coder", "judge"):
        be = remote_backend_for(role)
        if be is not None:
            print(f"  {role:6s} → 원격 {be.model} @ {be.base_url}")
        else:
            print(f"  {role:6s} → (원격 미설정 — 로컬/폴백)")
    if not provs:
        print("\n설정법: 환경변수 하나만 넣으면 됨.")
        print("  · 무료 GLM: OpenRouter 키 발급 → export OPENROUTER_API_KEY=... "
              "+ export ARTES_AI_FREE=1  (모델 z-ai/glm-5.2:free, $0)")
        print("  · 최강 GLM-5.3-Flash: 위 키 + ARTES_AI_FREE 없이 (유료·저렴)")
        print("  · Z.ai 직결: export ZAI_API_KEY=...")
        print("  · 자기 VM llama-server: export ARTES_CHAT_URL=http://<VM_IP>:8082/v1")
    if do_test and provs:
        try:
            be = remote_backend_for("chat")
            out = be.generate("한 단어로 답: 준비됐나?", max_tokens=8)
            print(f"\n[테스트] 응답: {out.strip()[:80]}")
        except Exception as e:
            print(f"\n[테스트 실패] {e}")
    return 0


def _do_models() -> int:
    from .ai.models import (ROLE_MODELS, recommend, detect_ram_gb, REMOTE_MODELS,
                            ONDEVICE_TIERS)
    ram = detect_ram_gb()
    print("── 원격(권장, 크롬북용): GLM 등 API로 최강 모델 ──")
    for role, r in REMOTE_MODELS.items():
        print(f"  {role:6s} 최강 {r['best']}  ·  무료 {r['free']}")
    print("  설정: artes ai remote  참고 (OPENROUTER_API_KEY 하나면 됨)\n")
    print("── 온디바이스(크롬북 ~8GB, 오프라인·프라이빗) ──")
    for name, m in ONDEVICE_TIERS.items():
        fit = "✓" if m.get("min_ram_gb", 99) <= ram else "✗"
        print(f"  {fit} {name:24s} {m['approx_gb']:>4}GB  — {m['note']}")
    print(f"\n── 로컬 서버 역할 모델 (감지 RAM ~{ram}GB, 강한 VM용) ──")
    role_ko = {"judge": "판정(OSINT)", "coder": "코딩", "chat": "대화(범용)"}
    for role, spec in ROLE_MODELS.items():
        rec = recommend(role, ram)
        print(f"\n[{role_ko.get(role, role)}]  추천: {rec}")
        for name, m in spec["tiers"].items():
            fit = "✓" if m.get("min_ram_gb", 999) <= ram else "✗(RAM 부족)"
            star = " ←추천" if name == rec else ""
            mo = " MoE" if m.get("moe") else ""
            print(f"  {fit} {name:32s} {m['approx_gb']:>5}GB  (RAM≥{m.get('min_ram_gb','?')}GB){mo}{star}")
    print("\n무검열(Dolphin/abliterated) GGUF. 모델은 ~/.artes/models/ 에. "
          "기동: artes ai serve <역할>. 정확 파일명은 HF에서 확인(양자화명 표준).")
    return 0


# ---------- 명령: keys ----------
def cmd_cookie(args) -> int:
    from .core.cookies import COOKIES, COOKIE_GUIDE
    site = (getattr(args, "site", None) or "").lower()
    val = getattr(args, "value", None)
    if not site:                                  # 상태 + 안내
        st = COOKIES.status()
        print("── SNS 심층조회용 쿠키 상태 (값은 표시 안 함) ──")
        for s in sorted(st):
            mark = "✓ 설정됨" if st[s] else "· 없음(심층 skip)"
            print(f"  {s:11s} {mark}   필요: {COOKIE_GUIDE.get(s, '?')}")
        print("\n저장:  artes cookie instagram 'sessionid=...'")
        print("주의: 본인이 로그인한 본인 계정의 쿠키만. ToS 위반·계정정지 위험은 사용자 책임.")
        print("      값은 ~/.artes/cookies.json(600)·요청 헤더에만. 로깅·배포 안 함.")
        return 0
    if not val:                                   # 특정 사이트 안내만
        print(f"{site} 필요 쿠키: {COOKIE_GUIDE.get(site, '알 수 없음')}")
        print(f"저장:  artes cookie {site} '<값>'  (브라우저 개발자도구>Application>Cookies에서 복사)")
        return 0
    COOKIES.set(site, val)
    print(f"✓ {site} 쿠키 저장(끝 4자리 …{val[-4:]}). ~/.artes/cookies.json (권한 600).")
    print("  이제 해당 심층 수집기가 활성화됩니다(예: instagram-auth).")
    return 0


def cmd_search_bench(args) -> int:
    from .core.searchpool import benchmark, save_ranked, SEARX_INSTANCES
    rounds = getattr(args, "rounds", 150) or 150
    print(f"검색엔진 벤치마크 — 인스턴스 {len(set(SEARX_INSTANCES))}개 × 프로브쿼리 병렬 "
          f"(최대 {rounds}라운드)…\n")
    ranked = asyncio.run(benchmark(max_rounds=rounds))
    live = [r for r in ranked if r["reachable"]]
    print(f"살아있는 인스턴스: {len(live)}/{len(ranked)}   (점수=고유결과+유출표면화×3)\n")
    print(f"  {'순위':<4}{'점수':>5}{'고유':>5}{'유출':>5}{'지연':>6}  인스턴스")
    for i, r in enumerate(ranked[:20], 1):
        if not r["reachable"]:
            continue
        print(f"  {i:<4}{r['score']:>5}{r['unique']:>5}{r['leak_hits']:>5}{r['latency']:>6}s  {r['source']}")
    top_k = getattr(args, "top", 12) or 12
    save_ranked(ranked, top_k=top_k)
    print(f"\n상위 {top_k}개를 ~/.artes/search_engines.json에 저장 — 이제 스캔 검색이 이걸 병렬 사용.")
    return 0


def cmd_keys(args) -> int:
    from .core.keys import KEYS
    st = KEYS.status()
    on = [s for s, v in st.items() if v]
    print("── 선택적 API 키 상태 (값은 표시 안 함) ──")
    for s in sorted(st):
        mark = "✓ 활성" if st[s] else "· 없음(해당 수집기 skip)"
        print(f"  {s:16s} {mark}  [{KEYS.source_of(s) if st[s] else 'none'}]")
    print(f"\n활성 {len(on)}/{len(st)}. 키 설정: 환경변수 ARTES_KEY_<SERVICE> 또는 "
          "~/.artes/keys.json (\"shodan\": \"...\"). 키 없이도 기본 70개 수집기는 그대로 동작.")
    return 0


# ---------- 명령: report ----------
def cmd_report(args) -> int:
    from .core.report import build_profile, render_html
    if args.load:
        graph = Graph.load_json(open(args.load, encoding="utf-8").read())
        targets = []
    else:
        if not args.inputs:
            print("리포트에 조각 입력이나 --load 필요.", file=sys.stderr); return 2
        if not _acknowledged(args.yes, args.mock):
            print("동의 필요(--yes).", file=sys.stderr); return 2
        graph = asyncio.run(_scan_to_graph(args, quiet=True)).graph
        targets = args.inputs
    out = args.out or "artes_report.html"
    open(out, "w", encoding="utf-8").write(render_html(build_profile(graph, targets)))
    print(f"프로파일 리포트: {out} (Chrome에서 열기)")
    return 0


# ---------- 명령: investigate (대화형 수사) ----------
async def _scan_values(args, values):
    eng = _build_engine(args)
    async for _ in eng.run(values):
        pass
    return eng


def cmd_investigate(args) -> int:
    print(NOTICE)
    if not _acknowledged(args.yes, args.mock):
        print("동의 필요(--yes).", file=sys.stderr); return 2
    from .ai.qa import answer as qa_answer
    from .ai.runtime import Runtime
    from .core import selectors as sel
    from .core.report import build_profile, render_html
    from .viewer.web import export

    print(f"\n수사 시작 — {', '.join(args.inputs)}\n")
    rt = Runtime.auto()

    if getattr(args, "agent", False):        # AI 지휘 자동 수사
        from .ai.agent import Investigator
        collectors = mock.DEFAULTS if args.mock else default_collectors(
            real=True, enable_darkweb=args.darkweb)
        inv = Investigator(rt, collectors, cache=Cache(), max_steps=args.max_steps,
                           engine_kw={"depth": args.depth})
        graph, log = asyncio.run(inv.investigate(args.inputs))
        for s in log:
            print(f"  [{s['step']}] {s['action']}: {s.get('hypothesis','')} "
                  f"{s.get('targets',[])[:6]}")
        print("  " + _summary_line(graph))
        _finish_investigate(graph, args); return 0

    if getattr(args, "auto", False):         # 규칙 기반 자동 피벗
        from .core.pivot import AutoPivot
        collectors = mock.DEFAULTS if args.mock else default_collectors(
            real=True, enable_darkweb=args.darkweb)
        ap = AutoPivot(collectors, cache=Cache(), max_rounds=args.max_steps,
                       depth=args.depth)
        graph = asyncio.run(ap.investigate(args.inputs))
        for r in ap.rounds_log:
            print(f"  라운드 {r['round']}: 피벗 {r.get('pivots',0)}건 {r.get('values',[])[:6]}")
        print("  " + _summary_line(graph))
        _finish_investigate(graph, args); return 0

    eng = asyncio.run(_scan_values(args, args.inputs))
    graph = eng.graph
    print(_summary_line(graph))
    print("명령: ask <질문> · pivot [값] · expand <값> · report <파일> · graph <파일> · quit")
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        if line in ("quit", "exit", "/quit"):
            break
        cmd, _, rest = line.partition(" ")
        if cmd == "ask":
            a = qa_answer(graph, rest, runtime=rt)
            print(a.text, f"[{a.certainty}]")
        elif cmd == "pivot" and not rest:
            for s in sel.extract_selectors(graph)[:10]:
                print(f"  · [{s['kind']}] {s['selector']} (가치 {s['pivot_value']}) — {s['why']}")
        elif cmd in ("pivot", "expand") and rest:
            print(f"  … '{rest}' 재조회")
            graph.merge(asyncio.run(_scan_values(args, [rest])).graph)
            from .core.resolve import EntityResolver, correlate_owners
            EntityResolver().correlate(graph); correlate_owners(graph)
            print("  " + _summary_line(graph))
        elif cmd == "report":
            open(rest or "artes_report.html", "w", encoding="utf-8").write(
                render_html(build_profile(graph, args.inputs)))
            print(f"  리포트: {rest or 'artes_report.html'}")
        elif cmd == "graph":
            export(graph, rest or "artes_graph.html")
            print(f"  그래프: {rest or 'artes_graph.html'}")
        else:
            print("  ? 명령: ask/pivot/expand/report/graph/quit")
    return 0


def _summary_line(graph):
    s = graph.stats()
    return (f"현재: 엔티티 {s['entities']}(확실 {s['confirmed']}/불확실 {s['unconfirmed']})"
            f" · 연결 {s['edges']}")


def _finish_investigate(graph, args):
    if getattr(args, "report", None):
        from .core.report import build_profile, render_html
        open(args.report, "w", encoding="utf-8").write(
            render_html(build_profile(graph, args.inputs)))
        print(f"  리포트: {args.report}")
    if getattr(args, "web", None):
        from .viewer.web import export
        export(graph, args.web); print(f"  그래프: {args.web}")
    if getattr(args, "out", None):
        open(args.out, "w", encoding="utf-8").write(graph.to_json())
    if getattr(args, "case", None):
        from .core.casedb import CaseDB
        CaseDB().merge(args.case, graph); print(f"  케이스 저장: {args.case}")


# ---------- 명령: workflow ----------
def cmd_workflow(args) -> int:
    from .core.workflow import WorkflowStore
    st = WorkflowStore()
    if args.wf_cmd == "list" or not args.wf_cmd:
        for name in st.list():
            wf = st.get(name)
            print(f"  {name}: {wf.description} (깊이 {wf.depth}, 실행 {wf.runs}회, "
                  f"평균 {wf.avg_entities()} 엔티티)")
        return 0
    if args.wf_cmd == "run":
        wf = st.get(args.name)
        if not wf:
            print(f"워크플로우 없음: {args.name}", file=sys.stderr); return 2
        if not _acknowledged(args.yes, args.mock):
            print("동의 필요(--yes).", file=sys.stderr); return 2
        args.depth, args.max_queries = wf.depth, wf.max_queries
        args.max_seconds, args.darkweb = wf.max_seconds, wf.darkweb
        print(f"[{wf.name}] {wf.description}\n")
        eng = asyncio.run(_scan_to_graph(args))
        from .core.types import detect
        st.record_run(wf.name, [detect(x).value for x in args.inputs],
                      eng.graph.stats()["entities"])
        if args.out:
            open(args.out, "w", encoding="utf-8").write(eng.graph.to_json())
        return 0
    return 2


# ---------- 명령: dork ----------
def cmd_dork(args) -> int:
    from .core import dorking
    from .core.types import detect
    for t in args.inputs:
        print(f"# {t}")
        for d in dorking.generate_dorks(t, detect(t).value, engines=args.engines):
            print(f"  [{d['engine']}] {d['query']}\n    {d['url']}")
    return 0


# ---------- 명령: export ----------
def cmd_export(args) -> int:
    from .core.export import FORMATS
    if args.load:
        graph = Graph.load_json(open(args.load, encoding="utf-8").read())
    else:
        if not args.inputs or not _acknowledged(args.yes, args.mock):
            print("조각 입력+동의(--yes) 또는 --load 필요.", file=sys.stderr); return 2
        graph = asyncio.run(_scan_to_graph(args, quiet=True)).graph
    text = FORMATS[args.format](graph)
    out = args.out or f"artes_export.{args.format if args.format!='csv' else 'csv'}"
    open(out, "w", encoding="utf-8").write(text)
    print(f"내보내기({args.format}): {out}")
    return 0


# ---------- 명령: monitor ----------
def cmd_monitor(args) -> int:
    from .core.monitor import diff, render_diff
    old = Graph.load_json(open(args.old, encoding="utf-8").read())
    if args.new:
        new = Graph.load_json(open(args.new, encoding="utf-8").read())
    else:
        if not args.inputs or not _acknowledged(args.yes, args.mock):
            print("새 그래프(new.json) 또는 조각+동의 필요.", file=sys.stderr); return 2
        new = asyncio.run(_scan_to_graph(args, quiet=True)).graph
    d = diff(old, new)
    print(render_diff(d))
    if args.out:
        import json as _j
        open(args.out, "w", encoding="utf-8").write(_j.dumps(d, ensure_ascii=False, indent=2))
    return 0


# ---------- 명령: demo ----------
def cmd_demo(args) -> int:
    from .core.demo import build_demo_graph
    from .core.resolve import EntityResolver, correlate_owners
    from .core.report import build_profile, render_html
    from .viewer.web import export
    g = build_demo_graph()
    added = EntityResolver().correlate(g)
    added += correlate_owners(g)
    print(f"데모 그래프 — 엔티티 {g.stats()['entities']}, 동일인/운영자 연결 {len(added)}건")
    for e in added:
        c = "확실" if e.certainty.value == "confirmed" else f"불확실 {e.confidence}"
        print(f"  · {e.relation}: {e.src.split(':',1)[-1]} ~ {e.dst.split(':',1)[-1]} [{c}]")
    rep = args.report or "artes_demo_report.html"
    web = args.web or "artes_demo_graph.html"
    open(rep, "w", encoding="utf-8").write(render_html(build_profile(g, ["김지완", "jiwan.kim@example.com"])))
    export(g, web)
    print(f"리포트: {rep}\n그래프: {web}")
    if args.out:
        open(args.out, "w", encoding="utf-8").write(g.to_json())
    return 0


# ---------- 명령: typo ----------
def cmd_typo(args) -> int:
    import socket
    from .core.typosquat import generate_variants
    for dom in args.inputs:
        variants = generate_variants(dom, max_variants=args.max)
        print(f"# {dom} — 변형 {len(variants)}개" + (" (등록 확인)" if args.check else ""))
        for v in variants:
            reg = ""
            if args.check:
                try:
                    socket.gethostbyname(v); reg = "  [등록됨·사칭의심]"
                except Exception:
                    reg = ""
            print(f"  {v}{reg}")
    return 0


# ---------- 명령: case ----------
def cmd_case(args) -> int:
    from .core.casedb import CaseDB
    from .core.monitor import render_diff
    db = CaseDB()
    if args.case_cmd == "list" or not args.case_cmd:
        for c in db.list_cases():
            print(f"  {c['name']}: 엔티티 {c['entities']}")
        return 0
    if args.case_cmd == "load":
        g = db.load(args.name)
        if not g:
            print("케이스 없음", file=sys.stderr); return 2
        out = args.out or f"{args.name}.json"
        open(out, "w", encoding="utf-8").write(g.to_json())
        print(f"{args.name} → {out} (엔티티 {g.stats()['entities']})")
        return 0
    if args.case_cmd == "diff":
        d = db.diff_latest(args.name)
        print(render_diff(d) if d else "스냅샷 부족")
        return 0
    if args.case_cmd == "save":
        args.name = args.nameinputs[0]
        args.inputs = args.nameinputs[1:]
        if not args.inputs:
            print("케이스명 뒤에 조각이 필요합니다.", file=sys.stderr); return 2
        if not _acknowledged(args.yes, args.mock):
            print("동의 필요(--yes).", file=sys.stderr); return 2
        graph = asyncio.run(_scan_to_graph(args, quiet=True)).graph
        db.merge(args.name, graph)
        print(f"케이스 '{args.name}' 저장/병합 — 총 엔티티 {db.load(args.name).stats()['entities']}")
        return 0
    return 2


# ---------- 명령: eval ----------
def cmd_eval(args) -> int:
    from .evaluation import sweep, calibrate_lr
    print("동일인 해소 정밀도/재현율(합성 라벨):")
    for r in sweep(n_people=args.people):
        print(f"  임계 {r['threshold']}: 정밀도 {r['precision']} 재현율 {r['recall']} F1 {r['f1']}")
    print("\n신호 LR 교정:")
    print(" ", calibrate_lr(n_people=args.people * 2))
    return 0


# ---------- 명령: docmeta ----------
def cmd_docmeta(args) -> int:
    from .core.docmeta import extract
    for f in args.files:
        meta = extract(f)
        print(f"# {f}")
        if not meta:
            print("  (메타데이터 없음/미지원)")
        for k, v in meta.items():
            print(f"  {k}: {v}")
    return 0


# ---------- 명령: view ----------
def cmd_view(args) -> int:
    graph = Graph.load_json(open(args.file, encoding="utf-8").read())
    out = args.web or (os.path.splitext(args.file)[0] + ".html")
    from .viewer.web import export
    export(graph, out)
    print(f"웹 그래프: {out} (Chrome에서 열기)")
    return 0


# ---------- 파서 ----------
def _add_scan_flags(p):
    p.add_argument("--depth", type=int, default=1)
    p.add_argument("--concurrency", type=int, default=128)
    p.add_argument("--json", action="store_true")
    p.add_argument("--mock", action="store_true", help="오프라인 데모")
    p.add_argument("--include-mock", action="store_true")
    p.add_argument("--darkweb", action="store_true", help="다크웹 축 활성(Tor 필요)")
    p.add_argument("--interpret", action="store_true", help="AI 해석층 실행")
    p.add_argument("--no-ai", action="store_true", help="해석 시 AI 미사용(사실만)")
    p.add_argument("--web", metavar="FILE", help="웹 그래프 HTML 출력")
    p.add_argument("--report", metavar="FILE", help="프로파일 카드 HTML 리포트")
    p.add_argument("--card", metavar="FILE", help="프로파일 JSON 저장")
    p.add_argument("--verify", action="store_true", help="동일인 주장 적대적 자기검증(AI)")
    p.add_argument("--deep-verify", action="store_true",
                   help="동일인 주장 심층 판정(다표본+의미엔트로피+p(True)+융합)")
    p.add_argument("--cluster", action="store_true",
                   help="전역 동일인 군집화(전이 일관 — 실신원 묶음)")
    p.add_argument("--fs-fusion", action="store_true",
                   help="동일인 융합에 Fellegi–Sunter m/u 가중 사용(증분 10)")
    p.add_argument("--pivots", action="store_true",
                   help="심층 그래프 분석 — 다음 조사 대상 순위(시드 PPR+중심성)")
    p.add_argument("--out", metavar="FILE", help="그래프 JSON 저장")
    p.add_argument("--max-queries", type=int, default=2000, help="예산: 조회 상한")
    p.add_argument("--max-seconds", type=float, default=180.0, help="예산: 시간 상한")
    p.add_argument("--no-cache", action="store_true")
    p.add_argument("--yes", action="store_true", help="용도 동의(비대화형)")


def _add_scan_opts(p):
    p.add_argument("inputs", nargs="*", help="이름·전화·이메일·아이디·도메인·IP")
    _add_scan_flags(p)


def build_parser():
    p = argparse.ArgumentParser(prog="artes", description="통합 OSINT 오케스트레이터")
    sub = p.add_subparsers(dest="cmd")

    s = sub.add_parser("scan", help="정보 조각으로 조회")
    _add_scan_opts(s); s.set_defaults(func=cmd_scan)

    a = sub.add_parser("ask", help="수집 데이터에 자연어 질문")
    a.add_argument("query", nargs="+", help="질문 그리고 조각들 (첫 토큰=질문)")
    a.add_argument("--load", metavar="FILE", help="저장된 그래프 JSON")
    a.add_argument("--rag", action="store_true", help="벡터 RAG 검색 근거로 답")
    _add_scan_flags(a); a.set_defaults(func=cmd_ask)

    ai = sub.add_parser("ai", help="터미널 AI(대화·스웜·벤치·모델)")
    aisub = ai.add_subparsers(dest="ai_cmd")
    aisub.add_parser("chat", help="대화")
    sw = aisub.add_parser("swarm", help="지휘자-일꾼 병렬 코딩")
    sw.add_argument("task"); sw.add_argument("--workers", type=int, default=8)
    co = aisub.add_parser("code", help="실행검증 코딩 에이전트(edit-run-test-fix)")
    co.add_argument("task"); co.add_argument("--tests", default="", help="assert 테스트")
    co.add_argument("--n", type=int, default=1, help="best-of-N 후보 수")
    aisub.add_parser("bench", help="3B/7B 벤치")
    aisub.add_parser("cache", help="AI 응답 캐시 통계")
    aisub.add_parser("models", help="역할별 모델(판정·코더·대화) + 원격·온디바이스 티어")
    sv = aisub.add_parser("serve", help="역할 모델 서버 기동(판정·코더·대화)")
    sv.add_argument("role", choices=["judge", "coder", "chat"])
    sv.add_argument("--name", help="특정 티어 지정(기본 RAM 자동추천)")
    rm = aisub.add_parser("remote", help="원격 큰 두뇌(GLM 등) 상태·테스트")
    rm.add_argument("--test", action="store_true", help="원격 연결 실제 호출 테스트")
    aisub.add_parser("providers", help="API 제공처 비교(무료 토큰량·가입 주소)")
    ky = aisub.add_parser("key", help="API 키 자동 인식(수천 종)+저장 — 붙여넣기만")
    ky.add_argument("key", help="아무 제공처의 API 키")
    ky.add_argument("--no-save", action="store_true", help="인식만 하고 저장 안 함")
    ky.add_argument("--test", action="store_true", help="실제 연결 호출로 확인")
    ca = aisub.add_parser("catalog", help="제공처 모델 카탈로그(/models, OpenRouter 400+)")
    ca.add_argument("provider", nargs="?", help="제공처명(openrouter/groq/…)")
    ca.add_argument("--all", action="store_true", help="전 제공처 합집합 집계+캐시(수천 모델)")
    fd = aisub.add_parser("find", help="모델 통합 검색(HF GGUF 10만+ · 원격 카탈로그)")
    fd.add_argument("query", help="검색어(예: qwen coder, llama 8b, dolphin)")
    fd.add_argument("--no-hf", action="store_true", help="HF 검색 생략(원격 캐시만)")
    rv = aisub.add_parser("resolve", help="모델 실행처 판별(로컬 GGUF? 어느 제공처?)")
    rv.add_argument("model", help="모델 id(예: Qwen/Qwen3-4B-Instruct-2507-GGUF)")
    aisub.add_parser("scale", help="모델 지원 규모(10만+ 근거)")
    pl = aisub.add_parser("pull-info", help="임의 HF GGUF repo 받기 안내(URL·파일·경로)")
    pl.add_argument("repo", help="HF repo(예: bartowski/Dolphin3.0-Llama3.1-8B-GGUF)")
    pl.add_argument("--file", help="특정 GGUF 파일(미지정 시 목록서 추천)")
    st = aisub.add_parser("setup", help="API 키 발급 안내 + 직접 입력(배포용)")
    st.add_argument("--provider", help="특정 제공자만")
    dp = aisub.add_parser("dolphin", help="크롬북 개인용 완전 무검열 Dolphin(로컬)")
    dp.add_argument("--name", help="Dolphin 티어(기본 3B)")
    qz = aisub.add_parser("quantize", help="우리 도메인 imatrix 양자화 계획 생성")
    qz.add_argument("model", help="원본 GGUF 경로")
    qz.add_argument("--out", default="model-osint.gguf")
    qz.add_argument("--quant", default="IQ2_M", help="IQ1_M·IQ2_M·Q4_K_M 등")
    mo = aisub.add_parser("model", help="모델 상태"); mo.add_argument("name", nargs="?")
    ai.set_defaults(func=cmd_ai)

    v = sub.add_parser("view", help="저장 그래프 → 웹 뷰어")
    v.add_argument("file"); v.add_argument("--web", metavar="FILE")
    v.set_defaults(func=cmd_view)

    r = sub.add_parser("report", help="프로파일 카드 리포트")
    _add_scan_opts(r)
    r.add_argument("--load", metavar="FILE", help="저장된 그래프 JSON")
    r.set_defaults(func=cmd_report)

    inv = sub.add_parser("investigate", help="수사(대화형/자동피벗/AI지휘)")
    _add_scan_opts(inv)
    inv.add_argument("--auto", action="store_true", help="자동 피벗 수사")
    inv.add_argument("--agent", action="store_true", help="AI 지휘 자동 수사")
    inv.add_argument("--max-steps", type=int, default=3, help="피벗/에이전트 라운드")
    inv.add_argument("--case", metavar="NAME", help="케이스로 저장")
    inv.set_defaults(func=cmd_investigate)

    ca = sub.add_parser("case", help="지속 케이스(save/load/list/diff)")
    casub = ca.add_subparsers(dest="case_cmd")
    casub.add_parser("list")
    cs = casub.add_parser("save"); cs.add_argument("nameinputs", nargs="+",
        help="케이스명 그리고 조각들 (첫 토큰=케이스명)"); _add_scan_flags(cs)
    cl = casub.add_parser("load"); cl.add_argument("name"); cl.add_argument("--out")
    cd = casub.add_parser("diff"); cd.add_argument("name")
    ca.set_defaults(func=cmd_case)

    ev = sub.add_parser("eval", help="동일인 해소 평가·교정")
    ev.add_argument("--people", type=int, default=8)
    ev.set_defaults(func=cmd_eval)

    wf = sub.add_parser("workflow", help="조사 워크플로우(list/run)")
    wfsub = wf.add_subparsers(dest="wf_cmd")
    wfsub.add_parser("list", help="목록")
    wr = wfsub.add_parser("run", help="실행"); wr.add_argument("name")
    _add_scan_opts(wr)
    wf.set_defaults(func=cmd_workflow)

    dk = sub.add_parser("dork", help="검색 dork 생성")
    dk.add_argument("inputs", nargs="+")
    dk.add_argument("--engines", nargs="+",
                    default=["google", "bing", "duckduckgo", "yandex"])
    dk.set_defaults(func=cmd_dork)

    ex = sub.add_parser("export", help="GraphML/CSV/STIX 내보내기")
    _add_scan_opts(ex)
    ex.add_argument("--format", choices=["graphml", "csv", "stix"], default="graphml")
    ex.add_argument("--load", metavar="FILE", help="저장된 그래프 JSON")
    ex.set_defaults(func=cmd_export)

    mo = sub.add_parser("monitor", help="그래프 변화 비교")
    mo.add_argument("old"); mo.add_argument("new", nargs="?")
    _add_scan_flags(mo)
    mo.add_argument("inputs", nargs="*")
    mo.set_defaults(func=cmd_monitor)

    dm = sub.add_parser("docmeta", help="문서 메타데이터 추출(PDF/Office)")
    dm.add_argument("files", nargs="+")
    dm.set_defaults(func=cmd_docmeta)

    dem = sub.add_parser("demo", help="오프라인 쇼케이스(전 신호 실증)")
    dem.add_argument("--report", metavar="FILE"); dem.add_argument("--web", metavar="FILE")
    dem.add_argument("--out", metavar="FILE")
    dem.set_defaults(func=cmd_demo)

    kp = sub.add_parser("keys", help="선택적 API 키 상태(값은 안 보임)")
    kp.set_defaults(func=cmd_keys)
    ck = sub.add_parser("cookie", help="벽 안쪽 SNS 심층조회용 본인 세션 쿠키 저장/상태")
    ck.add_argument("site", nargs="?", help="예: instagram, naver, tiktok, twitter")
    ck.add_argument("value", nargs="?", help="쿠키 값(예: sessionid=...) — 생략하면 안내만")
    ck.set_defaults(func=cmd_cookie)
    sb = sub.add_parser("search-bench",
                        help="검색엔진 200라운드 병렬 벤치마크 → 효과적 엔진 자동 선별·저장")
    sb.add_argument("--rounds", type=int, default=150, help="최대 라운드(인스턴스×쿼리)")
    sb.add_argument("--top", type=int, default=12, help="저장할 상위 인스턴스 수")
    sb.set_defaults(func=cmd_search_bench)
    ty = sub.add_parser("typo", help="오타·유사 도메인 생성(사칭 탐지)")
    ty.add_argument("inputs", nargs="+")
    ty.add_argument("--check", action="store_true", help="DNS 등록 확인")
    ty.add_argument("--max", type=int, default=60)
    ty.set_defaults(func=cmd_typo)
    return p


def _try_uvloop() -> None:
    """uvloop 있으면 이벤트루프 교체(고동시성 asyncio 2x+, 무료). 없으면 무시."""
    try:
        import uvloop
        uvloop.install()
    except Exception:
        pass


def main(argv=None) -> int:
    _try_uvloop()
    argv = list(sys.argv[1:] if argv is None else argv)
    # 기본 명령 = scan (첫 토큰이 명령이 아니면 scan으로).
    if argv and argv[0] not in KNOWN and argv[0] not in ("-h", "--help"):
        argv = ["scan"] + argv
    args = build_parser().parse_args(argv)
    if not getattr(args, "cmd", None):
        build_parser().print_help()
        return 0
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
