"""AI 신뢰도 교정 — 작은 로컬 모델의 '확실/불확실/기권'을 통계적으로 신뢰 가능하게.

연구 종합(2024~2026):
- 이질 신뢰신호를 산술평균하면 강신호가 약신호로 끌려간다(AUROC 0.71→0.52) → 로지스틱 융합.
- 의미 엔트로피(Nature 2024): 표본을 '의미'로 군집해 엔트로피 → 작화(confabulation) 탐지.
  토큰 확률이 높아도 표본들이 의미상 갈리면 불확실. (여기선 자기판정/정규화 군집으로.)
- 분할 컨포멀 예측: 소량 교정셋으로 기권율에 **통계적 보장**(오류율 ≤ α). 손튜닝 임계 대체.
- p(True) 자기평가(Kadavath): 자기 답을 True/False로 채점한 확률 — logprob과 다른 오류모드.
- GenRM: '단계적으로 검증' 후 Yes 토큰 확률을 점수로. 작은 검증자가 큰 판정자를 이김.
- 평가: ECE(교정), AUROC(변별). 둘 다 필요.

전부 순수 파이썬(로짓/다표본만 필요), StubBackend로 결정적 단위검증 가능.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field


# ---------------- 의미 엔트로피 ----------------
def _norm_answer(s: str) -> str:
    return " ".join((s or "").strip().lower().split())


def semantic_clusters(samples: list[str], equiv=None) -> list[list[int]]:
    """표본을 의미 등가로 군집. equiv(a,b)->bool 없으면 정규화 문자열 일치로 폴백.

    반환: 각 군집의 표본 인덱스 리스트.
    """
    reps: list[int] = []
    clusters: list[list[int]] = []
    for i, s in enumerate(samples):
        placed = False
        for ci, rep in enumerate(reps):
            same = (equiv(samples[rep], s) if equiv
                    else _norm_answer(samples[rep]) == _norm_answer(s))
            if same:
                clusters[ci].append(i)
                placed = True
                break
        if not placed:
            reps.append(i)
            clusters.append([i])
    return clusters


def semantic_entropy(samples: list[str], equiv=None) -> float:
    """이산 의미 엔트로피(0~1 정규화). 군집 크기 히스토그램의 정규화 섀넌 엔트로피.

    0=모든 표본 같은 의미(확신), 1=전부 제각각(작화 신호).
    """
    if not samples:
        return 1.0
    clusters = semantic_clusters(samples, equiv)
    n = len(samples)
    H = 0.0
    for c in clusters:
        p = len(c) / n
        H -= p * math.log(p)
    Hmax = math.log(n) if n > 1 else 1.0
    return round(H / Hmax, 4) if Hmax > 0 else 0.0


def agreement_rate(samples: list[str], equiv=None) -> float:
    """최빈 의미 군집의 비율(0~1). 자기일관성 '불확실' 신호로만 쓴다(투표 아님)."""
    if not samples:
        return 0.0
    clusters = semantic_clusters(samples, equiv)
    return round(max(len(c) for c in clusters) / len(samples), 4)


# ---------------- 분할 컨포멀 예측(기권 보장) ----------------
def conformal_threshold(cal_scores: list[float], alpha: float = 0.1) -> float:
    """비적합점수(클수록 오답 가능성↑)의 교정셋에서 (1-α) 컨포멀 분위수 q̂.

    테스트 점수 ≤ q̂ 이면 '확실', 아니면 기권 → 비기권 답의 오류율 ≤ α (교환가능성 가정).
    """
    xs = sorted(cal_scores)
    n = len(xs)
    if n == 0:
        return float("inf")
    rank = math.ceil((n + 1) * (1 - alpha))
    rank = min(max(rank, 1), n)
    return xs[rank - 1]


def conformal_decide(score: float, threshold: float) -> bool:
    """비적합점수가 임계 이하이면 발화(확실), 아니면 기권."""
    return score <= threshold


# ---------------- ECE / AUROC(교정·변별 평가) ----------------
def ece(confidences: list[float], correct: list[int], n_bins: int = 10) -> float:
    """Expected Calibration Error. 신뢰도와 실제 정답률의 절대차 가중평균."""
    if not confidences:
        return 0.0
    N = len(confidences)
    total = 0.0
    for b in range(n_bins):
        lo, hi = b / n_bins, (b + 1) / n_bins
        idx = [i for i, c in enumerate(confidences)
               if (c > lo or (b == 0 and c >= 0)) and c <= hi]
        if not idx:
            continue
        acc = sum(correct[i] for i in idx) / len(idx)
        conf = sum(confidences[i] for i in idx) / len(idx)
        total += (len(idx) / N) * abs(acc - conf)
    return round(total, 4)


def auroc(scores: list[float], labels: list[int]) -> float:
    """AUROC — 점수가 양성(1)을 음성(0) 위로 매기는가. Mann–Whitney U 기반, 동점 0.5."""
    pos = [s for s, y in zip(scores, labels) if y == 1]
    neg = [s for s, y in zip(scores, labels) if y == 0]
    if not pos or not neg:
        return 0.5
    wins = 0.0
    for p in pos:
        for q in neg:
            if p > q:
                wins += 1
            elif p == q:
                wins += 0.5
    return round(wins / (len(pos) * len(neg)), 4)


# ---------------- 로지스틱 신호 융합(산술평균 대체) ----------------
@dataclass
class LogisticFuser:
    """신뢰신호 벡터 → 보정확률. p=σ(w·x+b). 순수 경사하강 적합.

    적합 전(가중치 없음)에는 사용 가능한 신호의 '평균'으로 폴백(하위호환).
    적합 후에는 신뢰 낮은 신호(예: 3B의 서술확률)를 데이터가 알아서 낮게 준다.
    """
    weights: list[float] = field(default_factory=list)
    bias: float = 0.0
    fitted: bool = False

    def fit(self, X: list[list[float]], y: list[int], lr: float = 0.1,
            epochs: int = 3000, l2: float = 1e-3) -> "LogisticFuser":
        if not X:
            return self
        k = len(X[0])
        w = [0.0] * k
        b = 0.0
        n = len(X)
        for _ in range(epochs):
            gw = [0.0] * k
            gb = 0.0
            for xi, yi in zip(X, y):
                z = b + sum(w[j] * xi[j] for j in range(k))
                p = 1.0 / (1.0 + math.exp(-z))
                err = p - yi
                for j in range(k):
                    gw[j] += err * xi[j]
                gb += err
            for j in range(k):
                w[j] -= lr * (gw[j] / n + l2 * w[j])
            b -= lr * (gb / n)
        self.weights, self.bias, self.fitted = w, b, True
        return self

    def predict(self, x: list[float]) -> float:
        if not self.fitted or len(self.weights) != len(x):
            vals = [v for v in x if v is not None]
            return sum(vals) / len(vals) if vals else 0.0
        z = self.bias + sum(self.weights[j] * x[j] for j in range(len(x)))
        return 1.0 / (1.0 + math.exp(-z))

    def to_dict(self) -> dict:
        return {"weights": [round(w, 5) for w in self.weights],
                "bias": round(self.bias, 5), "fitted": self.fitted}

    @classmethod
    def from_dict(cls, d: dict) -> "LogisticFuser":
        return cls(weights=d.get("weights", []), bias=d.get("bias", 0.0),
                   fitted=d.get("fitted", False))


# ---------------- 모델 신뢰신호(runtime 사용) ----------------
def p_true(runtime, question: str, answer: str, context: str,
           samples: list[str] | None = None) -> float:
    """Kadavath p(True) — 모델이 자기 답을 True/False로 채점한 확률.

    표본(samples)을 '브레인스토밍'으로 함께 보이면 교정이 개선된다(원논문). logprob과
    다른 오류모드라 융합 특징으로 강하다. StubBackend 응답은 'true'/'false' 포함으로 판정.
    """
    brainstorm = ""
    if samples:
        brainstorm = "가능한 답들:\n" + "\n".join(f"- {s[:80]}" for s in samples[:5]) + "\n\n"
    prompt = (
        f"{brainstorm}[근거]\n{context}\n[질문] {question}\n[제안 답] {answer}\n"
        "이 제안 답이 근거에 비추어 참인가? True 또는 False로만 답하라.\n[판정] ")
    out, lp = runtime.generate_conf("p_true", prompt, max_tokens=6, temperature=0.0)
    low = (out or "").strip().lower()
    if "true" in low or "참" in low:
        # logprob이 있으면 신뢰도로 반영(없으면 0.8 기본).
        return round(min(1.0, math.exp(lp)) if lp is not None else 0.8, 4)
    if "false" in low or "거짓" in low:
        return round(max(0.0, 1 - (math.exp(lp) if lp is not None else 0.8)), 4)
    return 0.5


def genrm_pyes(runtime, claim: str, context: str, k: int = 8) -> float:
    """GenRM — '단계적으로 검증' 후 Yes 비율. K표본의 yes/no 다수결 확률(p_yes).

    각 표본은 문법강제 {reasoning, verdict:yes|no}. p_yes=(#yes)/K = 보정된 증거 강도.
    """
    from .grammar import parse_json_lenient
    schema = {
        "type": "object",
        "properties": {
            "reasoning": {"type": "string"},
            "verdict": {"type": "string", "enum": ["yes", "no"]},
        },
        "required": ["reasoning", "verdict"],
        "additionalProperties": False,
    }
    yes = 0
    for _ in range(k):
        raw = runtime.generate(
            "genrm",
            ("아래 근거로 주장을 단계적으로 검증하라. 지지되면 verdict=yes, 아니면 no.\n"
             f"[근거]\n{context}\n[주장] {claim}\n[JSON] "),
            max_tokens=160, temperature=0.7, json_schema=schema)
        obj = parse_json_lenient(raw) or {}
        if str(obj.get("verdict", "")).lower() == "yes":
            yes += 1
    return round(yes / k, 4) if k else 0.0
