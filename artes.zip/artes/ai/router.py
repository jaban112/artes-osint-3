"""적응형 라우터 — 가장 싼 방법/모델로 맞히기(증분 14).

원칙(FrugalGPT·적응 컴퓨트): 3B 싼 패스를 먼저 돌리고, 신뢰가 낮을 때만 비싼 경로
(다표본 판정·8B 티어)로 승격한다. 쉬운 입력은 1패스, 어려운 입력만 N패스.

- estimate_difficulty: 프롬프트만으로 난이도 추정(길이·엔티티수·복잡 키워드). 추론 0.
- confidence: 1패스 logprob→확률(변별 신호).
- route_judge: 싼 judge → 확실+고신뢰면 채택, 애매하면 judge_calibrated, 여전히 낮고
  big_runtime 있으면 8B 승격(캐스케이드).
- esc_vote: 조기종료 자기일관성(창 합의 시 표본 중단).
- adaptive_generate: 쉬우면 1패스, 어려우면 다표본.

전부 순수 파이썬 + 기존 verify 재사용. StubBackend로 검증.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

_HARD_KW = ("동일인", "왜", "비교", "관계", "연결", "추론", "언제", "누가", "어떻게",
            "compare", "relationship", "why", "infer", "same person")
_ENT = re.compile(r"[\w.\-]+@[\w.\-]+|\+?\d[\d\s\-]{6,}|https?://|[a-z0-9\-]+\.[a-z]{2,}")


@dataclass
class RoutePlan:
    tier: str                     # 'cheap' | 'calibrated' | 'big'
    n_samples: int
    reason: str


def estimate_difficulty(text: str) -> float:
    """프롬프트만으로 난이도 0~1(추론 0). 길이·엔티티수·복잡 키워드."""
    t = text or ""
    length = min(1.0, len(t) / 1200.0)
    ents = min(1.0, len(_ENT.findall(t)) / 8.0)
    kw = 1.0 if any(k in t.lower() for k in _HARD_KW) else 0.0
    return round(0.4 * length + 0.3 * ents + 0.3 * kw, 3)


def confidence(mean_logprob: float | None) -> float:
    """평균 logprob → 기하평균 토큰확률(신뢰 프록시). None이면 중립 0.5."""
    if mean_logprob is None:
        return 0.5
    import math
    try:
        return math.exp(mean_logprob)
    except OverflowError:
        return 0.0


def prefilter(text: str, hard_threshold: float = 0.6) -> RoutePlan:
    """모델 호출 전 난이도로 초기 경로. 쉬운 것은 cheap, 어려운 것은 calibrated 준비."""
    d = estimate_difficulty(text)
    if d >= hard_threshold:
        return RoutePlan("calibrated", n_samples=5, reason=f"난이도 {d}≥{hard_threshold}")
    return RoutePlan("cheap", n_samples=1, reason=f"난이도 {d}")


def route_judge(runtime, question: str, context: str, big_runtime=None,
                accept: float = 0.75, defer: float = 0.4) -> dict:
    """검증자 캐스케이드: 싼 judge → (애매)judge_calibrated → (여전히 낮고 8B)big.

    반환 {"verdict","confidence","tier","signals"}.
    """
    from . import verify as V
    plan = prefilter(question + " " + context[:200])
    if plan.tier == "cheap":
        j = V.judge(runtime, question, context)          # 싼 1차
        conf = j.confidence
        if j.verdict == "확실" and conf >= accept:
            return {"verdict": j.verdict, "confidence": conf, "tier": "cheap",
                    "signals": j.signals}
        if conf <= defer and big_runtime is not None:
            jb = V.judge_calibrated(big_runtime, question, context, n_samples=3)
            return {"verdict": jb.verdict, "confidence": jb.confidence, "tier": "big",
                    "signals": jb.signals}
    # 애매하거나 처음부터 어려움 → 교정 판정.
    jc = V.judge_calibrated(runtime, question, context, n_samples=plan.n_samples)
    if jc.verdict != "확실" and jc.confidence <= defer and big_runtime is not None:
        jb = V.judge_calibrated(big_runtime, question, context, n_samples=3)
        return {"verdict": jb.verdict, "confidence": jb.confidence, "tier": "big",
                "signals": jb.signals}
    return {"verdict": jc.verdict, "confidence": jc.confidence, "tier": "calibrated",
            "signals": jc.signals}


def esc_vote(sample_fn, key_fn=None, window: int = 5, max_samples: int = 15):
    """조기종료 자기일관성 — 한 창(window)이 만장일치면 멈추고 투표(적응 컴퓨트).

    반환 (대표답, 표본수, 다수표).
    """
    key_fn = key_fn or (lambda x: x)
    from collections import defaultdict
    samples = []
    tally: dict = defaultdict(list)
    while len(samples) < max_samples:
        window_keys = []
        for _ in range(window):
            if len(samples) >= max_samples:
                break
            s = sample_fn()
            samples.append(s)
            k = key_fn(s)
            tally[k].append(s)
            window_keys.append(k)
        if window_keys and len(set(window_keys)) == 1:   # 창 만장일치 → 중단
            break
    best = max(tally.items(), key=lambda kv: len(kv[1]))
    return best[1][0], len(samples), len(best[1])


def adaptive_generate(runtime, purpose: str, prompt: str, max_tokens: int = 256,
                      hard_threshold: float = 0.6, n_hard: int = 3, **kw):
    """쉬우면 1패스, 어려우면 다표본+자기일관성. (텍스트, 표본수) 반환."""
    d = estimate_difficulty(prompt)
    if d < hard_threshold:
        return runtime.generate(purpose, prompt, max_tokens=max_tokens,
                                temperature=0.2, **kw), 1
    def sample():
        return runtime.generate(purpose, prompt, max_tokens=max_tokens,
                                temperature=0.7, **kw).strip()
    ans, n, _ = esc_vote(sample, window=3, max_samples=n_hard)
    return ans, n
