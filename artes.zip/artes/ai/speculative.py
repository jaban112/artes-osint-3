"""투기적 디코딩 — 6권 축 1. 출력 불변 가속.

작은 초안 모델 q가 여러 토큰을 앞서 뽑고 큰 검증기 p가 병렬 검증만 한다.
- 그리디 규칙: 출력이 검증기 단독과 **비트 동일**(정리 A1 — 자반 R4 일반형).
- 표본 규칙: 출력 분포가 검증기 p와 **정확히 동일**(정리 A2, min(p,q)+(p−q)₊=p).
이득(호출 감소)은 수락률의 함수, 정확성은 수락률과 무관 — 이것이 무손실의 정의.

여기 함수들은 그 불변을 코드로 확인 가능하게 하고(단위검증), 런타임은 llama.cpp의
draft 모델(-md)로 실제 가속을 설정한다(설정은 backend/runtime).
"""
from __future__ import annotations

import random
from typing import Callable, Sequence


def greedy_speculative(prefix: list[int], draft_fn: Callable[[list[int]], int],
                       verifier_argmax_fn: Callable[[list[int]], int],
                       k: int, steps: int) -> tuple[list[int], int]:
    """그리디 투기. (출력, 검증기 호출 수). 출력은 검증기 단독 그리디와 비트 동일해야."""
    out = list(prefix)
    verifier_calls = 0
    while len(out) - len(prefix) < steps:
        # 초안이 k개 제안
        drafts = []
        cur = list(out)
        for _ in range(k):
            t = draft_fn(cur); drafts.append(t); cur.append(t)
        # 검증기 1회 병렬 채점(여기선 위치별 argmax를 호출로 모사)
        verifier_calls += 1
        accepted = 0
        for i, dt in enumerate(drafts):
            v = verifier_argmax_fn(out)
            if dt == v:
                out.append(v); accepted += 1
                if len(out) - len(prefix) >= steps:
                    break
            else:
                out.append(v)          # 첫 불일치: 검증기 토큰 놓고 종료
                break
        else:
            continue
        if accepted < len(drafts):
            continue
    return out[:len(prefix) + steps], verifier_calls


def greedy_direct(prefix: list[int], verifier_argmax_fn: Callable[[list[int]], int],
                  steps: int) -> list[int]:
    out = list(prefix)
    for _ in range(steps):
        out.append(verifier_argmax_fn(out))
    return out


def residual(p: Sequence[float], q: Sequence[float]) -> list[float]:
    """잔차 분포 (p−q)₊ / ‖(p−q)₊‖₁."""
    pos = [max(0.0, pi - qi) for pi, qi in zip(p, q)]
    s = sum(pos)
    return [x / s for x in pos] if s > 0 else [0.0] * len(p)


def speculative_sample(p: Sequence[float], q: Sequence[float], rng: random.Random) -> int:
    """표본 규칙: 초안 x~q 를 min(1,p/q)로 수락, 거부 시 잔차에서 재표본. 출력~p."""
    x = _sample(q, rng)
    if rng.random() < min(1.0, (p[x] / q[x]) if q[x] > 0 else 1.0):
        return x
    r = residual(p, q)
    return _sample(r, rng)


def _sample(dist: Sequence[float], rng: random.Random) -> int:
    u = rng.random(); c = 0.0
    for i, pi in enumerate(dist):
        c += pi
        if u <= c:
            return i
    return len(dist) - 1


def identity_residual_holds(p: Sequence[float], q: Sequence[float], tol=1e-12) -> bool:
    """min(p,q)+(p−q)₊ = p 를 성분별로 확인(정리 A2 핵심 항등식)."""
    return all(abs(min(pi, qi) + max(0.0, pi - qi) - pi) < tol for pi, qi in zip(p, q))
