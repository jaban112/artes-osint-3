"""역할별 다중 llama-server 관리 — 판정·코더·대화를 각기 다른 서버로(증분 15).

한 VM에서 특화 모델 여러 개를 동시에 띄우고 역할로 라우팅한다. 6권 서빙 정책을 각
서버에 적용(투기 디코딩·KV 정책·MoE 오프로드). 모델·바이너리 없으면 우아하게 폴백
(공유 Runtime.auto). 여기(컨테이너)는 모델 없어 폴백만 — 로직은 단위검증.
"""
from __future__ import annotations

import os
import time
import urllib.request
from dataclasses import dataclass, field

from .models import (model_spec, recommend, server_flags, ROLE_MODELS,
                     REMOTE_PROVIDERS, remote_model)
from .runtime import Runtime, find_llama_binary
from .backend import LlamaServerBackend, OpenAICompatBackend, AnthropicBackend

# 역할별 기본 포트(충돌 방지).
ROLE_PORTS = {"judge": 8080, "coder": 8081, "chat": 8082}
MODEL_DIR = os.path.expanduser("~/.artes/models")


def model_path(spec: dict) -> str:
    return os.path.join(MODEL_DIR, spec["file"]) if spec else ""


def draft_path(spec: dict) -> str | None:
    d = (spec or {}).get("draft")
    return os.path.join(MODEL_DIR, d["file"]) if d else None


@dataclass
class ModelManager:
    """역할→서버→Runtime. 필요 시 서버 기동, 실패 시 공유 폴백."""
    ram_gb: float | None = None
    ctx: int = 8192
    _servers: dict = field(default_factory=dict)     # role -> Popen
    _runtimes: dict = field(default_factory=dict)     # role -> Runtime
    _shared: Runtime | None = None

    def plan(self, role: str, name: str | None = None) -> dict | None:
        """역할에 쓸 모델 스펙(자동 추천 또는 지정). 존재 여부·경로 포함."""
        name = name or recommend(role, self.ram_gb)
        spec = model_spec(role, name)
        if not spec:
            return None
        mp = model_path(spec)
        spec = {**spec, "path": mp, "present": os.path.exists(mp),
                "draft_path": draft_path(spec), "port": ROLE_PORTS.get(role, 8080)}
        return spec

    def start_role(self, role: str, name: str | None = None,
                   wait: float = 180.0) -> bool:
        """역할 서버 기동. 바이너리·모델 있으면 True, 없으면 False(폴백)."""
        spec = self.plan(role, name)
        binary = find_llama_binary("llama-server")
        if not spec or not binary or not spec["present"]:
            return False
        dp = spec["draft_path"] if (spec["draft_path"] and
                                    os.path.exists(spec["draft_path"])) else None
        flags = server_flags(role, spec["path"], spec, ctx=self.ctx,
                             draft_path=dp, port=spec["port"])
        import subprocess
        proc = subprocess.Popen([binary] + flags, stdout=subprocess.DEVNULL,
                                stderr=subprocess.DEVNULL)
        self._servers[role] = proc
        url = f"http://127.0.0.1:{spec['port']}"
        deadline = time.time() + wait
        while time.time() < deadline:
            try:
                with urllib.request.urlopen(url + "/health", timeout=2) as r:
                    if r.status == 200:
                        self._runtimes[role] = Runtime(backend=LlamaServerBackend(url))
                        return True
            except Exception:
                time.sleep(1.0)
        return False

    def runtime_for(self, role: str) -> Runtime:
        """역할 Runtime 우선순위:
        1) 원격 큰 두뇌(GLM 등 API/원격 VM) — 크롬북에서 최강 AI를 쓰는 길.
        2) 전용 로컬 서버(이미 기동) 또는 떠 있는 역할 포트.
        3) 공유 폴백(auto).
        """
        if role in self._runtimes:
            return self._runtimes[role]
        remote = remote_backend_for(role)               # 1) 원격
        if remote is not None:
            rt = Runtime(backend=remote)
            self._runtimes[role] = rt
            return rt
        url = f"http://127.0.0.1:{ROLE_PORTS.get(role, 8080)}"  # 2) 로컬 서버
        srv = LlamaServerBackend(url)
        if srv.available():
            rt = Runtime(backend=srv)
            self._runtimes[role] = rt
            return rt
        if self._shared is None:                         # 3) 폴백
            self._shared = Runtime.auto()
        return self._shared

    def stop_all(self) -> None:
        for proc in self._servers.values():
            try:
                proc.terminate()
            except Exception:
                pass
        self._servers.clear(); self._runtimes.clear()


def backend_for_provider(provider: str, key: str | None, role: str = "chat",
                         free: bool = False, model: str | None = None):
    """제공처 이름 + 키 → 알맞은 백엔드(OpenAI 호환 또는 Anthropic 네이티브).

    증분 18: 커레이티드 5개 밖의 제공처(ALL_PROVIDERS 40+)도 이걸로 연결한다.
    - 모델: 명시 model > 제공처별 맵(PROVIDER_MODELS) > GLM 게이트웨이 추천 > 그 제공처 첫 모델.
    - anthropic(openai=False, native)만 AnthropicBackend, 나머지는 OpenAICompatBackend.
    키는 헤더에만, 로깅 안 함. 없으면 None.
    """
    from .providers import ALL_PROVIDERS
    from .models import PROVIDER_MODELS, remote_model as _rm
    p = ALL_PROVIDERS.get(provider) or (REMOTE_PROVIDERS.get(provider) and
        {"base_url": REMOTE_PROVIDERS[provider]["base_url"], "openai": True})
    if not p:
        return None
    base = p["base_url"]
    # 모델 결정.
    mdl = model
    if not mdl:
        if provider in PROVIDER_MODELS:
            mdl = PROVIDER_MODELS[provider].get(role, PROVIDER_MODELS[provider]["chat"])
        elif provider in ("openrouter", "zai", "zhipu"):    # GLM 게이트웨이/직결
            mdl = _rm(role, free_only=free, provider=provider)
        else:
            mdl = None                                       # 카탈로그에서 사용자가 고름
    if p.get("openai", True) is False and p.get("native") == "anthropic":
        return AnthropicBackend(base, api_key=key,
                                model=mdl or "claude-sonnet-4-5")
    return OpenAICompatBackend(base, api_key=key, model=mdl or "gpt-4o-mini")


def backend_from_key(key: str, role: str = "chat", model: str | None = None,
                     provider: str | None = None):
    """붙여넣은 API 키 하나로 백엔드 자동 구성(증분 18의 핵심).

    provider 미지정이면 키 접두사로 자동 판별(detect_provider). 애매하면 None.
    로컬(ollama 등)은 키 없이 base_url만으로 붙는다.
    """
    from .providers import detect_provider, ALL_PROVIDERS
    if not provider:
        det = detect_provider(key)
        if not det["provider"]:
            return None
        provider = det["provider"]
    if provider not in ALL_PROVIDERS and provider not in REMOTE_PROVIDERS:
        return None
    free = os.environ.get("ARTES_AI_FREE") == "1"
    return backend_for_provider(provider, key, role=role, free=free, model=model)


def remote_backend_for(role: str):
    """역할용 원격 백엔드. 설정 없으면 None.

    우선순위:
    1) 명시적 env: ARTES_<ROLE>_URL(+_KEY, _MODEL) — 원격 llama-server/VM/임의 API.
    2) ARTES_AI_PROVIDER 강제 지정(커레이티드 밖의 40+ 제공처 포함).
    3) 커레이티드 5개(openrouter/zai/cerebras/groq/gemini) priority 순 키 존재.
    4) (폴백) ALL_PROVIDERS 40+ 중 키 있는 첫 제공처 — 거의 모든 API 키 인식.
    ARTES_AI_FREE=1 이면 무료 모델. 키는 헤더에만, 로깅 안 함.
    """
    from ..core.keys import KEYS
    from .providers import ALL_PROVIDERS
    R = role.upper()
    url = os.environ.get(f"ARTES_{R}_URL")
    if url:
        return OpenAICompatBackend(
            url.rstrip("/"), api_key=os.environ.get(f"ARTES_{R}_KEY"),
            model=os.environ.get(f"ARTES_{R}_MODEL", remote_model(role)))
    free = os.environ.get("ARTES_AI_FREE") == "1"
    model_env = os.environ.get("ARTES_AI_MODEL")
    # 2) 사용자가 제공처 강제 지정.
    forced = os.environ.get("ARTES_AI_PROVIDER")
    if forced and (forced in ALL_PROVIDERS or forced in REMOTE_PROVIDERS):
        cfg = ALL_PROVIDERS.get(forced) or REMOTE_PROVIDERS[forced]
        key = KEYS.get(cfg.get("key", forced))
        is_local = str(cfg.get("base_url", "")).startswith("http://")   # ollama 등
        if key or is_local:
            return backend_for_provider(forced, key, role, free, model_env)
    # 3) 커레이티드 5개 priority 순.
    order = sorted(REMOTE_PROVIDERS.items(), key=lambda kv: kv[1].get("priority", 99))
    for prov, cfg in order:
        key = KEYS.get(cfg["key"])
        if key:
            return backend_for_provider(prov, key, role, free, model_env)
    # 4) 폴백 — ALL_PROVIDERS 전체에서 키 있는 첫 제공처(거의 모든 키 인식).
    for prov, cfg in ALL_PROVIDERS.items():
        if prov in REMOTE_PROVIDERS:
            continue
        key = KEYS.get(cfg.get("key", prov))
        if key:
            return backend_for_provider(prov, key, role, free, model_env)
    return None


def personal_runtime(name: str | None = None, wait: float = 120.0) -> Runtime:
    """크롬북 개인용 완전 무검열 Dolphin(로컬, 오프라인). OSINT와 완전 분리.

    이미 떠 있는 개인 포트(8083)가 있으면 붙고, 모델·바이너리 있으면 기동, 없으면 폴백.
    """
    from .models import personal_spec, PERSONAL_PORT
    url = f"http://127.0.0.1:{PERSONAL_PORT}"
    srv = LlamaServerBackend(url)
    if srv.available():
        return Runtime(backend=srv)
    spec = personal_spec(name)
    mp = os.path.join(MODEL_DIR, spec["file"])
    binary = find_llama_binary("llama-server")
    if binary and os.path.exists(mp):
        cmd = [binary, "-m", mp, "--port", str(PERSONAL_PORT), "--host", "127.0.0.1",
               "-c", "8192", "--mlock", "--flash-attn", "on"]
        import subprocess
        subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        deadline = time.time() + wait
        while time.time() < deadline:
            try:
                with urllib.request.urlopen(url + "/health", timeout=2) as r:
                    if r.status == 200:
                        return Runtime(backend=LlamaServerBackend(url))
            except Exception:
                time.sleep(1.0)
    return Runtime.auto(cache=False)          # 폴백(여긴 모델 없어 Stub)


# 프로세스 전역 매니저(CLI·모듈 공유).
MANAGER = ModelManager()


def role_runtime(role: str) -> Runtime:
    """역할 Runtime 얻기(전역 매니저). chat/coder/judge."""
    return MANAGER.runtime_for(role)
