"""ARTES 로컬 AI — 단일 llama.cpp 런타임 위의 세 용도.

용도1 내부 해석(interpret) · 용도2 질의응답(qa) · 용도3 터미널 대화(chat)+스웜(swarm).
전부 runtime.Runtime을 공유하고 호출이 감사된다. Ollama 의존 0.
"""
from .runtime import Runtime, MODELS, model_status
from .backend import StubBackend, LlamaServerBackend, LlamaCliBackend

__all__ = ["Runtime", "MODELS", "model_status", "StubBackend",
           "LlamaServerBackend", "LlamaCliBackend"]
