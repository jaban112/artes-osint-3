"""3B/7B 벤치 하네스 — 속도·간이 정확도 실측 보고.

이 컨테이너엔 모델이 없어 StubBackend라 수치가 참고용이다. 사용자 VM에서
실모델(3B, 7B)을 로드해 돌리면 실측 tok/s·정확도를 그대로 보고한다.
지어낸 수치는 없다 — 측정한 것만 인쇄한다.
"""
from __future__ import annotations

import time

_SPEED_PROMPT = ("다음 주제로 한 문단을 써라: 지역 도서관에서 보낸 조용한 오후. ")

# 결정적 정오답 프로브(형식·상식). 답 안에 기대 토큰이 있으면 통과.
_ACC = [
    ("2 더하기 2는 얼마인가? 숫자만.", ["4"]),
    ("대한민국의 수도는? 한 단어.", ["서울"]),
    ("JSON으로 {\"ok\": true} 를 그대로 출력하라.", ["ok", "true"]),
]


def speed_probe(runtime, n_predict: int = 128, repeats: int = 3) -> dict:
    times, outs = [], []
    for _ in range(repeats):
        t0 = time.perf_counter()
        out = runtime.generate("bench", _SPEED_PROMPT, max_tokens=n_predict,
                               temperature=0.0)
        times.append(time.perf_counter() - t0)
        outs.append(out)
    best = min(times)
    approx_tokens = max(1, len(outs[0]) // 4)      # 대략 4자/토큰(참고)
    return {"backend": runtime.backend.name,
            "n_predict": n_predict, "repeats": repeats,
            "best_sec": round(best, 3),
            "approx_tok_per_s": round(approx_tokens / best, 1) if best > 0 else None,
            "note": "stub(모델 없음) — 참고용" if runtime.is_stub else "실측"}


def accuracy_probe(runtime) -> dict:
    passed = 0
    details = []
    for q, expect in _ACC:
        ans = runtime.generate("bench-acc", q, max_tokens=40, temperature=0.0).lower()
        ok = all(e.lower() in ans for e in expect)
        passed += ok
        details.append({"q": q, "ok": ok})
    return {"passed": passed, "total": len(_ACC),
            "rate": round(passed / len(_ACC), 3), "details": details,
            "note": "stub" if runtime.is_stub else "실측"}


def run_all(runtime) -> dict:
    return {"speed": speed_probe(runtime), "accuracy": accuracy_probe(runtime)}
