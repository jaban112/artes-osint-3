"""문법 강제 디코딩 — 6권 축 3. 형식 위반을 확률로 줄이는 게 아니라 구조로 불가능하게.

두 부분:
1. DFA 마스크(정리 A4 검증용): 매 스텝 허용 문자만 남기고 마스크 → 어떤 로짓에서도
   출력이 문법에 수용된다(위반 확률 = 0, 구조적). 여기서 실제로 확인 가능.
2. GBNF/JSON 스키마 생성: llama.cpp 서버에 넘겨 실제 생성 출력을 문법에 강제한다
   → ARTES의 확실/불확실 라벨·엔티티 스키마·JSON 도구출력이 파싱 실패를 구조적으로 안 함.

아카이빙(2권)·Aho-Corasick(7권)의 접미사 오토마톤과 같은 결정적 전이 계열.
"""
from __future__ import annotations

import json
from typing import Callable


# ---------- 1. DFA 마스크(구조적 무결성 검증) ----------
class DFA:
    def __init__(self, transitions: dict, start, accept: set):
        self.trans = transitions          # {state: {char: state}}
        self.start = start
        self.accept = set(accept)

    def allowed(self, state) -> set:
        return set(self.trans.get(state, {}).keys())

    def step(self, state, ch):
        return self.trans.get(state, {}).get(ch)

    def accepts(self, s: str) -> bool:
        st = self.start
        for ch in s:
            st = self.step(st, ch)
            if st is None:
                return False
        return st in self.accept


def json_number_dfa() -> DFA:
    """정규식 -?(0|[1-9][0-9]*)(\\.[0-9]+)?([eE][+-]?[0-9]+)? 의 DFA(6권 A4 예시)."""
    d = "0123456789"
    nz = "123456789"
    t = {
        "S": {"-": "sign", "0": "int0", **{c: "int" for c in nz}},
        "sign": {"0": "int0", **{c: "int" for c in nz}},
        "int0": {".": "dot", "e": "exp", "E": "exp"},
        "int": {**{c: "int" for c in d}, ".": "dot", "e": "exp", "E": "exp"},
        "dot": {**{c: "frac" for c in d}},
        "frac": {**{c: "frac" for c in d}, "e": "exp", "E": "exp"},
        "exp": {"+": "esign", "-": "esign", **{c: "expd" for c in d}},
        "esign": {**{c: "expd" for c in d}},
        "expd": {**{c: "expd" for c in d}},
    }
    return DFA(t, "S", {"int0", "int", "frac", "expd"})


def generate_constrained(dfa: DFA, logit: Callable[[str, str], float], max_len: int = 40):
    """매 스텝 허용 문자만 후보로 두고 최고 로짓 선택. 종료는 수용 상태에서만.
    반환 문자열은 **항상** dfa.accepts()==True (구조적 무결성 — 정리 A4)."""
    st = dfa.start
    out: list[str] = []
    for step in range(max_len):
        allowed = dfa.allowed(st)
        if not allowed:
            break
        if st in dfa.accept and out and logit("".join(out), "<END>") > 0:
            break                               # 수용 상태에서만 종료
        cand = list(allowed)
        if step >= max_len - 6:                 # 상한 근처: 수용으로 가는 전이 선호
            acc = [c for c in allowed if dfa.step(st, c) in dfa.accept]
            cand = acc or cand
        best = max(cand, key=lambda c: logit("".join(out), c))
        st = dfa.step(st, best)
        out.append(best)
    # 종료 시 비수용이면 수용까지 최소 확장(번호 DFA는 항상 도달 가능).
    guard = 0
    while st not in dfa.accept and guard < 12:
        allowed = dfa.allowed(st)
        if not allowed:
            break
        acc = [c for c in allowed if dfa.step(st, c) in dfa.accept]
        c = (acc or list(allowed))[0]
        st = dfa.step(st, c)
        out.append(c)
        guard += 1
    return "".join(out)


# ---------- 2. GBNF / JSON 스키마(실제 생성 강제) ----------
def enum_grammar(options: list[str]) -> str:
    """GBNF: 루트가 주어진 문자열 중 하나만 되게."""
    alts = " | ".join('"' + o.replace('"', '\\"') + '"' for o in options)
    return f"root ::= {alts}"


def certainty_grammar() -> str:
    return enum_grammar(["확실", "불확실"])


def entity_schema() -> dict:
    """엔티티 추출용 JSON 스키마 — 서버에 json_schema로 넘긴다."""
    return {
        "type": "object",
        "properties": {
            "emails": {"type": "array", "items": {"type": "string"}},
            "usernames": {"type": "array", "items": {"type": "string"}},
            "phones": {"type": "array", "items": {"type": "string"}},
            "names": {"type": "array", "items": {"type": "string"}},
        },
        "required": ["emails", "usernames", "phones", "names"],
        "additionalProperties": False,
    }


def answer_schema() -> dict:
    return {
        "type": "object",
        "properties": {
            "answer": {"type": "string"},
            "certainty": {"type": "string", "enum": ["확실", "불확실", "확인 안 됨"]},
        },
        "required": ["answer", "certainty"],
        "additionalProperties": False,
    }


def verdict_schema() -> dict:
    """판정 스키마(증분 9 · 스키마 위생).

    연구 반영: 작은 모델은 (1) 자유서술 evidence를 **먼저** 쓰게 하고(스키마 안에서 먼저
    '생각'하게), (2) 범주 필드는 enum으로 불법값을 문법적으로 불가능하게, (3) 얕고 평평하게.
    - evidence(자유 문자열) → verdict(enum) → confidence(0~100) 순서(순서가 품질을 바꾼다).
    - 'insufficient_evidence'를 1급 값으로: 지어내기보다 기권을 허용(§ 확실/불확실 규율).
    """
    return {
        "type": "object",
        "properties": {
            "evidence": {"type": "string"},
            "verdict": {"type": "string",
                        "enum": ["확실", "불확실", "insufficient_evidence"]},
            "confidence": {"type": "integer", "minimum": 0, "maximum": 100},
        },
        "required": ["evidence", "verdict", "confidence"],
        "additionalProperties": False,
    }


def parse_json_lenient(text: str):
    """모델 출력에서 JSON 오브젝트를 견고하게 뽑는다(문법 강제면 항상 성공)."""
    text = text.strip()
    try:
        return json.loads(text)
    except Exception:
        pass
    a, b = text.find("{"), text.rfind("}")
    if a != -1 and b != -1 and b > a:
        try:
            return json.loads(text[a:b + 1])
        except Exception:
            return None
    return None
