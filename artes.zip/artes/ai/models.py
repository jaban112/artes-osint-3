"""역할별 모델 레지스트리 — 판정·코딩·대화를 각각 특화 모델로(증분 15).

3B 단일 모델의 한계를 넘어 역할을 세분화한다:
- judge  : OSINT 판정·해석 — 작고 빠른 무검열 모델(저지연, 대량 호출). 정확성은 뼈대가 보강.
- coder  : 코딩 — 현존 최강 오픈소스 코더(Qwen2.5-Coder 무검열/abliterated), FIM 지원.
- chat   : 범용 대화 — 초거대 모델을 양자화해 세계지식 극대화(무검열 abliterated/Dolphin).

전부 무검열(Dolphin/abliterated) GGUF. 크기 티어로 사용자 VM RAM에 맞춘다. 정직: 정확한
HF 파일명은 배포 시 재확인(양자화명은 표준). 여기(컨테이너)는 모델 없음 — 스펙만 관리.

6권 「추론의 가속」 서빙 정책(server_flags):
- 투기 디코딩(-md 드래프트): 출력 불변(무손실) → 전 역할에 켠다(정확성 무관, 속도만↑).
- KV 페이징(f16): 무손실 → 판정·코딩(정확 경로)은 이걸로 메모리 절약.
- KV 양자화(q8_0): 손실 → 대화(casual)만 허용, 판정·코딩엔 금지.
- 문법 강제: 무손실(품질) → 구조 출력에 자유 적용. flash-attn·물리코어 스레드는 전역.
- MoE 전문가 CPU 오프로드(--n-cpu-moe): 배치만 바뀜(무손실) → 거대 MoE를 작은 VRAM에.
"""
from __future__ import annotations

import os

# 역할별 모델 티어. draft = 투기 디코딩용 동일계열 소형(무손실 가속). min_ram_gb = 권장 여유.
ROLE_MODELS = {
    "judge": {
        "default": "dolphin3-qwen2.5-3b",
        "tiers": {
            "dolphin3-qwen2.5-0.5b": {"repo": "bartowski/Dolphin3.0-Qwen2.5-0.5B-GGUF",
                "file": "Dolphin3.0-Qwen2.5-0.5B-Q4_K_M.gguf", "approx_gb": 0.4,
                "min_ram_gb": 2, "moe": False, "draft": None},
            "dolphin3-qwen2.5-3b": {"repo": "bartowski/Dolphin3.0-Qwen2.5-3B-GGUF",
                "file": "Dolphin3.0-Qwen2.5-3B-Q4_K_M.gguf", "approx_gb": 2.0,
                "min_ram_gb": 6, "moe": False,
                "draft": {"repo": "bartowski/Dolphin3.0-Qwen2.5-0.5B-GGUF",
                          "file": "Dolphin3.0-Qwen2.5-0.5B-Q4_K_M.gguf"}},
            "dolphin3-llama3.1-8b": {"repo": "bartowski/Dolphin3.0-Llama3.1-8B-GGUF",
                "file": "Dolphin3.0-Llama3.1-8B-Q4_K_M.gguf", "approx_gb": 4.9,
                "min_ram_gb": 10, "moe": False, "draft": None},
        },
    },
    "coder": {
        # Qwen2.5-Coder 계열(Apache-2.0, FIM, 동일계열 드래프트). 무검열=abliterated.
        "default": "qwen2.5-coder-7b",
        "tiers": {
            "qwen2.5-coder-3b": {"repo": "bartowski/Qwen2.5-Coder-3B-Instruct-GGUF",
                "file": "Qwen2.5-Coder-3B-Instruct-Q4_K_M.gguf", "approx_gb": 2.1,
                "min_ram_gb": 6, "moe": False, "fim": True, "draft": None,
                "note": "3B는 Qwen Research(비상업). 상업용은 1.5B/7B(Apache)"},
            "qwen2.5-coder-7b": {"repo": "bartowski/Qwen2.5-Coder-7B-Instruct-GGUF",
                "file": "Qwen2.5-Coder-7B-Instruct-Q4_K_M.gguf", "approx_gb": 4.7,
                "min_ram_gb": 10, "moe": False, "fim": True,
                "draft": {"repo": "bartowski/Qwen2.5-Coder-0.5B-Instruct-GGUF",
                          "file": "Qwen2.5-Coder-0.5B-Instruct-Q4_K_M.gguf"}},
            "qwen2.5-coder-7b-uncensored": {
                "repo": "mradermacher/Qwen2.5-Coder-7B-Instruct-abliterated-i1-GGUF",
                "file": "Qwen2.5-Coder-7B-Instruct-abliterated.i1-Q4_K_M.gguf",
                "approx_gb": 4.7, "min_ram_gb": 10, "moe": False, "fim": False,
                "draft": {"repo": "bartowski/Qwen2.5-Coder-0.5B-Instruct-GGUF",
                          "file": "Qwen2.5-Coder-0.5B-Instruct-Q4_K_M.gguf"},
                "note": "무검열(abliterated). FIM은 base 모델 사용 권장"},
            "qwen2.5-coder-32b": {"repo": "bartowski/Qwen2.5-Coder-32B-Instruct-GGUF",
                "file": "Qwen2.5-Coder-32B-Instruct-Q4_K_M.gguf", "approx_gb": 19.9,
                "min_ram_gb": 26, "moe": False, "fim": True,
                "draft": {"repo": "bartowski/Qwen2.5-Coder-1.5B-Instruct-GGUF",
                          "file": "Qwen2.5-Coder-1.5B-Instruct-Q4_K_M.gguf"}},
            "qwen2.5-coder-32b-uncensored": {
                "repo": "bartowski/Qwen2.5-Coder-32B-Instruct-abliterated-GGUF",
                "file": "Qwen2.5-Coder-32B-Instruct-abliterated-Q4_K_M.gguf",
                "approx_gb": 19.9, "min_ram_gb": 26, "moe": False, "fim": False,
                "draft": {"repo": "bartowski/Qwen2.5-Coder-1.5B-Instruct-GGUF",
                          "file": "Qwen2.5-Coder-1.5B-Instruct-Q4_K_M.gguf"},
                "note": "현존 최강급 무검열 로컬 코더"},
            "qwen3-coder-30b-a3b": {"repo": "unsloth/Qwen3-Coder-30B-A3B-Instruct-GGUF",
                "file": "Qwen3-Coder-30B-A3B-Instruct-Q4_K_M.gguf", "approx_gb": 18.0,
                "min_ram_gb": 24, "moe": True, "fim": True, "draft": None,
                "note": "MoE 30B/3B활성 — CPU에서 빠름, 262K 컨텍스트"},
        },
    },
    "chat": {
        # 초거대 무검열 모델을 양자화 → 세계지식 극대화. RAM에 맞춰 티어 선택.
        "default": "llama3.3-70b-uncensored",
        "tiers": {
            "dolphin3-llama3.1-8b": {"repo": "bartowski/Dolphin3.0-Llama3.1-8B-GGUF",
                "file": "Dolphin3.0-Llama3.1-8B-Q4_K_M.gguf", "approx_gb": 4.9,
                "min_ram_gb": 10, "moe": False, "draft": None,
                "note": "저사양 폴백(무검열)"},
            "llama3.3-70b-uncensored": {
                "repo": "bartowski/Llama-3.3-70B-Instruct-abliterated-GGUF",
                "file": "Llama-3.3-70B-Instruct-abliterated-Q4_K_M.gguf", "approx_gb": 42.5,
                "min_ram_gb": 52, "moe": False,
                "draft": {"repo": "bartowski/Llama-3.2-1B-Instruct-GGUF",
                          "file": "Llama-3.2-1B-Instruct-Q4_K_M.gguf"},
                "note": "무검열 70B — 64GB VM 권장. IQ3_M(~32GB)/IQ2_M(~24GB)로 축소 가능"},
            "llama3.3-70b-uncensored-iq3": {
                "repo": "bartowski/Llama-3.3-70B-Instruct-abliterated-GGUF",
                "file": "Llama-3.3-70B-Instruct-abliterated-IQ3_M.gguf", "approx_gb": 31.9,
                "min_ram_gb": 40, "moe": False,
                "draft": {"repo": "bartowski/Llama-3.2-1B-Instruct-GGUF",
                          "file": "Llama-3.2-1B-Instruct-Q4_K_M.gguf"},
                "note": "70B를 IQ3로 — 32~40GB RAM VM"},
            "qwen2.5-72b-uncensored": {
                "repo": "mradermacher/Qwen2.5-72B-Instruct-abliterated-i1-GGUF",
                "file": "Qwen2.5-72B-Instruct-abliterated.i1-Q4_K_M.gguf", "approx_gb": 47.0,
                "min_ram_gb": 56, "moe": False,
                "draft": {"repo": "bartowski/Qwen2.5-0.5B-Instruct-GGUF",
                          "file": "Qwen2.5-0.5B-Instruct-Q4_K_M.gguf"},
                "note": "무검열 72B — 다국어·지식 밀도 높음"},
            "dolphin-mixtral-8x22b": {
                "repo": "bartowski/dolphin-2.9.2-mixtral-8x22b-GGUF",
                "file": "dolphin-2.9.2-mixtral-8x22b-Q4_K_M.gguf", "approx_gb": 86.0,
                "min_ram_gb": 100, "moe": True, "draft": None,
                "note": "Dolphin MoE 141B/39B활성 — 128GB VM"},
            "qwen3-235b-uncensored": {
                "repo": "mradermacher/Qwen3-235B-A22B-abliterated-i1-GGUF",
                "file": "Qwen3-235B-A22B-abliterated.i1-IQ3_M.gguf", "approx_gb": 103.0,
                "min_ram_gb": 120, "moe": True,
                "draft": {"repo": "bartowski/Qwen3-0.6B-GGUF",
                          "file": "Qwen3-0.6B-Q4_K_M.gguf"},
                "note": "최대 지식 — 235B/22B활성 무검열 MoE. 128GB VM·IQ3. 이게 '미친 초거대'"},
        },
    },
}


# ───────── 원격 큰 두뇌(크롬북 등 약한 기기용) — OpenAI 호환 API ─────────
# 크롬북에서 GLM-5.3-Flash 같은 초거대 모델을 '쓰는' 진짜 길: 로컬 탑재가 아니라 API.
# 정직: "가장 토큰 많은 곳"과 "가장 좋은 GLM"은 서로 다르다. 둘 다 두고 사용자가 고른다.
# priority = 자동 선택 순서(낮을수록 우선). signup = 사용자가 직접 키 받는 주소.
# ARTES엔 어떤 키도 동봉하지 않는다 — 사용자가 발급해 넣어야 한다(배포 원칙).
REMOTE_PROVIDERS = {
    # GLM 특화(최고 품질). 무료 GLM-5.2도 여기.
    "openrouter": {"base_url": "https://openrouter.ai/api/v1", "key": "openrouter",
                   "priority": 1, "signup": "https://openrouter.ai/keys",
                   "free": "GLM-5.2 무료(z-ai/glm-5.2:free, $0). 최초 50req/day, $10 1회충전 후 1000req/day",
                   "note": "다중 제공자 게이트웨이 — GLM·Qwen·DeepSeek·Llama 전부. GLM 쓰려면 여기"},
    "zai": {"base_url": "https://api.z.ai/api/paas/v4", "key": "zai",
            "priority": 2, "signup": "https://z.ai/manage-apikey/apikey-list",
            "free": "GLM Coding Plan Lite $18/월(~400프롬프트/주, GLM 헤비유저 최고 가성비). API는 GLM-5.3 ~$1.4/1M",
            "note": "Z.ai 직결(GLM 공식). GLM-5.3/5.3-Flash 최신"},
    # 가장 토큰 많은 무료(품질은 오픈모델). OSINT 대량 처리에 좋음.
    "cerebras": {"base_url": "https://api.cerebras.ai/v1", "key": "cerebras",
                 "priority": 3, "signup": "https://cloud.cerebras.ai",
                 "free": "**1M 토큰/일 무료**(카드 불필요) — 가장 관대. 초고속",
                 "note": "가장 토큰 많은 무료. 모델=Qwen/Llama(오픈). 대량 OSINT에 이상적"},
    "groq": {"base_url": "https://api.groq.com/openai/v1", "key": "groq",
             "priority": 4, "signup": "https://console.groq.com/keys",
             "free": "100K 토큰/일 무료(카드 불필요). 초고속",
             "note": "초저지연. 모델=Llama/Qwen(오픈)"},
    "gemini": {"base_url": "https://generativelanguage.googleapis.com/v1beta/openai",
               "key": "gemini", "priority": 5,
               "signup": "https://aistudio.google.com/apikey",
               "free": "Gemini 무료 티어 관대(카드 불필요). 모델=Gemini(비오픈)",
               "note": "구글 Gemini OpenAI 호환 엔드포인트"},
}

# 역할별 원격 추천 모델 — 제공자별로 다름. best/free는 GLM 기준(openrouter/zai).
REMOTE_MODELS = {
    "chat": {"best": "z-ai/glm-5.3-flash", "free": "z-ai/glm-5.2:free",
             "alt": ["z-ai/glm-5.3", "z-ai/glm-4.6", "z-ai/glm-4.5-air"]},
    "coder": {"best": "z-ai/glm-4.6", "free": "z-ai/glm-5.2:free",
              "alt": ["qwen/qwen3-coder-30b-a3b-instruct", "z-ai/glm-4.7"]},
    "judge": {"best": "z-ai/glm-4.5-air", "free": "z-ai/glm-5.2:free",
              "alt": ["z-ai/glm-4-32b"]},
}

# 제공자별 역할 모델(비-GLM 제공자용). 없으면 REMOTE_MODELS 폴백.
PROVIDER_MODELS = {
    "cerebras": {"chat": "gpt-oss-120b", "coder": "gpt-oss-120b",
                 "judge": "gemma-4-31b"},
    "groq": {"chat": "openai/gpt-oss-120b", "coder": "openai/gpt-oss-120b",
             "judge": "openai/gpt-oss-20b"},
    "gemini": {"chat": "gemini-2.5-flash", "coder": "gemini-2.5-flash",
               "judge": "gemini-2.5-flash"},
}

# 온디바이스(크롬북 ~8GB) 최강 소형 — 로컬 오프라인·프라이빗용. 무검열 우선.
ONDEVICE_TIERS = {
    "qwen3-4b": {"repo": "unsloth/Qwen3-4B-Instruct-2507-GGUF",
        "file": "Qwen3-4B-Instruct-2507-Q4_K_M.gguf", "approx_gb": 2.5,
        "min_ram_gb": 6, "note": "크롬북 최강 소형(추론 강함)"},
    "gemma3-4b": {"repo": "unsloth/gemma-3-4b-it-GGUF",
        "file": "gemma-3-4b-it-Q4_K_M.gguf", "approx_gb": 2.6,
        "min_ram_gb": 6, "note": "지식 밀도 높은 소형"},
    "dolphin3-qwen2.5-3b": {"repo": "bartowski/Dolphin3.0-Qwen2.5-3B-GGUF",
        "file": "Dolphin3.0-Qwen2.5-3B-Q4_K_M.gguf", "approx_gb": 2.0,
        "min_ram_gb": 5, "note": "무검열 소형(OSINT 판정)"},
    "qwen3-1.7b": {"repo": "unsloth/Qwen3-1.7B-GGUF",
        "file": "Qwen3-1.7B-Q4_K_M.gguf", "approx_gb": 1.1,
        "min_ram_gb": 3, "note": "초저사양 크롬북"},
}


# 크롬북 개인용 — 완전 무검열 Dolphin(로컬, 오프라인). OSINT와 무관, 순수 개인 사용.
# 작은 것부터: 크롬북 RAM에 맞게. 전부 무검열(Dolphin).
PERSONAL_MODELS = {
    "dolphin3-qwen2.5-3b": {"repo": "bartowski/Dolphin3.0-Qwen2.5-3B-GGUF",
        "file": "Dolphin3.0-Qwen2.5-3B-Q4_K_M.gguf", "approx_gb": 2.0, "min_ram_gb": 5},
    "dolphin3-qwen2.5-1.5b": {"repo": "bartowski/Dolphin3.0-Qwen2.5-1.5B-GGUF",
        "file": "Dolphin3.0-Qwen2.5-1.5B-Q4_K_M.gguf", "approx_gb": 1.1, "min_ram_gb": 3},
    "dolphin3-llama3.1-8b": {"repo": "bartowski/Dolphin3.0-Llama3.1-8B-GGUF",
        "file": "Dolphin3.0-Llama3.1-8B-Q4_K_M.gguf", "approx_gb": 4.9, "min_ram_gb": 10},
}
PERSONAL_DEFAULT = "dolphin3-qwen2.5-3b"
PERSONAL_PORT = 8083


def remote_model(role: str, free_only: bool = False, provider: str | None = None) -> str:
    """역할 원격 모델. 비-GLM 제공자면 그 제공자의 모델을, 아니면 GLM best/free."""
    if provider and provider in PROVIDER_MODELS:
        return PROVIDER_MODELS[provider].get(role, PROVIDER_MODELS[provider]["chat"])
    r = REMOTE_MODELS.get(role, REMOTE_MODELS["chat"])
    return r["free"] if free_only else r["best"]


def personal_spec(name: str | None = None) -> dict:
    name = name or PERSONAL_DEFAULT
    m = PERSONAL_MODELS.get(name) or PERSONAL_MODELS[PERSONAL_DEFAULT]
    return {**m, "name": name}


def detect_ram_gb() -> float:
    """가용 시스템 RAM(GB) 추정. /proc/meminfo → psutil → 보수적 기본."""
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                if line.startswith("MemTotal:"):
                    return round(int(line.split()[1]) / 1024 / 1024, 1)
    except Exception:
        pass
    try:
        import psutil
        return round(psutil.virtual_memory().total / 1e9, 1)
    except Exception:
        return 8.0


def recommend(role: str, ram_gb: float | None = None) -> str:
    """역할·RAM으로 가장 큰(=지식 많은) 적합 티어 선택. 없으면 default."""
    spec = ROLE_MODELS.get(role)
    if not spec:
        return ""
    ram = ram_gb if ram_gb is not None else detect_ram_gb()
    fits = [(k, v) for k, v in spec["tiers"].items() if v.get("min_ram_gb", 999) <= ram]
    if not fits:
        # 아무것도 안 맞으면 가장 작은 것.
        return min(spec["tiers"].items(), key=lambda kv: kv[1].get("approx_gb", 999))[0]
    # 맞는 것 중 가장 큰 모델(지식 극대화). 대화 역할은 특히 큰 걸 선호.
    return max(fits, key=lambda kv: kv[1].get("approx_gb", 0))[0]


def model_spec(role: str, name: str | None = None) -> dict | None:
    spec = ROLE_MODELS.get(role)
    if not spec:
        return None
    name = name or spec["default"]
    m = spec["tiers"].get(name)
    return {**m, "name": name, "role": role} if m else None


def server_flags(role: str, model_path: str, spec: dict, ctx: int = 8192,
                 threads: int | None = None, draft_path: str | None = None,
                 port: int = 8080) -> list[str]:
    """6권 서빙 정책을 반영한 llama-server 인자 조립.

    - 전 역할: flash-attn, 물리코어 스레드, 캐시-재사용, mlock.
    - 투기 디코딩(무손실): 드래프트 있으면 -md(정확성 무관 가속).
    - KV 양자화(손실): chat 역할만 q8_0(장문 casual). judge/coder는 f16 페이징(무손실).
    - MoE: --n-cpu-moe로 전문가 CPU 오프로드(무손실 배치) → 작은 VRAM에 초거대.
    """
    if threads is None:
        threads = os.cpu_count() or 4
    cmd = ["-m", model_path, "--port", str(port), "--host", "127.0.0.1",
           "-c", str(ctx), "-t", str(threads), "--mlock", "--flash-attn", "on",
           "--cache-reuse", "256"]
    if draft_path:                                   # 투기 디코딩(무손실)
        cmd += ["-md", draft_path, "--draft-max", "16", "--draft-min", "4"]
    if spec.get("moe"):                              # MoE 전문가 오프로드
        cmd += ["--n-cpu-moe", "999", "-ngl", "99"]
    if role == "chat":                               # casual만 KV 양자화(손실 허용)
        cmd += ["--cache-type-k", "q8_0", "--cache-type-v", "q8_0"]
    # judge/coder는 KV f16(무손실 페이징) — 정확 경로 보호(6권 A3).
    return cmd
