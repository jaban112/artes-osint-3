"""문법 강제 구조화 추출 — 6권 §5 ARTES 적용.

자유 텍스트(프로필 bio·페이스트)에서 이메일·아이디·전화·이름을 뽑을 때,
JSON 스키마를 강제해 **파싱이 구조적으로 실패하지 않게** 한다(정리 A4).
추출 후에도 규율 유지: 추출값은 불확실로 시작하고, 실제 형식 검증(타입 판정)을
통과한 것만 엔티티로 승격한다(모델이 헛본 것 차단).
"""
from __future__ import annotations

from ..core.model import Entity, EntityType, Certainty, Evidence
from ..core.types import detect
from .grammar import entity_schema, parse_json_lenient


def extract_entities(runtime, text: str, source_hint: str = "AI추출") -> list[Entity]:
    prompt = ("아래 텍스트에서 이메일·아이디·전화·이름을 JSON으로만 추출하라. "
              "없으면 빈 배열. 지어내지 마라.\n\n[텍스트]\n" + text[:2000] + "\n[JSON] ")
    raw = runtime.generate("extract", prompt, max_tokens=300, temperature=0.0,
                           json_schema=entity_schema())
    data = parse_json_lenient(raw) or {}
    out: list[Entity] = []
    mapping = [("emails", EntityType.EMAIL), ("usernames", EntityType.USERNAME),
               ("phones", EntityType.PHONE), ("names", EntityType.NAME)]
    for key, etype in mapping:
        for v in (data.get(key) or []):
            v = str(v).strip()
            if not v:
                continue
            # 형식 검증: 판정 타입이 기대와 맞는 것만 승격(모델 헛본 것 차단).
            det = detect(v)
            if etype in (EntityType.EMAIL, EntityType.PHONE) and det is not etype:
                continue
            out.append(Entity(etype, v, Certainty.UNCONFIRMED, 0.5,
                              evidence=[Evidence(source_hint, "텍스트에서 AI 추출(형식 검증됨)")]))
    return out
