"""코딩 에이전트 — 실행 기반 edit-run-test-fix(증분 12).

핵심 원칙(연구): 작은 모델의 '자기 비평(vibes)'은 약하다. 신뢰 신호는 **실제 실행
피드백**(트레이스백·테스트 결과)이다. 그래서 판정은 결정적 도구(인터프리터·정적검사·
테스트)가 하고, 모델은 그 오류만 보고 고친다.

파이프라인:
 계획(시그니처 스텁) → 생성 → 정적검사(ast/py_compile/pyflakes) → 실행(샌드박스) →
 테스트 → 실패 시 실오류를 넣어 수복(최대 K회) → 실행합의 best-of-N 선택.

safe_exec: 격리 서브프로세스(python -I) + 타임아웃 + rlimit(CPU/메모리/파일) + 임시dir.
로컬 개발 도구이므로 프로세스 격리가 적정하다. 전부 순수 파이썬, StubBackend로 검증 가능.
"""
from __future__ import annotations

import ast
import os
import re
import subprocess
import sys
import tempfile
from dataclasses import dataclass, field


# ---------------- 코드 추출 ----------------
_FENCE = re.compile(r"```(?:python|py)?\s*\n(.*?)```", re.S)


def extract_code(text: str) -> str:
    """모델 출력에서 코드만. 펜스 있으면 첫 블록, 없으면 전체(트리밍)."""
    m = _FENCE.search(text or "")
    if m:
        return m.group(1).strip()
    return (text or "").strip()


# ---------------- 정적 검사(실행 전 값싼 게이트) ----------------
def static_check(code: str) -> list[str]:
    """ast 파싱 + py_compile + (있으면)pyflakes. 문제 목록(빈 리스트면 통과)."""
    issues: list[str] = []
    try:
        ast.parse(code)
    except SyntaxError as e:
        return [f"SyntaxError: {e.msg} (line {e.lineno})"]
    try:
        compile(code, "<gen>", "exec")
    except Exception as e:  # noqa
        issues.append(f"{type(e).__name__}: {e}")
    try:
        from pyflakes.api import check as _pf_check
        from pyflakes.reporter import Reporter
        import io
        out, err = io.StringIO(), io.StringIO()
        _pf_check(code, "<gen>", Reporter(out, err))
        for line in (out.getvalue() + err.getvalue()).splitlines():
            if line.strip():
                issues.append(line.strip())
    except Exception:
        pass                                  # pyflakes 없으면 건너뜀
    return issues


# ---------------- 안전 실행 ----------------
@dataclass
class ExecResult:
    ok: bool
    stdout: str = ""
    stderr: str = ""
    returncode: int = 0
    timed_out: bool = False

    @property
    def error_signature(self) -> str:
        """수복 진척 판정용 오류 지문(마지막 예외 줄)."""
        if self.ok:
            return ""
        lines = [l for l in self.stderr.strip().splitlines() if l.strip()]
        return lines[-1] if lines else f"rc={self.returncode}"


def _limit_resources(cpu_sec: int, mem_mb: int):
    def _apply():
        try:
            import resource
            resource.setrlimit(resource.RLIMIT_CPU, (cpu_sec, cpu_sec))
            b = mem_mb * 1024 * 1024
            resource.setrlimit(resource.RLIMIT_AS, (b, b))
            resource.setrlimit(resource.RLIMIT_FSIZE, (50 * 1024 * 1024,) * 2)
        except Exception:
            pass
    return _apply


def safe_exec(code: str, stdin: str = "", timeout: float = 10.0,
              mem_mb: int = 512, extra_files: dict | None = None) -> ExecResult:
    """격리 서브프로세스에서 파이썬 실행. python -I, 타임아웃, rlimit, 임시dir."""
    with tempfile.TemporaryDirectory() as td:
        for name, content in (extra_files or {}).items():
            with open(os.path.join(td, name), "w", encoding="utf-8") as f:
                f.write(content)
        path = os.path.join(td, "_gen.py")
        with open(path, "w", encoding="utf-8") as f:
            f.write(code)
        try:
            proc = subprocess.run(
                [sys.executable, "-I", "_gen.py"], cwd=td,
                input=stdin, capture_output=True, text=True, timeout=timeout,
                preexec_fn=_limit_resources(int(timeout) + 1, mem_mb)
                if os.name == "posix" else None)
            return ExecResult(ok=(proc.returncode == 0), stdout=proc.stdout,
                              stderr=proc.stderr, returncode=proc.returncode)
        except subprocess.TimeoutExpired as e:
            return ExecResult(ok=False, stdout=e.stdout or "", stderr="TimeoutExpired",
                              returncode=-1, timed_out=True)


def run_tests(code: str, tests: str, timeout: float = 10.0) -> ExecResult:
    """코드 + 테스트(assert 블록)를 한 모듈로 실행. 통과 시 ok=True."""
    combined = code + "\n\n# ---- tests ----\n" + tests + "\nprint('ALL_TESTS_PASSED')"
    res = safe_exec(combined, timeout=timeout)
    if res.ok and "ALL_TESTS_PASSED" not in res.stdout:
        res.ok = False
    return res


# ---------------- 계획(시그니처 스텁) ----------------
_PLAN_SCHEMA = {
    "type": "object",
    "properties": {
        "signatures": {"type": "array", "items": {"type": "string"}},
        "plan": {"type": "array", "items": {"type": "string"}},
    },
    "required": ["signatures", "plan"],
    "additionalProperties": False,
}


def plan_code(runtime, task: str) -> dict:
    """계획 단계 — 함수 시그니처(스텁)와 단계 목록을 먼저(자기계획)."""
    from .grammar import parse_json_lenient
    raw = runtime.generate(
        "coder-plan",
        ("아래 작업을 구현하기 위한 함수 시그니처(파이썬 def 한 줄들)와 단계 목록을 "
         f"JSON으로 내라.\n[작업] {task}\n[JSON] "),
        max_tokens=300, temperature=0.2, json_schema=_PLAN_SCHEMA)
    obj = parse_json_lenient(raw) or {}
    return {"signatures": obj.get("signatures", []) or [],
            "plan": obj.get("plan", []) or []}


# ---------------- 생성 + 수복 루프 ----------------
def generate_code(runtime, task: str, context: str = "", temperature: float = 0.2) -> str:
    prompt = (f"아래 작업을 파이썬으로 구현하라. 코드만 출력.\n[작업] {task}\n")
    if context:
        prompt += f"[참고]\n{context}\n"
    prompt += "[코드]\n"
    return extract_code(runtime.generate("coder-gen", prompt, max_tokens=600,
                                         temperature=temperature))


def repair_once(runtime, code: str, feedback: str) -> str:
    """실제 오류(feedback)를 넣어 코드를 고친다. 새로 짜지 말고 오류만 수정."""
    prompt = (
        "아래 코드가 오류를 냈다. 오류만 고쳐 전체 코드를 다시 내라. 코드만.\n"
        f"[코드]\n{code}\n[오류]\n{feedback}\n[수정된 코드]\n")
    return extract_code(runtime.generate("coder-repair", prompt, max_tokens=600,
                                         temperature=0.1))


@dataclass
class CodeResult:
    code: str
    passed: bool
    attempts: int
    log: list = field(default_factory=list)     # [{stage, ok, detail}]


def repair_loop(runtime, task: str, tests: str = "", max_attempts: int = 4,
                context: str = "") -> CodeResult:
    """생성 → 정적검사 → (테스트)실행 → 실패 시 실오류로 수복. 최대 K회.

    정지: 통과 / 상한 / 동일 오류 지문 반복(진척 없음).
    """
    code = generate_code(runtime, task, context)
    log = []
    last_sig = None
    for attempt in range(1, max_attempts + 1):
        issues = static_check(code)
        if issues:
            log.append({"stage": "static", "ok": False, "detail": issues[:3]})
            code = repair_once(runtime, code, "\n".join(issues[:5]))
            continue
        log.append({"stage": "static", "ok": True})
        if tests:
            res = run_tests(code, tests)
            if res.ok:
                log.append({"stage": "test", "ok": True})
                return CodeResult(code, True, attempt, log)
            sig = res.error_signature
            log.append({"stage": "test", "ok": False, "detail": sig})
            if sig == last_sig:                 # 진척 없음 → 중단
                break
            last_sig = sig
            fb = (res.stderr or res.stdout)[-800:]
            code = repair_once(runtime, code, fb)
        else:
            # 테스트 없으면 실행만 확인(임포트/런타임 오류 잡기).
            res = safe_exec(code)
            if res.ok:
                return CodeResult(code, True, attempt, log)
            code = repair_once(runtime, code, (res.stderr or "")[-800:])
    return CodeResult(code, False, max_attempts, log)


# ---------------- 테스트 생성 ----------------
def generate_tests(runtime, task: str) -> str:
    """작업에서 assert 기반 테스트를 먼저 생성(테스트 주도). 코드(assert)만."""
    prompt = (
        "아래 작업의 정답을 검증할 파이썬 assert 문 몇 개를 내라. import 포함 가능. "
        "assert 만, 설명 없이.\n"
        f"[작업] {task}\n[테스트]\n")
    return extract_code(runtime.generate("coder-tests", prompt, max_tokens=300,
                                         temperature=0.2))


# ---------------- best-of-N(실행 합의) ----------------
def best_of_n(runtime, task: str, tests: str = "", n: int = 5,
              max_attempts: int = 2) -> CodeResult:
    """N개 후보를 다양 온도로 생성·수복하고 실행 합의로 선택.

    테스트 있으면 통과하는 것 중 최소 시도, 없으면 실행 출력 시그니처 최빈(behavioral
    clustering — AlphaCode식)으로 대표 선택.
    """
    cands = []
    for i in range(n):
        temp = 0.1 + 0.15 * i                    # 다양성(수복보다 다양 표본이 낫다)
        r = repair_loop(runtime, task, tests, max_attempts=max_attempts)
        cands.append(r)
        if tests and r.passed and i >= 1:        # 충분히 통과하면 조기 종료
            pass
    passed = [c for c in cands if c.passed]
    if passed:
        return min(passed, key=lambda c: c.attempts)   # 가장 빨리 통과
    # 실패뿐: 실행 출력 최빈 클러스터 대표.
    sigs = {}
    for c in cands:
        res = safe_exec(c.code)
        key = (res.ok, (res.stdout or "").strip()[:200])
        sigs.setdefault(key, []).append(c)
    best_cluster = max(sigs.values(), key=len)
    rep = best_cluster[0]
    rep.log.append({"stage": "best_of_n", "clusters": len(sigs),
                    "cluster_size": len(best_cluster)})
    return rep
