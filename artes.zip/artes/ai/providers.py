"""대규모 API 제공처 레지스트리 + 키 자동 인식(증분 18).

목표: 아무 AI API 키나 붙여넣으면 어느 제공처인지 자동 판별하고, 그 엔드포인트로
연결한다. 현존 거의 모든 LLM 제공처를 인식한다. OpenRouter 하나만 해도 400+ 모델이라,
이 레지스트리 + OpenRouter 라우팅으로 사실상 수천 종의 AI를 커버한다.

- ALL_PROVIDERS: 제공처별 base_url(OpenAI 호환 /v1)·키 env·키 접두사·가입 URL·비고.
- detect_provider(key): 키 접두사로 제공처 판별(고유 접두사 우선, 애매하면 후보 반환).
- list_models(provider, key): 그 제공처의 모델 카탈로그(/models)를 가져온다(수백~수천).

정직: base_url·접두사는 대표값 — 제공처가 바꾸면 배포 시 재확인. 로컬(ollama/lmstudio)도 포함.
"""
from __future__ import annotations

import json
import re
import urllib.request

# name: {base_url, key(서비스명), prefixes[정규식], signup, openai(호환여부), native, note}
ALL_PROVIDERS = {
    # ── 게이트웨이(하나로 수백~수천 모델) ──
    "openrouter": {"base_url": "https://openrouter.ai/api/v1", "key": "openrouter",
        "prefixes": [r"^sk-or-v1-", r"^sk-or-"], "openai": True,
        "signup": "https://openrouter.ai/keys",
        "note": "400+ 모델 게이트웨이(GLM·GPT·Claude·Gemini·Llama·Qwen…). 이거 하나면 대부분 커버"},
    # ── 대형 상용 ──
    "openai": {"base_url": "https://api.openai.com/v1", "key": "openai",
        "prefixes": [r"^sk-proj-", r"^sk-svcacct-", r"^sk-admin-", r"^sk-[A-Za-z0-9]{20,}"],
        "openai": True, "signup": "https://platform.openai.com/api-keys", "note": "GPT 계열"},
    "anthropic": {"base_url": "https://api.anthropic.com/v1", "key": "anthropic",
        "prefixes": [r"^sk-ant-"], "openai": False, "native": "anthropic",
        "signup": "https://console.anthropic.com/settings/keys", "note": "Claude 계열(네이티브 /messages)"},
    "gemini": {"base_url": "https://generativelanguage.googleapis.com/v1beta/openai",
        "key": "gemini", "prefixes": [r"^AIza[0-9A-Za-z_\-]{20,}"], "openai": True,
        "signup": "https://aistudio.google.com/apikey", "note": "Google Gemini(OpenAI 호환 엔드포인트)"},
    "xai": {"base_url": "https://api.x.ai/v1", "key": "xai", "prefixes": [r"^xai-"],
        "openai": True, "signup": "https://console.x.ai", "note": "Grok 계열"},
    "mistral": {"base_url": "https://api.mistral.ai/v1", "key": "mistral",
        "prefixes": [], "openai": True, "signup": "https://console.mistral.ai/api-keys",
        "note": "Mistral·Codestral(고유 접두사 없음 — 명시 필요)"},
    "cohere": {"base_url": "https://api.cohere.ai/compatibility/v1", "key": "cohere",
        "prefixes": [], "openai": True, "signup": "https://dashboard.cohere.com/api-keys",
        "note": "Command 계열(OpenAI 호환 경로)"},
    # ── GLM(중국계) ──
    "zai": {"base_url": "https://api.z.ai/api/paas/v4", "key": "zai", "prefixes": [],
        "openai": True, "signup": "https://z.ai/manage-apikey/apikey-list", "note": "Z.ai GLM 공식"},
    "zhipu": {"base_url": "https://open.bigmodel.cn/api/paas/v4", "key": "zhipu",
        "prefixes": [], "openai": True, "signup": "https://open.bigmodel.cn", "note": "Zhipu GLM(중국 본토)"},
    "deepseek": {"base_url": "https://api.deepseek.com/v1", "key": "deepseek",
        "prefixes": [], "openai": True, "signup": "https://platform.deepseek.com/api_keys",
        "note": "DeepSeek(sk- 형식 — openai와 애매, 명시 권장)"},
    "moonshot": {"base_url": "https://api.moonshot.ai/v1", "key": "moonshot",
        "prefixes": [], "openai": True, "signup": "https://platform.moonshot.ai", "note": "Kimi 계열"},
    # ── 무료·초고속 추론 ──
    "cerebras": {"base_url": "https://api.cerebras.ai/v1", "key": "cerebras",
        "prefixes": [r"^csk-"], "openai": True, "signup": "https://cloud.cerebras.ai",
        "note": "1M토큰/일 무료·초고속(Qwen/Llama)"},
    "groq": {"base_url": "https://api.groq.com/openai/v1", "key": "groq",
        "prefixes": [r"^gsk_"], "openai": True, "signup": "https://console.groq.com/keys",
        "note": "초저지연 무료(Llama/Qwen)"},
    "sambanova": {"base_url": "https://api.sambanova.ai/v1", "key": "sambanova",
        "prefixes": [], "openai": True, "signup": "https://cloud.sambanova.ai", "note": "초고속(Llama)"},
    # ── 오픈모델 호스팅 ──
    "together": {"base_url": "https://api.together.xyz/v1", "key": "together",
        "prefixes": [r"^tgp_v1_"], "openai": True, "signup": "https://api.together.ai/settings/api-keys",
        "note": "오픈모델 대량 호스팅"},
    "fireworks": {"base_url": "https://api.fireworks.ai/inference/v1", "key": "fireworks",
        "prefixes": [r"^fw_"], "openai": True, "signup": "https://fireworks.ai/account/api-keys",
        "note": "오픈모델 고속"},
    "deepinfra": {"base_url": "https://api.deepinfra.com/v1/openai", "key": "deepinfra",
        "prefixes": [], "openai": True, "signup": "https://deepinfra.com/dash/api_keys", "note": "오픈모델 저가"},
    "novita": {"base_url": "https://api.novita.ai/v3/openai", "key": "novita",
        "prefixes": [r"^sk_"], "openai": True, "signup": "https://novita.ai/settings/key-management", "note": "오픈모델"},
    "hyperbolic": {"base_url": "https://api.hyperbolic.xyz/v1", "key": "hyperbolic",
        "prefixes": [r"^eyJ[A-Za-z0-9_\-]+\."], "openai": True, "signup": "https://app.hyperbolic.xyz/settings",
        "note": "오픈모델 저가(JWT 키)"},
    "nebius": {"base_url": "https://api.studio.nebius.ai/v1", "key": "nebius",
        "prefixes": [], "openai": True, "signup": "https://studio.nebius.ai", "note": "오픈모델"},
    "nvidia": {"base_url": "https://integrate.api.nvidia.com/v1", "key": "nvidia",
        "prefixes": [r"^nvapi-"], "openai": True, "signup": "https://build.nvidia.com", "note": "NIM(오픈모델 무료체험)"},
    "perplexity": {"base_url": "https://api.perplexity.ai", "key": "perplexity",
        "prefixes": [r"^pplx-"], "openai": True, "signup": "https://www.perplexity.ai/settings/api", "note": "Sonar(검색형)"},
    "ai21": {"base_url": "https://api.ai21.com/studio/v1", "key": "ai21", "prefixes": [],
        "openai": True, "signup": "https://studio.ai21.com/account/api-key", "note": "Jamba 계열"},
    "lambda": {"base_url": "https://api.lambdalabs.com/v1", "key": "lambda", "prefixes": [],
        "openai": True, "signup": "https://cloud.lambdalabs.com", "note": "오픈모델"},
    "baseten": {"base_url": "https://inference.baseten.co/v1", "key": "baseten", "prefixes": [],
        "openai": True, "signup": "https://app.baseten.co/settings/api_keys", "note": "오픈모델"},
    "github": {"base_url": "https://models.inference.ai.azure.com", "key": "github",
        "prefixes": [r"^ghp_", r"^github_pat_"], "openai": True,
        "signup": "https://github.com/settings/tokens", "note": "GitHub Models(무료 소량)"},
    "huggingface": {"base_url": "https://router.huggingface.co/v1", "key": "huggingface",
        "prefixes": [r"^hf_"], "openai": True, "signup": "https://huggingface.co/settings/tokens",
        "note": "HF Inference(오픈모델)"},
    "replicate": {"base_url": "https://api.replicate.com/v1", "key": "replicate",
        "prefixes": [r"^r8_"], "openai": False, "signup": "https://replicate.com/account/api-tokens",
        "note": "오픈모델(네이티브 API — OpenAI 비호환)"},
    # ── 로컬(키 불필요) ──
    "ollama": {"base_url": "http://localhost:11434/v1", "key": "ollama", "prefixes": [],
        "openai": True, "signup": "https://ollama.com", "note": "로컬 Ollama(키 불필요, base_url만)"},
    "lmstudio": {"base_url": "http://localhost:1234/v1", "key": "lmstudio", "prefixes": [],
        "openai": True, "signup": "https://lmstudio.ai", "note": "로컬 LM Studio(키 불필요)"},
    "localai": {"base_url": "http://localhost:8080/v1", "key": "localai", "prefixes": [],
        "openai": True, "signup": "https://localai.io", "note": "로컬 LocalAI/우리 llama-server"},
}

# 고유 접두사(비애매) — 단독 판별 가능. 나열 순서로 우선 매칭(더 긴 것 먼저).
_DISTINCT = [
    ("anthropic", r"^sk-ant-"), ("openrouter", r"^sk-or-"), ("groq", r"^gsk_"),
    ("cerebras", r"^csk-"), ("xai", r"^xai-"), ("perplexity", r"^pplx-"),
    ("fireworks", r"^fw_"), ("nvidia", r"^nvapi-"), ("replicate", r"^r8_"),
    ("huggingface", r"^hf_"), ("gemini", r"^AIza"), ("together", r"^tgp_v1_"),
    ("github", r"^ghp_|^github_pat_"), ("novita", r"^sk_"),
    ("hyperbolic", r"^eyJ[A-Za-z0-9_\-]+\."),
]


def detect_provider(key: str) -> dict:
    """키 문자열로 제공처 판별.

    반환 {"provider": name|None, "confident": bool, "candidates": [names]}.
    고유 접두사면 confident=True. 'sk-...'처럼 여러 제공처가 공유하면 후보 목록.
    """
    k = (key or "").strip()
    if not k:
        return {"provider": None, "confident": False, "candidates": []}
    for name, pat in _DISTINCT:
        if re.search(pat, k):
            return {"provider": name, "confident": True, "candidates": [name]}
    # sk- 공유(openai·deepseek·moonshot 등). openai 기본, 후보 제시.
    if re.match(r"^sk-[A-Za-z0-9]", k):
        return {"provider": "openai", "confident": False,
                "candidates": ["openai", "deepseek", "moonshot"]}
    # JWT/기타 애매.
    return {"provider": None, "confident": False,
            "candidates": ["mistral", "cohere", "zai", "deepinfra", "together",
                           "sambanova", "nebius", "ai21"]}


def provider_base(name: str) -> str | None:
    p = ALL_PROVIDERS.get(name)
    return p["base_url"] if p else None


def list_models(provider: str, api_key: str | None = None, timeout: float = 20.0) -> list:
    """제공처 모델 카탈로그(/models). OpenRouter는 400+ 반환. 실패 시 []."""
    p = ALL_PROVIDERS.get(provider)
    if not p:
        return []
    url = p["base_url"].rstrip("/") + "/models"
    headers = {"Content-Type": "application/json",
               "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) ARTES/1.0"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=timeout) as r:
            obj = json.loads(r.read().decode("utf-8"))
    except Exception:
        return []
    data = obj.get("data") if isinstance(obj, dict) else obj
    ids = []
    for m in (data or []):
        mid = m.get("id") if isinstance(m, dict) else str(m)
        if mid:
            ids.append(mid)
    return ids
