"""단일 로컬 AI 런타임 — 세 용도(해석·질의응답·터미널/스웜)가 공유.

- 모든 AI 호출은 여기를 거친다 → 호출 횟수·용도별 로깅(감사). 수집 파이프라인은
  이걸 절대 부르지 않는다(AI 0회 원칙의 반대편 집행).
- 백엔드 자동 선택: 살아있는 llama-server > llama-cli(모델 있음) > llama-cpp-python >
  StubBackend(모델 없음 — 이 컨테이너 기본). 무엇이 선택됐는지 보고한다.
- 서버 수명관리: 우리가 빌드한 llama-server를 띄우고(--parallel 슬롯), 끝나면 정리.
- 모델 부트스트랩: 사용자 VM에서 GGUF를 내려받는 스펙(여기선 경로만 확인).
"""
from __future__ import annotations

import os
import shutil
import subprocess
import threading
import time
import urllib.request
from dataclasses import dataclass, field
from typing import Any

from .backend import (LLMBackend, StubBackend, LlamaServerBackend,
                      LlamaCliBackend, LlamaCppPythonBackend)

# 추천 모델 — Dolphin 시리즈(무검열 오픈웨이트, 키·계정 불필요). 작은 것부터.
# Dolphin(cognitivecomputations)은 검열/거부 성향을 제거한 파인튠이라 OSINT 해석에서
# 불필요한 거부 없이 동작한다. GGUF는 bartowski 표준 양자화 네이밍.
# 주의: 정확한 repo/file은 배포 시점에 HF에서 재확인(양자화명은 표준을 따름).
MODELS = {
    "dolphin3-qwen2.5-3b": {"repo": "bartowski/Dolphin3.0-Qwen2.5-3B-GGUF",
                            "file": "Dolphin3.0-Qwen2.5-3B-Q4_K_M.gguf", "approx_gb": 2.0},
    "dolphin3-llama3.1-8b": {"repo": "bartowski/Dolphin3.0-Llama3.1-8B-GGUF",
                             "file": "Dolphin3.0-Llama3.1-8B-Q4_K_M.gguf", "approx_gb": 4.9},
    "dolphin3-qwen2.5-1.5b": {"repo": "bartowski/Dolphin3.0-Qwen2.5-1.5B-GGUF",
                              "file": "Dolphin3.0-Qwen2.5-1.5B-Q4_K_M.gguf", "approx_gb": 1.1},
    "dolphin3-qwen2.5-0.5b": {"repo": "bartowski/Dolphin3.0-Qwen2.5-0.5B-GGUF",
                              "file": "Dolphin3.0-Qwen2.5-0.5B-Q4_K_M.gguf", "approx_gb": 0.4},
    "dolphin-2.9.4-llama3.1-8b": {"repo": "bartowski/dolphin-2.9.4-llama3.1-8b-GGUF",
                                  "file": "dolphin-2.9.4-llama3.1-8b-Q4_K_M.gguf", "approx_gb": 4.9},
}

# 기본 모델(설치·부트스트랩·auto가 이걸 씀).
DEFAULT_MODEL = "dolphin3-qwen2.5-3b"


def find_llama_binary(name: str) -> str | None:
    for cand in (os.environ.get("ARTES_LLAMA_DIR", ""),
                 os.path.expanduser("~/.artes/llama.cpp/build/bin"),
                 "/root/llama.cpp/build/bin", "/usr/local/bin", "/usr/bin"):
        if cand and os.path.exists(os.path.join(cand, name)):
            return os.path.join(cand, name)
    return shutil.which(name)


@dataclass
class CallRecord:
    purpose: str
    prompt_chars: int
    out_chars: int
    elapsed: float


@dataclass
class Runtime:
    backend: LLMBackend
    calls: dict[str, int] = field(default_factory=dict)
    log: list[CallRecord] = field(default_factory=list)
    cache: object = None                       # ResponseCache(선택) — 반복 호출 생성 스킵
    slots: int = 4                             # 병렬 배치 상한(서버 슬롯 수)
    _server: subprocess.Popen | None = None
    _lock: threading.Lock = field(default_factory=threading.Lock)

    # ---- 팩토리 ----
    @classmethod
    def auto(cls, model_path: str | None = None, server_url: str | None = None,
             threads: int | None = None, cache: bool = True) -> "Runtime":
        rc = None
        if cache:
            try:
                from .cache import ResponseCache
                rc = ResponseCache(path=os.path.expanduser("~/.artes/ai_cache.json"))
            except Exception:
                rc = None
        # 1) 이미 떠 있는 서버
        srv = LlamaServerBackend(server_url or "http://127.0.0.1:8080")
        if srv.available():
            return cls(backend=srv, cache=rc)
        # 2) 모델 파일이 있으면 llama-cli
        model_path = model_path or os.environ.get("ARTES_MODEL")
        cli_bin = find_llama_binary("llama-cli")
        if model_path and os.path.exists(model_path) and cli_bin:
            return cls(backend=LlamaCliBackend(cli_bin, model_path, threads), cache=rc)
        # 3) llama-cpp-python
        if model_path and os.path.exists(model_path):
            try:
                return cls(backend=LlamaCppPythonBackend(model_path, threads=threads),
                           cache=rc)
            except Exception:
                pass
        # 4) 스텁(모델 없음)
        return cls(backend=StubBackend(), cache=rc)

    # ---- 핵심 ----
    def generate(self, purpose: str, prompt: str, max_tokens: int = 256,
                 temperature: float = 0.2, stop: list[str] | None = None,
                 grammar: str | None = None, json_schema: dict | None = None,
                 sampler: dict | None = None) -> str:
        params = {"max_tokens": max_tokens, "temperature": temperature,
                  "grammar": grammar, "json_schema": json_schema}
        if self.cache is not None:
            cached = self.cache.get(purpose, prompt, params)
            if cached is not None:
                with self._lock:
                    self.calls[purpose] = self.calls.get(purpose, 0) + 1
                    self.log.append(CallRecord(purpose, len(prompt), len(cached), 0.0))
                return cached
        t0 = time.perf_counter()
        out = self.backend.generate(prompt, max_tokens=max_tokens,
                                    temperature=temperature, stop=stop,
                                    grammar=grammar, json_schema=json_schema,
                                    sampler=sampler)
        if self.cache is not None and temperature <= 0.35:   # 결정적 계열만 캐시
            self.cache.put(purpose, prompt, params, out)
        with self._lock:
            self.calls[purpose] = self.calls.get(purpose, 0) + 1
            self.log.append(CallRecord(purpose, len(prompt), len(out),
                                       time.perf_counter() - t0))
        return out

    def generate_batch(self, purpose: str, prompts: list[str], max_tokens: int = 256,
                       temperature: float = 0.2, **kw) -> list[str]:
        """독립 프롬프트 N개를 슬롯 수만큼 병렬 생성(순차 for보다 처리량↑).

        연속 배칭 서버에서 동시 요청이 겹쳐 처리된다. CPU에선 슬롯 수(2~4)까지만 이득.
        """
        from concurrent.futures import ThreadPoolExecutor
        if not prompts:
            return []
        workers = max(1, min(self.slots, len(prompts)))
        results: list = [None] * len(prompts)
        with ThreadPoolExecutor(max_workers=workers) as ex:
            futs = {ex.submit(self.generate, purpose, p, max_tokens, temperature, **kw): i
                    for i, p in enumerate(prompts)}
            for fut in futs:
                results[futs[fut]] = fut.result()
        return results

    def generate_conf(self, purpose: str, prompt: str, max_tokens: int = 256,
                      temperature: float = 0.2, stop: list[str] | None = None,
                      grammar: str | None = None, json_schema: dict | None = None,
                      sampler: dict | None = None) -> tuple[str, float | None]:
        """(텍스트, 평균 토큰 logprob). 신뢰도 신호가 필요한 판정 경로용.

        logprob은 작은 로컬 모델의 zero-shot 신뢰도 신호로 가장 신뢰할 만하다
        (2026 연구) → verify.fuse_confidence()의 1차 입력.
        """
        t0 = time.perf_counter()
        out, lp = self.backend.generate_conf(prompt, max_tokens=max_tokens,
                                             temperature=temperature, stop=stop,
                                             grammar=grammar, json_schema=json_schema,
                                             sampler=sampler)
        with self._lock:
            self.calls[purpose] = self.calls.get(purpose, 0) + 1
            self.log.append(CallRecord(purpose, len(prompt), len(out),
                                       time.perf_counter() - t0))
        return out, lp

    @property
    def is_stub(self) -> bool:
        return self.backend.name == "stub"

    def total_calls(self) -> int:
        return sum(self.calls.values())

    def stats(self) -> dict[str, Any]:
        return {"backend": self.backend.name, "total_calls": self.total_calls(),
                "by_purpose": dict(self.calls),
                "avg_sec": round(sum(r.elapsed for r in self.log) / len(self.log), 3)
                if self.log else 0.0}

    # ---- 서버 수명관리(우리가 빌드한 llama-server) ----
    def start_server(self, model: str, port: int = 8080, parallel: int = 4,
                     ctx: int = 8192, threads: int | None = None,
                     draft_model: str | None = None, kv_quant: str | None = None,
                     mlock: bool = True, cache_reuse: int = 256,
                     flash_attn: bool = True, wait: float = 120.0) -> bool:
        """우리가 빌드한 llama-server 기동(CPU 최적화 반영).

        6권 정책:
        - 페이징(연속-슬롯 KV)은 무손실 — 서버 기본. 확실 판정 경로는 이 기본만 쓴다.
        - draft_model(-md): 투기 디코딩. 출력 불변(그리디 비트동일), 속도만 이득.
          (CPU에선 대역폭 경쟁으로 이득이 작거나 역효과일 수 있어 7~8B 타깃에서만 권장.)
        - kv_quant('q8_0'/'q4_0'): KV 양자화는 **손실**이다(6권 정리 A3-b). 확실 판정에
          쓰지 말 것 — '규모 파악' 등 비판정 경로 전용. 명시할 때만 켠다.

        2026 CPU 튜닝:
        - --mlock: 가중치 페이지 고정(스왑/축출 방지 — CPU 최대 병목은 메모리 대역폭).
        - --cache-reuse N: 접두 외 청크도 KV 시프트로 재사용(고정 시스템 프롬프트에 큰 이득).
        - -t: 물리 코어 수(하이퍼스레드 초과 지정은 생성 속도를 오히려 낮춤).
        """
        binary = find_llama_binary("llama-server")
        if not binary or not os.path.exists(model):
            return False
        if threads is None:
            try:
                threads = os.cpu_count() or None    # 배포 시 물리코어로 재조정 권장
            except Exception:
                threads = None
        cmd = [binary, "-m", model, "--port", str(port), "--host", "127.0.0.1",
               "--parallel", str(parallel), "-c", str(ctx)]
        if threads:
            cmd += ["-t", str(threads)]
        if mlock:
            cmd += ["--mlock"]
        if cache_reuse:
            cmd += ["--cache-reuse", str(cache_reuse)]
        if flash_attn:
            cmd += ["--flash-attn", "on"]
        if draft_model and os.path.exists(draft_model):
            cmd += ["-md", draft_model]            # 투기 디코딩(출력 불변)
        if kv_quant:                               # 손실 — 규모파악 전용
            cmd += ["--cache-type-k", kv_quant, "--cache-type-v", kv_quant]
        self._server = subprocess.Popen(cmd, stdout=subprocess.DEVNULL,
                                        stderr=subprocess.DEVNULL)
        url = f"http://127.0.0.1:{port}"
        deadline = time.time() + wait
        while time.time() < deadline:
            try:
                with urllib.request.urlopen(url + "/health", timeout=2) as r:
                    if r.status == 200:
                        self.backend = LlamaServerBackend(url)
                        return True
            except Exception:
                time.sleep(1.0)
        self.stop_server()
        return False

    def stop_server(self) -> None:
        if self._server:
            self._server.terminate()
            try:
                self._server.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self._server.kill()
            self._server = None


def model_status(name: str) -> dict:
    """모델 부트스트랩 상태(여기선 경로 확인만; 다운로드는 사용자 VM install.sh)."""
    spec = MODELS.get(name)
    if not spec:
        return {"known": False}
    local = os.path.join(os.path.expanduser("~/.artes/models"), spec["file"])
    return {"known": True, "repo": spec["repo"], "file": spec["file"],
            "approx_gb": spec["approx_gb"], "local_path": local,
            "present": os.path.exists(local)}
