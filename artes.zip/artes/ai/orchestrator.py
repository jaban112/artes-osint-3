"""병렬 오케스트레이션 — 지휘-일꾼 스웜의 심장(증분 12).

작은 모델은 조용히·자주 실패한다 → 검증·투표가 프론티어 모델보다 더 중요하다.

- run_dag: 의존성 있는 하위작업을 위상정렬 웨이브로 실행(각 웨이브 최대 병렬). Kahn.
- SlotSemaphore: 서버 --parallel 슬롯 수로 전 호출을 감싸 백프레셔(Little's Law).
  포화점 위 초과요청은 llama.cpp 내부 큐만 늘림 → 무의미. 하나의 세마포어로 통제.
- with_retry: 워커 실패 격리 + 지수백오프+지터. 한 일꾼 실패가 배치를 안 죽임.
- best_of_n_vote: 같은 작업 N 표본 → 투표/판정. adaptive_stop(Beta 규칙)로 조기 종료.
- reduce_tree: 많은 조각을 트리로 계층 병합(단일 리듀스 컨텍스트 초과 방지).
- rrf: 순위 출력 융합(점수 보정 불필요).

순수 파이썬 + ThreadPoolExecutor. 결정적 단위검증(워커 함수 주입).
"""
from __future__ import annotations

import random
import threading
import time
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field


class SlotSemaphore:
    """전 LLM 호출을 감싸는 전역 슬롯 제한(서버 병렬 슬롯 수)."""

    def __init__(self, slots: int):
        self._sem = threading.Semaphore(max(1, slots))
        self.slots = max(1, slots)
        self.peak = 0
        self._in = 0
        self._lock = threading.Lock()

    def __enter__(self):
        self._sem.acquire()
        with self._lock:
            self._in += 1
            self.peak = max(self.peak, self._in)
        return self

    def __exit__(self, *a):
        with self._lock:
            self._in -= 1
        self._sem.release()


def with_retry(fn, retries: int = 2, base: float = 0.05):
    """호출을 지수백오프+풀지터로 재시도. 최종 실패는 예외 대신 (None, err) 반환용 래퍼."""
    last = None
    for attempt in range(retries + 1):
        try:
            return fn()
        except Exception as exc:  # noqa
            last = exc
            if attempt < retries:
                time.sleep(random.uniform(0, base * (2 ** attempt)))
    raise last


# ---------------- DAG 웨이브 스케줄러 ----------------
@dataclass
class Node:
    id: str
    payload: object
    depends_on: list = field(default_factory=list)


def topological_waves(nodes: list, edges: dict) -> list:
    """Kahn — 위상정렬 웨이브 목록. edges: {node_id: [dep_id,...]}. 사이클이면 예외."""
    ids = [n.id for n in nodes]
    indeg = {i: 0 for i in ids}
    succ = defaultdict(list)
    for i in ids:
        for dep in edges.get(i, []):
            if dep in indeg:
                indeg[i] += 1
                succ[dep].append(i)
    ready = sorted([i for i in ids if indeg[i] == 0])
    waves = []
    done = 0
    while ready:
        waves.append(list(ready))
        nxt = []
        for i in ready:
            done += 1
            for s in succ[i]:
                indeg[s] -= 1
                if indeg[s] == 0:
                    nxt.append(s)
        ready = sorted(nxt)
    if done != len(ids):
        raise ValueError("의존성 사이클(위상정렬 불가)")
    return waves


def run_dag(nodes: list, worker, edges: dict | None = None,
            max_parallel: int = 8) -> dict:
    """DAG를 웨이브별 병렬 실행. worker(node, results)->result. 반환 {node_id: result}.

    각 노드는 자기 의존 노드들의 결과(results)를 받아 실행된다.
    """
    edges = edges or {n.id: list(n.depends_on) for n in nodes}
    by_id = {n.id: n for n in nodes}
    waves = topological_waves(nodes, edges)
    results: dict = {}
    for wave in waves:
        with ThreadPoolExecutor(max_workers=max(1, min(max_parallel, len(wave)))) as ex:
            futs = {ex.submit(_safe_worker, worker, by_id[i], results): i for i in wave}
            for fut in as_completed(futs):
                i = futs[fut]
                results[i] = fut.result()
    return results


def _safe_worker(worker, node, results):
    try:
        return {"ok": True, "result": worker(node, results)}
    except Exception as exc:  # noqa
        return {"ok": False, "error": f"{type(exc).__name__}: {exc}"}


# ---------------- best-of-N + 적응 조기종료 ----------------
def adaptive_stop(counts: list, threshold: float = 0.95) -> bool:
    """상위-둘 카운트로 리더 확정 확률(Beta 적분)이 임계 넘으면 True(그만 표본).

    P(p1>p2) = ∫_0^0.5 p^v2 (1-p)^v1 dp / B(v2+1, v1+1) 근사(수치적분).
    """
    if not counts:
        return False
    s = sorted(counts, reverse=True)
    v1 = s[0]
    v2 = s[1] if len(s) > 1 else 0          # 만장일치는 runner-up 0으로
    if v1 == v2:
        return False
    # 수치 적분(사다리꼴).
    steps = 200
    num = 0.0
    for k in range(steps + 1):
        p = 0.5 * k / steps
        w = 0.5 if k in (0, steps) else 1.0
        num += w * (p ** v2) * ((1 - p) ** v1)
    num *= (0.5 / steps)
    # 정규화 상수 B(v2+1, v1+1) 전체 적분[0,1].
    import math
    beta = math.exp(math.lgamma(v2 + 1) + math.lgamma(v1 + 1) - math.lgamma(v1 + v2 + 2))
    prob = num / beta if beta > 0 else 0.0
    return prob > threshold


def best_of_n_vote(sample_fn, key_fn=None, n_max: int = 7, n_min: int = 2,
                   threshold: float = 0.95):
    """같은 작업 표본을 점증 생성, 최빈 답이 통계적으로 확정되면 조기 종료.

    sample_fn()->답, key_fn(답)->해시가능 키(의미 동일 판정). 반환 (대표답, 표본들, 표수).
    """
    key_fn = key_fn or (lambda x: x)
    samples = []
    tally: dict = defaultdict(list)
    for i in range(n_max):
        s = sample_fn()
        samples.append(s)
        tally[key_fn(s)].append(s)
        if i + 1 >= n_min and adaptive_stop([len(v) for v in tally.values()], threshold):
            break
    best_key = max(tally.items(), key=lambda kv: len(kv[1]))[0]
    return tally[best_key][0], samples, len(tally[best_key])


# ---------------- 계층 리듀스 ----------------
def reduce_tree(items: list, merge_fn, fanin: int = 3) -> object:
    """items를 fanin개씩 병합하며 트리로 축약(단일 대형 리듀스 회피)."""
    if not items:
        return None
    level = list(items)
    while len(level) > 1:
        nxt = []
        for i in range(0, len(level), fanin):
            group = level[i:i + fanin]
            nxt.append(group[0] if len(group) == 1 else merge_fn(group))
        level = nxt
    return level[0]


# ---------------- RRF(순위 융합) ----------------
def rrf(rankings: list, k: int = 60) -> list:
    """여러 워커의 순위 목록을 Reciprocal Rank Fusion으로 융합. 점수 보정 불필요."""
    score: dict = defaultdict(float)
    for ranking in rankings:
        for rank, item in enumerate(ranking):
            score[item] += 1.0 / (k + rank + 1)
    return [it for it, _ in sorted(score.items(), key=lambda kv: -kv[1])]
