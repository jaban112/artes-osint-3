"""LLM 백엔드 추상화 — 우리가 빌드한 llama.cpp 위에서만 돈다(Ollama 0).

교체형 백엔드:
- LlamaServerBackend: 우리가 빌드한 llama-server(HTTP /completion). 단일 서버가
  --parallel 슬롯으로 동시 요청을 받으므로 '단일 런타임 · 여러 용도/일꾼'에 맞다.
- LlamaCliBackend: llama-cli 서브프로세스(서버 없이 단발).
- LlamaCppPythonBackend: llama-cpp-python 있으면 인프로세스.
- StubBackend: 모델 없이 결정적 응답 — 로직 단위검증용(이 컨테이너는 모델 미탑재).

외부 런타임 의존 0. 모든 호출은 Runtime을 거쳐 감사(AI 호출 로깅)된다.

증분 9(2026 SOTA 반영):
- FACTUAL_SAMPLER: 사실 판정용 샘플러 프리셋 — min-p + DRY + 낮은 temp, top-k/top-p 비활성.
  작은 모델의 반복·비일관을 줄이고(연구: min-p가 고정 top-k보다 우수), DRY로 n-그램 루프 차단.
- generate_conf(): 토큰 logprob을 받아 (텍스트, 평균 logprob) 반환. 작은 로컬 모델에서
  '평균 logprob'은 zero-shot 신뢰도 신호로 가장 신뢰할 만하다(학습된 분류기보다 강함) →
  확실/불확실 라벨의 1차 근거.
"""
from __future__ import annotations

import json
import math
import subprocess
import urllib.request
from typing import Callable

# 사실 판정 샘플러 프리셋(2026 연구). 서버/파이썬 백엔드가 병합해 쓴다.
# top_k=0, top_p=1.0 → 사실상 비활성(min_p가 절단을 담당). XTC는 끈다(창의성 주입=사실성 저하).
FACTUAL_SAMPLER = {
    "temperature": 0.3,
    "min_p": 0.1,
    "top_p": 1.0,
    "top_k": 0,
    "dry_multiplier": 0.8,
    "dry_base": 1.75,
    "dry_allowed_length": 2,
    "xtc_probability": 0.0,
}


class LLMBackend:
    name = "base"

    def generate(self, prompt: str, max_tokens: int = 256,
                 temperature: float = 0.2, stop: list[str] | None = None,
                 grammar: str | None = None, json_schema: dict | None = None,
                 sampler: dict | None = None) -> str:
        raise NotImplementedError

    def generate_conf(self, prompt: str, max_tokens: int = 256,
                      temperature: float = 0.2, stop: list[str] | None = None,
                      grammar: str | None = None, json_schema: dict | None = None,
                      sampler: dict | None = None) -> tuple[str, float | None]:
        """(텍스트, 평균 토큰 logprob). logprob 미지원 백엔드는 (텍스트, None)."""
        return self.generate(prompt, max_tokens, temperature, stop,
                             grammar, json_schema, sampler), None

    def available(self) -> bool:
        return True


def _schema_skeleton(schema: dict):
    """JSON 스키마에서 최소 유효 인스턴스(스텁이 문법 강제를 흉내)."""
    t = schema.get("type")
    if t == "object":
        return {k: _schema_skeleton(v) for k, v in schema.get("properties", {}).items()}
    if t == "array":
        return []
    if t == "string":
        return schema.get("enum", ["확인 안 됨"])[0] if "enum" in schema else ""
    if t in ("number", "integer"):
        return 0
    if t == "boolean":
        return False
    return None


class StubBackend(LLMBackend):
    """모델 없이 결정적 응답. responder(prompt)->str 주입 가능."""
    name = "stub"

    def __init__(self, responder: Callable[[str], str] | None = None,
                 conf: float | None = None):
        self._responder = responder
        self._conf = conf                # 테스트에서 신뢰도 신호 주입용

    def generate(self, prompt, max_tokens=256, temperature=0.2, stop=None,
                 grammar=None, json_schema=None, sampler=None) -> str:
        if self._responder:
            return self._responder(prompt)
        if json_schema is not None:                 # 스키마 강제 흉내 → 유효 JSON
            import json as _j
            return _j.dumps(_schema_skeleton(json_schema), ensure_ascii=False)
        return "[stub] " + prompt.strip().splitlines()[-1][:80]

    def generate_conf(self, prompt, max_tokens=256, temperature=0.2, stop=None,
                      grammar=None, json_schema=None, sampler=None):
        return (self.generate(prompt, max_tokens, temperature, stop,
                              grammar, json_schema, sampler), self._conf)


class LlamaServerBackend(LLMBackend):
    name = "llama-server"

    def __init__(self, base_url: str = "http://127.0.0.1:8080"):
        self.base_url = base_url.rstrip("/")

    def available(self) -> bool:
        try:
            with urllib.request.urlopen(self.base_url + "/health", timeout=2) as r:
                return r.status == 200
        except Exception:
            return False

    def _payload(self, prompt, max_tokens, temperature, stop, grammar,
                 json_schema, sampler, n_probs=0):
        p = {"prompt": prompt, "n_predict": max_tokens, "stop": stop or [],
             "cache_prompt": True}            # 6권: 프롬프트 접두 캐시(고정 시스템 프리픽스)
        p.update(FACTUAL_SAMPLER)             # 사실 판정 프리셋 기본
        if sampler:
            p.update(sampler)                 # 호출자 오버라이드
        p["temperature"] = temperature        # 명시 온도 우선
        if grammar:
            p["grammar"] = grammar            # 서버가 GBNF로 출력 강제
        if json_schema is not None:
            p["json_schema"] = json_schema    # 서버가 스키마→문법 변환
        if n_probs:
            p["n_probs"] = n_probs            # 토큰별 logprob 반환
        return p

    def _post(self, payload):
        body = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(self.base_url + "/completion", data=body,
                                     headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=600) as r:
            return json.loads(r.read().decode("utf-8"))

    def generate(self, prompt, max_tokens=256, temperature=0.2, stop=None,
                 grammar=None, json_schema=None, sampler=None) -> str:
        obj = self._post(self._payload(prompt, max_tokens, temperature, stop,
                                       grammar, json_schema, sampler))
        return obj.get("content", "")

    def generate_conf(self, prompt, max_tokens=256, temperature=0.2, stop=None,
                      grammar=None, json_schema=None, sampler=None):
        obj = self._post(self._payload(prompt, max_tokens, temperature, stop,
                                       grammar, json_schema, sampler, n_probs=1))
        text = obj.get("content", "")
        lp = _mean_logprob(obj)
        return text, lp


def _mean_logprob(obj: dict) -> float | None:
    """llama-server /completion 응답에서 생성 토큰 평균 logprob 추출.

    서버 버전에 따라 completion_probabilities[*].logprob 또는 .prob(선형확률).
    둘 다 대응: prob이면 log로 변환. 없으면 None.
    """
    probs = obj.get("completion_probabilities") or obj.get("tokens") or []
    vals = []
    for tp in probs:
        if not isinstance(tp, dict):
            continue
        if "logprob" in tp and tp["logprob"] is not None:
            vals.append(float(tp["logprob"]))
        elif tp.get("prob"):
            try:
                vals.append(math.log(max(float(tp["prob"]), 1e-9)))
            except Exception:
                pass
    if not vals:
        return None
    return sum(vals) / len(vals)


class OpenAICompatBackend(LLMBackend):
    """OpenAI 호환 원격 백엔드 — GLM(Z.ai/OpenRouter)·원격 llama-server·기타 API.

    크롬북처럼 약한 기기에서 '진짜 큰 AI'(GLM-5.3-Flash, GLM-5.2-free 등)를 쓰는 길.
    /v1/chat/completions 로 POST. json_schema는 지원 제공자엔 response_format으로,
    아니면 프롬프트 지시로 폴백. 키는 요청 헤더에만(로깅 금지).
    """
    name = "openai-compat"

    def __init__(self, base_url: str, api_key: str | None = None,
                 model: str = "z-ai/glm-5.2:free", referer: str = "https://github.com/artes",
                 title: str = "ARTES"):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.model = model
        self.referer = referer
        self.title = title

    def available(self) -> bool:
        return bool(self.base_url)

    def _headers(self):
        h = {"Content-Type": "application/json",
             "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) ARTES/1.0"}
        if self.api_key:
            h["Authorization"] = f"Bearer {self.api_key}"
        # OpenRouter 권장 헤더(무해).
        h["HTTP-Referer"] = self.referer
        h["X-Title"] = self.title
        return h

    def _messages(self, prompt, json_schema):
        sys = "You are a precise assistant."
        if json_schema is not None:
            sys += (" Respond ONLY with a valid JSON object matching this schema, "
                    "no prose: " + json.dumps(json_schema))
        return [{"role": "system", "content": sys},
                {"role": "user", "content": prompt}]

    def _post(self, prompt, max_tokens, temperature, stop, json_schema,
              sampler, logprobs=False):
        payload = {"model": self.model, "messages": self._messages(prompt, json_schema),
                   "max_tokens": max_tokens, "temperature": temperature}
        if stop:
            payload["stop"] = stop
        if json_schema is not None:
            # 지원 제공자면 구조화 출력 강제(미지원이면 무시되고 프롬프트 지시로 폴백).
            payload["response_format"] = {"type": "json_object"}
        if logprobs:
            payload["logprobs"] = True
        if sampler:
            for k in ("top_p", "frequency_penalty", "presence_penalty"):
                if sampler.get(k) is not None:
                    payload[k] = sampler[k]
        body = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(self.base_url + "/chat/completions", data=body,
                                     headers=self._headers())
        with urllib.request.urlopen(req, timeout=600) as r:
            return json.loads(r.read().decode("utf-8"))

    def generate(self, prompt, max_tokens=256, temperature=0.2, stop=None,
                 grammar=None, json_schema=None, sampler=None) -> str:
        obj = self._post(prompt, max_tokens, temperature, stop, json_schema, sampler)
        return self._content(obj)

    def generate_conf(self, prompt, max_tokens=256, temperature=0.2, stop=None,
                      grammar=None, json_schema=None, sampler=None):
        obj = self._post(prompt, max_tokens, temperature, stop, json_schema,
                         sampler, logprobs=True)
        return self._content(obj), self._mean_logprob(obj)

    @staticmethod
    def _content(obj):
        try:
            return obj["choices"][0]["message"]["content"] or ""
        except (KeyError, IndexError, TypeError):
            return ""

    @staticmethod
    def _mean_logprob(obj):
        try:
            lps = obj["choices"][0]["logprobs"]["content"]
            vals = [t["logprob"] for t in lps if t.get("logprob") is not None]
            return sum(vals) / len(vals) if vals else None
        except (KeyError, IndexError, TypeError):
            return None


class AnthropicBackend(LLMBackend):
    """Claude 네이티브 백엔드(/v1/messages) — sk-ant- 키용(증분 18).

    OpenAI 비호환 제공처(Anthropic)를 위한 별도 경로. json_schema는 시스템 지시로 폴백.
    키는 x-api-key 헤더에만(로깅 금지). 크롬북에서 Claude를 '큰 두뇌'로 쓰는 길.
    """
    name = "anthropic"

    def __init__(self, base_url: str = "https://api.anthropic.com/v1",
                 api_key: str | None = None, model: str = "claude-sonnet-4-5",
                 version: str = "2023-06-01"):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.model = model
        self.version = version

    def available(self) -> bool:
        return bool(self.base_url and self.api_key)

    def _headers(self):
        return {"Content-Type": "application/json",
                "x-api-key": self.api_key or "",
                "anthropic-version": self.version}

    def _system(self, json_schema):
        s = "You are a precise assistant."
        if json_schema is not None:
            s += (" Respond ONLY with a valid JSON object matching this schema, "
                  "no prose: " + json.dumps(json_schema))
        return s

    def generate(self, prompt, max_tokens=256, temperature=0.2, stop=None,
                 grammar=None, json_schema=None, sampler=None) -> str:
        payload = {"model": self.model, "max_tokens": max_tokens,
                   "temperature": temperature, "system": self._system(json_schema),
                   "messages": [{"role": "user", "content": prompt}]}
        if stop:
            payload["stop_sequences"] = stop
        body = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(self.base_url + "/messages", data=body,
                                     headers=self._headers())
        try:
            with urllib.request.urlopen(req, timeout=600) as r:
                obj = json.loads(r.read().decode("utf-8"))
        except Exception:
            return ""
        # content: [{"type":"text","text":...}, ...]
        parts = obj.get("content") or []
        return "".join(p.get("text", "") for p in parts if isinstance(p, dict))


class LlamaCliBackend(LLMBackend):
    name = "llama-cli"

    def __init__(self, binary: str, model: str, threads: int | None = None):
        self.binary, self.model, self.threads = binary, model, threads

    def available(self) -> bool:
        import os
        return os.path.exists(self.binary) and os.path.exists(self.model)

    def generate(self, prompt, max_tokens=256, temperature=0.2, stop=None,
                 grammar=None, json_schema=None, sampler=None) -> str:
        cmd = [self.binary, "-m", self.model, "-p", prompt, "-n", str(max_tokens),
               "--temp", str(temperature), "-no-cnv", "--simple-io"]
        s = dict(FACTUAL_SAMPLER)
        if sampler:
            s.update(sampler)
        # llama-cli 샘플러 플래그(있으면 반영; 미지원 빌드는 무시돼도 안전).
        if s.get("min_p") is not None:
            cmd += ["--min-p", str(s["min_p"])]
        if s.get("top_k") is not None:
            cmd += ["--top-k", str(s["top_k"])]
        if s.get("top_p") is not None:
            cmd += ["--top-p", str(s["top_p"])]
        if s.get("dry_multiplier"):
            cmd += ["--dry-multiplier", str(s["dry_multiplier"])]
        if self.threads:
            cmd += ["-t", str(self.threads)]
        if grammar:
            cmd += ["--grammar", grammar]
        elif json_schema is not None:
            cmd += ["--json-schema", json.dumps(json_schema)]
        out = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
        text = out.stdout
        return text[len(prompt):] if text.startswith(prompt) else text


class LlamaCppPythonBackend(LLMBackend):
    name = "llama-cpp-python"

    def __init__(self, model: str, n_ctx: int = 4096, threads: int | None = None):
        from llama_cpp import Llama            # 지연 임포트
        self._llm = Llama(model_path=model, n_ctx=n_ctx, n_threads=threads,
                          logits_all=False, verbose=False)

    def _grammar(self, grammar, json_schema):
        try:
            from llama_cpp import LlamaGrammar
            if grammar:
                return LlamaGrammar.from_string(grammar)
            if json_schema is not None:
                return LlamaGrammar.from_json_schema(json.dumps(json_schema))
        except Exception:
            return None
        return None

    def _sampler_kw(self, sampler):
        s = dict(FACTUAL_SAMPLER)
        if sampler:
            s.update(sampler)
        kw = {}
        for k in ("min_p", "top_k", "top_p"):
            if s.get(k) is not None:
                kw[k] = s[k]
        return kw

    def generate(self, prompt, max_tokens=256, temperature=0.2, stop=None,
                 grammar=None, json_schema=None, sampler=None) -> str:
        out = self._llm(prompt, max_tokens=max_tokens, temperature=temperature,
                        stop=stop or [], grammar=self._grammar(grammar, json_schema),
                        **self._sampler_kw(sampler))
        return out["choices"][0]["text"]

    def generate_conf(self, prompt, max_tokens=256, temperature=0.2, stop=None,
                      grammar=None, json_schema=None, sampler=None):
        out = self._llm(prompt, max_tokens=max_tokens, temperature=temperature,
                        stop=stop or [], grammar=self._grammar(grammar, json_schema),
                        logprobs=1, **self._sampler_kw(sampler))
        ch = out["choices"][0]
        text = ch["text"]
        lps = ((ch.get("logprobs") or {}).get("token_logprobs")) or []
        vals = [v for v in lps if v is not None]
        return text, (sum(vals) / len(vals) if vals else None)
