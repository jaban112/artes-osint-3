"""AI 응답 캐시 — 생성 자체를 건너뛰는 가장 큰 속도 이득(증분 14).

많은 호출을 하는 엔진(해석·판정·검증·대화)에서 반복/유사 프롬프트는 흔하다.
- 정확 캐시: hash(purpose+prompt+params) → 출력. O(1), 즉시.
- 의미 캐시(선택): 프롬프트 임베딩 코사인 > 임계면 재사용(GPTCache식). 임베딩 없으면 비활성.

안전: 판정/검증 계열은 정확 캐시만(의미 캐시의 '유사≠동일' 위험 차단). 해석/대화/RAG는
의미 캐시 허용(임계 높게). 프로세스 캐시 + 선택적 디스크 지속.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import time
from collections import OrderedDict

# 의미 캐시를 허용하지 않는(정확만) 용도 — 오답 캐시 위험이 큰 판정류.
_EXACT_ONLY = {"judge", "verify", "extract", "cove-plan", "cove-check", "p_true",
               "genrm", "agent", "reason", "sem-equiv", "checklist"}


def _key(purpose: str, prompt: str, params: dict) -> str:
    h = hashlib.sha256()
    h.update(purpose.encode()); h.update(b"\x00")
    h.update(prompt.encode()); h.update(b"\x00")
    h.update(json.dumps(params, sort_keys=True, default=str).encode())
    return h.hexdigest()


class ResponseCache:
    def __init__(self, maxsize: int = 20000, ttl: float = 86400.0,
                 semantic_threshold: float = 0.95, embed=None,
                 path: str | None = None):
        self.maxsize = maxsize
        self.ttl = ttl
        self.semantic_threshold = semantic_threshold
        self._exact: OrderedDict = OrderedDict()   # key -> (exp, output)
        self._sem: list = []                        # [(purpose, vec, output, exp)]
        self.hits = 0; self.misses = 0; self.sem_hits = 0
        self.path = path
        self._embed = embed
        if embed is None:
            try:
                from sentence_transformers import SentenceTransformer
                self._embed = SentenceTransformer("all-MiniLM-L6-v2")
            except Exception:
                self._embed = None
        if path and os.path.exists(path):
            self._load()

    # ---- 정확 캐시 ----
    def get(self, purpose: str, prompt: str, params: dict, now: float | None = None):
        t = now if now is not None else time.time()
        k = _key(purpose, prompt, params)
        item = self._exact.get(k)
        if item and item[0] >= t:
            self._exact.move_to_end(k)
            self.hits += 1
            return item[1]
        if item:
            self._exact.pop(k, None)
        # 의미 캐시(허용 용도만).
        if purpose not in _EXACT_ONLY and self._embed is not None:
            hit = self._semantic_lookup(purpose, prompt, t)
            if hit is not None:
                self.sem_hits += 1
                return hit
        self.misses += 1
        return None

    def put(self, purpose: str, prompt: str, params: dict, output: str,
            now: float | None = None) -> None:
        t = now if now is not None else time.time()
        k = _key(purpose, prompt, params)
        self._exact[k] = (t + self.ttl, output)
        self._exact.move_to_end(k)
        while len(self._exact) > self.maxsize:
            self._exact.popitem(last=False)
        if purpose not in _EXACT_ONLY and self._embed is not None:
            try:
                vec = self._embed.encode(prompt, normalize_embeddings=True).tolist()
                self._sem.append((purpose, vec, output, t + self.ttl))
                if len(self._sem) > self.maxsize:
                    self._sem.pop(0)
            except Exception:
                pass

    def _semantic_lookup(self, purpose, prompt, t):
        try:
            q = self._embed.encode(prompt, normalize_embeddings=True).tolist()
        except Exception:
            return None
        best, best_out = self.semantic_threshold, None
        for pp, vec, out, exp in self._sem:
            if pp != purpose or exp < t:
                continue
            sim = sum(a * b for a, b in zip(q, vec))
            if sim >= best:
                best, best_out = sim, out
        return best_out

    def stats(self) -> dict:
        total = self.hits + self.sem_hits + self.misses
        return {"exact_hits": self.hits, "semantic_hits": self.sem_hits,
                "misses": self.misses, "size": len(self._exact),
                "hit_rate": round((self.hits + self.sem_hits) / total, 3) if total else 0.0,
                "embed": self._embed is not None}

    # ---- 디스크 지속(정확 캐시만) ----
    def save(self) -> None:
        if not self.path:
            return
        try:
            os.makedirs(os.path.dirname(self.path), exist_ok=True)
            with open(self.path, "w", encoding="utf-8") as f:
                json.dump({k: v for k, v in list(self._exact.items())[-5000:]}, f)
        except Exception:
            pass

    def _load(self) -> None:
        try:
            with open(self.path, encoding="utf-8") as f:
                data = json.load(f)
            for k, v in data.items():
                self._exact[k] = tuple(v)
        except Exception:
            pass
