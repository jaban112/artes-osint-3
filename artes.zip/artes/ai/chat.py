"""용도 3a — 터미널 범용 대화(증분 12 재구축).

작은 모델·좁은 컨텍스트(~8k)를 깊게 쓴다:
- 요약 버퍼 메모리: 최근 턴은 그대로, 오래된 건 러닝 요약으로 접어(재귀 요약) 무한 이력.
- 토큰 예산 조립: '최근 12턴'이 아니라 예산 기반(시스템 프롬프트가 잘리는 사고 방지).
- 엔티티/사실 저장: 이름·목표 등 정확히·항상 필요한 사실은 검색이 아니라 상시 주입.
- 대화 상태: 현재 목표·미해결 스레드를 꼬리에 붙여 장기 표류 억제.
- 시스템 재주입: 생성 직전 한 줄 규칙 재확인('lost-in-the-middle' 완화).
- ReAct 도구사용: 문법강제 JSON 액션으로 도구 호출→관측→계속(작은 모델도 파싱 실패 0).
- 반복 억제 샘플러: repeat_penalty + DRY(작은 모델 루프/표류 완화).

전부 순수 파이썬 + 런타임 공유. StubBackend로 로직 검증 가능.
"""
from __future__ import annotations

import sys
from dataclasses import dataclass, field

from .grammar import parse_json_lenient

_SYSTEM = ("너는 ARTES의 로컬 AI 어시스턴트다. 한국어로 간결하고 정확하게 답한다. "
           "모르면 모른다고 한다. 도구가 필요하면 도구를 쓴다.")
_REMINDER = "규칙: 간결·정확·근거. 아는 것만 답하라."

# 반복 억제 샘플러(작은 모델 루프 방지).
_CHAT_SAMPLER = {"temperature": 0.7, "min_p": 0.05, "top_p": 1.0, "top_k": 0,
                 "dry_multiplier": 0.8, "dry_base": 1.75, "dry_allowed_length": 2}


def _approx_tokens(text: str) -> int:
    return max(1, len(text) // 3)              # 대략 3자/토큰(한국어 보수적)


@dataclass
class ConversationMemory:
    """요약 버퍼 — 최근 verbatim + 러닝 요약 + 엔티티 사실."""
    summary: str = ""
    recent: list = field(default_factory=list)     # [(role, msg)]
    entities: dict = field(default_factory=dict)   # {키: 값} 상시 사실
    keep_recent: int = 6

    def add(self, role: str, msg: str) -> None:
        self.recent.append((role, msg))

    def fold(self, runtime) -> None:
        """최근 버퍼가 keep_recent를 넘으면 오래된 걸 러닝 요약에 접는다(재귀 요약)."""
        while len(self.recent) > self.keep_recent * 2:
            old = self.recent[:2]
            self.recent = self.recent[2:]
            chunk = "\n".join(f"{r}: {m}" for r, m in old)
            self.summary = runtime.generate(
                "chat-summary",
                ("기존 요약에 새 대화를 반영해 20문장 이내로 갱신하라.\n"
                 f"[기존 요약]\n{self.summary}\n[새 대화]\n{chunk}\n[갱신 요약]\n"),
                max_tokens=300, temperature=0.2).strip()

    def update_entities(self, runtime) -> None:
        """최근 대화에서 지속 사실(이름·목표·선호)을 추출해 병합. JSON."""
        if not self.recent:
            return
        convo = "\n".join(f"{r}: {m}" for r, m in self.recent[-4:])
        schema = {"type": "object", "properties": {"facts": {"type": "object"}},
                  "required": ["facts"], "additionalProperties": False}
        raw = runtime.generate(
            "chat-entities",
            ("대화에서 앞으로 계속 기억할 지속 사실만 뽑아 facts 객체로(키:값). 없으면 빈.\n"
             f"{convo}\n[JSON] "),
            max_tokens=160, temperature=0.1, json_schema=schema)
        facts = (parse_json_lenient(raw) or {}).get("facts") or {}
        if isinstance(facts, dict):
            self.entities.update({str(k): str(v) for k, v in facts.items()})


@dataclass
class DialogueState:
    goal: str = ""
    open_threads: list = field(default_factory=list)

    def render(self) -> str:
        if not self.goal and not self.open_threads:
            return ""
        parts = []
        if self.goal:
            parts.append(f"현재 목표: {self.goal}")
        if self.open_threads:
            parts.append("미해결: " + "; ".join(self.open_threads[:4]))
        return "\n".join(parts)


@dataclass
class Chat:
    runtime: object
    system: str = _SYSTEM
    history: list = field(default_factory=list)     # 하위호환(전체 로그)
    memory: ConversationMemory = field(default_factory=ConversationMemory)
    state: DialogueState = field(default_factory=DialogueState)
    tools: dict = field(default_factory=dict)       # {name: callable(args)->str}
    max_turns: int = 12
    n_ctx: int = 8192
    max_tokens: int = 400

    # ---- 프롬프트 조립(토큰 예산) ----
    def _assemble(self, user: str) -> str:
        budget = self.n_ctx - self.max_tokens - _approx_tokens(self.system) - 200
        parts = [self.system, ""]
        if self.memory.entities:
            facts = "; ".join(f"{k}={v}" for k, v in list(self.memory.entities.items())[:12])
            parts.append(f"[알려진 사실] {facts}")
        if self.memory.summary:
            parts.append(f"[이전 요약] {self.memory.summary}")
        # 최근 턴을 예산 안에서 최신순으로 채운다.
        picked, used = [], 0
        for role, msg in reversed(self.memory.recent):
            t = _approx_tokens(msg)
            if used + t > budget:
                break
            picked.append((role, msg)); used += t
        for role, msg in reversed(picked):
            parts.append(f"{'사용자' if role == 'user' else 'AI'}: {msg}")
        st = self.state.render()
        if st:
            parts.append(f"[상태] {st}")
        parts.append(user_line := f"사용자: {user}")
        parts.append(_REMINDER)                    # 생성 직전 규칙 재주입
        parts.append("AI: ")
        return "\n".join(parts)

    # ---- 기본 대화 ----
    def say(self, user: str, max_tokens: int | None = None) -> str:
        prompt = self._assemble(user)
        out = self.runtime.generate("chat", prompt, max_tokens=max_tokens or self.max_tokens,
                                    temperature=0.7, stop=["사용자:"],
                                    sampler=_CHAT_SAMPLER).strip()
        self.memory.add("user", user)
        self.memory.add("ai", out)
        self.history.append(("user", user)); self.history.append(("ai", out))
        self.memory.fold(self.runtime)
        return out

    # ---- ReAct 도구사용 대화 ----
    _ACTION_SCHEMA = {
        "type": "object",
        "properties": {
            "thought": {"type": "string"},
            "action": {"type": "string", "enum": ["answer", "tool"]},
            "tool": {"type": "string"},
            "args": {"type": "object"},
            "answer": {"type": "string"},
        },
        "required": ["action"],
    }

    def say_agentic(self, user: str, max_steps: int = 3) -> str:
        """ReAct — 도구가 있으면 문법강제 액션으로 호출→관측→계속. 없으면 일반 대화."""
        if not self.tools:
            return self.say(user)
        tool_list = ", ".join(self.tools.keys())
        obs = ""
        for step in range(max_steps):
            prompt = (
                f"{self.system}\n사용 가능한 도구: {tool_list}.\n"
                "도구가 필요하면 action='tool'과 tool·args를, 아니면 action='answer'와 answer를.\n"
                f"[질문] {user}\n{obs}[JSON] ")
            raw = self.runtime.generate("chat-react", prompt, max_tokens=220,
                                        temperature=0.2, json_schema=self._ACTION_SCHEMA)
            obj = parse_json_lenient(raw) or {}
            if obj.get("action") == "tool" and obj.get("tool") in self.tools:
                try:
                    result = self.tools[obj["tool"]](obj.get("args") or {})
                except Exception as exc:  # noqa
                    result = f"도구 오류: {exc}"
                obs += f"[관측 {obj['tool']}] {str(result)[:400]}\n"
                continue
            ans = obj.get("answer") or self.say(user)
            self.memory.add("user", user); self.memory.add("ai", ans)
            self.history.append(("user", user)); self.history.append(("ai", ans))
            return ans
        # 상한 도달 → 관측 종합해 답.
        final = self.runtime.generate(
            "chat-react-final",
            f"[질문] {user}\n관측:\n{obs}\n관측만으로 간결히 답하라.\n[답] ",
            max_tokens=300, temperature=0.3).strip()
        self.memory.add("user", user); self.memory.add("ai", final)
        return final

    def repl(self, stream=sys.stdin) -> None:
        print(f"ARTES AI 대화 (백엔드: {getattr(self.runtime.backend, 'name', '?')})."
              " 종료: /quit")
        for line in stream:
            line = line.strip()
            if line in ("/quit", "/exit"):
                break
            if not line:
                continue
            print("AI:", self.say_agentic(line) if self.tools else self.say(line))
