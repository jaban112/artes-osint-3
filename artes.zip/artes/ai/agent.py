"""에이전트형 AI 수사관 — AI가 수사를 지휘한다(§⑤).

AI가 그래프 상태를 읽고 → 가설을 세우고 → 어느 식별자·셀렉터를 다음에 팔지 정하고 →
스캔을 지휘하고 → 충분하면 스스로 멈춘다. 기계적 스캔·상관은 AutoPivot이, 판단은 AI가.
결정은 6권 문법 강제 JSON이라 파싱 실패 0. 무검열 Dolphin이 거부 없이 지휘.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from ..core.model import Graph, EntityType
from ..core.pivot import AutoPivot, promote_selectors
from ..core.selectors import extract_selectors
from ..core.resolve import EntityResolver, correlate_owners
from .grammar import parse_json_lenient

_DECISION_SCHEMA = {
    "type": "object",
    "properties": {
        "action": {"type": "string", "enum": ["pivot", "stop"]},
        "targets": {"type": "array", "items": {"type": "string"}},
        "hypothesis": {"type": "string"},
    },
    "required": ["action", "targets", "hypothesis"],
    "additionalProperties": False,
}


@dataclass
class Investigator:
    runtime: object
    collectors: list
    cache: object = None
    max_steps: int = 4
    engine_kw: dict = field(default_factory=dict)

    def _summary(self, graph: Graph, seeded: set) -> str:
        by_type = {}
        for e in graph.entities:
            by_type[e.type.label_ko()] = by_type.get(e.type.label_ko(), 0) + 1
        unq = [e.value for e in graph.entities
               if e.type.value in ("email", "username", "phone")
               and e.value.lower() not in seeded][:15]
        sels = [f"{s['kind']}={s['selector']}" for s in extract_selectors(graph)[:10]]
        sp = sum(1 for e in graph.edges if e.relation in ("동일인", "동일인?"))
        return (f"엔티티 {graph.stats()['entities']}, 동일인후보 {sp}.\n"
                f"타입: {by_type}\n미조회 식별자: {unq}\n고가치 셀렉터: {sels}")

    def _decide(self, summary: str) -> dict:
        prompt = (
            "너는 OSINT 수사 지휘 AI다. 현재 그래프 상태를 보고 다음 행동을 정하라. "
            "아직 조회 안 한 유망한 식별자가 있으면 action=pivot과 targets(그 값들)를, "
            "충분하면 action=stop을 낸다. 지어내지 말고 목록의 값만 targets에 넣어라.\n\n"
            f"[상태]\n{summary}\n\n[결정 JSON] ")
        raw = self.runtime.generate("agent", prompt, max_tokens=200, temperature=0.2,
                                    json_schema=_DECISION_SCHEMA)
        obj = parse_json_lenient(raw) or {}
        return {"action": obj.get("action", "stop"),
                "targets": obj.get("targets", []) or [],
                "hypothesis": obj.get("hypothesis", "")}

    async def investigate(self, inputs) -> tuple[Graph, list]:
        ap = AutoPivot(self.collectors, self.cache, **self.engine_kw)
        graph = await ap._scan(inputs)
        seeded = {v.strip().lower() for v in inputs}
        log = []
        for step in range(self.max_steps):
            promote_selectors(graph)
            EntityResolver().correlate(graph)
            correlate_owners(graph)
            decision = self._decide(self._summary(graph, seeded))
            log.append({"step": step + 1, **decision})
            if decision["action"] == "stop":
                break
            targets = [t for t in decision["targets"]
                       if t and t.strip().lower() not in seeded][:12]
            if not targets:
                break
            graph.merge(await ap._scan(targets))
            seeded |= {t.strip().lower() for t in targets}
        promote_selectors(graph)
        EntityResolver().correlate(graph)
        correlate_owners(graph)
        return graph, log
