"""용도 3b — 지휘-일꾼 병렬 코딩(증분 12 재구축).

지휘 AI가 구조화된 스펙으로 작업을 쪼개고(의존성 가능) → 일꾼들이 슬롯 세마포어 아래
병렬 구현 → 검증 게이트 통과분만 → 계층(트리) 취합. 실패는 격리·재시도.

정직(4권 초병렬화): 유효 병렬 = min(요청, CPU, 서버 슬롯). 하나의 슬롯 세마포어가 전
호출을 감싸 포화점 위 초과를 막는다. 같은 작업 best-of-N은 남는 슬롯만 채운다.
"""
from __future__ import annotations

import os
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field

from .grammar import parse_json_lenient
from .orchestrator import SlotSemaphore, with_retry, reduce_tree, run_dag, Node


def saturation_workers(requested: int, server_parallel: int = 1) -> int:
    cores = os.cpu_count() or 1
    return max(1, min(requested, cores, max(1, server_parallel)))


@dataclass
class SwarmResult:
    plan: list = field(default_factory=list)
    pieces: list = field(default_factory=list)
    assembled: str = ""
    workers_used: int = 0
    failed: list = field(default_factory=list)     # 격리된 실패 조각
    verified: int = 0                              # 검증 통과 조각 수

    def to_dict(self):
        return {"plan": self.plan, "pieces": self.pieces, "assembled": self.assembled,
                "workers_used": self.workers_used, "failed": self.failed,
                "verified": self.verified}


_PLAN_SCHEMA = {
    "type": "object",
    "properties": {
        "subtasks": {"type": "array", "items": {
            "type": "object",
            "properties": {
                "id": {"type": "string"},
                "objective": {"type": "string"},
                "output_format": {"type": "string"},
                "depends_on": {"type": "array", "items": {"type": "string"}},
            },
            "required": ["id", "objective"],
        }},
    },
    "required": ["subtasks"],
}


def _plan(runtime, task: str, max_subtasks: int) -> list:
    """구조화 스펙(목적·형식·의존성)으로 분해. 실패 시 번호목록 폴백(하위호환)."""
    raw = runtime.generate(
        "swarm-plan",
        ("너는 지휘 AI다. 아래 코딩 작업을 병렬 구현 가능한 하위작업으로 쪼개라. "
         "각 하위작업에 id·objective·output_format·depends_on(선행 id들)을 담아 JSON으로. "
         f"최대 {max_subtasks}개.\n\n[작업] {task}\n[JSON] "),
        max_tokens=400, temperature=0.2, json_schema=_PLAN_SCHEMA)
    obj = parse_json_lenient(raw)
    subs = []
    if isinstance(obj, dict) and obj.get("subtasks"):
        for i, s in enumerate(obj["subtasks"][:max_subtasks]):
            subs.append({"id": s.get("id") or f"t{i+1}",
                         "objective": s.get("objective", ""),
                         "output_format": s.get("output_format", "code"),
                         "depends_on": s.get("depends_on", []) or []})
    if not subs:
        # 폴백: 번호목록 파싱(구모델·비JSON).
        for line in (raw or "").splitlines():
            m = re.match(r"\s*\d+[.)]\s*(.+)", line)
            if m:
                subs.append({"id": f"t{len(subs)+1}", "objective": m.group(1).strip(),
                             "output_format": "code", "depends_on": []})
    return subs[:max_subtasks] or [
        {"id": "t1", "objective": task, "output_format": "code", "depends_on": []}]


def _work(runtime, spec: dict, dep_results: dict, slots: SlotSemaphore) -> dict:
    """일꾼 — 스펙(목적·형식) + 의존 결과로 구현. 슬롯 세마포어 + 재시도."""
    ctx = ""
    for dep in spec.get("depends_on", []):
        if dep in dep_results:
            ctx += f"\n# [{dep} 결과]\n{dep_results[dep].get('code','')[:500]}\n"
    prompt = (f"너는 일꾼 AI다. 아래 하위작업만 구현하라. 코드만 출력.\n"
              f"[목적] {spec['objective']}\n"
              f"[출력형식] {spec.get('output_format','code')}\n")
    if ctx:
        prompt += f"[선행 결과]{ctx}\n"
    prompt += "[코드]\n"

    def _gen():
        with slots:
            return runtime.generate("swarm-work", prompt, max_tokens=500,
                                    temperature=0.2)
    code = with_retry(_gen, retries=1).strip()
    return {"id": spec["id"], "subtask": spec["objective"], "code": code}


def _verify(runtime, piece: dict, slots: SlotSemaphore) -> bool:
    """검증 게이트 — 우선 무료 정적검사(ast), 그 다음 필요 시 모델 확인."""
    from .coder import static_check
    issues = static_check(piece.get("code", ""))
    if not issues:
        return True
    # 정적 문제 있으면 미검증(하지만 조각은 유지 — 취합에서 표시).
    return False


def run_swarm(runtime, task: str, max_subtasks: int = 6, requested_workers: int = 8,
              server_parallel: int = 4, verify: bool = True) -> SwarmResult:
    """지휘-일꾼 병렬 코딩. 구조화 스펙 → DAG 병렬 → 검증 → 트리 취합."""
    specs = _plan(runtime, task, max_subtasks)
    workers = saturation_workers(requested_workers, server_parallel)
    slots = SlotSemaphore(server_parallel)

    # 의존성 DAG 실행(웨이브별 병렬). 의존 없으면 전부 1웨이브.
    nodes = [Node(id=s["id"], payload=s, depends_on=s.get("depends_on", []))
             for s in specs]
    valid_ids = {s["id"] for s in specs}
    for n in nodes:                                 # 미존재 의존 제거(폴백 안전)
        n.depends_on = [d for d in n.depends_on if d in valid_ids and d != n.id]

    def worker(node, results):
        dep_res = {d: results[d]["result"] for d in node.depends_on
                   if d in results and results[d].get("ok")}
        return _work(runtime, node.payload, dep_res, slots)

    try:
        raw_results = run_dag(nodes, worker, max_parallel=workers)
    except ValueError:                              # 사이클 → 의존 무시하고 평면 실행
        raw_results = {}
        with ThreadPoolExecutor(max_workers=workers) as ex:
            futs = {ex.submit(_work, runtime, s, {}, slots): s["id"] for s in specs}
            for fut in as_completed(futs):
                raw_results[futs[fut]] = {"ok": True, "result": fut.result()}

    pieces, failed = [], []
    for s in specs:
        r = raw_results.get(s["id"], {})
        if r.get("ok"):
            pieces.append(r["result"])
        else:
            failed.append({"id": s["id"], "error": r.get("error", "unknown")})

    verified = 0
    if verify:
        for p in pieces:
            if _verify(runtime, p, slots):
                verified += 1
                p["verified"] = True
            else:
                p["verified"] = False

    # 계층(트리) 취합 — 단일 대형 리듀스 회피.
    def merge(group):
        joined = "\n\n".join(f"# --- {g['subtask']} ---\n{g['code']}"
                             if isinstance(g, dict) else str(g) for g in group)
        with slots:
            out = runtime.generate(
                "swarm-assemble",
                "너는 지휘 AI다. 아래 조각들을 하나의 일관된 코드로 취합하라. "
                "임포트 중복 제거·이름충돌 해소·누락 연결.\n\n" + joined + "\n\n[취합]\n",
                max_tokens=700, temperature=0.2)
        return {"code": out.strip(), "subtask": "merged"}

    assembled = ""
    if pieces:
        merged = reduce_tree(pieces, merge, fanin=3)
        assembled = merged["code"] if isinstance(merged, dict) else str(merged)

    return SwarmResult(plan=[s["objective"] for s in specs], pieces=pieces,
                       assembled=assembled, workers_used=workers,
                       failed=failed, verified=verified)


def run_swarm_coding(runtime, task: str, tests: str = "", max_subtasks: int = 5,
                     server_parallel: int = 4) -> dict:
    """실행 검증 병렬 코딩 — 각 하위작업을 coder.repair_loop로 실제 통과까지 수복."""
    from .coder import repair_loop
    specs = _plan(runtime, task, max_subtasks)
    slots = SlotSemaphore(server_parallel)
    workers = saturation_workers(len(specs), server_parallel)
    results = {}
    with ThreadPoolExecutor(max_workers=workers) as ex:
        def solve(s):
            with slots:
                return s["id"], repair_loop(runtime, s["objective"], tests=tests,
                                            max_attempts=3)
        for fut in as_completed([ex.submit(solve, s) for s in specs]):
            sid, cr = fut.result()
            results[sid] = {"passed": cr.passed, "attempts": cr.attempts,
                            "code": cr.code}
    return {"subtasks": [s["objective"] for s in specs], "results": results,
            "passed": sum(1 for r in results.values() if r["passed"]),
            "total": len(specs)}
