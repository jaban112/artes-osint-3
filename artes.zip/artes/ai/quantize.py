"""도메인 특화 양자화 — '우리만의 양자화'의 정직한 실체(증분 16).

정보이론상 무손실 마법 압축은 없다. 하지만 imatrix(중요도 행렬)를 **우리 작업 분포로
직접 만들면**, 우리가 실제로 쓰는 일(OSINT 판정·대화)에 중요한 가중치를 저비트에서도
우선 보존한다. 범용 imatrix를 버리고 우리 데이터로 만드는 것 — 이게 진짜 '우리만의 양자화'.

6권 「추론의 가속」과의 연결: 가중치 양자화는 **손실**(imatrix로 손실 최소화), 투기 디코딩·
KV 페이징은 **무손실**. 우리는 손실을 우리 도메인에서만 최소가 되게 배분한다.

이 모듈은:
1. build_calibration(): OSINT·판정·대화 프롬프트로 보정 코퍼스를 만든다(우리 파이프라인의
   실제 프롬프트 분포를 반영). 파일로 쓴다.
2. quantize_plan(): llama-imatrix → llama-quantize 명령을 생성(사용자 VM에서 실행).
   (실제 실행은 llama.cpp 바이너리·원본 모델 필요 → 사용자 VM. 여기선 계획·코퍼스만.)
"""
from __future__ import annotations

import os

# 보정 코퍼스 시드 — 우리 파이프라인이 실제로 모델에 보내는 유형들.
# (OSINT 판정·엔티티추출·근거기반 답변·문법강제 JSON·대화). 도메인 대표성이 핵심.
_CALIB_SEEDS = [
    # 동일인 판정(핵심 작업)
    "두 계정 github/jiwan 과 twitter/jiwan_kim 이 동일인인지 근거만으로 판정하고 확률을 매겨라.",
    "이메일 hong@gmail.com 과 아이디 hong123 이 같은 사람일 가능성을 신호별로 분석하라.",
    "공유 전화번호와 같은 프로필 사진(pHash 근접)이 있을 때 동일인 신뢰도를 설명하라.",
    # 엔티티 추출(문법강제 JSON)
    'JSON으로 답하라: {"emails":[],"usernames":[],"phones":[],"names":[]}. 텍스트: "연락 010-1234-5678, kim@corp.com, @kimdev".',
    "다음 프로필에서 실명·회사·위치를 뽑아 구조화하라: seoul python developer at ACME, blog kim.dev.",
    # 근거기반 질의응답
    "아래 근거만 써서 이 사람의 직업을 한국어로 답하고 없으면 '확인 안 됨'이라 하라.",
    "수집된 그래프에서 도메인 example.com 의 서브도메인과 운영자 신호를 요약하라.",
    # 판정 신뢰도/기권
    "근거가 약하면 '불확실', 충분하면 '확실', 없으면 기권으로 답하는 규율을 따라 판정하라.",
    # 위협·인프라
    "IP 1.2.3.4 의 ASN·역DNS·악용신고 연락처를 근거와 함께 정리하라.",
    "이 도메인이 피싱 피드에 있는지와 유사(사칭) 도메인 위험을 평가하라.",
    # 코딩(코더 역할 보정)
    "파이썬으로 CSV를 읽어 이메일 컬럼만 정규화해 반환하는 함수를 작성하고 테스트하라.",
    "이 코드가 AssertionError를 냈다. 실오류를 보고 고쳐라.",
    # 일반 대화(대화 역할 보정)
    "OSINT 조사에서 확실과 불확실을 구분하는 게 왜 중요한지 설명해줘.",
    "이 시스템의 동일인 융합 수학을 비전문가에게 쉽게 설명해줘.",
]


def build_calibration(path: str, repeats: int = 30, extra: list[str] | None = None) -> int:
    """보정 코퍼스 파일 생성. 우리 작업 분포를 반영한 텍스트. 반환: 줄 수.

    repeats로 분량을 늘린다(imatrix는 충분한 토큰이 필요 — 보통 수만~수십만 토큰 권장).
    """
    lines = list(_CALIB_SEEDS) + list(extra or [])
    os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
    n = 0
    with open(path, "w", encoding="utf-8") as f:
        for _ in range(repeats):
            for s in lines:
                f.write(s.strip() + "\n")
                n += 1
    return n


def quantize_plan(model_gguf: str, out_gguf: str, quant: str = "IQ2_M",
                  calib: str = "~/.artes/calib_osint.txt",
                  imatrix: str = "~/.artes/imatrix_osint.dat",
                  llama_dir: str = "~/.artes/llama.cpp/build/bin",
                  chunks: int = 0) -> dict:
    """도메인 imatrix 양자화 명령 2개를 생성(사용자 VM에서 실행).

    1) llama-imatrix: 우리 코퍼스로 중요도 행렬 계산.
    2) llama-quantize: 그 imatrix로 저비트 양자화(우리 작업 중요 가중치 우선 보존).
    """
    d = os.path.expanduser(llama_dir)
    calib = os.path.expanduser(calib)
    imatrix = os.path.expanduser(imatrix)
    imat_cmd = [os.path.join(d, "llama-imatrix"), "-m", model_gguf,
                "-f", calib, "-o", imatrix]
    if chunks:
        imat_cmd += ["--chunks", str(chunks)]
    quant_cmd = [os.path.join(d, "llama-quantize"), "--imatrix", imatrix,
                 model_gguf, out_gguf, quant]
    return {"imatrix_cmd": imat_cmd, "quantize_cmd": quant_cmd,
            "calib": calib, "imatrix": imatrix, "out": out_gguf, "quant": quant,
            "note": ("저비트(IQ2_M/IQ1_M)는 손실이 크다 — 우리 도메인에서만 손실 최소화. "
                     "범용 성능은 원본보다 낮다. 4B급엔 Q4_K_M 권장, 초거대엔 IQ2/IQ1로 크기 확보.")}
