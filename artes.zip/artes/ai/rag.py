"""하이브리드 RAG — 수집 텍스트를 색인해 AI 질의응답을 규모에서 근거 있게.

증분 9(2026 SOTA):
- 희소(BM25) + 밀집(임베딩/TF-IDF)을 **Reciprocal Rank Fusion(RRF)**으로 융합.
  BM25는 희귀 토큰(이름·핸들·ID — OSINT 핵심)에 강하고, 밀집은 의미에 강하다. 둘의
  RRF 융합이 각각 단독보다 안정적으로 낫고, 점수 정규화·가중치 학습이 필요 없다.
- 밀집 인코더: sentence-transformers 있으면 bge-small-en-v1.5(작지만 강함) → 없으면
  all-MiniLM → 그래도 없으면 순수 TF-IDF 코사인(여기 컨테이너 기본).
- 선택적 재순위: CrossEncoder(bge-reranker) 있으면 상위 후보만 재정렬(정밀도↑). 없으면 생략.
검색된 근거만 AI에 넘겨 환각을 줄인다(3권 규율).
"""
from __future__ import annotations

import math
import re
from collections import Counter

_DENSE_MODELS = ("BAAI/bge-small-en-v1.5", "all-MiniLM-L6-v2")


def _tokens(text: str) -> list[str]:
    return re.findall(r"[\w.@\-]+", (text or "").lower())


def rrf(rank_lists: list[list[str]], k: int = 60) -> dict[str, float]:
    """Reciprocal Rank Fusion — 각 랭킹에서 1/(k+rank) 합산. 튜닝·정규화 불필요."""
    score: dict[str, float] = {}
    for lst in rank_lists:
        for rank, doc in enumerate(lst):
            score[doc] = score.get(doc, 0.0) + 1.0 / (k + rank + 1)
    return score


class RagIndex:
    """하이브리드(BM25 + 밀집/TF-IDF) 색인. 공개 API 하위호환(add/search/backend)."""

    def __init__(self, k1: float = 1.5, b: float = 0.75):
        self.docs: dict[str, str] = {}
        self._tf: dict[str, Counter] = {}
        self._df: Counter = Counter()
        self._len: dict[str, int] = {}
        self._avglen = 0.0
        self.k1, self.b = k1, b
        self._emb = None
        self._emb_name = None
        self._vecs: dict[str, list[float]] = {}
        for name in _DENSE_MODELS:
            try:
                from sentence_transformers import SentenceTransformer
                self._emb = SentenceTransformer(name)
                self._emb_name = name
                break
            except Exception:
                self._emb = None
        self._reranker = None
        try:
            from sentence_transformers import CrossEncoder
            self._reranker = CrossEncoder("BAAI/bge-reranker-base")
        except Exception:
            self._reranker = None

    @property
    def backend(self) -> str:
        # 하위호환: 밀집 있으면 'embeddings', 없으면 'tfidf'.
        return "embeddings" if self._emb else "tfidf"

    def describe(self) -> dict:
        return {"dense": self._emb_name or "tfidf", "sparse": "bm25",
                "rerank": bool(self._reranker), "docs": len(self.docs)}

    def add(self, doc_id: str, text: str) -> None:
        if not text:
            return
        self.docs[doc_id] = text
        toks = _tokens(text)
        self._tf[doc_id] = Counter(toks)
        self._len[doc_id] = len(toks) or 1
        for t in set(toks):
            self._df[t] += 1
        self._avglen = sum(self._len.values()) / (len(self._len) or 1)
        if self._emb is not None:
            self._vecs[doc_id] = self._emb.encode(text, normalize_embeddings=True).tolist()

    # ---- 희소: BM25 ----
    def _bm25_scores(self, query: str) -> list[tuple[str, float]]:
        q = _tokens(query)
        n = len(self.docs) or 1
        out = []
        for d in self.docs:
            tf, dl = self._tf[d], self._len[d]
            s = 0.0
            for t in q:
                f = tf.get(t, 0)
                if not f:
                    continue
                idf = math.log(1 + (n - self._df.get(t, 0) + 0.5) / (self._df.get(t, 0) + 0.5))
                s += idf * (f * (self.k1 + 1)) / (f + self.k1 * (1 - self.b + self.b * dl / (self._avglen or 1)))
            out.append((d, s))
        out.sort(key=lambda x: -x[1])
        return [(d, s) for d, s in out if s > 0]

    # ---- 밀집: 임베딩 코사인 or TF-IDF 코사인 ----
    def _idf(self, term: str) -> float:
        n = len(self.docs) or 1
        return math.log((1 + n) / (1 + self._df.get(term, 0))) + 1.0

    def _tfidf_vec(self, toks) -> dict[str, float]:
        c = Counter(toks)
        return {t: (c[t] / len(toks)) * self._idf(t) for t in c} if toks else {}

    def _dense_scores(self, query: str) -> list[tuple[str, float]]:
        if self._emb is not None:
            qv = self._emb.encode(query, normalize_embeddings=True).tolist()
            scored = [(d, sum(a * b for a, b in zip(qv, self._vecs[d]))) for d in self.docs]
        else:
            qv = self._tfidf_vec(_tokens(query))
            scored = []
            for d in self.docs:
                dv = self._tfidf_vec(list(self._tf[d].elements()))
                num = sum(qv.get(t, 0) * dv.get(t, 0) for t in qv)
                na = math.sqrt(sum(v * v for v in qv.values())) or 1
                nb = math.sqrt(sum(v * v for v in dv.values())) or 1
                scored.append((d, num / (na * nb)))
        scored.sort(key=lambda x: -x[1])
        return [(d, s) for d, s in scored if s > 0]

    def _rerank(self, query: str, docs: list[str]) -> list[str]:
        if not self._reranker or len(docs) < 2:
            return docs
        try:
            scores = self._reranker.predict([(query, self.docs[d]) for d in docs])
            return [d for d, _ in sorted(zip(docs, scores), key=lambda x: -x[1])]
        except Exception:
            return docs

    def search(self, query: str, k: int = 5, pool: int = 30) -> list[tuple[str, float]]:
        """하이브리드 검색: BM25 ⊕ 밀집 → RRF → (선택)재순위 → 상위 k."""
        if not self.docs:
            return []
        bm = self._bm25_scores(query)
        dn = self._dense_scores(query)
        if not bm and not dn:
            return []
        fused = rrf([[d for d, _ in bm[:pool]], [d for d, _ in dn[:pool]]])
        ranked = [d for d, _ in sorted(fused.items(), key=lambda x: -x[1])]
        top = ranked[:max(k, min(pool, len(ranked)))]
        reranked = self._rerank(query, top)
        # 재순위 후 상위 k에 RRF 점수를 실어 반환(하위호환 tuple 형태).
        return [(d, round(fused.get(d, 0.0), 4)) for d in reranked[:k]]


def index_graph(graph) -> RagIndex:
    """그래프의 모든 텍스트(값·bio·근거)를 색인."""
    idx = RagIndex()
    for e in graph.entities:
        parts = [e.value, e.type.label_ko()]
        for kk in ("bio", "about", "txt", "org", "company", "location"):
            if e.attrs.get(kk):
                parts.append(str(e.attrs[kk]))
        for ev in e.evidence:
            if ev.detail:
                parts.append(ev.detail)
        idx.add(e.key, " ".join(parts))
    return idx


def rag_answer(runtime, graph, question: str, k: int = 6):
    """검색 근거만으로 답(6권 문법 강제 JSON). 하이브리드 RAG 컨텍스트 → AI."""
    from .grammar import answer_schema, parse_json_lenient
    idx = index_graph(graph)
    hits = idx.search(question, k)
    if not hits:
        return {"answer": "확인 안 됨(관련 데이터 없음)", "certainty": "확인 안 됨",
                "sources": [], "backend": idx.backend}
    ctx = "\n".join(f"- {graph.get(d).value if graph.get(d) else d}: {idx.docs[d][:160]}"
                    for d, _ in hits)
    prompt = ("아래 검색된 근거만 써서 한국어로 답하라. 없으면 '확인 안 됨'.\n\n"
              f"[근거]\n{ctx}\n\n[질문] {question}\n[JSON] ")
    raw = runtime.generate("rag", prompt, max_tokens=220, temperature=0.1,
                           json_schema=answer_schema())
    obj = parse_json_lenient(raw) or {}
    return {"answer": obj.get("answer", ""), "certainty": obj.get("certainty", "불확실"),
            "sources": [d for d, _ in hits], "backend": idx.backend}
