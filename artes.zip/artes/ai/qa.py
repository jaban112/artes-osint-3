"""용도 2 — 수집 데이터 질의응답.

규율(jaban 인증):
1. 먼저 **코드로** 그래프에서 답을 찾는다(AI 0회). 예: "김지완 전화번호?" →
   이름 노드의 전화 이웃을 그대로 답. 확실/불확실은 간선 근거대로.
2. 그래프에 없으면 "확인 안 됨"이라 답한다 — 지어내지 않는다.
3. 개방형 질문만 AI로 넘기되, 컨텍스트를 코드로 뽑아 주고 AI 답을 다시
   컨텍스트에 대조해 검증되지 않으면 "확인 안 됨"으로 강등한다.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from ..core.model import Graph, Entity, EntityType, Certainty

# 질문 키워드 → 원하는 타입.
_WANT = [
    (EntityType.PHONE, ["전화", "번호", "폰", "phone", "mobile"]),
    (EntityType.EMAIL, ["이메일", "메일", "email", "mail"]),
    (EntityType.ACCOUNT, ["계정", "아이디", "인스타", "instagram", "트위터", "twitter",
                          "깃허브", "github", "account", "sns", "프로필"]),
    (EntityType.DOMAIN, ["도메인", "domain", "사이트"]),
    (EntityType.HOST, ["포트", "서비스", "호스트", "port", "host"]),
    (EntityType.BREACH, ["유출", "breach", "leak"]),
    (EntityType.NAME, ["이름", "name", "실명"]),
]


@dataclass
class Answer:
    text: str
    certainty: str = "unconfirmed"          # confirmed / unconfirmed / unknown
    used_ai: bool = False
    items: list = field(default_factory=list)

    def to_dict(self):
        return {"text": self.text, "certainty": self.certainty,
                "used_ai": self.used_ai, "items": self.items}


def _wanted_types(q: str) -> list[EntityType]:
    ql = q.casefold()
    out = [t for t, kws in _WANT if any(k in ql for k in kws)]
    return out


def _targets(graph: Graph, q: str) -> list[Entity]:
    ql = q.casefold()
    hits = []
    for e in graph.entities:
        v = e.value.casefold()
        if len(v) >= 2 and v in ql:
            hits.append(e)
    # 긴 값(더 구체적인) 우선
    return sorted(hits, key=lambda e: -len(e.value))


def answer(graph: Graph, question: str, runtime=None) -> Answer:
    wants = _wanted_types(question)
    targets = _targets(graph, question)

    # --- 1) 구조적 답변(코드, AI 0회) ---
    if wants and targets:
        found = []
        seen = set()
        best_certainty = "unknown"
        for tgt in targets:
            for nb in graph.neighbors(tgt.key):
                if nb.type not in wants:
                    continue
                sig = (tgt.key, nb.key)
                if sig in seen:                  # 다중 간선으로 인한 중복 제거
                    continue
                seen.add(sig)
                found.append({"value": nb.value, "type": nb.type.label_ko(),
                              "certainty": nb.certainty.value, "of": tgt.value})
                if nb.certainty is Certainty.CONFIRMED:
                    best_certainty = "confirmed"
                elif best_certainty != "confirmed":
                    best_certainty = "unconfirmed"
        if found:
            lines = [f"- {it['of']}의 {it['type']}: {it['value']} "
                     f"[{'확실' if it['certainty']=='confirmed' else '불확실'}]"
                     for it in found]
            return Answer("\n".join(lines), best_certainty, used_ai=False, items=found)
        # 대상은 있는데 원하는 타입 이웃이 없음 → 확인 안 됨
        want_ko = "/".join(t.label_ko() for t in wants)
        return Answer(f"'{targets[0].value}'의 {want_ko}은(는) 수집 데이터에서 확인 안 됨.",
                      "unknown", used_ai=False)

    # --- 2) 개방형 → AI(컨텍스트 근거 + 대조 검증) ---
    if runtime is None:
        return Answer("확인 안 됨(질문을 구조적으로 해석 못 함; AI 런타임 없음).", "unknown")
    context, ctx_values = _context(graph, targets or graph.entities[:40])
    prompt = _grounded_prompt(context, question)
    # 6권 문법 강제: {answer, certainty} 스키마로 강제 → 파싱 실패 구조적 0.
    from .grammar import answer_schema, parse_json_lenient
    raw = runtime.generate("qa", prompt, max_tokens=220, temperature=0.1,
                           json_schema=answer_schema())
    obj = parse_json_lenient(raw) or {}
    ans_text = str(obj.get("answer", "")).strip() or raw.strip()
    cert = obj.get("certainty", "불확실")
    # 대조 검증: 답에 등장한 '값'이 컨텍스트에 없으면 근거 없음 → 강등.
    if _mentions_unknown_value(ans_text, ctx_values):
        return Answer("확인 안 됨(수집 데이터에서 근거를 찾지 못함).", "unknown", used_ai=True)
    cmap = {"확실": "confirmed", "불확실": "unconfirmed", "확인 안 됨": "unknown"}
    return Answer(ans_text or "확인 안 됨.", cmap.get(cert, "unconfirmed"), used_ai=True)


def _context(graph: Graph, entities) -> tuple[str, set[str]]:
    lines, values = [], set()
    for e in entities:
        c = "확실" if e.certainty is Certainty.CONFIRMED else "불확실"
        lines.append(f"[{e.type.label_ko()}] {e.value} ({c})")
        values.add(e.value.casefold())
        for nb in graph.neighbors(e.key):
            lines.append(f"    └ {nb.type.label_ko()}: {nb.value}")
            values.add(nb.value.casefold())
    return "\n".join(lines[:200]), values


def _grounded_prompt(context: str, question: str) -> str:
    return (
        "너는 OSINT 결과 해설기다. 아래 '수집 데이터' 안의 사실만 써서 한국어로 답하라. "
        "데이터에 없으면 반드시 '확인 안 됨'이라고만 답하라. 절대 지어내지 마라.\n\n"
        f"[수집 데이터]\n{context}\n\n[질문] {question}\n[답변] ")


def _mentions_unknown_value(text: str, ctx_values: set[str]) -> bool:
    # 이메일·URL·전화처럼 보이는 토큰이 답에 있는데 컨텍스트에 없으면 근거 없음.
    for tok in re.findall(r"[\w.\-+]+@[\w.\-]+\.\w+|https?://\S+|\+?\d[\d\-\s]{6,}\d", text):
        if tok.strip().casefold() not in ctx_values:
            return True
    return False
