"""판정·검증 계층 — 작은 로컬 모델을 '신뢰할 수 있게' 만드는 2026 SOTA 기법 묶음.

세 축(전부 연구 근거):
1. reason-then-format(형식세 회피): 문법 강제 JSON 안에서 '추론'하면 작은 모델의 정확도가
   급락한다(구조 만족에 토큰을 태움). → 1패스는 문법 없이 자유서술로 추론하고, 2패스는
   그 서술에서 판정만 문법 강제로 '추출'한다.
2. Chain-of-Verification(factored, CoVe): 초안 주장 → 독립 검증질문 생성 → 각 질문을
   원주장과 격리된 새 프롬프트에서 답 → 상호확증률로 확실/불확실. entity 정확도를
   17%→70%로 끌어올린 방식. 격리(factored)가 작은 모델에서 특히 중요.
3. 신뢰도 융합: 평균 logprob(1차·zero-shot 최강) + 서술적 확률(보조) + CoVe 확증률을
   합쳐 확실/불확실/insufficient_evidence. 하나라도 없으면 그 신호는 빠지고 나머지로 판단.

전부 Runtime을 거치며(감사), StubBackend로 단위검증 가능.
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass, field

from .grammar import verdict_schema, parse_json_lenient

# CoVe 검증질문 생성 스키마(평평·얕게).
_VQ_SCHEMA = {
    "type": "object",
    "properties": {"questions": {"type": "array", "items": {"type": "string"}}},
    "required": ["questions"],
    "additionalProperties": False,
}

_PROB_RE = re.compile(r"(?:확률|probability)[^\d]{0,12}(\d{1,3})", re.I)


def _verbalized_prob(text: str) -> float | None:
    """자유서술 끝의 '정답 확률: NN' 한 줄에서 0~1 값 추출(없으면 None).

    작은 모델은 단순 '확률(0~100)' 표현이 최선 — few-shot/순위매김은 오히려 악화.
    """
    m = None
    for m in _PROB_RE.finditer(text or ""):
        pass                                  # 마지막 매치(결론부) 사용
    if not m:
        return None
    v = int(m.group(1))
    return max(0.0, min(1.0, v / 100.0))


def _p_from_logprob(mean_logprob: float | None) -> float | None:
    """평균 토큰 logprob → 기하평균 토큰확률 ∈ (0,1] (신뢰도 프록시)."""
    if mean_logprob is None:
        return None
    try:
        return math.exp(mean_logprob)
    except OverflowError:
        return 0.0


@dataclass
class Judgment:
    verdict: str                     # '확실' | '불확실' | 'insufficient_evidence'
    confidence: float                # 융합 신뢰도 0~1
    evidence: str = ""
    signals: dict = field(default_factory=dict)   # 개별 신호(logprob/verbalized/cove)

    def certain(self) -> bool:
        return self.verdict == "확실"


def reason(runtime, question: str, context: str, max_tokens: int = 320) -> tuple[str, float | None]:
    """패스 1 — 문법 없이 자유서술 추론(Plan-and-Solve + 서술적 확률로 마무리).

    반환: (추론텍스트, 평균 logprob). logprob은 판정 스팬 신뢰도의 1차 신호.
    """
    prompt = (
        "너는 OSINT 분석가다. 먼저 확인할 점을 나열한 뒤 근거만으로 단계적으로 추론하라. "
        "근거에 없는 것은 지어내지 마라. 마지막 줄에 반드시 "
        "'정답 확률: NN'(0~100 정수)만 적어라.\n\n"
        f"[근거]\n{context}\n\n[질문] {question}\n[추론]\n")
    return runtime.generate_conf("reason", prompt, max_tokens=max_tokens,
                                 temperature=0.3)


def extract_verdict(runtime, reasoning: str, question: str) -> dict:
    """패스 2 — 자유서술에서 판정만 문법 강제로 추출(형식세 회피).

    reasoning을 그대로 두고 '요약/추출'만 시킨다 — 여기서 새로 추론하지 않는다.
    """
    prompt = (
        "아래 분석에서 결론만 뽑아 JSON으로 만들어라. 새로 추론하지 말고 분석 내용만 반영하라. "
        "근거가 부족하면 verdict를 'insufficient_evidence'로.\n\n"
        f"[질문] {question}\n[분석]\n{reasoning}\n[JSON] ")
    raw = runtime.generate("extract", prompt, max_tokens=200, temperature=0.1,
                           json_schema=verdict_schema())
    obj = parse_json_lenient(raw) or {}
    return {"evidence": obj.get("evidence", ""),
            "verdict": obj.get("verdict", "insufficient_evidence"),
            "confidence": obj.get("confidence", 0)}


def cove_verify(runtime, claim: str, context: str, max_q: int = 3) -> dict:
    """factored Chain-of-Verification — 각 검증질문을 격리 프롬프트에서 답해 확증률 산출.

    반환 {"ratio": 0~1, "n": 검증수, "supported": 지지수}. n=0이면 ratio=None.
    """
    vraw = runtime.generate(
        "cove-plan",
        ("다음 주장을 검증할 독립적인 사실확인 질문을 만들어라(주장을 반복하지 말 것). "
         f"최대 {max_q}개.\n주장: {claim}\n[JSON] "),
        max_tokens=180, temperature=0.2, json_schema=_VQ_SCHEMA)
    qs = (parse_json_lenient(vraw) or {}).get("questions", []) or []
    qs = [q for q in qs if isinstance(q, str) and q.strip()][:max_q]
    if not qs:
        return {"ratio": None, "n": 0, "supported": 0}
    supported = 0
    for q in qs:
        # 격리: 원주장을 보여주지 않고 근거만으로 독립 답변 → 자기 앵무새 방지.
        ans = runtime.generate(
            "cove-check",
            ("아래 근거만으로 질문에 사실만 간단히 답하라. 근거에 없으면 '모름'.\n"
             f"[근거]\n{context}\n[질문] {q}\n[답] "),
            max_tokens=120, temperature=0.1)
        low = (ans or "").strip().lower()
        if low and "모름" not in low and "unknown" not in low and "don't know" not in low:
            supported += 1
    return {"ratio": supported / len(qs), "n": len(qs), "supported": supported}


def fuse_confidence(logprob_p: float | None, verbalized: float | None,
                    cove_ratio: float | None, spread: float | None = None,
                    certain_threshold: float = 0.6) -> tuple[str, float, dict]:
    """신호 융합 → (verdict, 신뢰도, 신호표).

    규칙(보수적 — 지어내기보다 기권):
    - 사용 가능한 신호만 평균해 fused 산출.
    - 신호가 하나도 없으면 insufficient_evidence.
    - CoVe가 강하게 반증(ratio<0.34)이면 확실 불가.
    - 샘플 분산(spread)이 크면 확실 불가.
    - fused ≥ threshold 이고 반증/분산 위배 없을 때만 '확실', 아니면 '불확실'.
    """
    signals = {}
    vals = []
    if logprob_p is not None:
        signals["logprob"] = round(logprob_p, 4); vals.append(logprob_p)
    if verbalized is not None:
        signals["verbalized"] = round(verbalized, 4); vals.append(verbalized)
    if cove_ratio is not None:
        signals["cove"] = round(cove_ratio, 4); vals.append(cove_ratio)
    if spread is not None:
        signals["spread"] = round(spread, 4)
    if not vals:
        return "insufficient_evidence", 0.0, signals
    fused = sum(vals) / len(vals)
    blocked = False
    if cove_ratio is not None and cove_ratio < 0.34:      # 검증 다수 실패
        blocked = True
    if spread is not None and spread > 0.5:               # 표본 이견 큼
        blocked = True
    verdict = "확실" if (fused >= certain_threshold and not blocked) else "불확실"
    return verdict, round(fused, 4), signals


def judge(runtime, question: str, context: str, do_cove: bool = True) -> Judgment:
    """전 파이프라인 — reason→extract→(CoVe)→융합. 확실/불확실/insufficient_evidence.

    이것이 ARTES의 판정 진입점(기본): 확실은 여러 독립 신호가 합의할 때만 발급된다.
    더 강한 다표본·의미엔트로피·p(True)·컨포멀 판정은 judge_calibrated()를 쓴다.
    """
    reasoning, mean_lp = reason(runtime, question, context)
    ex = extract_verdict(runtime, reasoning, question)
    if ex["verdict"] == "insufficient_evidence":
        return Judgment("insufficient_evidence", 0.0, ex.get("evidence", ""),
                        {"extract": "insufficient"})
    verb = _verbalized_prob(reasoning)
    lp_p = _p_from_logprob(mean_lp)
    cove = {"ratio": None, "n": 0, "supported": 0}
    if do_cove:
        claim = ex.get("evidence") or reasoning[:200]
        cove = cove_verify(runtime, claim, context)
    verdict, conf, signals = fuse_confidence(lp_p, verb, cove["ratio"])
    signals["cove_detail"] = cove
    signals["model_verdict"] = ex["verdict"]
    return Judgment(verdict, conf, ex.get("evidence", ""), signals)


# ─────────────────────────────────────────────────────────────────────────────
# 증분 10 — 교정된 다신호 판정(judge_calibrated).
# 다표본 추론 → 의미 엔트로피/자기일관성 + p(True) + (선택)GenRM + min-logprob 을
# 로지스틱 융합(미적합 시 평균 폴백)하고, (선택)분할 컨포멀로 기권을 보장.
# 산술평균의 약점(강신호가 약신호로 끌려감)을 융합이 교정, 작화는 의미엔트로피가 잡는다.
# ─────────────────────────────────────────────────────────────────────────────
def sample_reasonings(runtime, question: str, context: str, n: int = 5,
                      temperature: float = 0.9) -> list[tuple[str, float | None]]:
    """N개 자유서술 추론 표본(의미 엔트로피·자기일관성용). 각 (텍스트, 평균 logprob)."""
    out = []
    for _ in range(n):
        r, lp = reason(runtime, question, context, max_tokens=280)
        out.append((r, lp))
    return out


def _model_equiv(runtime):
    """두 답이 같은 의미인지 모델로 판정하는 equiv 클로저(의미 군집용)."""
    def eq(a: str, b: str) -> bool:
        out = runtime.generate(
            "sem-equiv",
            ("두 답이 같은 결론을 말하는가? yes/no로만.\n"
             f"[A] {a[:200]}\n[B] {b[:200]}\n[답] "),
            max_tokens=4, temperature=0.0)
        return "yes" in (out or "").lower() or "네" in (out or "")
    return eq


def judge_calibrated(runtime, question: str, context: str, n_samples: int = 5,
                     use_genrm: bool = False, use_model_equiv: bool = False,
                     fuser=None, conformal_threshold: float | None = None) -> Judgment:
    """교정된 다신호 판정 — ARTES 강판정 진입점.

    신호: 1-semantic_entropy(자기일관성), 평균 logprob→확률, 서술확률, p(True),
    (선택)GenRM p_yes. LogisticFuser로 융합(fuser 미적합이면 평균). conformal_threshold가
    주어지면 컨포멀로 기권 결정(비적합점수 = 1 - fused).
    """
    from . import calibrate as C

    samples = sample_reasonings(runtime, question, context, n_samples)
    texts = [t for t, _ in samples]
    lps = [lp for _, lp in samples]
    # 대표 추론(첫 표본)으로 판정 추출.
    ex = extract_verdict(runtime, texts[0], question)
    if ex["verdict"] == "insufficient_evidence":
        return Judgment("insufficient_evidence", 0.0, ex.get("evidence", ""),
                        {"extract": "insufficient"})

    equiv = _model_equiv(runtime) if use_model_equiv else None
    sem_ent = C.semantic_entropy(texts, equiv)
    agree = C.agreement_rate(texts, equiv)
    consistency = 1.0 - sem_ent                     # 높을수록 확신

    valid_lp = [_p_from_logprob(lp) for lp in lps if lp is not None]
    lp_p = sum(valid_lp) / len(valid_lp) if valid_lp else None
    verb = _verbalized_prob(texts[0])
    ptrue = C.p_true(runtime, question, ex.get("evidence", "") or texts[0][:160], context, texts)
    pyes = C.genrm_pyes(runtime, ex.get("evidence") or question, context) if use_genrm else None

    # 특징 벡터(순서 고정) — 없는 신호는 중립 0.5로 대체하되 신호표엔 실제값만.
    feats = [consistency,
             lp_p if lp_p is not None else 0.5,
             verb if verb is not None else 0.5,
             ptrue,
             pyes if pyes is not None else 0.5]
    fused = (fuser or C.LogisticFuser()).predict(feats)

    signals = {"semantic_entropy": sem_ent, "agreement": agree,
               "consistency": round(consistency, 4),
               "logprob_p": round(lp_p, 4) if lp_p is not None else None,
               "verbalized": verb, "p_true": ptrue, "genrm_pyes": pyes,
               "fused": round(fused, 4), "model_verdict": ex["verdict"]}

    # 판정: 컨포멀(보장) 우선, 없으면 임계 + 작화·이견 가드.
    if conformal_threshold is not None:
        nonconf = 1.0 - fused
        certain = C.conformal_decide(nonconf, conformal_threshold)
        signals["nonconformity"] = round(nonconf, 4)
        signals["conformal_threshold"] = conformal_threshold
        verdict = "확실" if certain else "불확실"
    else:
        blocked = sem_ent > 0.66 or agree < 0.5     # 표본 의미가 크게 갈림
        verdict = "확실" if (fused >= 0.6 and not blocked) else "불확실"
    return Judgment(verdict, round(fused, 4), ex.get("evidence", ""), signals)


# ── 체크리스트 분해 + 근거 인용 강제(evidence-grounded judging) ──
_CHECK_SCHEMA = {
    "type": "object",
    "properties": {
        "reasoning": {"type": "string"},
        "present": {"type": "boolean"},
        "evidence_id": {"type": "integer"},
    },
    "required": ["reasoning", "present", "evidence_id"],
    "additionalProperties": False,
}


def checklist_verify(runtime, claim: str, evidence: list[str],
                     checklist: list[str]) -> dict:
    """체크리스트 분해 판정 — 각 항목을 격리 검증하고 근거 인용(evidence_id)을 강제.

    evidence: 관측 근거 배열(인덱스가 evidence_id). checklist: 확인할 신호 질문들.
    인용이 실제 근거 인덱스가 아니면 그 항목은 무효(작화 억제 — 근거 없는 결론 폐기).
    반환 {"items":[{signal,present,evidence_id,valid}], "supported": 유효지지수}.
    """
    from .grammar import parse_json_lenient
    ev_text = "\n".join(f"[{i}] {e}" for i, e in enumerate(evidence))
    items = []
    supported = 0
    for q in checklist:
        raw = runtime.generate(
            "checklist",
            ("아래 관측 근거만으로 이 조건이 충족되는지 판정하라. 충족되면 present=true와 "
             "그 근거의 번호를 evidence_id로. 근거가 없으면 present=false.\n"
             f"[근거]\n{ev_text}\n[조건] {q}\n[주장] {claim}\n[JSON] "),
            max_tokens=140, temperature=0.1, json_schema=_CHECK_SCHEMA)
        obj = parse_json_lenient(raw) or {}
        present = bool(obj.get("present"))
        eid = obj.get("evidence_id", -1)
        valid = present and isinstance(eid, int) and 0 <= eid < len(evidence)
        if valid:
            supported += 1
        items.append({"signal": q, "present": present, "evidence_id": eid,
                      "valid": valid})
    return {"items": items, "supported": supported, "total": len(checklist)}


# ─────────────────────────────────────────────────────────────────────────────
# 적대적 자기검증(§3, 3권 교차검증의 극한) — 기존 계층 유지.
# 주장을 검사 AI가 **반박**하게 한다: "틀렸다면 왜? 반증은? 데이터에서만."
# 반박이 데이터로 뒷받침되면 원 주장을 강등. 약한 AI 여러 개의 적대적 합의가
# 강한 AI 하나보다 환각이 적다 — 지휘자-일꾼(스웜)과 맞물린다. (증분 9의 CoVe/융합과
# 상호보완: CoVe는 주장 확증률을, 이쪽은 적대적 반증을 담당.)
# ─────────────────────────────────────────────────────────────────────────────
_VERDICT_SCHEMA = {
    "type": "object",
    "properties": {
        "verdict": {"type": "string", "enum": ["반증 있음", "반증 없음"]},
        "reason": {"type": "string"},
    },
    "required": ["verdict", "reason"],
    "additionalProperties": False,
}


@dataclass
class VerifyResult:
    upheld: bool
    verdict: str
    reason: str
    used_ai: bool = True

    def to_dict(self):
        return {"upheld": self.upheld, "verdict": self.verdict,
                "reason": self.reason, "used_ai": self.used_ai}


def verify_claim(runtime, claim: str, context: str) -> VerifyResult:
    prompt = (
        "너는 반대심문 검사 AI다. 아래 주장을 **반박**하라. 오직 '데이터' 안의 사실로만 "
        "반증을 찾아라. 데이터가 주장을 반증하지 못하면 '반증 없음'이라고 판정하라. "
        "지어내지 마라.\n\n"
        f"[주장] {claim}\n\n[데이터]\n{context}\n\n[판정 JSON] ")
    raw = runtime.generate("verify", prompt, max_tokens=200, temperature=0.0,
                           json_schema=_VERDICT_SCHEMA)
    obj = parse_json_lenient(raw) or {}
    verdict = obj.get("verdict", "반증 없음")
    reason = str(obj.get("reason", "")).strip()
    upheld = verdict != "반증 있음"
    return VerifyResult(upheld=upheld, verdict=verdict, reason=reason)


def verify_same_person(runtime, graph, edge) -> VerifyResult:
    """동일인 간선을 적대 검증. 반증되면 신뢰도 강등(간선을 직접 수정)."""
    a = graph.get(edge.src); b = graph.get(edge.dst)
    if not a or not b:
        return VerifyResult(True, "반증 없음", "대상 없음", used_ai=False)
    ctx_lines = []
    for ent in (a, b):
        ctx_lines.append(f"[{ent.type.label_ko()}] {ent.value} "
                         f"({'확실' if ent.certainty.value=='confirmed' else '불확실'})")
        for nb in graph.neighbors(ent.key):
            ctx_lines.append(f"  └ {nb.type.label_ko()}: {nb.value}")
    claim = f"{a.value} 와 {b.value} 는 동일인이다(신뢰 {edge.confidence})"
    result = verify_claim(runtime, claim, "\n".join(ctx_lines[:120]))
    if not result.upheld and edge.certainty.value != "confirmed":
        from ..core.model import Evidence
        edge.confidence = round((edge.confidence or 0.5) * 0.5, 4)
        edge.evidence.append(Evidence("자기검증", f"적대 반박: {result.reason[:120]}"))
    return result
