"""용도 1 — 내부 해석층(아키텍처 7단계에서만).

규율:
- 사실(개수·핵심 노드·동일인 군집)은 **코드로** 뽑는다(AI 0회).
- AI는 그 사실을 자연어로 '서술'만 한다. 서술이 언급한 값이 그래프에 없으면
  그 문장은 폐기(교차검증). 사실=확실, AI 서술=불확실로 라벨.
- 동일인/숨은연결은 resolve.py(코드)가 이미 신뢰 하한과 함께 만든다 — 해석층은
  그걸 읽어 요약할 뿐, 새 연결을 지어내지 않는다.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from ..core.model import Graph, EntityType, Certainty
from ..core.resolve import EntityResolver


@dataclass
class Interpretation:
    facts: dict = field(default_factory=dict)
    same_person: list = field(default_factory=list)
    narrative: str = ""
    narrative_certainty: str = "unconfirmed"
    used_ai: bool = False

    def to_dict(self):
        return {"facts": self.facts, "same_person": self.same_person,
                "narrative": self.narrative,
                "narrative_certainty": self.narrative_certainty,
                "used_ai": self.used_ai}


def interpret(graph: Graph, runtime=None, run_resolver: bool = True) -> Interpretation:
    if run_resolver:
        EntityResolver().correlate(graph)      # 코드로 동일인 간선 생성/보강

    # --- 사실(코드) ---
    deg: dict[str, int] = {}
    for e in graph.edges:
        deg[e.src] = deg.get(e.src, 0) + 1
        deg[e.dst] = deg.get(e.dst, 0) + 1
    top = sorted(graph.entities, key=lambda e: -deg.get(e.key, 0))[:8]
    by_type: dict[str, int] = {}
    for e in graph.entities:
        by_type[e.type.label_ko()] = by_type.get(e.type.label_ko(), 0) + 1

    same_person = []
    for edge in graph.edges:
        if edge.relation in ("동일인", "동일인?"):
            same_person.append({
                "a": edge.src, "b": edge.dst, "relation": edge.relation,
                "certainty": edge.certainty.value, "confidence": edge.confidence,
                "why": edge.evidence[0].detail if edge.evidence else "",
            })

    # 종합 사실(코드): 발자국·타임라인·셀렉터·활동 시간대.
    from ..core import timeline as _tl, selectors as _sel, negative as _neg
    accounts = [e for e in graph.entities if e.type is EntityType.ACCOUNT]
    footprint = _neg.footprint_size({a.value for a in accounts},
                                    {a.value for a in accounts})
    tl = _tl.build_timeline(graph)
    hours = [ev["when"].hour for ev in _tl.collect_events(graph)
             if ev["when"].hour or ev["when"].minute]
    activity = _tl.activity_timezone(hours) if len(hours) >= 5 else {"applicable": False}

    facts = {
        "summary": graph.stats(),
        "by_type": by_type,
        "key_nodes": [{"value": e.value, "type": e.type.label_ko(),
                       "degree": deg.get(e.key, 0),
                       "certainty": e.certainty.value} for e in top],
        "footprint": footprint,
        "timeline": tl[:20],
        "top_selectors": _sel.extract_selectors(graph)[:8],
        "activity": activity,
        "tainted": [e.value for e in graph.entities if e.attrs.get("tainted")],
    }
    result = Interpretation(facts=facts, same_person=same_person)

    # --- AI 서술(선택, 교차검증) ---
    if runtime is not None:
        ctx = _facts_text(facts, same_person)
        prompt = (
            "너는 OSINT 그래프 요약기다. 아래 사실만 근거로 한국어 3~5문장 요약을 써라. "
            "사실에 없는 값·연결을 추가하지 마라.\n\n"
            f"[사실]\n{ctx}\n\n[요약] ")
        raw = runtime.generate("interpret", prompt, max_tokens=220, temperature=0.2).strip()
        result.narrative = _verify(raw, graph)
        result.used_ai = True
    return result


def _facts_text(facts, same_person) -> str:
    lines = [f"엔티티 {facts['summary']['entities']}개, 간선 {facts['summary']['edges']}개 "
             f"(확실 {facts['summary']['confirmed']}, 불확실 {facts['summary']['unconfirmed']})",
             "타입별: " + ", ".join(f"{k} {v}" for k, v in facts["by_type"].items()),
             "핵심 노드: " + ", ".join(f"{n['value']}({n['type']},연결 {n['degree']})"
                                    for n in facts["key_nodes"])]
    fp = facts.get("footprint", {})
    if fp:
        lines.append(f"발자국: 계정 {fp.get('present',0)}개({fp.get('bucket','')}) — 규모 파악")
    if facts.get("timeline"):
        lines.append("타임라인: " + "; ".join(
            f"{t['date']} {t['entity']}" for t in facts["timeline"][:6]))
    if facts.get("top_selectors"):
        lines.append("피벗 셀렉터: " + ", ".join(
            f"{s['kind']}={s['selector']}" for s in facts["top_selectors"][:5]))
    act = facts.get("activity", {})
    if act.get("applicable"):
        lines.append(f"활동 시간대(불확실): UTC{act['utc_offset_est']:+d} 추정")
    if facts.get("tainted"):
        lines.append(f"오염 표시(재평가 필요): {len(facts['tainted'])}건")
    if same_person:
        parts = []
        for s in same_person[:10]:
            cert = "확실" if s["certainty"] == "confirmed" else "불확실"
            conf = "" if s["confidence"] is None else f" {s['confidence']}"
            parts.append(f"{s['a']}~{s['b']} [{cert}{conf}]")
        lines.append("동일인 후보: " + "; ".join(parts))
    return "\n".join(lines)


def _verify(text: str, graph: Graph) -> str:
    """AI 서술에서 근거 없는 식별자를 포함한 문장은 버린다."""
    values = {e.value.casefold() for e in graph.entities}
    kept = []
    for sent in re.split(r"(?<=[.!?。])\s+|\n", text):
        toks = re.findall(r"[\w.\-+]+@[\w.\-]+\.\w+|https?://\S+", sent)
        if all(t.casefold() in values for t in toks):
            kept.append(sent)
    return " ".join(s for s in kept if s.strip()).strip()
