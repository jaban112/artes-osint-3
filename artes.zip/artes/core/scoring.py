"""후보 신뢰도 자동 채점(증분 36) — '이 후보가 대상 본인일 확신도'를 점수화.

지금까지 결과는 확실/불확실 두 통에 담기만 했다. 여기서 각 후보(계정·아이디·이메일·전화)를
'대상 본인일 확신도 0~1'로 채점해 순위를 준다. AI 없이 코드로만(결정적) — 씨앗과의 강한
교차신호(같은 생일·같은 이메일/전화·같은 프로필 사진·교차 핸들·확인여부·이름일치)로 계산.
이게 'AI 판정 실패해도 되는' 결정적 동일인 판정도 겸한다.
"""
from __future__ import annotations

from collections import defaultdict, deque

from .model import EntityType, Certainty

# 강한 연결 관계(같은 사람으로 이어주는 간선)
_STRONG_REL = {"가진 계정", "동일인", "동일인?", "검색 발견 계정", "연결 계정",
               "커밋한 GitHub 계정", "Gravatar 핸들", "Matrix 연결", "같은 이메일",
               "같은 전화", "생년월일", "노출됨", "노출됨(LeakCheck Pro)"}
# 강한 식별자 타입(공유하면 동일인 신호 강함)
_ID_TYPES = {EntityType.EMAIL, EntityType.PHONE, EntityType.DOB}


def score_targets(graph, seed_keys, top: int = 40) -> list[dict]:
    """씨앗 기준으로 각 엔티티의 '대상 본인 확신도' 채점 → 내림차순 목록."""
    seeds = set(seed_keys)
    ents = {e.key: e for e in graph.entities}

    # 인접(전체 간선) + 강한 간선 인접
    adj = defaultdict(list)
    strong_adj = defaultdict(set)
    for e in graph.edges:
        adj[e.src].append(e.dst); adj[e.dst].append(e.src)
        if e.relation in _STRONG_REL or e.certainty == Certainty.CONFIRMED:
            strong_adj[e.src].add(e.dst); strong_adj[e.dst].add(e.src)

    # 씨앗에서 강한 간선으로 BFS → 거리(핵심군)
    dist = {k: 0 for k in seeds if k in ents}
    dq = deque(dist)
    while dq:
        k = dq.popleft()
        for nb in strong_adj.get(k, ()):
            if nb not in dist:
                dist[nb] = dist[k] + 1
                dq.append(nb)

    # 씨앗군이 공유하는 식별자(이메일·전화·생일)·이미지 해시 수집
    seed_ids = {k for k in dist if k in ents and ents[k].type in _ID_TYPES}
    seed_hashes = {ents[k].attrs.get("image_phash") for k in dist
                   if k in ents and ents[k].attrs.get("image_phash")}
    seed_names = {ents[k].value.lower() for k in seeds if ents.get(k) and ents[k].type == EntityType.NAME}

    out = []
    for ent in graph.entities:
        if ent.key in seeds:
            continue
        d = dist.get(ent.key)
        if d is None:
            continue                              # 씨앗과 강하게 안 이어짐 → 대상 후보 아님
        reasons = []
        s = max(0.0, 0.62 - 0.16 * (d - 1))       # 1홉≈0.62, 2홉≈0.46, 3홉≈0.30
        if d == 1:
            reasons.append("씨앗에 직접 연결")
        if ent.certainty == Certainty.CONFIRMED:
            s += 0.12; reasons.append("확인된 존재")
        # 같은 식별자(이메일/전화/생일) 공유 → 강함
        if any(nb in seed_ids for nb in adj.get(ent.key, ())):
            s += 0.28; reasons.append("같은 이메일/전화/생일 공유")
        # 같은 프로필 사진
        ph = ent.attrs.get("image_phash")
        if ph and ph in seed_hashes:
            s += 0.34; reasons.append("같은 프로필 사진")
        # 이름 일치(계정 표시이름이 씨앗 이름과 겹침)
        disp = (ent.attrs.get("display") or ent.attrs.get("name") or "").lower()
        if disp and any(n in disp or disp in n for n in seed_names if n):
            s += 0.12; reasons.append("이름 일치")
        # 이름 추정 순열인데 코로보 없음 → 감점
        if ent.attrs.get("variant") and s < 0.5:
            s -= 0.18; reasons.append("이름 추정 후보(미확증)")
        s = max(0.0, min(0.99, s))
        out.append({"key": ent.key, "type": ent.type.name, "value": ent.value,
                    "score": round(s, 2), "reasons": reasons})

    out.sort(key=lambda r: r["score"], reverse=True)
    return out[:top]


def promote_confident(graph, seed_keys, threshold: float = 0.75) -> int:
    """확신도 높은 불확실 후보를 확인(CONFIRMED)으로 승격 — AI 없이 결정적 판정. 반환=승격 수."""
    n = 0
    ranked = score_targets(graph, seed_keys, top=200)
    by_key = {r["key"]: r for r in ranked}
    for ent in graph.entities:
        r = by_key.get(ent.key)
        if r and r["score"] >= threshold and ent.certainty != Certainty.CONFIRMED:
            ent.certainty = Certainty.CONFIRMED
            ent.attrs["confidence_score"] = r["score"]
            n += 1
        elif r:
            ent.attrs.setdefault("confidence_score", r["score"])
    return n
