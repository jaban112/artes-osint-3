"""유사도 엔진 — 7권 J1·J2를 한 기계로 재사용.

MinHash 서명 + 지역 민감 해싱(후보) + Clopper–Pearson 신뢰**구간**(점추정 아님).
같은 기계를 이름·핸들·문체(char n-gram)·팔로워 집합·bio 어디에나 쓴다 —
"압축된 서명 위에서 유사도 검색 + 신뢰도 보증"(7권 §8 K2)의 실체.

핵심(J2): 슬롯 일치 수 M ~ Binomial(k, J) 이므로, 참 Jaccard J의 CP 구간을 그대로
발급한다. 유사도는 확률 추정이고, 그 신뢰도는 보증서다.
"""
from __future__ import annotations

import hashlib
import re
from collections import defaultdict

from .warrant import cp_lower, cp_interval

_MERSENNE = (1 << 61) - 1


def shingles(s: str, k: int = 3) -> set[str]:
    s = re.sub(r"\s+", "", (s or "").casefold())
    if len(s) < k:
        return {s} if s else set()
    return {s[i:i + k] for i in range(len(s) - k + 1)}


def char_ngrams(text: str, n: int = 3) -> set[str]:
    t = re.sub(r"\s+", " ", (text or "").casefold()).strip()
    if len(t) < n:
        return {t} if t else set()
    return {t[i:i + n] for i in range(len(t) - n + 1)}


def word_set(text: str) -> set[str]:
    return set(re.findall(r"\w+", (text or "").casefold()))


def _h(token: str) -> int:
    return int.from_bytes(hashlib.blake2b(token.encode("utf-8"), digest_size=8).digest(), "big")


def _lcg(seed: int):
    x = seed & 0xFFFFFFFF
    while True:
        x = (1103515245 * x + 12345) & 0x7FFFFFFF
        yield x


class MinHash:
    def __init__(self, num_perm: int = 64, k: int = 3, seed: int = 1):
        self.num_perm = num_perm
        self.k = k
        rng = _lcg(seed)
        self.a = [next(rng) % _MERSENNE or 1 for _ in range(num_perm)]
        self.b = [next(rng) % _MERSENNE for _ in range(num_perm)]

    def sign_tokens(self, tokens: set[str]) -> tuple[int, ...]:
        if not tokens:
            return tuple([0] * self.num_perm)
        hs = [_h(x) for x in tokens]
        return tuple(min((a * hv + b) % _MERSENNE for hv in hs)
                     for a, b in zip(self.a, self.b))

    def signature(self, s: str) -> tuple[int, ...]:
        return self.sign_tokens(shingles(s, self.k))

    @staticmethod
    def match_count(sa, sb) -> int:
        return sum(1 for x, y in zip(sa, sb) if x == y)

    @staticmethod
    def jaccard(sa, sb) -> float:
        return MinHash.match_count(sa, sb) / len(sa) if sa else 0.0


def jaccard_ci(sig_a, sig_b, alpha: float = 0.05) -> dict:
    """서명 두 개에서 참 Jaccard의 점추정과 CP 신뢰구간(J1·J2)."""
    k = len(sig_a)
    m = MinHash.match_count(sig_a, sig_b)
    lo, hi = cp_interval(m, k, alpha)
    return {"point": m / k if k else 0.0, "lower": lo, "upper": hi,
            "matches": m, "k": k, "confidence": round(1 - alpha, 3)}


class LSH:
    """밴딩 LSH — 근접중복 후보(전수 비교 회피). b·r = num_perm."""

    def __init__(self, bands: int = 16, rows: int = 4):
        self.bands, self.rows = bands, rows
        self.buckets: dict[tuple, set] = defaultdict(set)

    def add(self, key: str, sig) -> None:
        for bi in range(self.bands):
            band = sig[bi * self.rows:(bi + 1) * self.rows]
            self.buckets[(bi, band)].add(key)

    def candidate_pairs(self) -> set[tuple[str, str]]:
        pairs = set()
        for members in self.buckets.values():
            if len(members) < 2:
                continue
            ms = sorted(members)
            for i in range(len(ms)):
                for j in range(i + 1, len(ms)):
                    pairs.add((ms[i], ms[j]))
        return pairs
