"""지속 케이스 저장소(SQLite) — 일회성 스캔을 수사 플랫폼으로.

케이스가 누적된다: 저장·재오픈·병합·시간축 스냅샷 diff. 표준 sqlite3만 사용.
엔티티/간선은 조회용 테이블에, 전체 그래프는 스냅샷 JSON으로 이력 보존.
"""
from __future__ import annotations

import json
import sqlite3
import time
from pathlib import Path

from .model import Graph
from . import monitor


class CaseDB:
    def __init__(self, path: str | None = None):
        self.path = str(path) if path else str(Path.home() / ".artes" / "cases.db")
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(self.path)
        self.conn.execute("PRAGMA journal_mode=WAL")
        self._init()

    def _init(self):
        c = self.conn
        c.execute("""CREATE TABLE IF NOT EXISTS cases(
            name TEXT PRIMARY KEY, created REAL, updated REAL, graph TEXT)""")
        c.execute("""CREATE TABLE IF NOT EXISTS snapshots(
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, ts REAL, graph TEXT)""")
        c.execute("""CREATE TABLE IF NOT EXISTS entities(
            name TEXT, key TEXT, type TEXT, value TEXT, certainty TEXT,
            PRIMARY KEY(name, key))""")
        c.execute("CREATE INDEX IF NOT EXISTS ix_ent_val ON entities(value)")
        c.commit()

    def save(self, name: str, graph: Graph, snapshot: bool = True) -> None:
        now = time.time()
        gj = graph.to_json(indent=0)
        c = self.conn
        row = c.execute("SELECT created FROM cases WHERE name=?", (name,)).fetchone()
        created = row[0] if row else now
        c.execute("INSERT OR REPLACE INTO cases(name,created,updated,graph) VALUES(?,?,?,?)",
                  (name, created, now, gj))
        c.execute("DELETE FROM entities WHERE name=?", (name,))
        c.executemany("INSERT OR REPLACE INTO entities VALUES(?,?,?,?,?)",
                      [(name, e.key, e.type.value, e.value, e.certainty.value)
                       for e in graph.entities])
        if snapshot:
            c.execute("INSERT INTO snapshots(name,ts,graph) VALUES(?,?,?)", (name, now, gj))
        c.commit()

    def load(self, name: str) -> Graph | None:
        row = self.conn.execute("SELECT graph FROM cases WHERE name=?", (name,)).fetchone()
        return Graph.load_json(row[0]) if row else None

    def merge(self, name: str, graph: Graph) -> Graph:
        existing = self.load(name) or Graph()
        existing.merge(graph)
        self.save(name, existing)
        return existing

    def list_cases(self) -> list[dict]:
        rows = self.conn.execute(
            "SELECT name,created,updated,(SELECT COUNT(*) FROM entities e WHERE e.name=c.name) "
            "FROM cases c ORDER BY updated DESC").fetchall()
        return [{"name": r[0], "created": r[1], "updated": r[2], "entities": r[3]} for r in rows]

    def search(self, value_substr: str) -> list[dict]:
        rows = self.conn.execute(
            "SELECT name,type,value FROM entities WHERE value LIKE ? LIMIT 100",
            (f"%{value_substr}%",)).fetchall()
        return [{"case": r[0], "type": r[1], "value": r[2]} for r in rows]

    def history(self, name: str) -> list[float]:
        return [r[0] for r in self.conn.execute(
            "SELECT ts FROM snapshots WHERE name=? ORDER BY ts", (name,)).fetchall()]

    def diff_latest(self, name: str) -> dict | None:
        snaps = self.conn.execute(
            "SELECT graph FROM snapshots WHERE name=? ORDER BY ts DESC LIMIT 2",
            (name,)).fetchall()
        if len(snaps) < 2:
            return None
        new = Graph.load_json(snaps[0][0])
        old = Graph.load_json(snaps[1][0])
        return monitor.diff(old, new)

    def close(self):
        self.conn.close()
