"""선택적 키 경로 — 있으면 강화, 없으면 키 없이 그대로(증분 14).

원칙: ARTES의 기본은 키 불필요다. 키는 **선택적 부스터**다 — 있으면 유료/제한 소스를
열고, 없으면 해당 수집기는 조용히 skip(available()=False). 키는 절대 로깅·그래프·근거에
남기지 않는다(요청 URL/헤더에만 쓴다).

소스 순위: (1) 환경변수 ARTES_KEY_<SERVICE> (2) 서비스 표준 env 이름 (3) ~/.artes/keys.json.
"""
from __future__ import annotations

import json
import os

# 서비스 → 표준 환경변수 이름(대체 인식용).
_STD_ENV = {
    "shodan": "SHODAN_API_KEY",
    "hibp": "HIBP_API_KEY",
    "virustotal": "VT_API_KEY",
    "greynoise": "GREYNOISE_API_KEY",
    "abuseipdb": "ABUSEIPDB_API_KEY",
    "hunter": "HUNTER_API_KEY",
    "numverify": "NUMVERIFY_API_KEY",
    "securitytrails": "SECURITYTRAILS_API_KEY",
    "censys": "CENSYS_API_KEY",
    "intelx": "INTELX_API_KEY",
    "leakcheck": "LEAKCHECK_API_KEY",     # LeakCheck Pro(정식 키) — 메타데이터만 저장
    "github": "GITHUB_TOKEN",
    "openrouter": "OPENROUTER_API_KEY",   # 원격 큰 두뇌(GLM 등) 게이트웨이
    "zai": "ZAI_API_KEY",                 # Z.ai 직결(GLM 공식)
    "cerebras": "CEREBRAS_API_KEY",       # 가장 토큰 많은 무료(1M/일)
    "groq": "GROQ_API_KEY",               # 초고속 무료
    "gemini": "GEMINI_API_KEY",           # 구글 Gemini 무료
    # 증분 18: 현존 거의 모든 LLM 제공처의 표준 env 이름도 인식.
    "openai": "OPENAI_API_KEY",
    "anthropic": "ANTHROPIC_API_KEY",     # Claude(네이티브 /messages)
    "xai": "XAI_API_KEY",                 # Grok
    "mistral": "MISTRAL_API_KEY",
    "cohere": "COHERE_API_KEY",
    "zhipu": "ZHIPUAI_API_KEY",           # GLM 중국 본토
    "deepseek": "DEEPSEEK_API_KEY",
    "moonshot": "MOONSHOT_API_KEY",       # Kimi
    "sambanova": "SAMBANOVA_API_KEY",
    "together": "TOGETHER_API_KEY",
    "fireworks": "FIREWORKS_API_KEY",
    "deepinfra": "DEEPINFRA_API_KEY",
    "novita": "NOVITA_API_KEY",
    "hyperbolic": "HYPERBOLIC_API_KEY",
    "nebius": "NEBIUS_API_KEY",
    "nvidia": "NVIDIA_API_KEY",
    "perplexity": "PERPLEXITY_API_KEY",
    "ai21": "AI21_API_KEY",
    "lambda": "LAMBDA_API_KEY",
    "baseten": "BASETEN_API_KEY",
    "huggingface": "HF_TOKEN",
    "replicate": "REPLICATE_API_TOKEN",
    "ollama": "OLLAMA_HOST",              # 로컬(키 아님, base_url 힌트)
    "lmstudio": "LMSTUDIO_HOST",
    "localai": "LOCALAI_HOST",
}


class KeyStore:
    """키 조회 — env 우선, 파일 폴백. 키 값은 노출용 API를 두지 않는다."""

    def __init__(self, path: str | None = None):
        self.path = path or os.path.expanduser("~/.artes/keys.json")
        self._file: dict = {}
        self._load_file()

    def _load_file(self) -> None:
        try:
            with open(self.path, encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                self._file = {str(k).lower(): str(v) for k, v in data.items() if v}
        except Exception:
            self._file = {}

    def get(self, service: str) -> str | None:
        """키 값(내부용). 로깅 금지."""
        s = service.lower()
        v = os.environ.get(f"ARTES_KEY_{s.upper()}")
        if v:
            return v.strip()
        std = _STD_ENV.get(s)
        if std and os.environ.get(std):
            return os.environ[std].strip()
        return self._file.get(s)

    def has(self, service: str) -> bool:
        return bool(self.get(service))

    def status(self) -> dict:
        """서비스별 키 존재 여부(값은 절대 반환 안 함 — 존재 True/False만)."""
        services = sorted(set(_STD_ENV) | set(self._file))
        return {s: self.has(s) for s in services}

    def source_of(self, service: str) -> str:
        """키 출처(env/std-env/file/none) — 디버그용, 값은 노출 안 함."""
        s = service.lower()
        if os.environ.get(f"ARTES_KEY_{s.upper()}"):
            return "env(ARTES_KEY_*)"
        std = _STD_ENV.get(s)
        if std and os.environ.get(std):
            return f"env({std})"
        if s in self._file:
            return "file(~/.artes/keys.json)"
        return "none"


# 프로세스 전역 키스토어(수집기가 공유).
KEYS = KeyStore()


class KeyedCollector:
    """키 게이트 믹스인 — service 키가 있을 때만 available(). 없으면 엔진이 skip."""
    service: str = ""

    def available(self) -> bool:
        return KEYS.has(self.service)

    def api_key(self) -> str | None:
        return KEYS.get(self.service)
