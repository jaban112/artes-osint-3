"""라우터 — 타입별 수집기 선택 + 밴딧 우선순위(7권). 전부 일반 코드(AI 0회).

밴딧이 도구별 첫-히트 성공률을 학습해 조회 순서를 정한다(첫 유효결과 가속).
학습이 없으면(첫 실행) 원래 순서 그대로 — 후회 상계가 탐색을 보증.
"""
from __future__ import annotations

from typing import Iterable

from .model import EntityType
from ..collectors.base import Collector


class Router:
    def __init__(self, collectors: Iterable[Collector], bandit=None):
        self.collectors = list(collectors)
        self.bandit = bandit

    def route(self, entity_type: EntityType, value: str = "") -> list[Collector]:
        cols = [c for c in self.collectors
                if c.handles(entity_type) and c.available()]
        if self.bandit is not None and cols:
            ordered = self.bandit.order_for(entity_type.value, value,
                                            [c.name for c in cols])
            order = {name: i for i, name in enumerate(ordered)}
            cols.sort(key=lambda c: order.get(c.name, 0))
        return cols

    def route_all(self, entity_type: EntityType) -> list[Collector]:
        return [c for c in self.collectors if c.handles(entity_type)]
