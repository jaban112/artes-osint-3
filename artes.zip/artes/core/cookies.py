"""쿠키 저장소(증분 28) — 벽 안쪽 SNS 심층조회용 '본인 인증 세션 쿠키'.

키(KeyStore)와 같은 원칙: 값은 요청 헤더에만 쓰고 로깅·그래프·근거·배포에 절대 남기지 않는다.
~/.artes/cookies.json(권한 600) 또는 env ARTES_COOKIE_<SITE>에서 읽는다.

정직·법적 경계:
- 이건 '본인이 로그인한 본인 계정'의 쿠키다. 수사자가 자신의 인가된 계정으로만 쓴다.
- 플랫폼 ToS 위반 소지가 있고, 과도하면 그 계정이 정지될 수 있다(사용자 책임).
- ARTES는 프로필 공개성 메타(이름·바이오·팔로워수·링크·공개/인증 여부)까지만 다룬다.
  DM·비공개 콘텐츠·실시간 위치는 다루지 않는다(불변 원칙).
- 어떤 쿠키를 어디서 얻는지: COOKIE_GUIDE 참고.
"""
from __future__ import annotations

import json
import os
from pathlib import Path

_COOKIE_FILE = Path.home() / ".artes" / "cookies.json"

# 플랫폼별 '어떤 쿠키가 필요한가' 안내(브라우저 개발자도구 > Application > Cookies에서 복사).
COOKIE_GUIDE = {
    "instagram": "sessionid  (instagram.com 로그인 후)",
    "tiktok":    "sessionid  (tiktok.com 로그인 후)",
    "twitter":   "auth_token  (x.com 로그인 후)",
    "facebook":  "c_user 와 xs  (형식: 'c_user=...; xs=...')",
    "linkedin":  "li_at  (linkedin.com 로그인 후)",
    "naver":     "NID_AUT 와 NID_SES  (형식: 'NID_AUT=...; NID_SES=...')",
    "reddit":    "reddit_session  (reddit.com 로그인 후)",
    "google":    "GHunt 마스터쿠키(__Secure-1PSID 등) — 심층은 GHunt 도구 권장",
}


class CookieStore:
    def __init__(self):
        self._file: dict[str, str] = {}
        try:
            if _COOKIE_FILE.exists():
                self._file = json.loads(_COOKIE_FILE.read_text("utf-8"))
        except Exception:
            self._file = {}

    def get(self, site: str) -> str | None:
        s = (site or "").lower()
        env = os.environ.get(f"ARTES_COOKIE_{s.upper()}")
        if env:
            return env
        return self._file.get(s) or None

    def has(self, site: str) -> bool:
        return bool(self.get(site))

    def set(self, site: str, value: str) -> str:
        s = (site or "").lower()
        self._file[s] = value
        _COOKIE_FILE.parent.mkdir(parents=True, exist_ok=True)
        _COOKIE_FILE.write_text(json.dumps(self._file, ensure_ascii=False, indent=2), "utf-8")
        try:
            os.chmod(_COOKIE_FILE, 0o600)
        except OSError:
            pass
        return s

    def status(self) -> dict[str, bool]:
        sites = sorted(set(COOKIE_GUIDE) | set(self._file))
        return {s: self.has(s) for s in sites}


COOKIES = CookieStore()


class CookieCollector:
    """쿠키 게이트 믹스인 — site 쿠키가 있을 때만 available(). 없으면 엔진이 skip."""
    site: str = ""

    def available(self) -> bool:
        return COOKIES.has(self.site)

    def cookie(self) -> str | None:
        return COOKIES.get(self.site)
