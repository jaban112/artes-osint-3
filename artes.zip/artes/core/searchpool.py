"""검색엔진 풀 + 벤치마크(증분 30) — 100+ 엔진 커버·병렬·자동 랭킹.

'독립 범용엔진 100개'는 실존하지 않는다. 대신 SearXNG 공개 인스턴스(각각 구글·빙·브레이브·
얀덱스·Qwant·Mojeek 등 수십 upstream을 묶어 무키 JSON 제공) 다수 + 직접 엔진으로 실질 100+
커버. 어떤 인스턴스가 (a)살아있고 (b)고유 결과를 많이 주고 (c)유출 언급을 잘 표면화하는지
200라운드(인스턴스×프로브쿼리) 병렬 벤치마크로 측정해 상위권만 스캔에 쓴다.

정직: 벤치마크는 '엔진 수율'을 잰다(어느 검색엔진이 관련 결과를 더 준다). 유출 결과도 그 페이지
URL(검토용)까지 — 원문 자격증명은 수집·저장 안 함(불변). 인스턴스는 배포 시 살아있는지 재확인
필요(그게 벤치마크의 목적).
"""
from __future__ import annotations

import asyncio
import json
import re
import time
import urllib.parse
from pathlib import Path

from ..collectors.proc import get_text

_RANK_FILE = Path.home() / ".artes" / "search_engines.json"

# 공개 SearXNG 인스턴스 후보(각각 수십 upstream 엔진 집계). 살아있는지는 벤치마크가 판정.
SEARX_INSTANCES = [
    "https://searx.be", "https://searx.tiekoetter.com", "https://search.rhscz.eu",
    "https://baresearch.org", "https://priv.au", "https://search.inetol.net",
    "https://opnxng.com", "https://search.hbubli.cc", "https://searxng.site",
    "https://search.bus-hit.me", "https://s.trung.fun", "https://search.disroot.org",
    "https://ooglester.com", "https://search.mdosch.de", "https://searxng.world",
    "https://search.sapti.me", "https://paulgo.io", "https://northboot.xyz",
    "https://etsi.me", "https://search.demoniak.ch", "https://search.im-in.space",
    "https://searxng.ch", "https://search.privacyredirect.com", "https://searx.dresden.network",
    "https://search.rowie.at", "https://searx.tuxcloud.net", "https://searxng.brihx.fr",
    "https://search.gcomm.ch", "https://searx.stream", "https://xo.wtf",
    "https://searx.ox2.fr", "https://search.canine.tools", "https://searxng.online",
    "https://search.charliewhiskey.net", "https://search.url4irl.com", "https://searx.aleteoryx.me",
    "https://search.leptons.xyz", "https://search.indst.eu", "https://opnxng.com",
    "https://search.blitzw.in",
]

_LEAK_HINT = re.compile(r"paste|leak|breach|dump|combolist|stealer|pwn|유출|덤프", re.I)

_PROBE_QUERIES = [
    '"john smith" instagram',
    'test@example.com',
    '"admin" leak OR breach OR pastebin',
    'site:pastebin.com password',
    '"data breach" combolist',
]


def searx_url(inst: str, query: str) -> str:
    return f"{inst.rstrip('/')}/search?q={urllib.parse.quote(query)}&format=json"


def _parse_searx(txt: str) -> list[dict]:
    try:
        obj = json.loads(txt)
    except Exception:
        return []
    out = []
    for r in (obj or {}).get("results", []):
        if r.get("url"):
            out.append({"url": r["url"], "title": r.get("title", ""),
                        "snippet": r.get("content", "")})
    return out


async def _probe(inst: str, queries: list[str], timeout: float) -> dict:
    """한 인스턴스를 프로브쿼리들로 두드려 수율 측정."""
    t0 = time.monotonic()
    urls, leak, ok = set(), 0, False
    for q in queries:
        txt = await get_text(searx_url(inst, q), timeout=timeout,
                             headers={"User-Agent": "Mozilla/5.0 artes/1.0"})
        rows = _parse_searx(txt or "")
        if rows:
            ok = True
        for r in rows:
            urls.add(r["url"].rstrip("/"))
            if _LEAK_HINT.search((r.get("url", "") + " " + r.get("snippet", "")).lower()):
                leak += 1
    dt = round(time.monotonic() - t0, 2)
    # 점수: 고유결과 + 유출표면화 가중(×3). 살아있지 않으면 0.
    score = (len(urls) + leak * 3) if ok else 0
    return {"source": inst, "reachable": ok, "unique": len(urls),
            "leak_hits": leak, "latency": dt, "score": score}


async def benchmark(queries: list[str] | None = None, timeout: float = 8.0,
                    concurrency: int = 40, max_rounds: int = 200) -> list[dict]:
    """모든 인스턴스 × 프로브쿼리를 병렬 벤치마크 → 점수순 랭킹. 최대 max_rounds(인스턴스×쿼리)."""
    queries = queries or _PROBE_QUERIES
    # 라운드 예산: 인스턴스×쿼리 ≤ max_rounds 가 되도록 쿼리 수 조정.
    per = max(1, min(len(queries), max_rounds // max(1, len(SEARX_INSTANCES))))
    queries = queries[:per]
    sem = asyncio.Semaphore(concurrency)

    async def _one(inst):
        async with sem:
            try:
                return await _probe(inst, queries, timeout)
            except Exception:
                return {"source": inst, "reachable": False, "unique": 0,
                        "leak_hits": 0, "latency": 0.0, "score": 0}

    results = await asyncio.gather(*[_one(i) for i in dict.fromkeys(SEARX_INSTANCES)])
    results.sort(key=lambda r: r["score"], reverse=True)
    return results


def save_ranked(ranked: list[dict], top_k: int = 12) -> None:
    live = [r["source"] for r in ranked if r.get("reachable") and r.get("score", 0) > 0][:top_k]
    if not live:
        return
    _RANK_FILE.parent.mkdir(parents=True, exist_ok=True)
    _RANK_FILE.write_text(json.dumps({"instances": live}, ensure_ascii=False, indent=2), "utf-8")


def load_ranked(default_k: int = 10) -> list[str]:
    """벤치마크로 저장된 상위 인스턴스. 없으면 후보 앞부분."""
    try:
        if _RANK_FILE.exists():
            d = json.loads(_RANK_FILE.read_text("utf-8"))
            inst = d.get("instances") or []
            if inst:
                return inst
    except Exception:
        pass
    return list(dict.fromkeys(SEARX_INSTANCES))[:default_k]
