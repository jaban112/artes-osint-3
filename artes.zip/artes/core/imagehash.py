"""지각 해시(perceptual hash) — 같은/유사 이미지 자체 판정. 7권 유사도 해싱 계열.

같은 프로필 사진이 다른 계정에 쓰였는지 = 강한 동일인 근거(하드 신호에 준함).
키·외부 서비스 불필요, 순수 코드(이미지 디코드에 Pillow 필요; 없으면 해시 계산만 skip,
해밍 비교는 언제나 가능).

- dHash: 인접 픽셀 밝기 비교(64비트). 크기·압축에 강인.
- pHash: DCT 저주파(64비트). numpy 있으면.
해밍 거리 ≤ 임계면 '같은 사진'으로 본다.
"""
from __future__ import annotations


def _hex_to_bits(h: str) -> int:
    try:
        return int(h, 16)
    except (ValueError, TypeError):
        return -1


def hamming_hex(a: str, b: str) -> int:
    """두 해시 hex 문자열의 해밍 거리(비교는 항상 가능, Pillow 불필요)."""
    x, y = _hex_to_bits(a), _hex_to_bits(b)
    if x < 0 or y < 0:
        return 999
    return bin(x ^ y).count("1")


def dhash(path_or_img, size: int = 8) -> str | None:
    """dHash. 반환 hex(길이 size*size/4). Pillow 없으면 None."""
    img = _load_gray(path_or_img, size + 1, size)
    if img is None:
        return None
    px = list(img.getdata())
    w = size + 1
    bits = 0
    idx = 0
    for row in range(size):
        for col in range(size):
            left = px[row * w + col]
            right = px[row * w + col + 1]
            bits = (bits << 1) | (1 if left > right else 0)
            idx += 1
    return f"{bits:0{size*size//4}x}"


def phash(path_or_img, hash_size: int = 8, highfreq: int = 4) -> str | None:
    """pHash(DCT 저주파). numpy 필요. 없으면 dhash로 대체."""
    try:
        import numpy as np
    except Exception:
        return dhash(path_or_img)
    n = hash_size * highfreq
    img = _load_gray(path_or_img, n, n)
    if img is None:
        return None
    a = np.asarray(img, dtype=float)
    dct = _dct2(a, np)
    low = dct[:hash_size, :hash_size]
    med = np.median(low[1:, 1:]) if hash_size > 1 else np.median(low)
    bits = 0
    for v in low.flatten():
        bits = (bits << 1) | (1 if v > med else 0)
    return f"{bits:0{hash_size*hash_size//4}x}"


def _dct2(a, np):
    m = a.shape[0]
    k = np.arange(m)
    basis = np.cos(np.pi * (2 * k[:, None] + 1) * k[None, :] / (2 * m))
    return basis @ a @ basis.T


def phash_bytes(data: bytes) -> str | None:
    """바이트(다운로드한 이미지)에서 pHash. Pillow 없으면 None."""
    try:
        from PIL import Image
        import io
        return phash(Image.open(io.BytesIO(data)))
    except Exception:
        return None


def _load_gray(path_or_img, w: int, h: int):
    try:
        from PIL import Image
    except Exception:
        return None
    try:
        img = path_or_img if hasattr(path_or_img, "convert") else Image.open(path_or_img)
        return img.convert("L").resize((w, h))
    except Exception:
        return None
