"""문체·저자 판별 — 짧은 소셜 텍스트용 문자 n-그램(3~5) 특징(순수 코드, AI 0회).

연구 정리(증분 9): 트윗 길이의 짧은 텍스트에서는 Burrows Delta(함수어 빈도, 챕터급
길이 필요)보다 **문자 n-그램 TF-IDF + 선형분류**가 일관되게 강하다 — 문장부호·이모지·
대소문자·형태가 짧은 글에도 남기 때문. 여기선 학습 라벨 없이 쓰는 쌍대 유사도를 제공:
- authorship_similarity(a, b): 문자 3~5그램 TF-IDF 코사인(0~1). 동일저자 경향 신호.
- StyleClassifier: 라벨이 있으면 sklearn(char_wb 3-5 + LinearSVC), 없으면 미사용.

동일저자 '확실' 판정은 이 신호 하나로 내리지 않는다(동명이인/스타일 모방) — resolve의
융합 계층에서 등급 우도비로만 들어간다.
"""
from __future__ import annotations

import math
import re
from collections import Counter

_WS = re.compile(r"\s+")


def _norm(text: str) -> str:
    return _WS.sub(" ", (text or "").strip().lower())


def char_ngrams(text: str, lo: int = 3, hi: int = 5) -> Counter:
    """문자 n-그램(단어경계 포함) 빈도. 짧은 글의 스타일 지문."""
    t = _norm(text)
    if not t:
        return Counter()
    grams: Counter = Counter()
    for n in range(lo, hi + 1):
        if len(t) < n:
            continue
        for i in range(len(t) - n + 1):
            grams[t[i:i + n]] += 1
    return grams


def _tfidf(grams: Counter, df: Counter, n_docs: int) -> dict:
    out = {}
    total = sum(grams.values()) or 1
    for g, c in grams.items():
        idf = math.log((1 + n_docs) / (1 + df.get(g, 0))) + 1.0
        out[g] = (c / total) * idf
    return out


def _cosine(a: dict, b: dict) -> float:
    if not a or not b:
        return 0.0
    common = set(a) & set(b)
    num = sum(a[g] * b[g] for g in common)
    na = math.sqrt(sum(v * v for v in a.values())) or 1.0
    nb = math.sqrt(sum(v * v for v in b.values())) or 1.0
    return num / (na * nb)


def authorship_similarity(text_a: str, text_b: str, lo: int = 3, hi: int = 5) -> float:
    """두 텍스트의 문자 n-그램 TF-IDF 코사인(0~1). 짧은 글 동일저자 신호."""
    ga, gb = char_ngrams(text_a, lo, hi), char_ngrams(text_b, lo, hi)
    if not ga or not gb:
        return 0.0
    df: Counter = Counter()
    for g in set(ga):
        df[g] += 1
    for g in set(gb):
        df[g] += 1
    va = _tfidf(ga, df, 2)
    vb = _tfidf(gb, df, 2)
    return round(_cosine(va, vb), 4)


class StyleClassifier:
    """라벨 있는 저자판별 — sklearn(char_wb 3-5 + LinearSVC). 미설치면 available=False."""

    def __init__(self):
        self.model = None
        try:
            from sklearn.feature_extraction.text import TfidfVectorizer
            from sklearn.svm import LinearSVC
            from sklearn.pipeline import Pipeline
            self.model = Pipeline([
                ("tfidf", TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5))),
                ("clf", LinearSVC()),
            ])
        except Exception:
            self.model = None

    @property
    def available(self) -> bool:
        return self.model is not None

    def fit(self, texts: list[str], labels: list[str]) -> bool:
        if not self.available:
            return False
        self.model.fit(texts, labels)
        return True

    def predict(self, texts: list[str]) -> list[str]:
        if not self.available:
            return []
        return list(self.model.predict(texts))
