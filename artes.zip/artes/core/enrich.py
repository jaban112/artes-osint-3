"""능동 확장 유틸 — 순수 코드. 커버리지를 몇 배로.

- username_variants: 아이디 순열(jiwan123 → jiwan, jiwan_, jiwan.kim, kimjiwan …)
- email_candidates: 이름+도메인 → 이메일 후보(j.kim@, kimjiwan@ …)
- infer_name_from_email: 로컬파트 역산(j.kim → j kim)
- gravatar_url: 이메일 MD5 → 아바타(이메일→얼굴, 키 불필요)
"""
from __future__ import annotations

import hashlib
import re


def username_variants(username: str, max_variants: int = 20) -> list[str]:
    u = (username or "").strip()
    if not u:
        return []
    base = re.sub(r"\d+$", "", u)                  # 끝자리 숫자 제거
    core = re.sub(r"[._\-]", "", base).casefold()
    out = {u, base, core}
    seps = ["", "_", ".", "-"]
    # core를 두 조각으로 볼 수 있으면(이름/성) 뒤집기·구분자 삽입
    for sep in seps:
        out.add(f"{core}{sep}")
        out.add(f"{sep}{core}")
    # 흔한 접미 패턴
    for suf in ("", "1", "01", "123", "_", "official", "real", "the"):
        out.add(f"{core}{suf}")
        out.add(f"{suf}{core}")
    out = {v for v in (x.strip() for x in out) if 2 <= len(v) <= 30}
    ordered = [u] + sorted(out - {u})
    return ordered[:max_variants]


def _name_parts(name: str) -> list[str]:
    return [p for p in re.split(r"[\s._\-]+", (name or "").casefold()) if p]


def email_candidates(name: str, domain: str, max_candidates: int = 20) -> list[str]:
    parts = _name_parts(name)
    domain = (domain or "").strip().lstrip("@").casefold()
    if not parts or not domain:
        return []
    first = parts[0]
    last = parts[-1] if len(parts) > 1 else ""
    locals_ = {first}
    if last:
        locals_ |= {
            f"{first}{last}", f"{first}.{last}", f"{first}_{last}",
            f"{first[0]}{last}", f"{first[0]}.{last}", f"{last}{first}",
            f"{last}.{first}", f"{first}{last[0]}", last,
        }
    cands = [f"{lp}@{domain}" for lp in sorted(locals_) if lp]
    return cands[:max_candidates]


def infer_name_from_email(local_part: str) -> str | None:
    lp = re.sub(r"\d+", "", (local_part or "").split("@")[0])
    toks = [t for t in re.split(r"[._\-]+", lp) if t]
    # 2개 이상 토큰 + 최소 하나는 2글자 이상(이니셜+성 포함)일 때만 이름으로 본다.
    if len(toks) >= 2 and any(len(t) >= 2 for t in toks):
        return " ".join(t.capitalize() for t in toks[:3])
    return None


def gravatar_url(email: str, size: int = 200) -> str:
    h = hashlib.md5((email or "").strip().casefold().encode("utf-8")).hexdigest()
    return f"https://www.gravatar.com/avatar/{h}?s={size}&d=404"


def gravatar_hash(email: str) -> str:
    return hashlib.md5((email or "").strip().casefold().encode("utf-8")).hexdigest()
