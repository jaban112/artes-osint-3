"""얼굴 임베딩 매칭 — 다른 사진이라도 같은 얼굴(§⑥).

pHash는 '똑같은 사진'만 잡지만, 얼굴 임베딩은 각도·조명·크롭이 달라도 같은 인물을
잡는다. 모델(face_recognition/insightface)은 무거워 옵션이다 — 없으면 encode는 None,
그러나 거리·매칭 로직은 항상 동작한다. 임베딩은 계정 attrs["face_encoding"]에 실린다.
"""
from __future__ import annotations

import math

DEFAULT_THRESHOLD = 0.6          # face_recognition 권장 컷


def available() -> bool:
    try:
        import face_recognition  # noqa
        return True
    except Exception:
        try:
            import insightface  # noqa
            return True
        except Exception:
            return False


def encode(image_bytes: bytes) -> list[float] | None:
    """이미지 바이트 → 얼굴 임베딩(128/512d). 모델 없으면 None."""
    try:
        import io
        import numpy as np
        import face_recognition
        from PIL import Image
        img = np.array(Image.open(io.BytesIO(image_bytes)).convert("RGB"))
        encs = face_recognition.face_encodings(img)
        return encs[0].tolist() if encs else None
    except Exception:
        return None


def distance(a: list[float], b: list[float]) -> float:
    if not a or not b or len(a) != len(b):
        return 999.0
    return math.sqrt(sum((x - y) ** 2 for x, y in zip(a, b)))


def same_face(a: list[float], b: list[float], threshold: float = DEFAULT_THRESHOLD) -> bool:
    return distance(a, b) <= threshold
