"""조직 정찰(비접촉) — 이메일 명명 규칙 추론·전 직원 이메일 생성(§3 pro).

알려진 이메일 몇 개로 조직의 명명 규칙(first.last@, flast@ …)을 역추론하고,
직원 이름 목록에 적용해 전 직원 이메일을 생성한다. 순수 코드.
"""
from __future__ import annotations

import re
from collections import Counter


def _tokens(name: str):
    return [t for t in re.split(r"[\s._\-]+", (name or "").casefold()) if t]


def infer_convention(known: list[tuple[str, str]]) -> str | None:
    """known: [(full_name, email)]. 규칙 코드 반환(first.last / flast / first / firstl …)."""
    votes = Counter()
    for name, email in known:
        toks = _tokens(name)
        local = email.split("@")[0].casefold()
        if len(toks) < 2:
            continue
        f, l = toks[0], toks[-1]
        cands = {
            "first.last": f"{f}.{l}", "firstlast": f"{f}{l}", "first_last": f"{f}_{l}",
            "flast": f"{f[0]}{l}", "f.last": f"{f[0]}.{l}", "firstl": f"{f}{l[0]}",
            "first": f, "last": l, "lastfirst": f"{l}{f}", "last.first": f"{l}.{f}",
        }
        for pat, val in cands.items():
            if val == local:
                votes[pat] += 1
    return votes.most_common(1)[0][0] if votes else None


def apply_convention(name: str, domain: str, pattern: str) -> str | None:
    toks = _tokens(name)
    if len(toks) < 1:
        return None
    f = toks[0]
    l = toks[-1] if len(toks) > 1 else ""
    builders = {
        "first.last": f"{f}.{l}", "firstlast": f"{f}{l}", "first_last": f"{f}_{l}",
        "flast": f"{f[:1]}{l}", "f.last": f"{f[:1]}.{l}", "firstl": f"{f}{l[:1]}",
        "first": f, "last": l, "lastfirst": f"{l}{f}", "last.first": f"{l}.{f}",
    }
    local = builders.get(pattern)
    if not local or (pattern not in ("first", "last") and not l):
        return None
    return f"{local}@{domain.lstrip('@').casefold()}"


def generate_org_emails(names: list[str], domain: str, pattern: str) -> list[str]:
    out = []
    for n in names:
        e = apply_convention(n, domain, pattern)
        if e:
            out.append(e)
    return out
