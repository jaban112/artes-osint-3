"""대량 텍스트 표적 스캔 — 7권 프리미티브를 한자리에서.

다크웹 크롤·유출 덤프 같은 대량 텍스트에서 표적 식별자를 찾을 때:
- Aho-Corasick: 표적 수백 개를 **한 번의 스캔**으로 정확 탐지(위음성 0·위양성 0).
- Bloom: 같은 문서를 두 번 세지 않게 dedup(위음성 0 → 놓치지 않음).
- HyperLogLog: 스캔한 고유 문서 수를 극소 메모리로 **규모 파악**(불확실).
- Count-Min: 표적별 문서 출현 빈도를 대규모에서 근사(**규모 파악**, 불확실).
- 안전 필터: 불법 콘텐츠 문서는 통째로 배제(그래프·AI 진입 차단).
"""
from __future__ import annotations

from collections import defaultdict

from ..bigdata.aho import AhoCorasick
from ..bigdata.bloom import BloomFilter
from ..bigdata.sketch import HyperLogLog, CountMin
from .safety import FILTER


class BulkScanner:
    def __init__(self, targets: list[str]):
        self.targets = [t for t in targets if t]
        self.ac = AhoCorasick(self.targets).build()
        self.seen_docs = BloomFilter(capacity=200000, error_rate=0.001)
        self.hll = HyperLogLog(p=12)
        self.freq = CountMin(epsilon=0.001, delta=0.01)
        self.mentions: dict[str, int] = defaultdict(int)   # 정확(Aho)
        self.docs_scanned = 0
        self.docs_blocked = 0
        self.docs_dupe = 0

    def add_doc(self, doc_id: str, text: str) -> None:
        if FILTER.is_blocked(text):
            self.docs_blocked += 1
            return
        if not self.seen_docs.add_if_absent(doc_id):        # 중복 문서
            self.docs_dupe += 1
            return
        self.docs_scanned += 1
        self.hll.add(doc_id)
        hit_targets = set()
        for _, pat, _ in self.ac.search(text):
            self.mentions[pat] += 1
            hit_targets.add(pat)
        for pat in hit_targets:
            self.freq.add(pat)                              # 문서 빈도(규모 파악)

    def report(self) -> dict:
        return {
            "docs_scanned": self.docs_scanned,
            "docs_blocked_illegal": self.docs_blocked,
            "docs_duplicate": self.docs_dupe,
            "unique_docs_estimate": self.hll.count(),        # 규모 파악(불확실)
            "target_mentions_exact": {t: self.mentions.get(t, 0) for t in self.targets},
            "target_doc_frequency_estimate": {t: self.freq.estimate(t) for t in self.targets},
            "note": "표적 언급은 Aho-Corasick 정확(위음성0); 고유 문서 수·문서빈도는 "
                    "규모 파악(불확실)이며 '확실' 판정에 쓰지 않는다",
        }

    def found_targets(self) -> set[str]:
        return {t for t in self.targets if self.mentions.get(t, 0) > 0}
