"""병렬 수집 엔진 — ARTES의 속도 심장.

설계(자반전집 적용):
- 병렬·오버랩(4권 초병렬화): 모든 조회를 동시에 발사하되, 동시성은
  자원 포화점까지만 연다(이득 ≤ 자원 수 · R(N) 포화). 무한 병렬은 없다.
- 실패 격리: 한 도구의 타임아웃/예외가 전체를 죽이지 않는다(base.run).
- 캐시(2권 아카이빙): 같은 조회는 네트워크로 다시 안 나간다 — 재조회 0초.
- 자동 확장: 새로 나온 값(이메일→아이디 등)을 깊이 제한 안에서 재조회.
- AI 0회: 수집·파싱·그래프·확장은 전부 코드. ai_calls 는 감사용으로 0을 확인한다.
"""
from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Any, AsyncIterator

from .cache import Cache
from .model import Entity, Edge, EntityType, Certainty, Evidence, Graph
from .router import Router
from .types import detect
from ..collectors.base import Collector, CollectorResult

# 확장 대상이 되는(재조회하면 새 정보가 나올 수 있는) 타입.
_EXPANDABLE = {EntityType.EMAIL, EntityType.USERNAME, EntityType.DOMAIN,
               EntityType.PHONE, EntityType.NAME, EntityType.BREACH}


@dataclass
class RunStats:
    started: float = field(default_factory=time.perf_counter)
    elapsed: float = 0.0
    collectors_run: int = 0
    collectors_skipped: int = 0
    collectors_failed: int = 0
    ai_calls: int = 0                      # 반드시 0(수집 단계)
    cache_hits: int = 0
    cache_misses: int = 0
    per_collector: dict[str, float] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "elapsed_sec": round(self.elapsed, 3),
            "collectors_run": self.collectors_run,
            "collectors_skipped": self.collectors_skipped,
            "collectors_failed": self.collectors_failed,
            "ai_calls": self.ai_calls,
            "cache": {"hits": self.cache_hits, "misses": self.cache_misses},
            "per_collector_sec": {k: round(v, 3) for k, v in self.per_collector.items()},
        }


class Engine:
    def __init__(self, collectors: list[Collector], cache: Cache | None = None,
                 concurrency: int = 128, depth: int = 1, use_cache: bool = True,
                 resolve: bool = True, bandit=None, use_bandit: bool = True,
                 max_queries: int = 2000, max_seconds: float = 180.0, min_new: int = 1,
                 use_fs: bool = False, max_frontier: int = 48):
        self.use_fs = use_fs                  # Fellegi–Sunter 융합(증분 10)
        self.max_queries = max_queries        # 예산: 총 조회 상한
        self.max_seconds = max_seconds        # 예산: 시간 상한
        self.min_new = min_new                # 수렴: 새 확장가능 엔티티 임계
        self.max_frontier = max_frontier      # 확장 폭발 방지: 반복당 확장 대상 상한(증분31)
        self.max_variant_frontier = 10        # 이름 순열 후보 확장 상한(증분36 속도)
        if bandit is None and use_bandit:
            from ..bigdata.bandit import ContextualBandit
            bandit = ContextualBandit()      # 조건부 밴딧(§4) — 특징별 학습
        self.bandit = bandit
        self.router = Router(collectors, bandit=bandit)
        self.cache = cache or Cache()
        # 조회는 I/O 바운드라 동시성을 높게(기본 128기통). 자원 포화 위는 대기만
        # 늘 뿐이라(4권 초병렬화 정리), 실제 유효 병렬은 도구 수·자원이 상한한다.
        self.concurrency = max(1, concurrency)
        self.depth = depth
        self.use_cache = use_cache
        self.resolve = resolve
        self.hash_images = True                # 아바타 pHash로 같은사진=동일인(증분36)
        self.graph = Graph()
        self.stats = RunStats()

    # ---- 공개 API: 스트리밍 실행 ----
    async def run(self, inputs: list[str]) -> AsyncIterator[dict[str, Any]]:
        sem = asyncio.Semaphore(self.concurrency)
        done: set[tuple[str, str]] = set()   # (collector, entity.key) 중복 방지
        self._ctx = {"targets": list(inputs)}   # 표적 식별자(다크웹 표적 스캔 등)

        # 씨앗: 입력 조각을 엔티티로.
        frontier: list[Entity] = []
        for raw in inputs:
            et = detect(raw)
            val = raw
            if et == EntityType.DOB:                 # 생년월일은 ISO로 정규화(중복제거·매칭)
                from .types import normalize_dob
                val = normalize_dob(raw) or raw
            ent = Entity(type=et, value=val, certainty=Certainty.CONFIRMED,
                         evidence=[Evidence("입력", "사용자 입력")])
            stored = self.graph.add(ent)
            frontier.append(stored)
            yield {"type": "seed", "entity": stored.to_dict()}

        # 고정점 반복(1권): 새 정보가 안 나올 때까지 확장하되, 예산(반복·조회수·시간)
        # 상한과 수렴 판정으로 정지. Bloom이 중복조회를 막아 깊이 파도 무한루프 없음.
        iteration = 0
        while frontier:
            self._ctx["depth"] = iteration
            tasks = []
            for ent in frontier:
                if self.stats.collectors_run + len(tasks) >= self.max_queries:
                    break
                for col in self.router.route(ent.type, ent.value):
                    sig = (col.name, ent.key)
                    if sig in done:
                        continue
                    done.add(sig)
                    tasks.append(self._run_one(sem, col, ent))
            if not tasks:
                break

            new_entities: dict[str, Entity] = {}
            for fut in asyncio.as_completed(tasks):
                res, ent = await fut
                self._absorb_stats(res)
                if self.bandit is not None and not res.skipped:
                    self.bandit.update_for(ent.type.value, ent.value,
                                           res.source, bool(res.entities))
                added = self._absorb_result(res)
                for e in added:
                    if e.key not in new_entities:
                        new_entities[e.key] = e
                yield {"type": "result", "collector": res.source,
                       "for": ent.value, "summary": res.summary(),
                       "ok": res.ok, "skipped": res.skipped,
                       "added": [e.to_dict() for e in added]}

            iteration += 1
            elapsed = time.perf_counter() - self.stats.started
            new_expandable = [e for e in new_entities.values() if e.type in _EXPANDABLE]
            # 수렴·예산 판정: 반복 상한 / 조회수 / 시간 / 새 확장가능 엔티티가 임계 미만.
            stop = (iteration > self.depth
                    or self.stats.collectors_run >= self.max_queries
                    or elapsed >= self.max_seconds
                    or len(new_expandable) < self.min_new)
            frontier = [] if stop else self._prioritize_frontier(new_expandable)
            if frontier:
                yield {"type": "expand", "depth": iteration, "count": len(frontier),
                       "values": [e.value for e in frontier][:50]}
            elif new_expandable:
                yield {"type": "converged", "iteration": iteration,
                       "reason": self._stop_reason(iteration, elapsed),
                       "pending": len(new_expandable)}

        # 단계 4.5: 아바타 pHash — 프로필 사진 받아 해시(같은 사진=동일인 신호, 증분36).
        if self.hash_images:
            try:
                from .imagestep import hash_avatars
                nh = await hash_avatars(self.graph)
                if nh:
                    yield {"type": "images", "hashed": nh}
            except Exception:
                pass

        # 단계 5·6: 동일인 해소 + 운영자 상관(코드, AI 0회).
        if self.resolve:
            from .resolve import EntityResolver, correlate_owners
            added = EntityResolver(use_fs=self.use_fs).correlate(self.graph)
            added += correlate_owners(self.graph)
            if added:
                yield {"type": "correlate", "count": len(added),
                       "links": [e.to_dict() for e in added]}

        if self.bandit is not None:
            self.bandit.save()
        self.stats.cache_hits = self.cache.hits
        self.stats.cache_misses = self.cache.misses
        self.stats.elapsed = time.perf_counter() - self.stats.started
        yield {"type": "done", "stats": self.stats.as_dict(),
               "graph": self.graph.stats()}

    def _prioritize_frontier(self, entities):
        """확장 대상 우선순위·상한(병목 해소). 확실·강한 단서·비순열을 먼저, max_frontier까지.

        이름 순열 후보 수십 개가 다음 반복을 폭발시키던 문제를 막는다. 강한 단서(이메일·전화·
        도메인·확인된 계정)를 우선 확장, 약한 순열 후보는 상한 안에서만.
        """
        tw = {EntityType.EMAIL: 5, EntityType.PHONE: 5, EntityType.DOMAIN: 4,
              EntityType.USERNAME: 3, EntityType.NAME: 1, EntityType.BREACH: 2}

        def score(e):
            s = tw.get(e.type, 1)
            if e.certainty == Certainty.CONFIRMED:
                s += 4
            if (e.attrs or {}).get("variant"):
                s -= 2
            s += float(getattr(e, "confidence", 0) or 0)
            return s

        ranked = sorted(entities, key=score, reverse=True)
        # 이름 순열 후보는 상위 몇 개만 확장(폭발·속도 핵심). 강한 단서는 상한까지.
        out, variants = [], 0
        for e in ranked:
            if (e.attrs or {}).get("variant"):
                if variants >= self.max_variant_frontier:
                    continue
                variants += 1
            out.append(e)
            if len(out) >= self.max_frontier:
                break
        return out

    def _stop_reason(self, iteration, elapsed) -> str:
        if iteration > self.depth:
            return f"반복 상한({self.depth})"
        if self.stats.collectors_run >= self.max_queries:
            return f"조회수 상한({self.max_queries})"
        if elapsed >= self.max_seconds:
            return f"시간 상한({self.max_seconds}s)"
        return f"수렴(새 엔티티 < {self.min_new})"

    # ---- 내부 ----
    async def _run_one(self, sem, col: Collector, ent: Entity):
        async with sem:
            ck = self.cache.key(col.name, ent.type.value, ent.key)
            if self.use_cache and col.needs_network:
                cached = self.cache.get(ck)
                if cached is not None:
                    return self._result_from_cache(col.name, cached), ent
            res = await col.run(ent.value, ent.type, getattr(self, "_ctx", {}))
            if self.use_cache and res.ok and not res.skipped and col.needs_network:
                self.cache.put(ck, self._result_to_cache(res))
            return res, ent

    def _absorb_stats(self, res: CollectorResult) -> None:
        self.stats.ai_calls += res.ai_calls
        if res.skipped:
            self.stats.collectors_skipped += 1
        elif not res.ok:
            self.stats.collectors_failed += 1
        else:
            self.stats.collectors_run += 1
        self.stats.per_collector[res.source] = (
            self.stats.per_collector.get(res.source, 0.0) + res.elapsed)

    def _absorb_result(self, res: CollectorResult) -> list[Entity]:
        added: list[Entity] = []
        for e in res.entities:
            before = self.graph.get(e.key)
            stored = self.graph.add(e)
            if before is None:
                added.append(stored)
        for edge in res.edges:
            self.graph.link(edge)   # 근거 없으면 내부에서 거부됨
        return added

    @staticmethod
    def _result_to_cache(res: CollectorResult) -> dict[str, Any]:
        return {"entities": [e.to_dict() for e in res.entities],
                "edges": [e.to_dict() for e in res.edges]}

    @staticmethod
    def _result_from_cache(source: str, data: dict[str, Any]) -> CollectorResult:
        return CollectorResult(
            source=source, ok=True, elapsed=0.0,
            entities=[Entity.from_dict(d) for d in data.get("entities", [])],
            edges=[Edge.from_dict(d) for d in data.get("edges", [])],
        )
