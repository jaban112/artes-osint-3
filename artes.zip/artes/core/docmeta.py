"""문서 메타데이터 법의학 — 파일이 뱉는 자백(§4 pro). 키 불필요.

PDF·Office(docx/xlsx/pptx) 파일에서 작성자·회사·소프트웨어·수정 이력을 뽑는다.
공개 문서 한 장에 내부 사용자명·회사·도구가 그대로 박혀 있는 경우가 흔하다(FOCA식).
Office는 표준 라이브러리(zip+xml)만으로, PDF는 pypdf 있으면.
"""
from __future__ import annotations

import re
import zipfile
import xml.etree.ElementTree as ET


def extract(path: str) -> dict:
    p = path.lower()
    if p.endswith((".docx", ".xlsx", ".pptx", ".dotx")):
        return extract_office(path)
    if p.endswith(".pdf"):
        return extract_pdf(path)
    return {}


def extract_office(path: str) -> dict:
    out = {}
    try:
        with zipfile.ZipFile(path) as z:
            names = set(z.namelist())
            if "docProps/core.xml" in names:
                out.update(_parse_core(z.read("docProps/core.xml")))
            if "docProps/app.xml" in names:
                out.update(_parse_app(z.read("docProps/app.xml")))
    except Exception:
        return out
    return out


_NS = {
    "cp": "http://schemas.openxmlformats.org/package/2006/metadata/core-properties",
    "dc": "http://purl.org/dc/elements/1.1/",
    "dcterms": "http://purl.org/dc/terms/",
    "ep": "http://schemas.openxmlformats.org/officeDocument/2006/extended-properties",
}


def _parse_core(data: bytes) -> dict:
    out = {}
    try:
        root = ET.fromstring(data)
    except ET.ParseError:
        return out
    m = {"creator": "dc:creator", "last_modified_by": "cp:lastModifiedBy",
         "created": "dcterms:created", "modified": "dcterms:modified",
         "title": "dc:title"}
    for k, tag in m.items():
        el = root.find(tag, _NS)
        if el is not None and (el.text or "").strip():
            out[k] = el.text.strip()
    return out


def _parse_app(data: bytes) -> dict:
    out = {}
    try:
        root = ET.fromstring(data)
    except ET.ParseError:
        return out
    for k, tag in {"application": "ep:Application", "company": "ep:Company"}.items():
        el = root.find(tag, _NS)
        if el is not None and (el.text or "").strip():
            out[k] = el.text.strip()
    return out


def extract_pdf(path: str) -> dict:
    try:
        from pypdf import PdfReader
    except Exception:
        return _pdf_raw(path)
    try:
        meta = PdfReader(path).metadata or {}
        out = {}
        for k, v in meta.items():
            key = str(k).lstrip("/").lower()
            if key in ("author", "creator", "producer", "creationdate", "moddate", "title"):
                out[key] = str(v)
        return out
    except Exception:
        return _pdf_raw(path)


def _pdf_raw(path: str) -> dict:
    """pypdf 없을 때 원시 파싱(제한적)."""
    out = {}
    try:
        data = open(path, "rb").read(200000)
    except Exception:
        return out
    for field in ("Author", "Creator", "Producer"):
        m = re.search(rf"/{field}\s*\(([^)]{{1,120}})\)".encode(), data)
        if m:
            out[field.lower()] = m.group(1).decode("latin-1", "replace")
    return out
