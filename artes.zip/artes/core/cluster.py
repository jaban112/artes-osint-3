"""전역 동일인 군집화 — 쌍대 판정의 전이 불일치를 바로잡는다(연구: collective ER).

문제: 쌍대 Fellegi–Sunter는 A~B, B~C는 확실인데 A≁C 같은 모순을 낳는다. 쌍대 점수만으론
전역적으로 일관되지 않다 — 군집화 단계가 필요하다.

두 단계:
1. connected_components: 확정 간선(양의 강한 증거)의 연결요소 = 하나의 신원. 싸지만 잘못된
   강한 간선 하나가 두 사람을 병합('블랙홀')할 수 있다.
2. pivot_cluster: 상관 군집화(correlation clustering)의 PIVOT 근사(기대 3-근사).
   부호 있는 그래프(양=동일 지지, 음=타인 지지)에서 (동일클러스터 음간선 |w| + 다른클러스터
   양간선 w) 합을 줄이는 분할. must-link(+∞)·cannot-link(−∞)을 자연히 존중 →
   하드 양성은 전이 전파, 하드 음성(상호배타 계정·DOB 불일치)은 잘못된 사슬을 끊는다.

순수 파이썬, 결정적(pivot 순서는 노드정렬+가중 우선). networkx 불필요.
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field

NEG_INF = float("-inf")
POS_INF = float("inf")


@dataclass
class SignedGraph:
    nodes: set = field(default_factory=set)
    # (a,b) 정렬쌍 → 가중치(비트 log-오즈). 양=동일 지지, 음=타인 지지.
    edges: dict = field(default_factory=dict)

    def add_node(self, n) -> None:
        self.nodes.add(n)

    def add_edge(self, a, b, weight: float) -> None:
        if a == b:
            return
        self.nodes.add(a); self.nodes.add(b)
        self.edges[tuple(sorted((a, b)))] = weight

    def must_link(self, a, b) -> None:
        self.add_edge(a, b, POS_INF)

    def cannot_link(self, a, b) -> None:
        self.add_edge(a, b, NEG_INF)

    def weight(self, a, b) -> float:
        return self.edges.get(tuple(sorted((a, b))), 0.0)


def connected_components(g: SignedGraph, threshold: float = 0.0) -> list[set]:
    """threshold 초과 양의 간선만으로 연결요소. cannot-link(−∞)는 절대 잇지 않음."""
    parent = {n: n for n in g.nodes}

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(x, y):
        rx, ry = find(x), find(y)
        if rx != ry:
            parent[rx] = ry

    for (a, b), w in g.edges.items():
        if w > threshold and w != NEG_INF:
            union(a, b)
    comps = defaultdict(set)
    for n in g.nodes:
        comps[find(n)].add(n)
    return sorted(comps.values(), key=lambda s: (-len(s), sorted(map(str, s))[0] if s else ""))


def pivot_cluster(g: SignedGraph) -> list[set]:
    """상관 군집화 PIVOT 근사. 결정적: 피벗은 (양의 가중합 큰 순, 이름 순)으로 고른다.

    각 라운드: 남은 노드 중 피벗 선택 → 피벗과 양의 간선(+cannot-link 아님)인 이웃을 모아
    한 클러스터 → 제거 → 반복. must-link는 강한 양의 간선이라 자연히 함께 묶인다.
    """
    remaining = set(g.nodes)
    clusters: list[set] = []
    # 노드별 양의 가중합(피벗 우선순위).
    posdeg = defaultdict(float)
    for (a, b), w in g.edges.items():
        if w > 0:
            posdeg[a] += (1e6 if w == POS_INF else w)
            posdeg[b] += (1e6 if w == POS_INF else w)
    while remaining:
        pivot = max(sorted(remaining, key=lambda n: str(n)),
                    key=lambda n: posdeg.get(n, 0.0))
        cluster = {pivot}
        for other in list(remaining):
            if other == pivot:
                continue
            w = g.weight(pivot, other)
            if w > 0 and w != NEG_INF:        # 양의 증거이고 cannot-link 아님
                cluster.add(other)
        # cannot-link 위배 정리: 클러스터 내 −∞ 간선이 있으면 약한 쪽을 뺀다.
        cluster = _resolve_cannot_link(g, cluster, pivot)
        clusters.append(cluster)
        remaining -= cluster
    return sorted(clusters, key=lambda s: (-len(s), sorted(map(str, s))[0] if s else ""))


def _resolve_cannot_link(g: SignedGraph, cluster: set, pivot) -> set:
    """클러스터 안에 cannot-link(−∞) 쌍이 있으면 피벗과의 결합이 약한 노드를 축출."""
    members = list(cluster)
    to_remove = set()
    for i in range(len(members)):
        for j in range(i + 1, len(members)):
            a, b = members[i], members[j]
            if g.weight(a, b) == NEG_INF:
                # 피벗과 더 약하게 연결된 쪽을 제거(피벗 자신은 유지).
                wa = g.weight(pivot, a)
                wb = g.weight(pivot, b)
                loser = a if (a != pivot and wa <= wb) else b
                if loser != pivot:
                    to_remove.add(loser)
    return cluster - to_remove


def cluster_identities(graph, pos_threshold: float = 0.0, use_pivot: bool = True) -> list:
    """ARTES 그래프의 동일인 간선 → 부호 그래프 → 군집. 각 군집=하나의 실신원.

    - '동일인'(확정) = must-link(+∞), '동일인?' = 사후오즈(비트)로 부호 가중.
    - 상호배타 하드 음성이 있으면 cannot-link로(현재는 확정 동일인만 사용, 확장 여지).
    반환: 노드 key 집합들의 리스트(크기 내림차순).
    """
    import math
    from .model import Certainty
    sg = SignedGraph()
    idents = [e for e in graph.entities
              if e.type.value in ("name", "username", "account")]
    for e in idents:
        sg.add_node(e.key)
    for edge in graph.edges:
        if edge.relation not in ("동일인", "동일인?"):
            continue
        a, b = edge.src, edge.dst
        if a not in sg.nodes or b not in sg.nodes:
            continue
        if edge.certainty is Certainty.CONFIRMED or edge.relation == "동일인":
            sg.must_link(a, b)
        else:
            conf = edge.confidence or 0.5
            conf = min(max(conf, 1e-6), 1 - 1e-6)
            sg.add_edge(a, b, math.log2(conf / (1 - conf)))   # 사후오즈(비트)
    clusters = pivot_cluster(sg) if use_pivot else connected_components(sg, pos_threshold)
    return [c for c in clusters if len(c) >= 2] + \
           [c for c in clusters if len(c) == 1]
