"""부정 정보의 가치화 — "없음"도 강력한 신호(§6).

- 발자국 크기: 조회한 사이트 중 몇 곳에 존재하나(3000개 중 5개 vs 500개 = 다른 사람).
  대규모에선 HyperLogLog로 고유 존재처 수를 규모 파악(불확실).
- 부재 지문: 두 신원이 "똑같은 곳들에 똑같이 없다"면 그것도 유사도다 — 대부분
  시스템이 버리는 신호를 줍는다. 부재 집합의 Jaccard로.
전부 규모 파악·유사도 축(불확실)이며 확실 판정엔 쓰지 않는다.
"""
from __future__ import annotations

from ..bigdata.sketch import HyperLogLog
from .similarity import MinHash, jaccard_ci


def footprint_size(present_sites: set[str], checked_sites: set[str]) -> dict:
    present = len(present_sites)
    checked = len(checked_sites) or present
    ratio = present / checked if checked else 0.0
    if present <= 3:
        bucket = "극소(신중/새 계정)"
    elif present <= 20:
        bucket = "소"
    elif present <= 100:
        bucket = "중"
    else:
        bucket = "대(활발)"
    return {"present": present, "checked": checked,
            "ratio": round(ratio, 3), "bucket": bucket}


def footprint_size_est(present_iter) -> int:
    """대규모 스트림에서 고유 존재처 수 규모 파악(HLL, 불확실)."""
    hll = HyperLogLog(p=12)
    for s in present_iter:
        hll.add(str(s))
    return hll.count()


def absence_similarity(absent_a: set[str], absent_b: set[str],
                       num_perm: int = 64, alpha: float = 0.05) -> dict:
    """두 신원의 부재 집합 유사도 + CP 구간. 같은 곳들에 똑같이 없음 = 유사 신호."""
    if not absent_a or not absent_b:
        return {"point": 0.0, "lower": 0.0, "upper": 0.0, "applicable": False}
    mh = MinHash(num_perm=num_perm, seed=11)
    ci = jaccard_ci(mh.sign_tokens(absent_a), mh.sign_tokens(absent_b), alpha)
    ci["applicable"] = True
    return ci
