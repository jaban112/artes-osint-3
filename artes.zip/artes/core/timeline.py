"""시간축 정합 — 발자국의 생애 재구성(§7) + 행동/시간대 추론(§8).

계정 생성일·게시 시각·도메인 등록일·유출 날짜·Wayback 스냅샷을 한 타임라인에
정렬해 생애사를 만든다. 시간적 인과는 동일인 판정의 강한 근거("A 죽은 직후 B 시작").
게시 시각 분포로 활동 시간대→대략 거주 경도(시간대)를 추론한다.
"""
from __future__ import annotations

import re
from datetime import datetime, timezone

from .model import Graph

_DATE_KEYS = ("registration", "created_at", "created", "last changed",
              "timestamp", "date", "DateTimeOriginal", "DateTime")


def _parse_date(v: str):
    v = str(v).strip()
    if not v:
        return None
    # Wayback: 14자리 YYYYMMDDhhmmss
    if re.fullmatch(r"\d{14}", v):
        try:
            return datetime.strptime(v, "%Y%m%d%H%M%S").replace(tzinfo=timezone.utc)
        except ValueError:
            return None
    for fmt in ("%Y-%m-%dT%H:%M:%S%z", "%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%d %H:%M:%S",
                "%Y-%m-%d", "%Y:%m:%d %H:%M:%S", "%Y/%m/%d"):
        try:
            dt = datetime.strptime(v.replace("Z", "+0000") if fmt.endswith("%z") else v, fmt)
            return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
        except ValueError:
            continue
    try:
        return datetime.fromisoformat(v)
    except ValueError:
        return None


def collect_events(graph: Graph) -> list[dict]:
    events = []
    for e in graph.entities:
        for k, v in e.attrs.items():
            if any(dk.lower() in k.lower() for dk in _DATE_KEYS):
                dt = _parse_date(v)
                if dt:
                    events.append({"when": dt, "what": f"{k}={v}",
                                   "entity": e.value, "type": e.type.label_ko()})
    events.sort(key=lambda x: x["when"])
    return events


def build_timeline(graph: Graph) -> list[dict]:
    return [{"date": e["when"].date().isoformat(), "entity": e["entity"],
             "type": e["type"], "detail": e["what"]} for e in collect_events(graph)]


def activity_timezone(hours_utc: list[int]) -> dict:
    """UTC 시(0~23) 리스트로 활동 히스토그램 → 추정 시간대 오프셋.

    사람은 대략 현지 09~23시에 활발, 02~06시 최소. 최소활동(수면 중앙)을 현지 새벽 4시로
    가정해 오프셋을 역산한다(대략, 불확실)."""
    if not hours_utc:
        return {"applicable": False}
    hist = [0] * 24
    for h in hours_utc:
        hist[h % 24] += 1
    # 수면 창(연속 6시간 최소합)의 중앙을 찾는다.
    best_start, best_sum = 0, float("inf")
    for start in range(24):
        s = sum(hist[(start + i) % 24] for i in range(6))
        if s < best_sum:
            best_sum, best_start = s, start
    sleep_center = (best_start + 3) % 24        # 수면창 중앙(UTC시)
    # 현지 새벽 4시라고 가정 → offset = 4 - sleep_center
    offset = (4 - sleep_center) % 24
    if offset > 12:
        offset -= 24
    return {"applicable": True, "utc_offset_est": offset,
            "sleep_window_utc": [best_start % 24, (best_start + 6) % 24],
            "peak_hour_utc": max(range(24), key=lambda h: hist[h]),
            "note": "게시 시각 기반 추정(불확실) — 거주 시간대 근사"}
