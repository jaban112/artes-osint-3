"""변화 모니터링 — 표적 재조회 시 달라진 것(§87).

두 시점 그래프를 비교해 새로 나온/사라진 엔티티·연결, 확실성 변화를 낸다.
정기 재조회로 "이 표적의 새 계정·새 유출·삭제된 흔적"을 알림.
"""
from __future__ import annotations

from .model import Graph


def diff(old: Graph, new: Graph) -> dict:
    old_e = {e.key: e for e in old.entities}
    new_e = {e.key: e for e in new.entities}
    old_edges = {ed.key for ed in old.edges}
    new_edges = {ed.key for ed in new.edges}

    added = [new_e[k].to_dict() for k in new_e.keys() - old_e.keys()]
    removed = [old_e[k].to_dict() for k in old_e.keys() - new_e.keys()]
    upgrades = []
    for k in old_e.keys() & new_e.keys():
        if old_e[k].certainty.value != new_e[k].certainty.value:
            upgrades.append({"value": new_e[k].value,
                             "from": old_e[k].certainty.value,
                             "to": new_e[k].certainty.value})
    return {
        "added_entities": added,
        "removed_entities": removed,
        "added_edges": len(new_edges - old_edges),
        "removed_edges": len(old_edges - new_edges),
        "certainty_changes": upgrades,
        "changed": bool(added or removed or (new_edges != old_edges) or upgrades),
    }


def render_diff(d: dict) -> str:
    if not d["changed"]:
        return "변화 없음."
    lines = []
    if d["added_entities"]:
        lines.append(f"+ 새 엔티티 {len(d['added_entities'])}: " +
                     ", ".join(e["value"] for e in d["added_entities"][:15]))
    if d["removed_entities"]:
        lines.append(f"- 사라진 엔티티 {len(d['removed_entities'])}: " +
                     ", ".join(e["value"] for e in d["removed_entities"][:15]))
    if d["added_edges"] or d["removed_edges"]:
        lines.append(f"연결 +{d['added_edges']} / -{d['removed_edges']}")
    for c in d["certainty_changes"][:15]:
        lines.append(f"  ↕ {c['value']}: {c['from']}→{c['to']}")
    return "\n".join(lines)
