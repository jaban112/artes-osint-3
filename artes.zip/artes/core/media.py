"""이미지 메타데이터(EXIF) 추출 — GPS·기기·촬영시각. 키 불필요(Pillow).

프로필 사진 한 장의 EXIF에 GPS가 박혀 있으면 위치가 확정된다. Pillow 없으면
빈 dict(우아하게). exiftool이 설치돼 있으면 더 풍부하게 뽑을 수도 있으나 여기선 Pillow.
"""
from __future__ import annotations


def extract_exif(path) -> dict:
    try:
        from PIL import Image
        from PIL.ExifTags import TAGS, GPSTAGS
    except Exception:
        return {}
    try:
        img = Image.open(path)
        raw = img._getexif()
    except Exception:
        return {}
    if not raw:
        return {}
    out = {}
    gps = {}
    for tag_id, val in raw.items():
        tag = TAGS.get(tag_id, tag_id)
        if tag == "GPSInfo" and isinstance(val, dict):
            for t, v in val.items():
                gps[GPSTAGS.get(t, t)] = v
        elif tag in ("Make", "Model", "DateTime", "DateTimeOriginal", "Software"):
            out[tag] = str(val)
    latlon = _gps_to_deg(gps)
    if latlon:
        out["gps_lat"], out["gps_lon"] = latlon
    return out


def _gps_to_deg(gps: dict):
    try:
        def conv(coord, ref):
            d, m, s = [float(x) for x in coord]
            val = d + m / 60 + s / 3600
            return -val if ref in ("S", "W") else val
        lat = conv(gps["GPSLatitude"], gps.get("GPSLatitudeRef", "N"))
        lon = conv(gps["GPSLongitude"], gps.get("GPSLongitudeRef", "E"))
        return round(lat, 6), round(lon, 6)
    except Exception:
        return None
