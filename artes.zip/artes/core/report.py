"""종합 산출 — 신뢰도 스코어·프로파일 카드·리포트(§J 85/86).

수집·해소·타임라인·셀렉터·발자국을 한 표적 요약으로 종합한다. 확실/불확실을 분리하고,
동일인 군집은 융합 신뢰도로, 발자국 크기·시간대는 규모 파악(불확실)으로 게시한다.
"""
from __future__ import annotations

import html
import json

from .model import Graph, EntityType, Certainty
from . import timeline, selectors, negative, dorking
from .types import detect


def build_profile(graph: Graph, targets: list[str] | None = None) -> dict:
    ents = graph.entities
    by_type = {}
    for e in ents:
        by_type.setdefault(e.type.label_ko(), []).append(e)

    same_person = [e.to_dict() for e in graph.edges
                   if e.relation in ("동일인", "동일인?")]
    owners = [e.to_dict() for e in graph.edges if e.relation == "동일 운영자"]

    # 발자국: 계정 존재처.
    accounts = [e for e in ents if e.type is EntityType.ACCOUNT]
    fp = negative.footprint_size({a.value for a in accounts},
                                 {a.value for a in accounts})

    def dump(t):
        return sorted({e.value for e in by_type.get(t, [])
                       if e.certainty is Certainty.CONFIRMED})

    return {
        "targets": targets or [],
        "summary": graph.stats(),
        "identities": {
            "이름": dump("이름"), "이메일": dump("이메일"), "전화": dump("전화"),
            "아이디": dump("아이디"),
        },
        "accounts": [{"value": a.value, "url": a.attrs.get("url", "")} for a in accounts],
        "same_person": same_person,
        "owner_clusters": owners,
        "footprint": fp,
        "timeline": timeline.build_timeline(graph),
        "top_selectors": selectors.extract_selectors(graph)[:10],
        "tainted": [e.value for e in ents if e.attrs.get("tainted")],
        "dorks": _dorks_for_targets(targets or []),
        "activity": _activity(graph),
    }


def _activity(graph: Graph) -> dict:
    hours = [ev["when"].hour for ev in timeline.collect_events(graph)
             if ev["when"].hour or ev["when"].minute]
    return timeline.activity_timezone(hours) if len(hours) >= 5 else {"applicable": False}


def _dorks_for_targets(targets: list[str], per: int = 4) -> list[dict]:
    out = []
    for t in targets[:5]:
        for d in dorking.generate_dorks(t, detect(t).value, engines=["duckduckgo"])[:per]:
            out.append({"query": d["query"], "url": d["url"]})
    return out


def render_html(profile: dict, title: str = "ARTES 프로파일") -> str:
    def esc(x):
        return html.escape(str(x))

    def chips(items):
        return "".join(f'<span class="chip">{esc(i)}</span>' for i in items) or \
            '<span class="muted">—</span>'

    ident = profile["identities"]
    rows_same = "".join(
        f'<tr><td>{esc(s["src"].split(":",1)[-1])}</td>'
        f'<td>{esc(s["dst"].split(":",1)[-1])}</td>'
        f'<td>{"확실" if s["certainty"]=="confirmed" else "불확실"}</td>'
        f'<td>{"" if s["confidence"] is None else round(s["confidence"],3)}</td></tr>'
        for s in profile["same_person"][:30])
    rows_tl = "".join(
        f'<tr><td>{esc(t["date"])}</td><td>{esc(t["type"])}</td>'
        f'<td>{esc(t["entity"])}</td><td>{esc(t["detail"])}</td></tr>'
        for t in profile["timeline"][:40])
    rows_sel = "".join(
        f'<tr><td>{esc(s["kind"])}</td><td>{esc(s["selector"])}</td>'
        f'<td>{s["pivot_value"]}</td><td>{esc(s["why"])}</td></tr>'
        for s in profile["top_selectors"])
    rows_dork = "".join(
        f'<tr><td>{esc(d["query"])}</td><td><a href="{esc(d["url"])}" target="_blank">검색 ↗</a></td></tr>'
        for d in profile.get("dorks", []))
    s = profile["summary"]
    fp = profile["footprint"]
    return f"""<!doctype html><html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>{esc(title)}</title>
<style>
:root{{color-scheme:light dark}}
body{{margin:0;font-family:system-ui,'Noto Sans KR',sans-serif;background:#0f1115;color:#e7e9ee;line-height:1.5}}
.wrap{{max-width:900px;margin:0 auto;padding:28px 20px 80px}}
h1{{font-size:22px;margin:0 0 4px}} h2{{font-size:15px;color:#7fd1ff;margin:26px 0 8px;border-bottom:1px solid #232833;padding-bottom:6px}}
.muted{{color:#8b93a1}} .stat{{display:flex;gap:18px;flex-wrap:wrap;margin:10px 0}}
.stat div{{background:#171a21;border:1px solid #232833;border-radius:10px;padding:10px 14px;min-width:90px}}
.stat b{{font-size:20px;display:block}}
.chip{{display:inline-block;background:#1b2330;border:1px solid #2b3646;border-radius:999px;padding:3px 10px;margin:3px 4px 0 0;font-size:13px}}
table{{width:100%;border-collapse:collapse;font-size:13px;margin-top:6px}}
th,td{{text-align:left;padding:6px 8px;border-bottom:1px solid #1f2530;vertical-align:top}}
th{{color:#8b93a1;font-weight:600}} .tag{{font-size:12px;padding:2px 6px;border-radius:6px;background:#22c55e22;color:#4ade80}}
</style></head><body><div class="wrap">
<h1>{esc(title)}</h1>
<div class="muted">표적: {chips(profile["targets"])}</div>
<div class="stat">
  <div><b>{s['entities']}</b>엔티티</div><div><b>{s['confirmed']}</b>확실</div>
  <div><b>{s['unconfirmed']}</b>불확실</div><div><b>{s['edges']}</b>연결</div>
  <div><b>{fp['present']}</b>계정({esc(fp['bucket'])})</div>
</div>
<h2>신원</h2>
<div><b>이름</b> {chips(ident['이름'])}</div>
<div><b>이메일</b> {chips(ident['이메일'])}</div>
<div><b>전화</b> {chips(ident['전화'])}</div>
<div><b>아이디</b> {chips(ident['아이디'])}</div>
<h2>동일인 후보 (융합 신뢰도)</h2>
<table><tr><th>A</th><th>B</th><th>판정</th><th>신뢰</th></tr>{rows_same or '<tr><td class="muted" colspan=4>—</td></tr>'}</table>
<h2>피벗 셀렉터 (역검색 씨앗)</h2>
<table><tr><th>종류</th><th>값</th><th>피벗가치</th><th>근거</th></tr>{rows_sel or '<tr><td class="muted" colspan=4>—</td></tr>'}</table>
<h2>타임라인</h2>
<table><tr><th>날짜</th><th>유형</th><th>대상</th><th>내용</th></tr>{rows_tl or '<tr><td class="muted" colspan=4>—</td></tr>'}</table>
<h2>검색 리드 (dork)</h2>
<table><tr><th>질의</th><th>실행</th></tr>{rows_dork or '<tr><td class="muted" colspan=2>—</td></tr>'}</table>
<p class="muted" style="margin-top:30px">발자국 크기·시간대 등은 규모 파악(불확실)이며, 확실 판정은 정확 신호에 한합니다.
동의·인가된 조사 용도로만 사용하세요.</p>
</div></body></html>"""


def render_json(profile: dict) -> str:
    return json.dumps(profile, ensure_ascii=False, indent=2, default=str)
