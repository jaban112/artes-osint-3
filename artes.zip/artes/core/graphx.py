"""그래프 분석 심화 — '더 깊이'(증분 11). 순수 파이썬, networkx 불필요·결정적.

쌍대 판정을 넘어 그래프 구조로 추론한다:
- 시드 편향 PageRank: '지금 아는 것' 기준 다음에 볼 노드 순위(피벗 랭커).
- 중심성(betweenness): 브로커/다리 노드 — 두 군집을 잇는 핵심(공유 버너폰 등).
- 집합적 ER(라벨 전파): A~B, B~C 증거를 이웃으로 전파해 전이적으로 신원 통합.
- 링크 예측(공통이웃·Adamic-Adar·자원할당): 아직 없는 유망 연결 = 다음 조사 후보.
- k-core: 촘촘한 코어(계정 링·협조 군집).
- 이분 투영: 공유 식별자(트래커·전화)로 같은 소유자 후보 생성(희소성 가중).
- 경로 설명: 두 신원이 어떻게 연결됐는지 최단경로/단순경로로 서술.

가중치는 융합 신뢰도(log-오즈)를 쓴다 — 구조가 증거 강도를 반영하게.
"""
from __future__ import annotations

import math
from collections import defaultdict, deque


# ---------------- 인접 구성 ----------------
def build_adj(graph, relations=None, weighted: bool = True) -> dict:
    """ARTES Graph → 무향 인접 {node: {nbr: weight}}. relations로 간선 종류 필터."""
    adj: dict = defaultdict(dict)
    for e in graph.entities:
        adj.setdefault(e.key, {})
    for edge in graph.edges:
        if relations is not None and edge.relation not in relations:
            continue
        w = 1.0
        if weighted:
            c = edge.confidence if edge.confidence is not None else (
                0.99 if getattr(edge.certainty, "value", "") == "confirmed" else 0.5)
            w = max(0.01, min(0.999, c))
        a, b = edge.src, edge.dst
        adj.setdefault(a, {}); adj.setdefault(b, {})
        adj[a][b] = max(adj[a].get(b, 0.0), w)
        adj[b][a] = max(adj[b].get(a, 0.0), w)
    return dict(adj)


# ---------------- 시드 편향 PageRank ----------------
def personalized_pagerank(adj: dict, seeds, alpha: float = 0.85,
                          iters: int = 100, tol: float = 1e-9) -> dict:
    """시드로 재시작하는 랜덤워크 정상분포. 시드에 구조적으로 가까운 노드가 상위."""
    nodes = list(adj.keys())
    if not nodes:
        return {}
    seeds = [s for s in seeds if s in adj] or nodes
    p = {n: (1.0 / len(seeds) if n in seeds else 0.0) for n in nodes}
    x = {n: 1.0 / len(nodes) for n in nodes}
    # 가중 out-degree.
    wdeg = {n: sum(adj[n].values()) for n in nodes}
    for _ in range(iters):
        nx = {n: (1 - alpha) * p[n] for n in nodes}
        dangling = alpha * sum(x[n] for n in nodes if wdeg[n] == 0) / len(nodes)
        for n in nodes:
            if wdeg[n] == 0:
                continue
            share = alpha * x[n] / wdeg[n]
            for m, w in adj[n].items():
                nx[m] += share * w
        for n in nodes:
            nx[n] += dangling
        err = sum(abs(nx[n] - x[n]) for n in nodes)
        x = nx
        if err < tol:
            break
    return dict(sorted(x.items(), key=lambda kv: -kv[1]))


# ---------------- 중심성(브로커) ----------------
def betweenness(adj: dict) -> dict:
    """Brandes 매개중심성(비가중, 정규화). 다리/브로커 노드 식별."""
    nodes = list(adj.keys())
    CB = {n: 0.0 for n in nodes}
    for s in nodes:
        stack = []
        pred = {w: [] for w in nodes}
        sigma = {w: 0.0 for w in nodes}
        sigma[s] = 1.0
        dist = {w: -1 for w in nodes}
        dist[s] = 0
        Q = deque([s])
        while Q:
            v = Q.popleft()
            stack.append(v)
            for w in adj[v]:
                if dist[w] < 0:
                    dist[w] = dist[v] + 1
                    Q.append(w)
                if dist[w] == dist[v] + 1:
                    sigma[w] += sigma[v]
                    pred[w].append(v)
        delta = {w: 0.0 for w in nodes}
        while stack:
            w = stack.pop()
            for v in pred[w]:
                if sigma[w] > 0:
                    delta[v] += (sigma[v] / sigma[w]) * (1 + delta[w])
            if w != s:
                CB[w] += delta[w]
    n = len(nodes)
    scale = 1.0 / ((n - 1) * (n - 2)) if n > 2 else 1.0
    return {k: round(v * scale, 6) for k, v in
            sorted(CB.items(), key=lambda kv: -kv[1])}


# ---------------- 집합적 ER(라벨 전파) ----------------
def propagate_identity(adj: dict, clamped: dict, iters: int = 30) -> dict:
    """고정 라벨(clamped)을 이웃으로 전파(가중 평균)해 신원 소속을 전이적으로.

    clamped: {node: label}. 반환: {node: label} (미고정 노드는 다수 이웃 라벨로 수렴).
    """
    # 미지정은 None(라벨 없음) — 고정 라벨이 이웃으로 전파되게 한다.
    labels = {n: clamped.get(n) for n in adj}
    order = sorted(adj.keys(), key=str)
    for _ in range(iters):
        changed = False
        for n in order:
            if n in clamped:
                continue
            tally: dict = defaultdict(float)
            for m, w in adj[n].items():
                if labels[m] is not None:              # None(미지정)은 표에서 제외
                    tally[labels[m]] += w
            if tally:
                best = max(tally.items(), key=lambda kv: (kv[1], str(kv[0])))[0]
                if best != labels[n]:
                    labels[n] = best
                    changed = True
        if not changed:
            break
    # 끝까지 미지정인 노드는 자기 라벨(분리 신원).
    for n in adj:
        if labels[n] is None:
            labels[n] = f"_self:{n}"
    return labels


def label_propagation_communities(adj: dict, iters: int = 30) -> list:
    """비지도 라벨전파 커뮤니티(각 노드 초기 고유라벨 → 이웃 다수결 수렴)."""
    labels = {n: n for n in adj}
    order = sorted(adj.keys(), key=str)
    for _ in range(iters):
        changed = False
        for n in order:
            tally: dict = defaultdict(float)
            for m, w in adj[n].items():
                tally[labels[m]] += w
            if tally:
                best = max(tally.items(), key=lambda kv: (kv[1], str(kv[0])))[0]
                if best != labels[n]:
                    labels[n] = best
                    changed = True
        if not changed:
            break
    comms: dict = defaultdict(set)
    for n, l in labels.items():
        comms[l].add(n)
    return sorted(comms.values(), key=lambda s: (-len(s), sorted(map(str, s))[0]))


# ---------------- k-core ----------------
def core_numbers(adj: dict) -> dict:
    """각 노드의 coreness(비가중). 높을수록 촘촘한 코어."""
    deg = {n: len(adj[n]) for n in adj}
    core = dict(deg)
    order = sorted(adj.keys(), key=lambda n: deg[n])
    processed = set()
    nbr = {n: set(adj[n].keys()) for n in adj}
    # 반복 peel.
    import heapq
    heap = [(deg[n], n) for n in adj]
    heapq.heapify(heap)
    cur = {n: deg[n] for n in adj}
    level = 0
    while heap:
        d, n = heapq.heappop(heap)
        if n in processed or d > cur[n]:
            continue
        processed.add(n)
        level = max(level, d)
        core[n] = level
        for m in nbr[n]:
            if m not in processed and cur[m] > level:
                cur[m] -= 1
                heapq.heappush(heap, (cur[m], m))
    return core


# ---------------- 링크 예측 ----------------
def link_prediction(adj: dict, candidates=None, method: str = "adamic_adar") -> list:
    """비인접 쌍의 은닉연결 점수. method: common/jaccard/adamic_adar/resource.

    반환: [(a, b, score)] 내림차순. candidates 없으면 2-홉 이내 비인접 쌍.
    """
    nodes = list(adj.keys())
    def gen():
        seen = set()
        for u in nodes:
            two = set()
            for v in adj[u]:
                two |= set(adj[v].keys())
            for w in two:
                if w == u or w in adj[u]:
                    continue
                key = tuple(sorted((u, w)))
                if key not in seen:
                    seen.add(key)
                    yield key
    pairs = candidates if candidates is not None else gen()
    out = []
    for a, b in pairs:
        if a not in adj or b not in adj:
            continue
        common = set(adj[a]) & set(adj[b])
        if not common:
            continue
        if method == "common":
            s = len(common)
        elif method == "jaccard":
            uni = set(adj[a]) | set(adj[b])
            s = len(common) / len(uni) if uni else 0
        elif method == "resource":
            s = sum(1.0 / len(adj[z]) for z in common if adj[z])
        else:  # adamic_adar
            s = sum(1.0 / math.log(len(adj[z])) for z in common if len(adj[z]) > 1)
        out.append((a, b, round(s, 5)))
    return sorted(out, key=lambda t: -t[2])


# ---------------- 이분 투영(공유 소유) ----------------
def bipartite_cooccur(graph, entity_types, connector_types, idf: bool = True) -> list:
    """공유 커넥터(트래커·전화·이메일)로 엔티티 쌍을 잇는다. 희소 커넥터일수록 강함.

    반환: [(a_key, b_key, weight, shared_connector_key)] — 같은 소유자 후보.
    """
    conn_owners: dict = defaultdict(set)
    for e in graph.entities:
        if e.type.value in connector_types:
            for nb in graph.neighbors(e.key):
                if nb.type.value in entity_types:
                    conn_owners[e.key].add(nb.key)
    out = []
    for conn, owners in conn_owners.items():
        owners = sorted(owners)
        if len(owners) < 2:
            continue
        w = 1.0
        if idf:
            w = 1.0 / math.log(1 + len(owners))     # 많이 공유될수록 약함
        for i in range(len(owners)):
            for j in range(i + 1, len(owners)):
                out.append((owners[i], owners[j], round(w, 4), conn))
    return sorted(out, key=lambda t: -t[2])


# ---------------- 경로 설명 ----------------
def shortest_path(adj: dict, a, b) -> list:
    """a→b 최단경로(홉 수). 없으면 []."""
    if a not in adj or b not in adj:
        return []
    prev = {a: None}
    Q = deque([a])
    while Q:
        n = Q.popleft()
        if n == b:
            path = []
            while n is not None:
                path.append(n)
                n = prev[n]
            return list(reversed(path))
        for m in adj[n]:
            if m not in prev:
                prev[m] = n
                Q.append(m)
    return []


def all_simple_paths(adj: dict, a, b, cutoff: int = 4) -> list:
    """a→b 단순경로 전부(길이 cutoff 이하). 연결 설명용."""
    if a not in adj or b not in adj:
        return []
    out = []
    def dfs(node, path):
        if len(path) - 1 > cutoff:
            return
        if node == b:
            out.append(list(path))
            return
        for m in adj[node]:
            if m not in path:
                path.append(m)
                dfs(m, path)
                path.pop()
    dfs(a, [a])
    return sorted(out, key=len)


def ego(graph, node, radius: int = 2) -> set:
    """node 반경 radius 이내 노드 집합(에고넷 — 리포트 단위)."""
    adj = build_adj(graph, weighted=False)
    if node not in adj:
        return {node}
    seen = {node}
    frontier = {node}
    for _ in range(radius):
        nxt = set()
        for n in frontier:
            nxt |= set(adj[n].keys())
        nxt -= seen
        seen |= nxt
        frontier = nxt
        if not frontier:
            break
    return seen


# ---------------- 통합 피벗 점수 ----------------
def rank_pivots(graph, seeds, top: int = 20) -> list:
    """시드 PPR + 매개중심성 블렌드로 다음 조사 대상 순위. [(key, score)]."""
    adj = build_adj(graph)
    if not adj:
        return []
    ppr = personalized_pagerank(adj, seeds)
    btw = betweenness(adj)
    seed_set = {s for s in seeds if s in adj}
    # 정규화 후 가중합(PPR 0.7 + betweenness 0.3), 시드 제외.
    pmax = max(ppr.values()) or 1.0
    bmax = max(btw.values()) or 1.0
    scores = []
    for n in adj:
        if n in seed_set:
            continue
        s = 0.7 * (ppr.get(n, 0) / pmax) + 0.3 * (btw.get(n, 0) / bmax)
        scores.append((n, round(s, 5)))
    return sorted(scores, key=lambda t: -t[1])[:top]
