"""피벗팅 — 하나의 셀렉터로 전체를 여는 기술(§1 pro).

재사용되는 고유 식별자(셀렉터)를 뽑아 그걸로 전 축을 역검색한다:
전화·이메일·재사용 프로필 사진·분석/광고 ID·PGP 지문·암호화폐 주소·특이 아이디.
Bellingcat식 — 하나의 전화번호로 수십 신원 연결. 각 셀렉터에 피벗 가치를 매겨 랭크.
"""
from __future__ import annotations

import re

from .model import Graph, EntityType

_BTC = re.compile(r"\b(?:bc1|[13])[a-zA-HJ-NP-Z0-9]{25,39}\b")
_ETH = re.compile(r"\b0x[a-fA-F0-9]{40}\b")
_PGP = re.compile(r"\b[A-F0-9]{40}\b")

# 타입별 피벗 가치(고유성·역검색 유용도). 높을수록 강력.
_PIVOT_VALUE = {
    EntityType.PHONE: 0.95, EntityType.EMAIL: 0.9, EntityType.TRACKER: 0.85,
    "image_phash": 0.9, "crypto": 0.95, "pgp": 0.9,
    EntityType.USERNAME: 0.5,
}


def extract_selectors(graph: Graph) -> list[dict]:
    sels = []
    seen = set()

    def add(value, kind, value_score, why):
        k = (kind, value)
        if value and k not in seen:
            seen.add(k)
            sels.append({"selector": value, "kind": kind,
                         "pivot_value": value_score, "why": why})

    for e in graph.entities:
        if e.type is EntityType.PHONE:
            add(e.value, "phone", _PIVOT_VALUE[EntityType.PHONE], "재사용 고유 번호")
        elif e.type is EntityType.EMAIL:
            add(e.value, "email", _PIVOT_VALUE[EntityType.EMAIL], "재사용 이메일")
        elif e.type is EntityType.TRACKER:
            add(e.value, "tracker", _PIVOT_VALUE[EntityType.TRACKER], "공유 분석/광고 ID")
        elif e.type is EntityType.USERNAME and _is_unusual(e.value):
            add(e.value, "username", 0.7, "특이 아이디(고유성 높음)")
        # 프로필 사진 해시
        if e.attrs.get("image_phash"):
            add(e.attrs["image_phash"], "image_phash", _PIVOT_VALUE["image_phash"],
                "재사용 프로필 사진")
        # bio/텍스트 속 암호화폐·PGP
        blob = " ".join(str(e.attrs.get(k, "")) for k in ("bio", "txt")) + " " + e.value
        for m in set(_BTC.findall(blob)) | set(_ETH.findall(blob)):
            add(m, "crypto", _PIVOT_VALUE["crypto"], "암호화폐 주소(강한 피벗)")
        for m in set(_PGP.findall(blob)):
            if not _ETH.match("0x" + m):
                add(m, "pgp", _PIVOT_VALUE["pgp"], "PGP 지문")

    sels.sort(key=lambda s: -s["pivot_value"])
    return sels


def _is_unusual(username: str) -> bool:
    u = username or ""
    if len(u) < 4:
        return False
    # 사전어 아닌 듯한(숫자·특수 혼합, 긴 랜덤성) 아이디를 고유로 본다.
    has_digit = any(c.isdigit() for c in u)
    has_sep = any(c in "._-" for c in u)
    return (has_digit or has_sep) and len(u) >= 6
