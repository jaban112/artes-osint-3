"""동일인 융합 수학 — Fellegi–Sunter 정식 + EM 학습 + 희소성 보정 + 교정.

기존 fusion.py의 '고정 우도비(LR) 나이브 베이즈'를 정식 레코드 링키지 수학으로 승격한다.
전부 순수 파이썬(numpy 불필요), 오프라인, StubBackend 없이 결정적 단위검증 가능.

축(연구 근거 — Fellegi–Sunter 1969, Winkler, Splink/fastLink EM):
1. m/u 분해: 신호별로 m=P(일치|동일인), u=P(일치|타인)을 분리. 우도비를 두 실패모드로 나눔.
   - 일치 가중치  w = log2(m/u)          (양의 증거)
   - 불일치 가중치 w = log2((1-m)/(1-u))  (음의 증거 — 나이브 LR가 버리던 것)
2. 다단계 비교(exact/high/low/disagree): 이진 대신 단계별 (m,u). '동일'과 '유사'를 구분.
3. 희소성 보정(Winkler TF): 희귀값 일치(rare handle)는 흔한값보다 훨씬 강함.
   w += log2(ū / u_value),  u_value ≈ 값의 상대빈도(하한 u_min).
4. 총가중 → 확률: W = log2(prior_odds) + Σ w_i,  P = 2^W/(1+2^W).
5. EM: 라벨 없이 후보쌍의 일치벡터에서 (m,u,λ)를 추정(혼합모형). E/M 스텝 제공.
6. 교정: Platt(로지스틱) 스케일링으로 W→보정확률. 순수 경사하강.
7. 독립신호 개수 가드레일: Beta-이항 하한(cp_lower 재사용)으로 '한 신호로 확정' 방지.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

from .warrant import cp_lower

# 신호별 기본 (m, u) — 보수적. 각 값은 단계별로도 줄 수 있다(아래 LEVELS).
# m: 동일인일 때 이 신호가 관측될 확률. u: 타인인데 우연히 관측될 확률.
DEFAULT_MU = {
    "email":       (0.85, 0.0002),   # 유일 식별자 공유(하드에 준함)
    "phone":       (0.80, 0.0003),
    "image":       (0.72, 0.001),    # 같은 프로필 사진(pHash)
    "face":        (0.70, 0.002),    # 같은 얼굴(다른 사진)
    "selector":    (0.75, 0.0001),   # 암호화폐/PGP/SSH 키 재사용
    "bio_reuse":   (0.55, 0.001),    # 프로필 텍스트 복붙
    "handle":      (0.60, 0.02),     # 동일 핸들
    "name_sim":    (0.65, 0.03),     # 이름/핸들 근접(단계로 스케일)
    "stylometry":  (0.50, 0.05),     # 문체 동일저자 경향
    "absence":     (0.45, 0.15),     # 부재 패턴 일치
    "timezone":    (0.55, 0.30),
    "geo":         (0.50, 0.20),
}

# 다단계 비교의 단계별 m/u(값이 주어진 신호만). 첫 일치 단계를 쓴다.
# 각 단계 (임계, m, u). name_sim은 유사도 하한으로 단계 판정.
LEVELS = {
    "name_sim": [(0.95, 0.55, 0.002), (0.85, 0.30, 0.02), (0.70, 0.15, 0.08)],
    "stylometry": [(0.80, 0.45, 0.01), (0.55, 0.35, 0.05), (0.40, 0.20, 0.12)],
}

PRIOR = 0.02
U_MIN = 1e-4                    # 희소성 보정 하한(한 신호 폭주 방지)


def weight_agree(m: float, u: float) -> float:
    """일치 가중치 log2(m/u). m>u 이면 양수(동일인 지지)."""
    m = min(max(m, 1e-9), 1 - 1e-9)
    u = min(max(u, 1e-12), 1 - 1e-9)
    return math.log2(m / u)


def weight_disagree(m: float, u: float) -> float:
    """불일치 가중치 log2((1-m)/(1-u)). 보통 음수(타인 지지)."""
    m = min(max(m, 1e-9), 1 - 1e-9)
    u = min(max(u, 1e-12), 1 - 1e-9)
    return math.log2((1 - m) / (1 - u))


def level_of(signal: str, strength: float) -> int:
    """유사도 강도 → 단계 인덱스(0=최상). 단계표 없으면 -1(이진 취급)."""
    lv = LEVELS.get(signal)
    if not lv:
        return -1
    for i, (thr, _m, _u) in enumerate(lv):
        if strength >= thr:
            return i
    return len(lv)                 # 모든 단계 미달 = 불일치


def signal_weight(signal: str, strength: float | None = None,
                  mu: dict | None = None) -> float:
    """한 신호의 부분 가중치. strength가 있고 단계표가 있으면 단계별 (m,u)로.

    strength=None → 이진 일치(기본 m,u). strength가 모든 단계 미달 → 불일치 가중치.
    """
    mu = mu or DEFAULT_MU
    lv = LEVELS.get(signal)
    if strength is not None and lv is not None:
        idx = level_of(signal, strength)
        if idx >= len(lv):                       # 불일치
            base_m, base_u = mu.get(signal, (0.5, 0.1))
            return weight_disagree(base_m, base_u)
        _thr, m, u = lv[idx]
        return weight_agree(m, u)
    m, u = mu.get(signal, (0.5, 0.1))
    return weight_agree(m, u)


def tf_adjust(weight: float, u_avg: float, u_value: float) -> float:
    """Winkler 희소성 보정 — 희귀값 일치는 가중을 키운다.

    w' = w + log2(ū / u_value). u_value는 값의 상대빈도(하한 U_MIN).
    """
    u_value = max(u_value, U_MIN)
    u_avg = max(u_avg, U_MIN)
    return weight + math.log2(u_avg / u_value)


def prob_from_weight(total_weight: float) -> float:
    """총가중 W(비트) → 확률 2^W/(1+2^W). 오버플로 안전."""
    if total_weight > 60:
        return 1.0
    if total_weight < -60:
        return 0.0
    p2 = 2.0 ** total_weight
    return p2 / (1.0 + p2)


@dataclass
class FusionResult:
    posterior: float
    total_weight: float          # 비트(log2 오즈)
    prior: float
    breakdown: list = field(default_factory=list)   # [{signal, weight, level?}]
    n_independent: int = 0       # 독립 지지 신호 수
    corroboration_lower: float = 0.0   # Beta-이항 하한(독립성 가드레일)


def fuse_fs(signals: list, prior: float = PRIOR, mu: dict | None = None,
            independent_groups: dict | None = None, alpha: float = 0.05) -> FusionResult:
    """Fellegi–Sunter 융합. signals: [(name, strength|None, tf_u|None), ...] 또는 [(name,), ...].

    - strength: 유사도(단계 판정용). None이면 이진 일치.
    - tf_u: 값의 상대빈도(희소성 보정). None이면 보정 없음.
    - independent_groups: {group: [signal,...]} 상관 신호를 한 그룹으로 묶어 1표로 셈(독립성 가드).
    """
    mu = mu or DEFAULT_MU
    prior_w = math.log2((prior / (1 - prior)))
    W = prior_w
    breakdown = []
    fired = []
    for s in signals:
        name = s[0]
        strength = s[1] if len(s) > 1 else None
        tf_u = s[2] if len(s) > 2 else None
        w = signal_weight(name, strength, mu)
        if tf_u is not None:
            _m, u_avg = mu.get(name, (0.5, 0.1))
            w = tf_adjust(w, u_avg, tf_u)
        W += w
        breakdown.append({"signal": name, "weight": round(w, 3),
                          "level": level_of(name, strength) if strength is not None else None})
        if w > 0:
            fired.append(name)
    # 독립 신호 개수(상관 그룹은 1로 축약).
    n_ind = _count_independent(fired, independent_groups)
    corr_lower = cp_lower(n_ind, max(n_ind, 1), alpha) if n_ind else 0.0
    return FusionResult(posterior=prob_from_weight(W), total_weight=W, prior=prior,
                        breakdown=breakdown, n_independent=n_ind,
                        corroboration_lower=round(corr_lower, 4))


def _count_independent(fired: list, groups: dict | None) -> int:
    """상관 신호를 그룹으로 축약해 독립 지지 신호 수를 센다."""
    if not groups:
        return len(fired)
    seen_groups = set()
    count = 0
    sig2group = {}
    for g, members in groups.items():
        for mname in members:
            sig2group[mname] = g
    for name in fired:
        g = sig2group.get(name)
        if g is None:
            count += 1                         # 그룹 없는 신호는 독립
        elif g not in seen_groups:
            seen_groups.add(g)
            count += 1                         # 그룹당 1표
    return count


# ---------------- EM: 라벨 없이 (m,u,λ) 추정 ----------------
def estimate_mu(gamma_vectors: list[list[int]], n_iter: int = 50,
                init_lambda: float = 0.1, tol: float = 1e-7) -> dict:
    """혼합모형 EM으로 신호별 (m,u)와 매치 사전확률 λ 추정(이진 일치벡터).

    gamma_vectors: 후보쌍마다 [0/1,...] (각 위치=신호). 조건부 독립 가정.
    반환 {"m": [...], "u": [...], "lambda": λ, "iters": t}.
    """
    if not gamma_vectors:
        return {"m": [], "u": [], "lambda": 0.0, "iters": 0}
    K = len(gamma_vectors[0])
    N = len(gamma_vectors)
    lam = init_lambda
    m = [0.9] * K
    u = [0.1] * K
    prev = None
    t = 0
    for t in range(1, n_iter + 1):
        # E-step: 각 쌍의 매치 책임 ξ_p.
        xis = []
        for g in gamma_vectors:
            pm = lam
            pu = 1 - lam
            for k in range(K):
                pm *= (m[k] if g[k] else (1 - m[k]))
                pu *= (u[k] if g[k] else (1 - u[k]))
            denom = pm + pu
            xis.append(pm / denom if denom > 0 else lam)
        # M-step.
        sx = sum(xis)
        lam = sx / N
        for k in range(K):
            num_m = sum(xis[p] * gamma_vectors[p][k] for p in range(N))
            num_u = sum((1 - xis[p]) * gamma_vectors[p][k] for p in range(N))
            m[k] = _clip(num_m / sx) if sx > 0 else m[k]
            u[k] = _clip(num_u / (N - sx)) if (N - sx) > 0 else u[k]
        # 수렴 판정.
        cur = (lam, tuple(m), tuple(u))
        if prev is not None:
            d = abs(cur[0] - prev[0]) + sum(abs(a - b) for a, b in zip(m, prev[1]))
            if d < tol:
                break
        prev = cur
    return {"m": [round(x, 5) for x in m], "u": [round(x, 5) for x in u],
            "lambda": round(lam, 5), "iters": t}


def _clip(x: float, lo: float = 1e-5, hi: float = 1 - 1e-5) -> float:
    return min(max(x, lo), hi)


# ---------------- 교정: Platt(로지스틱) 스케일링 ----------------
@dataclass
class PlattCalibrator:
    """W(또는 원점수) → 보정확률. logistic p=σ(a·x+b). 순수 경사하강 적합.

    작은 라벨셋에 강건(2 파라미터). fit 없이 쓰면 항등(σ(x))에 가깝게 동작.
    """
    a: float = 1.0
    b: float = 0.0

    def fit(self, xs: list[float], ys: list[int], lr: float = 0.05,
            epochs: int = 2000, l2: float = 1e-4) -> "PlattCalibrator":
        n = len(xs)
        if n == 0:
            return self
        a, b = self.a, self.b
        for _ in range(epochs):
            ga = gb = 0.0
            for x, y in zip(xs, ys):
                p = 1.0 / (1.0 + math.exp(-(a * x + b)))
                err = p - y
                ga += err * x
                gb += err
            a -= lr * (ga / n + l2 * a)
            b -= lr * (gb / n)
        self.a, self.b = a, b
        return self

    def predict(self, x: float) -> float:
        return 1.0 / (1.0 + math.exp(-(self.a * x + self.b)))

    def to_dict(self) -> dict:
        return {"a": round(self.a, 6), "b": round(self.b, 6)}

    @classmethod
    def from_dict(cls, d: dict) -> "PlattCalibrator":
        return cls(a=d.get("a", 1.0), b=d.get("b", 0.0))
