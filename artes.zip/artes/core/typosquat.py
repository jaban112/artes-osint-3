"""오타·유사 도메인 생성 — 사칭/피싱 도메인 탐지(§82). 순수 코드.

표적 도메인의 흔한 변형(문자 생략·중복·바꿔치기·인접키·동형글자·TLD 스왑)을 생성한다.
사칭 계정/피싱 사이트 탐지(공격)와 브랜드 보호(방어) 양쪽에 쓴다. 존재 확인은 DNS(사용자 VM).
"""
from __future__ import annotations

_KEYBOARD = {
    "a": "qsz", "b": "vgn", "c": "xdv", "d": "sfe", "e": "wrd", "f": "dgr",
    "g": "fht", "h": "gjy", "i": "uko", "j": "hkn", "k": "jlm", "l": "kop",
    "m": "nk", "n": "bm", "o": "ipl", "p": "ol", "q": "wa", "r": "et",
    "s": "adw", "t": "ryg", "u": "yij", "v": "cb", "w": "qes", "x": "zc",
    "y": "tuh", "z": "xas", "0": "o", "1": "l", "5": "s",
}
_HOMOGLYPH = {"o": "0", "l": "1", "i": "1", "e": "3", "a": "@", "s": "5", "b": "8"}
_TLDS = ("com", "net", "org", "co", "io", "info", "biz", "app", "online", "site")


def _split(domain: str):
    parts = domain.lower().split(".")
    if len(parts) < 2:
        return domain.lower(), ""
    return ".".join(parts[:-1]), parts[-1]


def generate_variants(domain: str, max_variants: int = 60) -> list[str]:
    name, tld = _split(domain)
    out = set()

    def dom(n, t=tld):
        return f"{n}.{t}"

    # 1) 문자 생략
    for i in range(len(name)):
        out.add(dom(name[:i] + name[i + 1:]))
    # 2) 문자 중복
    for i in range(len(name)):
        out.add(dom(name[:i] + name[i] + name[i:]))
    # 3) 인접 문자 바꿔치기
    for i in range(len(name) - 1):
        out.add(dom(name[:i] + name[i + 1] + name[i] + name[i + 2:]))
    # 4) 인접 키 대체
    for i, ch in enumerate(name):
        for r in _KEYBOARD.get(ch, ""):
            out.add(dom(name[:i] + r + name[i + 1:]))
    # 5) 동형 글자
    for i, ch in enumerate(name):
        if ch in _HOMOGLYPH:
            out.add(dom(name[:i] + _HOMOGLYPH[ch] + name[i + 1:]))
    # 6) 하이픈 삽입
    for i in range(1, len(name)):
        out.add(dom(name[:i] + "-" + name[i:]))
    # 7) TLD 스왑
    for t in _TLDS:
        if t != tld:
            out.add(dom(name, t))

    out.discard(dom(name))
    out = {d for d in out if len(d.split(".")[0]) >= 1}
    return sorted(out)[:max_variants]
