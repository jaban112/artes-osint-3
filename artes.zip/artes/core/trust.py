"""견고성·신뢰 — '더 강하게'(증분 11). 조작·저품질·충돌 데이터에 저항.

원칙: 모든 탐지기의 출력은 진실발견 루프의 '소스 신뢰' 항으로 들어가고, CONFIRMED 승격은
'독립성 + 다중 양식' 게이트를 통과해야 한다 → 방어 심층: 스푸핑 가능한 단일 신호 하나로는
확정 불가.

- truth_discovery: 소스 신뢰 ↔ 주장 믿음을 함께 추정(Average·Log — 다작 소스 감쇠).
- independence_groups: 상관 소스(재게시·에코)를 묶어 1표로(가짜 합의 방지).
- bot_score: 공개 메타데이터 특징(활동률·핸들 엔트로피·케이던스)으로 자동화 점수.
- confusable_skeleton: 유니코드 동형이의어 골격(사칭 탐지).
- decay_weight: 신선도 지수감쇠(오래된 값은 스스로 강등).
- ds_combine: Dempster-Shafer 결합(Yager 규칙 — 고충돌에서 안전).
- sybil_rank: 신뢰 씨앗에서 조기종료 전파(가짜 계정 군집 강등).
- classify_confidence: 독립·다중양식 게이트(방어 심층).

전부 순수 파이썬, 결정적 단위검증 가능.
"""
from __future__ import annotations

import math
import unicodedata
from collections import defaultdict


# ---------------- 진실 발견 ----------------
def truth_discovery(claims: list, iters: int = 20, damp_prolific: bool = True) -> dict:
    """소스 신뢰 ↔ 주장 믿음 공동 추정(Average·Log).

    claims: [(source, claim_key)]. 반환 {"belief": {claim: 0~1}, "trust": {source: 0~1}}.
    다작 소스(claim 많이 던지는)를 log(n)/n 로 감쇠 → 스팸 소스가 지배 못함.
    """
    src_claims: dict = defaultdict(set)
    claim_srcs: dict = defaultdict(set)
    for s, c in claims:
        src_claims[s].add(c)
        claim_srcs[c].add(s)
    if not claim_srcs:
        return {"belief": {}, "trust": {}}
    trust = {s: 0.9 for s in src_claims}
    belief = {c: 0.5 for c in claim_srcs}
    for _ in range(iters):
        # 믿음 = 그 주장을 하는 소스 신뢰 합(정규화).
        for c in claim_srcs:
            belief[c] = sum(trust[s] for s in claim_srcs[c])
        bmax = max(belief.values()) or 1.0
        for c in belief:
            belief[c] /= bmax
        # 신뢰 = 그 소스가 한 주장들의 믿음 평균(다작 감쇠).
        for s in src_claims:
            cs = src_claims[s]
            avg = sum(belief[c] for c in cs) / len(cs)
            if damp_prolific and len(cs) > 1:
                avg *= math.log(len(cs) + 1) / (len(cs))  # log(n)/n 스케일 근사
                avg *= len(cs)                             # 평균이므로 n 되돌림 → log(n)/1
            trust[s] = min(1.0, avg)
        tmax = max(trust.values()) or 1.0
        for s in trust:
            trust[s] /= tmax
    return {"belief": {c: round(v, 4) for c, v in
                       sorted(belief.items(), key=lambda kv: -kv[1])},
            "trust": {s: round(v, 4) for s, v in
                      sorted(trust.items(), key=lambda kv: -kv[1])}}


def independence_groups(sources: list, correlated_pairs: list) -> dict:
    """상관 소스를 그룹으로 축약(재게시·에코 클리크). 반환 {source: group_id}.

    correlated_pairs: [(a,b)] 같은 원천으로 판정된 소스쌍(near-dup·공유호스트 등).
    """
    parent = {s: s for s in sources}
    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x
    for a, b in correlated_pairs:
        if a in parent and b in parent:
            parent[find(a)] = find(b)
    return {s: find(s) for s in sources}


def independent_count(sources: list, correlated_pairs: list) -> int:
    """독립 원천 수(상관 그룹 축약 후 고유 그룹 수)."""
    g = independence_groups(sources, correlated_pairs)
    return len(set(g.values()))


# ---------------- 봇/자동화 점수 ----------------
def _entropy(counts) -> float:
    total = sum(counts) or 1
    h = 0.0
    for c in counts:
        if c > 0:
            p = c / total
            h -= p * math.log2(p)
    return h


def handle_randomness(handle: str) -> float:
    """핸들 무작위도 0~1(숫자비율·문자 엔트로피 기반). 높을수록 랜덤(봇 시사)."""
    h = (handle or "").strip()
    if not h:
        return 0.0
    digits = sum(ch.isdigit() for ch in h)
    digit_ratio = digits / len(h)
    # 문자 분포 엔트로피 정규화.
    from collections import Counter
    ent = _entropy(list(Counter(h.lower()).values()))
    ent_norm = ent / math.log2(len(set(h.lower())) or 1) if len(set(h)) > 1 else 0.0
    return round(min(1.0, 0.5 * digit_ratio + 0.5 * ent_norm), 4)


def bot_score(profile: dict, post_times: list | None = None) -> float:
    """공개 메타데이터 특징 → 봇 점수 0~1. profile: age_days, followers, following,
    statuses, default_avatar(bool), handle. post_times: epoch 리스트(케이던스 엔트로피)."""
    feats = []
    age = max(1.0, profile.get("age_days", 30))
    statuses = profile.get("statuses", 0)
    rate = statuses / age                                # 일일 게시율
    feats.append(min(1.0, rate / 50.0))                  # 하루 50+ = 매우 높음
    following = profile.get("following", 0)
    followers = profile.get("followers", 0)
    if followers + following > 0:
        feats.append(min(1.0, following / (followers + 1) / 10.0))  # 팔로잉≫팔로워
    if profile.get("default_avatar"):
        feats.append(0.7)
    feats.append(handle_randomness(profile.get("handle", "")))
    if post_times and len(post_times) >= 3:
        gaps = [t2 - t1 for t1, t2 in zip(sorted(post_times), sorted(post_times)[1:])]
        # 규칙적(저 엔트로피) 간격 = 기계적. 간격을 버킷팅해 엔트로피.
        buckets = defaultdict(int)
        for g in gaps:
            buckets[round(math.log1p(max(g, 0)), 1)] += 1
        ent = _entropy(list(buckets.values()))
        ent_norm = ent / (math.log2(len(buckets)) or 1) if len(buckets) > 1 else 0.0
        feats.append(1.0 - ent_norm)                     # 낮은 엔트로피 → 봇
    return round(sum(feats) / len(feats), 4) if feats else 0.0


# ---------------- 동형이의어(사칭) ----------------
_CONFUSABLES = {
    "а": "a", "е": "e", "о": "o", "р": "p", "с": "c", "х": "x", "у": "y",
    "ѕ": "s", "і": "i", "ј": "j", "ԁ": "d", "ո": "n", "０": "0", "１": "1",
    "ⅼ": "l", "ｏ": "o", "𝗮": "a", "ạ": "a", "ο": "o", "ν": "v", "α": "a",
}


def confusable_skeleton(s: str) -> str:
    """유니코드 골격 — 혼동가능 문자를 원형으로. 두 문자열의 골격이 같으면 시각 동일."""
    s = unicodedata.normalize("NFKD", (s or "")).casefold()
    out = []
    for ch in s:
        if ch in _CONFUSABLES:
            out.append(_CONFUSABLES[ch])
        elif ch.isascii() or ch.isalnum():
            out.append(ch)
        else:
            # 기저 라틴 근사(발음기호 제거 후 남는 것).
            base = unicodedata.normalize("NFKD", ch)
            out.append("".join(c for c in base if not unicodedata.combining(c)) or ch)
    return "".join(out)


def is_confusable(a: str, b: str) -> bool:
    """두 식별자가 시각적으로 혼동가능한가(사칭 후보). 완전동일은 제외."""
    if a == b:
        return False
    return confusable_skeleton(a) == confusable_skeleton(b)


def mixed_script(s: str) -> bool:
    """한 토큰에 라틴+키릴 등 스크립트 혼용(사칭 강력 신호)."""
    scripts = set()
    for ch in s or "":
        if not ch.isalpha():
            continue
        try:
            name = unicodedata.name(ch)
        except ValueError:
            continue
        for sc in ("LATIN", "CYRILLIC", "GREEK", "ARMENIAN"):
            if sc in name:
                scripts.add(sc)
    return len(scripts) > 1


# ---------------- 신선도 감쇠 ----------------
DEFAULT_HALFLIFE = {                     # 일 단위 반감기
    "phone": 365, "email": 540, "account": 400, "ip": 30, "domain": 400,
    "name": 3650, "dob": 100000, "location": 200,
}


def decay_weight(age_days: float, kind: str = "account",
                 halflife: dict | None = None) -> float:
    """신선도 지수감쇠 w = 0.5^(Δt/half_life). 오래된 값 자동 강등."""
    hl = (halflife or DEFAULT_HALFLIFE).get(kind, 400)
    return round(0.5 ** (max(0.0, age_days) / hl), 4)


# ---------------- Dempster-Shafer(충돌 증거) ----------------
def ds_combine(masses: list, rule: str = "yager") -> dict:
    """두 개 이상의 질량함수 결합. 프레임 {same, different}, 불확실집합 'both' 허용.

    masses: [{"same":x,"different":y,"both":z}, ...]. rule: 'dempster' 또는 'yager'.
    반환 {"same","different","both","belief_same","plausibility_same","conflict"}.
    """
    def combine2(m1, m2):
        keys = ("same", "different", "both")
        out = {"same": 0.0, "different": 0.0, "both": 0.0}
        conflict = 0.0
        for a in keys:
            for b in keys:
                inter = _ds_intersect(a, b)
                prod = m1.get(a, 0.0) * m2.get(b, 0.0)
                if inter is None:
                    conflict += prod
                else:
                    out[inter] += prod
        if rule == "yager":                  # 충돌을 불확실('both')로 — 고충돌 안전
            out["both"] += conflict
            k = 0.0
        else:                                # Dempster 정규화
            k = conflict
            if k < 1.0:
                for key in out:
                    out[key] /= (1 - k)
        out["_conflict"] = conflict
        return out
    acc = masses[0]
    for m in masses[1:]:
        acc = combine2(acc, m)
    same = acc.get("same", 0.0)
    both = acc.get("both", 0.0)
    diff = acc.get("different", 0.0)
    return {"same": round(same, 4), "different": round(diff, 4), "both": round(both, 4),
            "belief_same": round(same, 4), "plausibility_same": round(same + both, 4),
            "conflict": round(acc.get("_conflict", 0.0), 4)}


def _ds_intersect(a: str, b: str):
    """{same,different,both} 원소의 교집합. 공집합이면 None(충돌)."""
    seta = {"same", "different"} if a == "both" else {a}
    setb = {"same", "different"} if b == "both" else {b}
    inter = seta & setb
    if not inter:
        return None
    return "both" if inter == {"same", "different"} else next(iter(inter))


# ---------------- SybilRank ----------------
def sybil_rank(adj: dict, trusted_seeds: list, rounds: int | None = None) -> dict:
    """신뢰 씨앗에서 차수정규화 조기종료 전파. 낮은 정규화 신뢰 = 가짜(Sybil) 후보.

    반환 {node: normalized_trust}. rounds 미지정 시 O(log n).
    """
    nodes = list(adj.keys())
    if not nodes:
        return {}
    seeds = [s for s in trusted_seeds if s in adj] or nodes
    T = {n: (1.0 / len(seeds) if n in seeds else 0.0) for n in nodes}
    if rounds is None:
        rounds = max(1, int(math.log2(len(nodes) + 1)) + 1)
    for _ in range(rounds):
        nT = {n: 0.0 for n in nodes}
        for n in nodes:
            deg = len(adj[n]) or 1
            share = T[n] / deg
            for m in adj[n]:
                nT[m] += share
        T = nT
    # 차수 정규화.
    return {n: round(T[n] / (len(adj[n]) or 1), 6) for n in
            sorted(nodes, key=lambda x: -(T[x] / (len(adj[x]) or 1)))}


# ---------------- 방어 심층 게이트 ----------------
def classify_confidence(belief: float, independent_origins: int,
                        modality_classes: int, tau_high: float = 0.7,
                        min_origins: int = 2, min_modalities: int = 2) -> str:
    """CONFIRMED는 믿음↑ AND 독립원천≥2 AND 양식클래스≥2 일 때만. 아니면 '불확실'.

    스푸핑 가능한 단일 신호 하나로는 확정 불가(방어 심층).
    """
    if (belief >= tau_high and independent_origins >= min_origins
            and modality_classes >= min_modalities):
        return "확실"
    if belief <= 0.2:
        return "insufficient_evidence"
    return "불확실"
