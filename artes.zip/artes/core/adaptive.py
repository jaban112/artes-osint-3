"""적응형 동시성·합류·캐시 — '더 빠르게'의 심장(증분 11).

고정 Semaphore(32)는 빠른 호스트엔 너무 낮고 느린 호스트엔 너무 높다. 관측된
지연·오류(429/timeout)로 동시성을 **학습**한다(Netflix concurrency-limits / Little's Law).

- AdaptiveLimiter: AIMD(성공 시 +1, 429/timeout 시 ×0.7) 동적 세마포어.
- TokenBucket: 호스트별 속도 제한(전역 병렬은 유지 — 느린 호스트가 전체를 막지 않음).
- SingleFlight: 동일 키 in-flight 요청을 하나로 합류(고정점 반복의 중복 조회 제거).
- TTLCache: 인메모리 TTL LRU(디스크 캐시 앞단 — 반복 조회 0 디스크왕복).

전부 순수 파이썬·asyncio, 결정적 단위검증 가능.
"""
from __future__ import annotations

import asyncio
import time
from collections import OrderedDict


class AdaptiveLimiter:
    """AIMD 동적 동시성 한계. acquire/release로 세마포어처럼 쓰되 한계가 부유한다."""

    def __init__(self, start: int = 8, min_limit: int = 1, max_limit: int = 64,
                 backoff: float = 0.7):
        self.limit = float(start)
        self.min_limit = min_limit
        self.max_limit = max_limit
        self.backoff = backoff
        self.in_flight = 0
        self._waiters: list[asyncio.Future] = []

    async def acquire(self) -> None:
        while self.in_flight >= int(self.limit):
            fut = asyncio.get_event_loop().create_future()
            self._waiters.append(fut)
            await fut
        self.in_flight += 1

    def _wake(self) -> None:
        while self._waiters and self.in_flight < int(self.limit):
            fut = self._waiters.pop(0)
            if not fut.done():
                fut.set_result(None)
                return

    def release(self, ok: bool = True, throttled: bool = False) -> None:
        """반납 + 피드백. ok/throttled로 한계를 조정(가법증가·승법감소)."""
        self.in_flight = max(0, self.in_flight - 1)
        if throttled:                                   # 429/timeout → 승법 감소
            self.limit = max(self.min_limit, self.limit * self.backoff)
        elif ok and self.in_flight + 1 >= int(self.limit):  # 포화에서 성공 → +1
            self.limit = min(self.max_limit, self.limit + 1.0)
        self._wake()

    def snapshot(self) -> dict:
        return {"limit": round(self.limit, 2), "in_flight": self.in_flight}


class TokenBucket:
    """호스트별 토큰버킷 속도제한. rate 토큰/초, 버스트 capacity."""

    def __init__(self, rate: float = 5.0, capacity: float | None = None):
        self.rate = rate
        self.capacity = capacity if capacity is not None else max(1.0, rate)
        self.tokens = self.capacity
        self.updated = time.monotonic()
        self._lock = asyncio.Lock()

    async def acquire(self, now: float | None = None) -> None:
        async with self._lock:
            t = now if now is not None else time.monotonic()
            self.tokens = min(self.capacity, self.tokens + (t - self.updated) * self.rate)
            self.updated = t
            if self.tokens < 1.0:
                deficit = (1.0 - self.tokens) / self.rate
                await asyncio.sleep(deficit)
                self.tokens = 0.0
                self.updated = time.monotonic()
            else:
                self.tokens -= 1.0

    def _refill_take(self, now: float) -> bool:
        """동기 테스트용: 토큰 있으면 소비하고 True."""
        self.tokens = min(self.capacity, self.tokens + (now - self.updated) * self.rate)
        self.updated = now
        if self.tokens >= 1.0:
            self.tokens -= 1.0
            return True
        return False


class SingleFlight:
    """동일 키 in-flight 요청 합류. 동시 N 요청 → 1 네트워크 호출."""

    def __init__(self):
        self._inflight: dict[str, asyncio.Future] = {}
        self.coalesced = 0                              # 합류로 절약된 호출 수(감사)

    async def do(self, key: str, coro_factory):
        fut = self._inflight.get(key)
        if fut is not None:
            self.coalesced += 1
            return await asyncio.shield(fut)
        fut = asyncio.get_event_loop().create_future()
        self._inflight[key] = fut
        try:
            result = await coro_factory()
            if not fut.done():
                fut.set_result(result)
            return result
        except Exception as exc:
            if not fut.done():
                fut.set_exception(exc)
            raise
        finally:
            self._inflight.pop(key, None)


class TTLCache:
    """인메모리 TTL LRU. 디스크 캐시 앞단 — 반복 조회를 객체 속도로."""

    def __init__(self, maxsize: int = 4096, ttl: float = 300.0):
        self.maxsize = maxsize
        self.ttl = ttl
        self._d: OrderedDict = OrderedDict()
        self.hits = 0
        self.misses = 0

    def get(self, key: str, now: float | None = None):
        t = now if now is not None else time.monotonic()
        item = self._d.get(key)
        if item is None:
            self.misses += 1
            return None
        exp, val = item
        if exp < t:
            self._d.pop(key, None)
            self.misses += 1
            return None
        self._d.move_to_end(key)
        self.hits += 1
        return val

    def put(self, key: str, val, now: float | None = None) -> None:
        t = now if now is not None else time.monotonic()
        self._d[key] = (t + self.ttl, val)
        self._d.move_to_end(key)
        while len(self._d) > self.maxsize:
            self._d.popitem(last=False)

    def stats(self) -> dict:
        return {"size": len(self._d), "hits": self.hits, "misses": self.misses}
