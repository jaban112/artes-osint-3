"""통일 데이터 모델 — 엔티티, 간선, 그래프.

원칙:
- 확실/불확실 두 상태만 구분한다(그 외 라벨 없음).
- 근거(evidence)가 없는 연결은 그래프에 넣지 않는다.
- 같은 대상은 정규화 키로 자동 중복제거한다.

외계어 금지 규약에 따라 클래스·필드 이름은 전부 평범한 영어이고,
사람에게 보여줄 문자열만 한국어("확실"/"불확실")로 낸다.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Iterable


class EntityType(str, Enum):
    """조회 대상/산출물의 타입."""
    NAME = "name"
    PHONE = "phone"
    EMAIL = "email"
    USERNAME = "username"
    DOMAIN = "domain"
    IP = "ip"
    URL = "url"
    ACCOUNT = "account"      # 특정 사이트의 프로필(예: instagram/hong123)
    HOST = "host"            # 네트워크 호스트/포트
    BREACH = "breach"        # 유출 출처(로컬 유출 DB 매칭)
    TRACKER = "tracker"      # 분석/광고 ID(GA·AdSense·GTM) — 동일 운영자 신호
    ORG = "org"              # 조직·회사(SEC/GLEIF/Wikidata)
    ASN = "asn"              # 자율시스템(네트워크 소유)
    GEO = "geo"              # 지리 위치(좌표·주소)
    CRYPTO = "crypto"        # 암호화폐 주소
    MALWARE = "malware"      # 악성 인디케이터(위협 인텔)
    DOB = "dob"              # 생년월일(입력 단서/산출) — 신원 교차검증 앵커
    UNKNOWN = "unknown"

    def label_ko(self) -> str:
        return {
            "name": "이름", "phone": "전화", "email": "이메일",
            "username": "아이디", "domain": "도메인", "ip": "IP",
            "url": "링크", "account": "계정", "host": "호스트",
            "breach": "유출", "tracker": "추적ID", "org": "조직",
            "asn": "네트워크(ASN)", "geo": "위치", "crypto": "암호화폐",
            "malware": "악성지표", "unknown": "미상",
        }[self.value]


class Certainty(str, Enum):
    """확실/불확실 — 두 상태뿐."""
    CONFIRMED = "confirmed"        # 직접 확인
    UNCONFIRMED = "unconfirmed"    # 추정

    def label_ko(self) -> str:
        return "확실" if self is Certainty.CONFIRMED else "불확실"


@dataclass(frozen=True)
class Evidence:
    """이 사실/연결이 어디서 왔는지. 근거 없는 발화 0 규약의 실체."""
    source: str                    # 어느 수집기/도구
    detail: str = ""               # 사람이 읽을 설명
    url: str = ""                  # 확인 가능한 링크(있으면)
    raw_ref: str = ""              # 원자료 참조(캐시 키 등)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Evidence":
        return cls(source=d.get("source", ""), detail=d.get("detail", ""),
                   url=d.get("url", ""), raw_ref=d.get("raw_ref", ""))


def _normalize(entity_type: EntityType, value: str) -> str:
    """중복제거용 정규화 키. 표시값(value)은 원형을 보존하고, 키만 정규화한다."""
    v = (value or "").strip()
    if entity_type in (EntityType.EMAIL, EntityType.DOMAIN, EntityType.URL,
                       EntityType.USERNAME, EntityType.ACCOUNT):
        v = v.lower()
    if entity_type is EntityType.PHONE:
        # 숫자와 선행 +만 남긴다.
        plus = v.strip().startswith("+")
        digits = re.sub(r"\D", "", v)
        v = ("+" + digits) if plus else digits
    if entity_type is EntityType.NAME:
        v = re.sub(r"\s+", " ", v).strip().casefold()
    return v


@dataclass
class Entity:
    type: EntityType
    value: str
    certainty: Certainty = Certainty.UNCONFIRMED
    confidence: float | None = None          # 불확실일 때만 의미(0~1)
    evidence: list[Evidence] = field(default_factory=list)
    attrs: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if isinstance(self.type, str):
            self.type = EntityType(self.type)
        if isinstance(self.certainty, str):
            self.certainty = Certainty(self.certainty)
        if self.certainty is Certainty.CONFIRMED:
            self.confidence = 1.0

    @property
    def key(self) -> str:
        return f"{self.type.value}:{_normalize(self.type, self.value)}"

    def merge(self, other: "Entity") -> None:
        """같은 키의 엔티티를 흡수. 확실이 불확실을 이긴다."""
        seen = {(e.source, e.detail, e.url) for e in self.evidence}
        for e in other.evidence:
            if (e.source, e.detail, e.url) not in seen:
                self.evidence.append(e)
                seen.add((e.source, e.detail, e.url))
        if other.certainty is Certainty.CONFIRMED:
            self.certainty = Certainty.CONFIRMED
            self.confidence = 1.0
        elif self.certainty is Certainty.UNCONFIRMED:
            # 두 추정 중 더 높은 신뢰를 취한다.
            c = [x for x in (self.confidence, other.confidence) if x is not None]
            self.confidence = max(c) if c else None
        self.attrs.update({k: v for k, v in other.attrs.items() if k not in self.attrs})

    def to_dict(self) -> dict[str, Any]:
        return {
            "key": self.key,
            "type": self.type.value,
            "type_ko": self.type.label_ko(),
            "value": self.value,
            "certainty": self.certainty.value,
            "certainty_ko": self.certainty.label_ko(),
            "confidence": self.confidence,
            "evidence": [e.to_dict() for e in self.evidence],
            "attrs": self.attrs,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Entity":
        return cls(
            type=EntityType(d["type"]),
            value=d["value"],
            certainty=Certainty(d.get("certainty", "unconfirmed")),
            confidence=d.get("confidence"),
            evidence=[Evidence.from_dict(e) for e in d.get("evidence", [])],
            attrs=dict(d.get("attrs", {})),
        )


@dataclass
class Edge:
    src: str                       # Entity.key
    dst: str                       # Entity.key
    relation: str                  # 예: "가진 계정", "같은 이메일", "동일인?"
    certainty: Certainty = Certainty.UNCONFIRMED
    confidence: float | None = None
    evidence: list[Evidence] = field(default_factory=list)

    def __post_init__(self) -> None:
        if isinstance(self.certainty, str):
            self.certainty = Certainty(self.certainty)
        if self.certainty is Certainty.CONFIRMED:
            self.confidence = 1.0

    @property
    def key(self) -> str:
        return f"{self.src}|{self.relation}|{self.dst}"

    def to_dict(self) -> dict[str, Any]:
        return {
            "src": self.src, "dst": self.dst, "relation": self.relation,
            "certainty": self.certainty.value,
            "certainty_ko": self.certainty.label_ko(),
            "confidence": self.confidence,
            "evidence": [e.to_dict() for e in self.evidence],
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Edge":
        return cls(
            src=d["src"], dst=d["dst"], relation=d["relation"],
            certainty=Certainty(d.get("certainty", "unconfirmed")),
            confidence=d.get("confidence"),
            evidence=[Evidence.from_dict(e) for e in d.get("evidence", [])],
        )


class Graph:
    """인메모리 그래프. 규모가 커지면 Neo4j로 승격(같은 인터페이스 유지 예정)."""

    def __init__(self) -> None:
        self._entities: dict[str, Entity] = {}
        self._edges: dict[str, Edge] = {}

    # --- 엔티티 ---
    def add(self, entity: Entity) -> Entity:
        k = entity.key
        if k in self._entities:
            self._entities[k].merge(entity)
        else:
            self._entities[k] = entity
        return self._entities[k]

    def get(self, key: str) -> Entity | None:
        return self._entities.get(key)

    @property
    def entities(self) -> list[Entity]:
        return list(self._entities.values())

    # --- 간선 ---
    def link(self, edge: Edge) -> Edge | None:
        """근거 없는 연결은 거부한다(None 반환). 이게 규약의 집행 지점."""
        if not edge.evidence:
            return None
        if edge.src not in self._entities or edge.dst not in self._entities:
            return None
        k = edge.key
        if k in self._edges:
            existing = self._edges[k]
            seen = {(e.source, e.detail) for e in existing.evidence}
            for e in edge.evidence:
                if (e.source, e.detail) not in seen:
                    existing.evidence.append(e)
            if edge.certainty is Certainty.CONFIRMED:
                existing.certainty = Certainty.CONFIRMED
                existing.confidence = 1.0
            return existing
        self._edges[k] = edge
        return edge

    @property
    def edges(self) -> list[Edge]:
        return list(self._edges.values())

    def neighbors(self, key: str) -> list[Entity]:
        out = []
        for e in self._edges.values():
            if e.src == key and e.dst in self._entities:
                out.append(self._entities[e.dst])
            elif e.dst == key and e.src in self._entities:
                out.append(self._entities[e.src])
        return out

    # --- 직렬화 ---
    def to_dict(self) -> dict[str, Any]:
        conf = sum(1 for e in self._entities.values() if e.certainty is Certainty.CONFIRMED)
        return {
            "summary": {
                "entities": len(self._entities),
                "edges": len(self._edges),
                "confirmed": conf,
                "unconfirmed": len(self._entities) - conf,
            },
            "entities": [e.to_dict() for e in self._entities.values()],
            "edges": [e.to_dict() for e in self._edges.values()],
        }

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=indent)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Graph":
        g = cls()
        for ed in d.get("entities", []):
            g.add(Entity.from_dict(ed))
        for edg in d.get("edges", []):
            g.link(Edge.from_dict(edg))
        return g

    @classmethod
    def load_json(cls, text: str) -> "Graph":
        return cls.from_dict(json.loads(text))

    def merge(self, other: "Graph") -> None:
        """다른 그래프를 흡수(대화형 수사에서 추가 조회 결과 병합)."""
        for e in other.entities:
            self.add(e)
        for edg in other.edges:
            self.link(edg)

    def stats(self) -> dict[str, int]:
        return self.to_dict()["summary"]
