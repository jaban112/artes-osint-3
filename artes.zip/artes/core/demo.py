"""오프라인 쇼케이스 — 전 신호를 실증하는 합성 신원 그래프. 네트워크·실인물 0.

같은 사진(pHash)·공유 이메일·재사용 bio·유사 이름·운영자 상관(추적ID)·타임라인·셀렉터·
발자국을 한 그래프에 담아, 동일인 융합·리포트·내보내기 전 파이프라인을 오프라인으로 보여준다.
"""
from __future__ import annotations

from .model import Graph, Entity, Edge, EntityType, Certainty, Evidence


def _phash_pair():
    """Pillow 있으면 실제 근접 pHash, 없으면 고정 문자열."""
    try:
        import io
        from PIL import Image
        from .imagehash import phash_bytes
        img = Image.new("RGB", (96, 96))
        px = img.load()
        for y in range(96):
            for x in range(96):
                px[x, y] = ((x * 3) % 256, (y * 5) % 256, ((x + y) % 256))
        b1 = io.BytesIO(); img.save(b1, "PNG")
        b2 = io.BytesIO(); img.resize((80, 80)).save(b2, "JPEG")
        return phash_bytes(b1.getvalue()), phash_bytes(b2.getvalue())
    except Exception:
        return "aabbccddeeff0011", "aabbccddeeff0011"


def build_demo_graph() -> Graph:
    g = Graph()
    ev = lambda s, d="": [Evidence(s, d)]
    ph1, ph2 = _phash_pair()

    email = g.add(Entity(EntityType.EMAIL, "jiwan.kim@example.com", Certainty.CONFIRMED,
                         evidence=ev("입력", "사용자 입력")))
    name = g.add(Entity(EntityType.NAME, "김지완", Certainty.CONFIRMED, evidence=ev("입력")))
    phone = g.add(Entity(EntityType.PHONE, "+821012345678", Certainty.CONFIRMED,
                         evidence=ev("phoneinfoga", "통신사 확인")))

    # 계정 A·B: 같은 사진 + 같은 bio + 공유 이메일 → 확실 동일인
    a = g.add(Entity(EntityType.ACCOUNT, "github/jiwankim", Certainty.CONFIRMED,
                     attrs={"handle": "jiwankim", "image_phash": ph1,
                            "bio": "hiking, coffee, open source, seoul",
                            "created_at": "2019-05-01"},
                     evidence=ev("github", "공개 프로필")))
    b = g.add(Entity(EntityType.ACCOUNT, "gitlab/jiwan.k", Certainty.CONFIRMED,
                     attrs={"handle": "jiwan.k", "image_phash": ph2,
                            "bio": "hiking, coffee, open source, seoul",
                            "created_at": "2020-02-15"},
                     evidence=ev("keybase", "검증 연결")))
    # 계정 C: 이름/핸들만 유사 → 등급 불확실
    c = g.add(Entity(EntityType.ACCOUNT, "instagram/jiwan_kim", Certainty.CONFIRMED,
                     attrs={"handle": "jiwan_kim", "created_at": "2021-08-20"},
                     evidence=ev("maigret", "CLAIMED")))

    for acc in (a, b, c):
        g.link(Edge(email.key, acc.key, "가진 계정", Certainty.CONFIRMED, evidence=ev("holehe")))
    g.link(Edge(name.key, email.key, "연결", Certainty.CONFIRMED, evidence=ev("입력")))
    g.link(Edge(email.key, phone.key, "연결", Certainty.UNCONFIRMED, 0.6, evidence=ev("추정")))

    # 도메인 2개 — 같은 추적 ID(동일 운영자)
    d1 = g.add(Entity(EntityType.DOMAIN, "jiwan.dev", Certainty.CONFIRMED,
                      attrs={"registration": "2020-01-10"}, evidence=ev("rdap")))
    d2 = g.add(Entity(EntityType.DOMAIN, "jiwan-blog.net", Certainty.CONFIRMED,
                      evidence=ev("crtsh")))
    tid = g.add(Entity(EntityType.TRACKER, "UA-778899-1", Certainty.CONFIRMED,
                       attrs={"kind": "GA"}, evidence=ev("webfp", "GA")))
    for d in (d1, d2):
        g.link(Edge(d.key, tid.key, "추적 ID", Certainty.CONFIRMED, evidence=ev("webfp")))
    g.link(Edge(a.key, d1.key, "블로그", Certainty.CONFIRMED, evidence=ev("github")))

    # 유출 + 셀렉터(암호화폐)
    breach = g.add(Entity(EntityType.BREACH, "dump2021/jiwan.kim@example.com",
                          Certainty.CONFIRMED, attrs={"date": "2021-11-03"},
                          evidence=ev("h8mail", "로컬 매칭")))
    g.link(Edge(email.key, breach.key, "유출 노출", Certainty.CONFIRMED, evidence=ev("h8mail")))
    a.attrs["bio"] += " btc:1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa"
    return g
