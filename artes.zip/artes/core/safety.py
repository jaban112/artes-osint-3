"""안전 필터 — 불법 콘텐츠(특히 아동 성착취물, CSAM) 자동 배제.

다크웹 크롤 결과·페이스트 등 임의 텍스트가 그래프나 AI로 들어가기 전에
반드시 통과한다. 매칭되면 내용은 **버려지고**(저장·표시·AI 전달 모두 안 함),
차단 사실만 카운트로 남긴다. 위협인텔·연구 목적의 파이프라인이 불법 콘텐츠를
취급·재유통하지 않게 하는 게 목적이다.

보수적으로 동작한다: 애매하면 통과시키되, 명백한 불법-콘텐츠 지표는 차단.
"""
from __future__ import annotations

import re

# 아동 성착취물 관련 명백한 지표(약어·정형 표현). 실제 배포 시 신뢰할 수 있는
# 해시셋/전문 서비스(예: 신고기관 해시 DB) 연동으로 강화해야 한다.
_CSAM_INDICATORS = [
    r"\bcsam\b", r"\bcp\s*(?:video|pack|collection)\b",
    r"child\s*(?:porn|abuse\s*material|sexual)", r"pre\s*teen\s*(?:porn|nude)",
    r"\bpthc\b", r"\bpedo\b\s*(?:pack|content|link)",
]
_PATTERNS = [re.compile(p, re.I) for p in _CSAM_INDICATORS]


class HashDB:
    """알려진 불법 콘텐츠 해시셋(md5/sha1/지각해시) 훅.

    실배포는 신고기관(NCMEC/IWF 등) 해시 목록을 인가받아 연동해야 완전하다. 여기서는
    파일(한 줄 한 해시)에서 로드하는 인터페이스만 제공 — 텍스트 정규식은 1차 방어일 뿐이다.
    """
    def __init__(self):
        self.exact: set[str] = set()          # md5/sha1 정확 해시
        self.phashes: list[str] = []          # 지각해시(해밍 비교)

    def load(self, path: str) -> int:
        """파일에서 로드. 'p:<hex>' = 지각해시, 그 외 = 정확 해시. '#' 주석."""
        try:
            with open(path, encoding="utf-8") as f:
                for line in f:
                    h = line.strip().lower()
                    if not h or h.startswith("#"):
                        continue
                    if h.startswith("p:"):
                        self.phashes.append(h[2:])
                    else:
                        self.exact.add(h)
            return len(self.exact) + len(self.phashes)
        except Exception:
            return 0

    def blocks_hash(self, h: str) -> bool:
        return (h or "").lower() in self.exact

    def blocks_image(self, phash: str, max_hamming: int = 6) -> bool:
        from .imagehash import hamming_hex
        return any(hamming_hex(phash, p) <= max_hamming for p in self.phashes)


class ContentFilter:
    def __init__(self) -> None:
        self.blocked = 0
        self.hashdb = HashDB()

    def is_blocked(self, text: str) -> bool:
        if not text:
            return False
        for pat in _PATTERNS:
            if pat.search(text):
                self.blocked += 1
                return True
        return False

    def is_blocked_media(self, exact_hash: str = "", phash: str = "") -> bool:
        """이미지/파일 해시가 알려진 불법셋과 일치하면 차단(해시DB 로드 시)."""
        if exact_hash and self.hashdb.blocks_hash(exact_hash):
            self.blocked += 1
            return True
        if phash and self.hashdb.blocks_image(phash):
            self.blocked += 1
            return True
        return False

    def clean(self, text: str) -> str | None:
        """차단이면 None, 아니면 원문."""
        return None if self.is_blocked(text) else text

    def filter_items(self, items, key=lambda x: x):
        """차단 항목을 제거한 리스트를 돌려준다."""
        return [it for it in items if not self.is_blocked(str(key(it)))]

    def stats(self) -> dict:
        return {"blocked": self.blocked}


# 프로세스 전역 필터(엔진·다크웹 수집기가 공유).
FILTER = ContentFilter()
