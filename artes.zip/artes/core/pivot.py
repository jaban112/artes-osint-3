"""자동 피벗 수사 엔진 — 하나의 셀렉터로 전체를 여는 기술을 자동화.

1) 승격: 계정 bio·텍스트에 숨은 고유 셀렉터(암호화폐 주소·PGP·SSH 키)를 그래프
   엔티티로 끌어올린다 → 공유하면 강한 동일인 신호가 된다.
2) 역검색: 조회 가능한 셀렉터(새로 나온 이메일·아이디·전화)를 가치 순으로 랭크해,
   예산 안에서 다음 파동의 씨앗으로 재투입한다 → 수렴까지.

Bellingcat식 — 재사용 식별자 하나로 수십 신원을 연다. 엔진 위 오케스트레이션.
"""
from __future__ import annotations

import re

from .model import Graph, Entity, Edge, EntityType, Certainty, Evidence
from .engine import Engine
from .selectors import extract_selectors, _BTC, _ETH, _PGP
from .resolve import EntityResolver, correlate_owners

# 조회 가능한(재투입 가능) 셀렉터 종류 → 씨앗 값.
_QUERYABLE = {"email", "phone", "username"}
# 상관 전용(공유하면 동일인 신호, 재조회는 안 함).
_CORRELATION = {"crypto", "pgp", "image_phash", "tracker", "ssh_key"}


def promote_selectors(graph: Graph) -> int:
    """계정/신원의 bio·텍스트에서 암호화폐·PGP를 TRACKER 엔티티로 승격. 개수 반환."""
    added = 0
    for e in list(graph.entities):
        if e.type not in (EntityType.ACCOUNT, EntityType.USERNAME, EntityType.NAME):
            continue
        blob = " ".join(str(e.attrs.get(k, "")) for k in ("bio", "txt", "about")) + " " + e.value
        found = [("crypto", m) for m in set(_BTC.findall(blob)) | set(_ETH.findall(blob))]
        found += [("pgp", m) for m in set(_PGP.findall(blob)) if not m.startswith("0x")]
        for kind, val in found:
            t = Entity(EntityType.TRACKER, f"{kind}:{val}", Certainty.CONFIRMED,
                       attrs={"kind": kind},
                       evidence=[Evidence("셀렉터승격", f"{kind} 고유 식별자")])
            graph.add(t)
            if graph.link(Edge(e.key, t.key, "고유 셀렉터", Certainty.CONFIRMED,
                               evidence=[Evidence("셀렉터승격", f"{kind}={val}")])):
                added += 1
    return added


class AutoPivot:
    def __init__(self, collectors, cache=None, max_rounds: int = 3,
                 max_pivots_per_round: int = 12, **engine_kw):
        self.collectors = collectors
        self.cache = cache
        self.max_rounds = max_rounds
        self.max_pivots_per_round = max_pivots_per_round
        self.engine_kw = engine_kw
        self.graph = Graph()
        self.rounds_log: list[dict] = []

    def _engine(self) -> Engine:
        from .cache import Cache
        return Engine(self.collectors, cache=self.cache or Cache(),
                      resolve=False, use_bandit=False, **self.engine_kw)

    async def _scan(self, values) -> Graph:
        eng = self._engine()
        async for _ in eng.run(list(values)):
            pass
        return eng.graph

    async def investigate(self, inputs) -> Graph:
        self.graph = await self._scan(inputs)
        seeded = {v.strip().lower() for v in inputs}

        for rnd in range(self.max_rounds):
            promote_selectors(self.graph)
            EntityResolver().correlate(self.graph)
            correlate_owners(self.graph)

            # 조회 가능한 새 셀렉터를 가치 순으로.
            cands = []
            for s in extract_selectors(self.graph):
                if s["kind"] in _QUERYABLE and s["selector"].strip().lower() not in seeded:
                    cands.append(s)
            # 새로 나온 이메일·아이디·전화 엔티티도 씨앗 후보(엔티티 확장 밖의 것).
            for e in self.graph.entities:
                if e.type.value in _QUERYABLE and e.value.strip().lower() not in seeded:
                    cands.append({"selector": e.value, "kind": e.type.value,
                                  "pivot_value": 0.6, "why": "신규 식별자"})
            # 중복 제거 + 랭크.
            uniq, seen = [], set()
            for c in sorted(cands, key=lambda x: -x["pivot_value"]):
                k = c["selector"].strip().lower()
                if k not in seen:
                    seen.add(k); uniq.append(c)
            batch = uniq[:self.max_pivots_per_round]
            if not batch:
                self.rounds_log.append({"round": rnd + 1, "pivots": 0, "reason": "수렴"})
                break

            values = [c["selector"] for c in batch]
            self.graph.merge(await self._scan(values))
            seeded |= {v.strip().lower() for v in values}
            self.rounds_log.append({"round": rnd + 1, "pivots": len(batch),
                                    "values": values[:20]})

        promote_selectors(self.graph)
        EntityResolver().correlate(self.graph)
        correlate_owners(self.graph)
        return self.graph
