"""입력 조각의 타입 판정 — 전부 일반 코드(AI 0회).

판정은 결정적 규칙이다. 애매하면 UNKNOWN으로 두고, 라우터가
가능한 여러 경로로 보내되 근거 없는 단정은 하지 않는다.
"""
from __future__ import annotations

import re

from .model import EntityType

_EMAIL = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
_IPV4 = re.compile(r"^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$")
_IPV6 = re.compile(r"^[0-9a-fA-F:]+:[0-9a-fA-F:]+$")
_DOMAIN = re.compile(r"^(?=.{1,253}$)([a-zA-Z0-9](-?[a-zA-Z0-9])*\.)+[a-zA-Z]{2,}$")
_URL = re.compile(r"^https?://", re.I)
_PHONE = re.compile(r"^\+?[\d][\d\s\-().]{5,}$")
_USERNAME = re.compile(r"^[a-zA-Z0-9._\-]{2,64}$")
# 한글 등 비ASCII 글자가 있고 공백/두 어절이면 사람 이름으로 본다.
_HANGUL = re.compile(r"[가-힣]")
# 암호화폐 주소: BTC(base58 1/3, bech32 bc1), ETH(0x40hex).
_BTC = re.compile(r"^(bc1[a-z0-9]{25,90}|[13][a-km-zA-HJ-NP-Z1-9]{25,39})$")
_ETH = re.compile(r"^0x[a-fA-F0-9]{40}$")


_DOB_SEP = re.compile(r"^(\d{1,4})[-./](\d{1,2})[-./](\d{1,4})$")
_DOB_COMPACT = re.compile(r"^\d{8}$")
_DOB_ISO_LEAD = re.compile(r"^(\d{4})-(\d{2})-(\d{2})")


def normalize_dob(value: str) -> str | None:
    """생년월일을 ISO(YYYY-MM-DD)로 정규화. 아니면 None. 다양한 표기·앞부분 날짜 허용."""
    v = (value or "").strip()
    if not v:
        return None
    m = _DOB_ISO_LEAD.match(v)          # '1990-01-01T..' 같은 앞부분 날짜
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        return _iso_if_valid(y, mo, d)
    if _DOB_COMPACT.match(v):           # YYYYMMDD
        y, mo, d = int(v[:4]), int(v[4:6]), int(v[6:8])
        return _iso_if_valid(y, mo, d)
    m = _DOB_SEP.match(v)
    if m:
        a, b, c = m.groups()
        if len(a) == 4:                 # YYYY-MM-DD
            return _iso_if_valid(int(a), int(b), int(c))
        if len(c) == 4:                 # DD-MM-YYYY
            return _iso_if_valid(int(c), int(b), int(a))
    return None


def _iso_if_valid(y, mo, d):
    import datetime
    if not (1900 <= y <= 2025):
        return None
    try:
        datetime.date(y, mo, d)                 # 실제 달력 유효성(2월 30일 등 거름)
    except ValueError:
        return None
    return f"{y:04d}-{mo:02d}-{d:02d}"


def detect(value: str) -> EntityType:
    v = (value or "").strip()
    if not v:
        return EntityType.UNKNOWN
    if _URL.match(v):
        return EntityType.URL
    if _EMAIL.match(v):
        return EntityType.EMAIL
    # 생년월일은 전화(7자리+)보다 먼저 판정(YYYYMMDD가 전화로 오인되지 않게).
    if normalize_dob(v):
        return EntityType.DOB
    if _ipv4_ok(v) or _IPV6.match(v):
        return EntityType.IP
    if _BTC.match(v) or _ETH.match(v):
        return EntityType.CRYPTO
    if _DOMAIN.match(v):
        return EntityType.DOMAIN
    if _PHONE.match(v) and sum(c.isdigit() for c in v) >= 7:
        return EntityType.PHONE
    # 이름: 한글 포함, 또는 공백으로 나뉜 두 어절 이상의 글자.
    if _HANGUL.search(v):
        return EntityType.NAME
    if " " in v and all(part.isalpha() for part in v.split()):
        return EntityType.NAME
    if _USERNAME.match(v):
        return EntityType.USERNAME
    return EntityType.UNKNOWN


def _ipv4_ok(v: str) -> bool:
    m = _IPV4.match(v)
    if not m:
        return False
    return all(0 <= int(g) <= 255 for g in m.groups())
