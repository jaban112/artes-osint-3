"""증거 출처 추적·오염 전파 — 3권 "무보증 발화 0"을 시스템 위상으로(§5).

모든 결론의 "왜"를 역추적하고, 잘못된 전제가 전파되는 걸 막는 면역계.
유출 하나가 오염 판명되면, 그 유출에 의존한 모든 하위 결론이 자동 재평가된다.

그래프의 간선이 곧 유도 사슬이다(src → dst = dst는 src에서 유도). 여기서:
- derivation_chain: 씨앗에서 이 엔티티까지의 근거 경로("왜 존재하나").
- dependents: 이 엔티티/출처에서 유도된 하위 전부.
- taint: 출처를 오염 표시하고 하위를 재평가(확실→불확실 강등, 근거 기록).
"""
from __future__ import annotations

from collections import deque

from .model import Graph, Certainty, Evidence


def dependents(graph: Graph, key: str) -> set[str]:
    """key 에서 간선을 따라 도달하는 하위 엔티티(유도된 것들)."""
    out = set()
    q = deque([key])
    while q:
        cur = q.popleft()
        for e in graph.edges:
            if e.src == cur and e.dst not in out and e.dst != key:
                out.add(e.dst); q.append(e.dst)
    return out


def derivation_chain(graph: Graph, key: str, seeds: set[str] | None = None) -> list[str]:
    """씨앗(또는 입력)에서 key 까지의 최단 근거 경로. 역방향 BFS."""
    parents = {}
    q = deque([key])
    seen = {key}
    root = None
    while q:
        cur = q.popleft()
        incoming = [e.src for e in graph.edges if e.dst == cur]
        if not incoming:
            root = cur; break
        for p in incoming:
            if p not in seen:
                seen.add(p); parents[p] = cur; q.append(p)
                if seeds and p in seeds:
                    root = p; parents[p] = cur; q.clear(); break
    if root is None:
        return [key]
    chain = [root]
    cur = root
    while cur != key and cur in parents:
        cur = parents[cur]; chain.append(cur)
    return chain


def taint(graph: Graph, key: str, reason: str) -> list[str]:
    """key 와 그 하위 전부를 오염 표시: 확실→불확실 강등 + 근거 기록. 영향 키 목록."""
    affected = {key} | dependents(graph, key)
    for k in affected:
        ent = graph.get(k)
        if ent is None:
            continue
        if ent.certainty is Certainty.CONFIRMED:
            ent.certainty = Certainty.UNCONFIRMED
            ent.confidence = min(ent.confidence or 0.5, 0.3)
        ent.evidence.append(Evidence("오염전파", f"출처 오염 재평가: {reason}"))
        ent.attrs["tainted"] = True
    return sorted(affected)
