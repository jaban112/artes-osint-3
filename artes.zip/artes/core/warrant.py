"""신뢰 하한 — 「보증된 선택」(5권)의 정확 이항 하한을 코드로.

점추정(임의 %) 대신, k개의 맞는 신호 / n개의 비교 신호에서 참 일치율의
**정확 하한**(Clopper–Pearson)을 낸다. scipy 없이 정규화 불완전베타를
연분수(Lentz)로 계산하고 이분법으로 역산한다 — 결정적, 근사 상수 없음.

용어 규약(외계어 금지): 공개 API·UI에는 "신뢰 하한"으로만 노출한다.
"""
from __future__ import annotations

import math


def _betacf(a: float, b: float, x: float, itmax: int = 300, eps: float = 3e-16) -> float:
    """정규화 불완전베타의 연분수 부분(Lentz 방법)."""
    qab, qap, qam = a + b, a + 1.0, a - 1.0
    c = 1.0
    d = 1.0 - qab * x / qap
    if abs(d) < 1e-300:
        d = 1e-300
    d = 1.0 / d
    h = d
    for m in range(1, itmax + 1):
        m2 = 2 * m
        aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1.0 + aa * d
        if abs(d) < 1e-300:
            d = 1e-300
        c = 1.0 + aa / c
        if abs(c) < 1e-300:
            c = 1e-300
        d = 1.0 / d
        h *= d * c
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1.0 + aa * d
        if abs(d) < 1e-300:
            d = 1e-300
        c = 1.0 + aa / c
        if abs(c) < 1e-300:
            c = 1e-300
        d = 1.0 / d
        de = d * c
        h *= de
        if abs(de - 1.0) < eps:
            break
    return h


def betai(a: float, b: float, x: float) -> float:
    """정규화 불완전베타 I_x(a, b) ∈ [0, 1]."""
    if x <= 0.0:
        return 0.0
    if x >= 1.0:
        return 1.0
    lnbeta = math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b)
    front = math.exp(lnbeta + a * math.log(x) + b * math.log1p(-x))
    if x < (a + 1.0) / (a + b + 2.0):
        return front * _betacf(a, b, x) / a
    return 1.0 - front * _betacf(b, a, 1.0 - x) / b


def beta_ppf(p: float, a: float, b: float, tol: float = 1e-12) -> float:
    """I_x(a,b) = p 의 x 역산(이분법). 0<p<1."""
    lo, hi = 0.0, 1.0
    for _ in range(200):
        mid = 0.5 * (lo + hi)
        if betai(a, b, mid) < p:
            lo = mid
        else:
            hi = mid
        if hi - lo < tol:
            break
    return 0.5 * (lo + hi)


def cp_lower(k: int, n: int, alpha: float = 0.05) -> float:
    """k/n 에 대한 Clopper–Pearson 단측 신뢰 하한(신뢰 1−alpha)."""
    if n <= 0:
        return 0.0
    if k <= 0:
        return 0.0
    if k >= n:
        return alpha ** (1.0 / n)          # 정확: 하한 = alpha^(1/n)
    return beta_ppf(alpha, k, n - k + 1)


def cp_interval(k: int, n: int, alpha: float = 0.05) -> tuple[float, float]:
    """양측 Clopper–Pearson 구간."""
    if n <= 0:
        return 0.0, 1.0
    lo = 0.0 if k == 0 else beta_ppf(alpha / 2, k, n - k + 1)
    hi = 1.0 if k == n else beta_ppf(1 - alpha / 2, k + 1, n - k)
    return lo, hi
