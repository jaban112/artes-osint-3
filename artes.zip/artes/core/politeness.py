"""매너/반밴 계층 — 대규모 스캔이 실제로 굴러가게.

- RateLimiter: 호스트별 최소 간격(토큰버킷). 같은 API를 도배하지 않는다.
- with_retry: 지수 백오프 + 지터로 일시 실패·429를 흡수.
- 프록시 풀 로테이션 / Tor 서킷 재생성(NEWNYM): IP 밴 회피.

전역 POLICY를 proc의 HTTP 헬퍼가 참조한다. 기본은 온건(호스트당 1req/0.5s, 재시도 3).
"""
from __future__ import annotations

import asyncio
import random
import socket
import time
from dataclasses import dataclass, field
from urllib.parse import urlparse


class RateLimiter:
    """호스트별 최소 간격 보장. async."""
    def __init__(self, min_interval: float = 0.5):
        self.min_interval = min_interval
        self._last: dict[str, float] = {}
        self._locks: dict[str, asyncio.Lock] = {}

    def _lock(self, host: str) -> asyncio.Lock:
        if host not in self._locks:
            self._locks[host] = asyncio.Lock()
        return self._locks[host]

    async def acquire(self, host: str) -> None:
        async with self._lock(host):
            now = time.monotonic()
            wait = self.min_interval - (now - self._last.get(host, 0.0))
            if wait > 0:
                await asyncio.sleep(wait)
            self._last[host] = time.monotonic()


@dataclass
class Policy:
    retries: int = 3
    base_delay: float = 0.7
    max_delay: float = 8.0
    min_interval: float = 0.5
    proxies: list[str] = field(default_factory=list)   # http(s)://host:port
    _proxy_i: int = 0
    tor_socks: str = ""                                 # socks5h://127.0.0.1:9050
    tor_control_port: int = 9051
    limiter: RateLimiter = field(default_factory=lambda: RateLimiter())

    def __post_init__(self):
        self.limiter.min_interval = self.min_interval

    def next_proxy(self) -> str | None:
        if self.tor_socks:
            return self.tor_socks
        if not self.proxies:
            return None
        p = self.proxies[self._proxy_i % len(self.proxies)]
        self._proxy_i += 1
        return p

    def backoff(self, attempt: int) -> float:
        d = min(self.max_delay, self.base_delay * (2 ** attempt))
        return d * (0.5 + random.random())            # 지터

    def tor_newnym(self) -> bool:
        """Tor 서킷 재생성(새 출구 IP). control 포트로 NEWNYM."""
        try:
            with socket.create_connection(("127.0.0.1", self.tor_control_port), timeout=3) as s:
                s.sendall(b'AUTHENTICATE ""\r\n')
                s.recv(256)
                s.sendall(b"SIGNAL NEWNYM\r\n")
                return b"250" in s.recv(256)
        except OSError:
            return False


# 전역 정책(proc가 참조). 기본 온건.
POLICY = Policy()


def host_of(url: str) -> str:
    try:
        return urlparse(url).netloc or url
    except Exception:
        return url


async def with_retry(coro_factory, retries: int | None = None):
    """coro_factory(): 매 시도마다 새 코루틴 반환. None/예외면 백오프 재시도."""
    r = POLICY.retries if retries is None else retries
    last = None
    for attempt in range(r + 1):
        try:
            result = await coro_factory()
            if result is not None:
                return result
            last = None
        except Exception as e:               # noqa
            last = e
        if attempt < r:
            await asyncio.sleep(POLICY.backoff(attempt))
    return None if last is None else None
