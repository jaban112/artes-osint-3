"""검색 연산자 마스터리 — 검색엔진을 무기로(§2 pro). 순수 코드(질의 생성).

표적 정보로 수십 개 dork를 자동 생성해 여러 엔진(Google·Bing·DuckDuckGo·Yandex·Brave)
검색 URL을 만든다. 실제 검색은 사용자 VM에서(엔진은 스크래핑/키를 막음) — ARTES는
'초 단위로 조사 리드를 뿌리는' 질의 생성을 담당.
"""
from __future__ import annotations

import urllib.parse

_ENGINES = {
    "google": "https://www.google.com/search?q=",
    "bing": "https://www.bing.com/search?q=",
    "duckduckgo": "https://duckduckgo.com/?q=",
    "yandex": "https://yandex.com/search/?text=",
    "brave": "https://search.brave.com/search?q=",
}


def _dorks_for(value: str, kind: str) -> list[str]:
    v = value.strip()
    q = f'"{v}"'
    if kind == "name":
        return [f'{q} site:linkedin.com', f'{q} site:facebook.com', f'{q} 이메일 OR email',
                f'{q} filetype:pdf', f'{q} 회사 OR company', f'{q} 전화 OR phone']
    if kind == "email":
        return [q, f'{q} -site:{v.split("@")[-1]}', f'{q} filetype:xlsx OR filetype:csv',
                f'{q} site:pastebin.com', f'{q} 비밀번호 OR password OR leak']
    if kind == "username":
        return [q, f'intitle:{q}', f'inurl:{v}', f'{q} site:github.com',
                f'{q} site:reddit.com', f'{q} 프로필 OR profile']
    if kind == "domain":
        return [f'site:{v}', f'site:{v} filetype:pdf', f'site:{v} intitle:"index of"',
                f'inurl:{v} -site:{v}', f'"{v}" 이메일 OR email', f'site:{v} inurl:admin OR inurl:login']
    if kind == "phone":
        return [q, f'{q} 이름 OR name', f'{q} site:facebook.com', f'{q} 판매 OR 중고']
    return [q]


def generate_dorks(value: str, kind: str,
                   engines: list[str] | None = None) -> list[dict]:
    engines = engines or list(_ENGINES)
    out = []
    for dork in _dorks_for(value, kind):
        enc = urllib.parse.quote(dork)
        for eng in engines:
            if eng in _ENGINES:
                out.append({"engine": eng, "query": dork, "url": _ENGINES[eng] + enc})
    return out
