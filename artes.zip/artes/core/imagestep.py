"""이미지 아바타 해시 단계(증분 36) — 프로필 사진을 받아 pHash 계산 → 같은 사진=동일인.

인프라(imagehash.phash_bytes, resolve._image_pairs)는 이미 있었지만 아바타를 실제로 받아
해시하는 단계가 없어 꺼져 있었다. 여기서 계정 엔티티의 아바타 URL을 병렬로 받아 pHash를
attrs['image_phash']에 채운다. 그러면 resolve가 같은 사진을 공유하는 계정들을 자동으로
'동일인(확실)'으로 잇는다 — 플랫폼이 달라도 같은 사진이면 같은 사람.

정직: 웹 역이미지검색(구글/얀덱스/TinEye)은 캡차·키라 무키 불가. 여기선 '우리가 찾은 계정들
사이의 사진 교차대조'까지 — 그것만으로도 강력하다(다른 플랫폼 같은 셀카 = 확실한 동일인).
"""
from __future__ import annotations

import asyncio

from .model import EntityType
from .imagehash import phash_bytes

_AVATAR_KEYS = ("avatar", "avatar_url", "profile_pic", "profile_pic_url", "profile_pic_url_hd",
                "image", "thumbnail", "thumbnail_url", "picture", "icon_img", "avatar_thumb",
                "profile_image", "profile_image_url", "profile_image_url_https")


def avatar_url(ent) -> str | None:
    a = ent.attrs or {}
    for k in _AVATAR_KEYS:
        v = a.get(k)
        if isinstance(v, str) and v.startswith("http"):
            return v
    return None


async def hash_avatars(graph, max_images: int = 96, concurrency: int = 32,
                       timeout: float = 10.0) -> int:
    """계정 엔티티의 아바타를 병렬로 받아 pHash 채움. 반환=해시한 이미지 수."""
    from ..collectors.proc import get_bytes
    targets = []
    for ent in graph.entities:
        if ent.attrs.get("image_phash"):
            continue
        if ent.attrs.get("rel_node"):        # 관계망(팔로워/팔로잉) 노드는 pHash 예산서 제외(속도)
            continue
        u = avatar_url(ent)
        if u:
            targets.append((ent, u))
    targets = targets[:max_images]
    if not targets:
        return 0
    sem = asyncio.Semaphore(concurrency)
    done = 0

    async def _one(ent, url):
        nonlocal done
        async with sem:
            data = await get_bytes(url, timeout=timeout, max_bytes=3_000_000)
        if data:
            h = phash_bytes(data)
            if h:
                ent.attrs["image_phash"] = h
                done += 1

    await asyncio.gather(*[_one(e, u) for e, u in targets], return_exceptions=True)
    return done
