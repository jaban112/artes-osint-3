"""내보내기 — GraphML·Maltego CSV·STIX 2.1(§88). 팀·타 도구 상호운용.

확실/불확실·근거를 보존해 다른 분석 도구(Gephi·Maltego·MISP/STIX 파이프라인)로 넘긴다.
"""
from __future__ import annotations

import csv
import io
import json
import uuid
import xml.sax.saxutils as sx

from .model import Graph


def to_graphml(graph: Graph) -> str:
    def esc(x):
        return sx.escape(str(x))
    out = ['<?xml version="1.0" encoding="UTF-8"?>',
           '<graphml xmlns="http://graphml.graphdrawing.org/xmlns">',
           '<key id="type" for="node" attr.name="type" attr.type="string"/>',
           '<key id="value" for="node" attr.name="value" attr.type="string"/>',
           '<key id="certainty" for="node" attr.name="certainty" attr.type="string"/>',
           '<key id="rel" for="edge" attr.name="relation" attr.type="string"/>',
           '<graph edgedefault="directed">']
    for e in graph.entities:
        out.append(f'<node id="{esc(e.key)}">'
                   f'<data key="type">{esc(e.type.value)}</data>'
                   f'<data key="value">{esc(e.value)}</data>'
                   f'<data key="certainty">{esc(e.certainty.value)}</data></node>')
    for i, ed in enumerate(graph.edges):
        out.append(f'<edge id="e{i}" source="{esc(ed.src)}" target="{esc(ed.dst)}">'
                   f'<data key="rel">{esc(ed.relation)}</data></edge>')
    out += ['</graph>', '</graphml>']
    return "\n".join(out)


def to_maltego_csv(graph: Graph) -> str:
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["key", "type", "value", "certainty", "confidence"])
    for e in graph.entities:
        w.writerow([e.key, e.type.value, e.value, e.certainty.value, e.confidence or ""])
    w.writerow([])
    w.writerow(["src", "relation", "dst", "certainty"])
    for ed in graph.edges:
        w.writerow([ed.src, ed.relation, ed.dst, ed.certainty.value])
    return buf.getvalue()


_STIX_TYPE = {
    "email": "email-addr", "domain": "domain-name", "ip": "ipv4-addr",
    "url": "url", "username": "user-account", "account": "user-account",
    "name": "identity", "phone": "identity",
}


def to_stix(graph: Graph) -> str:
    objs = []
    idmap = {}
    for e in graph.entities:
        st = _STIX_TYPE.get(e.type.value, "x-artes-observable")
        oid = f"{st}--{uuid.uuid5(uuid.NAMESPACE_URL, e.key)}"
        idmap[e.key] = oid
        obj = {"type": st, "id": oid, "spec_version": "2.1"}
        if st == "identity":
            obj["name"] = e.value
        elif st == "email-addr":
            obj["value"] = e.value
        elif st == "domain-name":
            obj["value"] = e.value
        elif st == "ipv4-addr":
            obj["value"] = e.value
        elif st == "url":
            obj["value"] = e.value
        elif st == "user-account":
            obj["account_login"] = e.value
        else:
            obj["value"] = e.value
        obj["x_artes_certainty"] = e.certainty.value
        objs.append(obj)
    for ed in graph.edges:
        if ed.src in idmap and ed.dst in idmap:
            rid = f"relationship--{uuid.uuid4()}"
            objs.append({"type": "relationship", "id": rid, "spec_version": "2.1",
                         "relationship_type": ed.relation,
                         "source_ref": idmap[ed.src], "target_ref": idmap[ed.dst],
                         "x_artes_certainty": ed.certainty.value})
    return json.dumps({"type": "bundle", "id": f"bundle--{uuid.uuid4()}",
                       "objects": objs}, ensure_ascii=False, indent=2)


FORMATS = {"graphml": to_graphml, "csv": to_maltego_csv, "stix": to_stix}
