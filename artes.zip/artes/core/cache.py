"""캐시 — 재조회 0초의 근거.

아카이빙(2권)의 압축+정확검색 발상을 조회 계층에 이식한다:
같은 (수집기, 타입, 정규화 값)은 다시 네트워크로 나가지 않고 저장본을
'정확히' 되짚는다. 지금은 콘텐츠 주소(내용 해시) 기반 JSON 저장이고,
대형화되면 여기만 BWT/FM 본체로 교체하면 된다(인터페이스 불변).
"""
from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import Any


class Cache:
    def __init__(self, root: str | Path | None = None, ttl: float = 7 * 24 * 3600):
        self.root = Path(root) if root else (Path.home() / ".artes" / "cache")
        self.root.mkdir(parents=True, exist_ok=True)
        self.ttl = ttl
        self._mem: dict[str, Any] = {}
        self.hits = 0
        self.misses = 0

    @staticmethod
    def key(collector: str, entity_type: str, value: str) -> str:
        raw = f"{collector}\x00{entity_type}\x00{value}".encode("utf-8")
        return hashlib.sha256(raw).hexdigest()

    def _path(self, k: str) -> Path:
        return self.root / k[:2] / f"{k}.json"

    def get(self, k: str) -> Any | None:
        if k in self._mem:
            self.hits += 1
            return self._mem[k]
        p = self._path(k)
        if not p.exists():
            self.misses += 1
            return None
        try:
            obj = json.loads(p.read_text("utf-8"))
        except Exception:
            self.misses += 1
            return None
        if self.ttl and (time.time() - obj.get("_ts", 0)) > self.ttl:
            self.misses += 1
            return None
        self.hits += 1
        self._mem[k] = obj["data"]
        return obj["data"]

    def put(self, k: str, data: Any) -> None:
        self._mem[k] = data
        p = self._path(k)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps({"_ts": time.time(), "data": data},
                                ensure_ascii=False), "utf-8")

    def stats(self) -> dict[str, int]:
        return {"hits": self.hits, "misses": self.misses}
