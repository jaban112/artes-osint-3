"""이름→아이디 후보 생성(증분 27) — 한글 이름의 로마자·이름만 형태까지.

핵심 문제 해결: "김지완" 같은 한글 풀네임에서 인스타 아이디 "지완"/"jiwan"을 만들어낸다.
기존 username_variants는 입력을 한 덩어리로만 봐서 성/이름 분해·로마자 변환·이름만 형태를
못 만들었다. 여기서 한글 음절 분해(개정 로마자)+흔한 성씨 표기+이름만/성+이름/이니셜을 생성.
전부 규칙 기반(AI 0). 후보는 미확인(불확실)이며, 큰 SNS 존재확인기가 실제로 검증한다.
"""
from __future__ import annotations

import re

# 개정 로마자(RR) 자모 표 — 초성 19·중성 21·종성 28
_CHO = ["g", "kk", "n", "d", "tt", "r", "m", "b", "pp", "s", "ss", "", "j",
        "jj", "ch", "k", "t", "p", "h"]
_JUNG = ["a", "ae", "ya", "yae", "eo", "e", "yeo", "ye", "o", "wa", "wae", "oe",
         "yo", "u", "wo", "we", "wi", "yu", "eu", "ui", "i"]
_JONG = ["", "k", "kk", "ks", "n", "nj", "nh", "t", "l", "lk", "lm", "lb", "ls",
         "lt", "lp", "lh", "m", "p", "ps", "s", "ss", "ng", "j", "ch", "k", "t", "p", "h"]

# 흔한 성씨의 실제 통용 표기(RR과 다른 관습 표기 포함)
_SURNAME = {
    "김": ["kim", "gim"], "이": ["lee", "yi", "rhee"], "박": ["park", "bak"],
    "최": ["choi", "choe"], "정": ["jung", "jeong", "chung"], "강": ["kang", "gang"],
    "조": ["cho", "jo"], "윤": ["yoon", "yun"], "장": ["jang", "chang"],
    "임": ["lim", "im", "rim"], "한": ["han"], "오": ["oh", "o"], "서": ["seo", "suh"],
    "신": ["shin", "sin"], "권": ["kwon", "gwon"], "황": ["hwang"], "안": ["ahn", "an"],
    "송": ["song"], "전": ["jeon", "jun"], "홍": ["hong"], "유": ["yoo", "yu", "ryu"],
    "고": ["ko", "go"], "문": ["moon", "mun"], "손": ["son"], "양": ["yang"],
    "배": ["bae"], "백": ["baek", "paik"], "남": ["nam"], "노": ["noh", "no", "roh"],
    "하": ["ha"], "성": ["sung", "seong"], "차": ["cha"], "주": ["joo", "ju"],
    "우": ["woo", "wu"], "구": ["koo", "gu"], "민": ["min"], "나": ["na", "ra"],
    "지": ["ji", "jee"], "천": ["cheon", "chun"], "방": ["bang"], "심": ["shim", "sim"],
    "허": ["heo", "hur", "huh"], "곽": ["kwak"], "성문": ["sungmun"],
}

# 이름(given) 로마자 변형 규칙 — 흔한 대체 표기(한 번에 하나씩 적용)
_GIVEN_ALT = [
    ("eu", "u"), ("yeong", "young"), ("seong", "sung"), ("jun", "joon"),
    ("hyeon", "hyun"), ("woo", "wu"), ("gyu", "kyu"), ("eo", "u"),
]


def _is_hangul(ch: str) -> bool:
    return "가" <= ch <= "힣"


def romanize_syllable(ch: str) -> str:
    if not _is_hangul(ch):
        return ch
    code = ord(ch) - 0xAC00
    cho, rem = divmod(code, 21 * 28)
    jung, jong = divmod(rem, 28)
    return _CHO[cho] + _JUNG[jung] + _JONG[jong]


def romanize(text: str) -> str:
    """한글 문자열을 개정 로마자로(비한글은 그대로)."""
    return "".join(romanize_syllable(c) for c in (text or ""))


def _given_variants(hangul_given: str) -> list[str]:
    """이름(given)의 로마자 후보들 — RR + 흔한 대체 표기."""
    base = romanize(hangul_given)
    out = {base}
    for a, b in _GIVEN_ALT:
        if a in base:
            out.add(base.replace(a, b))
    return [v for v in out if v]


def _surname_variants(hangul_family: str) -> list[str]:
    if hangul_family in _SURNAME:
        return list(_SURNAME[hangul_family])
    return [romanize(hangul_family)]


def _decorate(cands: list[str], max_extra: int = 6) -> list[str]:
    """상위 후보 몇 개에 흔한 장식(_, ., 숫자, official 등) 부착."""
    extra = []
    for c in cands[:4]:
        for suf in ("_", ".", "1", "01", "07", "official", "real"):
            extra.append(f"{c}{suf}")
        extra.append(f"_{c}")
    return extra[:max_extra]


def korean_name_handles(name: str) -> list[str]:
    """한글 풀네임 → 아이디 후보. '김지완'→ 지완·jiwan·kimjiwan·jiwankim·kim.jiwan·kjw…"""
    s = re.sub(r"\s+", "", name.strip())
    hangul = [c for c in s if _is_hangul(c)]
    if len(hangul) < 2:
        # 한 글자 등은 그대로 로마자만
        r = romanize(s)
        return [s, r] if r and r != s else [s]
    # 한국 이름: 첫 글자=성, 나머지=이름(대부분). 성이 두 글자인 복성은 소수라 단순화.
    family_h, given_h = hangul[0], "".join(hangul[1:])
    fam = _surname_variants(family_h)
    giv = _given_variants(given_h)
    out: list[str] = []
    # 1) 이름만(가장 흔한 개인 아이디) — 한글·로마자 둘 다. ★핵심
    out.append(given_h)                 # 지완
    out.extend(giv)                     # jiwan (+대체표기)
    # 2) 성+이름 / 이름+성 (붙여쓰기·구분자)
    for f in fam:
        for g in giv:
            out += [f + g, g + f, f"{f}.{g}", f"{f}_{g}", f"{g}.{f}"]
    # 3) 이니셜
    for f in fam:
        for g in giv:
            out.append((f[0] + g) if g else f)          # kjiwan
            out.append((f[0] + g[0]) if g else f)        # kj
    # 4) 한글 성+이름 전체
    out.append(family_h + given_h)      # 김지완
    # 5) 장식
    out += _decorate([given_h] + giv)
    # 정리: 중복 제거·2~30자, 순서 보존
    seen, final = set(), []
    for v in out:
        v = v.strip()
        k = v.lower()
        if v and 2 <= len(v) <= 30 and k not in seen:
            seen.add(k)
            final.append(v)
    return final[:30]


def latin_name_handles(name: str) -> list[str]:
    """라틴 풀네임 → 아이디 후보. 'John Smith'→ john·jsmith·johnsmith·john.smith·js…"""
    parts = [p for p in re.split(r"[\s._\-]+", name.strip().lower()) if p]
    if not parts:
        return []
    if len(parts) == 1:
        from .enrich import username_variants
        return username_variants(parts[0])
    first, last = parts[0], parts[-1]
    out = [
        first, last, first + last, last + first,
        f"{first}.{last}", f"{first}_{last}", f"{first}-{last}",
        f"{first[0]}{last}", f"{first[0]}.{last}", f"{first}{last[0]}",
        "".join(p[0] for p in parts),                # 이니셜
        first + last[0], last + first[0],
    ]
    out += _decorate([first, first + last, f"{first}.{last}"])
    seen, final = set(), []
    for v in out:
        if v and 2 <= len(v) <= 30 and v not in seen:
            seen.add(v)
            final.append(v)
    return final[:30]


def name_handles(name: str) -> list[str]:
    """이름→아이디 후보(한글/라틴 자동 판별)."""
    if any(_is_hangul(c) for c in (name or "")):
        return korean_name_handles(name)
    return latin_name_handles(name)
