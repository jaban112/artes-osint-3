"""워크플로우 기록·재현 — 수사를 "프로그램"으로(§10, 5권 경로선택의 승격).

"실종자 수사", "사기 계정 추적" 같은 절차를 한 번 만들면 다음 표적에 한 번에 적용.
그리고 어떤 표적 유형에 효과적이었는지 성과를 학습한다(Maltego 정적 머신과 다른 지점).
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass, field, asdict
from pathlib import Path


@dataclass
class Workflow:
    name: str
    description: str = ""
    depth: int = 2
    max_queries: int = 2000
    max_seconds: float = 180.0
    darkweb: bool = False
    verify: bool = False
    runs: int = 0
    total_entities: int = 0
    effective_types: dict = field(default_factory=dict)   # 표적유형 → 평균 산출

    def record(self, seed_types: list[str], entities: int) -> None:
        self.runs += 1
        self.total_entities += entities
        for t in set(seed_types):
            cur = self.effective_types.get(t, [0, 0])   # [runs, total]
            self.effective_types[t] = [cur[0] + 1, cur[1] + entities]

    def avg_entities(self) -> float:
        return round(self.total_entities / self.runs, 1) if self.runs else 0.0

    def to_dict(self):
        return asdict(self)


DEFAULTS = {
    "person": Workflow("person", "개인 프로파일(계정·연락처·발자국)", depth=2, verify=True),
    "fraud": Workflow("fraud", "사기 계정 추적(유출·재사용·동일인)", depth=3, verify=True),
    "developer": Workflow("developer", "개발자(GitHub 커밋→실명·이메일)", depth=2),
    "infra": Workflow("infra", "도메인 인프라(RDAP·crt.sh·DNS·운영자)", depth=2),
    "missing": Workflow("missing", "실종자(전 축·다크웹·타임라인)", depth=3, darkweb=True, verify=True),
}


class WorkflowStore:
    def __init__(self, root: str | None = None):
        self.root = Path(root) if root else (Path.home() / ".artes" / "workflows")
        self.root.mkdir(parents=True, exist_ok=True)

    def _path(self, name: str) -> Path:
        return self.root / f"{name}.json"

    def get(self, name: str) -> Workflow | None:
        p = self._path(name)
        if p.exists():
            try:
                return Workflow(**json.loads(p.read_text("utf-8")))
            except Exception:
                pass
        return DEFAULTS.get(name)

    def save(self, wf: Workflow) -> None:
        self._path(wf.name).write_text(json.dumps(wf.to_dict(), ensure_ascii=False), "utf-8")

    def list(self) -> list[str]:
        names = {p.stem for p in self.root.glob("*.json")} | set(DEFAULTS)
        return sorted(names)

    def record_run(self, name: str, seed_types: list[str], entities: int) -> Workflow:
        wf = self.get(name) or Workflow(name)
        wf.record(seed_types, entities)
        self.save(wf)
        return wf
