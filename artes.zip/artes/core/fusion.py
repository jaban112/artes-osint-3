"""베이지안 신호 융합 — 여러 약한 근거의 수학적으로 정당한 종합(§2).

각 신호에 우도비 LR = P(신호|동일인)/P(신호|타인) 를 부여하고, 사전 오즈에
곱해 사후 확률을 낸다(로그오즈 누적). "이름유사(약)+같은 시간대(약)+지명 겹침(약)"이
개별론 바닥이어도 결합하면 높은 확신이 된다 — Maltego가 선을 긋기만 하는 것과 다른 지점.

정직: 이 사후확률은 **모델 기반**이다(LR은 가정·교정 대상). 반면 개별 유사도의
Clopper–Pearson 구간은 **측정 기반**(7권 J2)이다 — 둘을 섞지 않고, 사후확률은 모델
신뢰도로, 측정 CI는 근거로 함께 게시한다. LR은 여기 한곳에서 교정한다.
"""
from __future__ import annotations

import math

# 신호별 기본 우도비(보수적). 실배포에서 라벨된 데이터로 교정 가능.
DEFAULT_LR = {
    "image": 60.0,        # 같은 프로필 사진(지각해시 근접)
    "bio_reuse": 40.0,    # 프로필 텍스트 복붙
    "handle": 6.0,        # 동일 핸들(다른 사람도 가능하나 시사적)
    "name_sim": 4.0,      # 이름/핸들 근접(기본; 강도로 스케일)
    "stylometry": 8.0,    # 문체 동일저자 경향
    "timezone": 2.0,      # 활동 시간대 겹침
    "geo": 3.0,           # 언급 지명 겹침
    "follower": 5.0,      # 팔로워 집합 겹침
    "tracker": 50.0,      # 공유 분석/광고 ID(운영자)
    "absence": 1.8,       # 부재 패턴 일치(§6 — 같은 곳들에 똑같이 없음)
}

PRIOR = 0.02              # 임의 두 신원이 동일인일 사전확률(보수적)


def graded_lr(name: str, strength: float | None = None) -> float:
    """등급 신호는 강도(0~1, 예: 유사도 하한)로 LR을 스케일한다."""
    base = DEFAULT_LR.get(name, 2.0)
    if strength is None:
        return base
    s = max(0.0, min(1.0, strength))
    # 강도 0.5에서 base, 1.0에서 base^~2 로 완만히 증가; 낮으면 1로 수렴(무정보).
    return max(1.0, base ** (2 * s))


def fuse(signals: list[tuple[str, float]], prior: float = PRIOR) -> dict:
    """signals: [(name, lr)]. 사후확률 + 로그오즈 + 분해 반환."""
    log_odds = math.log(prior / (1 - prior))
    breakdown = []
    for name, lr in signals:
        lr = max(1e-6, lr)
        log_odds += math.log(lr)
        breakdown.append({"signal": name, "lr": round(lr, 2)})
    odds = math.exp(log_odds)
    p = odds / (1 + odds)
    return {"posterior": p, "log_odds": log_odds, "prior": prior,
            "breakdown": breakdown}
