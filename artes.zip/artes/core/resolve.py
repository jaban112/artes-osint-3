"""동일인 해소 — 7권을 영혼까지. MinHash/LSH 후보 + Clopper–Pearson 신뢰구간.

신호(강→약):
- 하드(구조적 확실): 유일 식별자 공유(이메일·전화), 같은 이미지 지각해시(같은 사진).
- 준하드: 프로필 bio 재사용(복붙), 문체 동일저자 하한 높음.
- 소프트(등급): 이름/핸들 유사도 CI, 문체 유사도 CI, 같은 핸들.

유사도는 점추정이 아니라 **CP 구간**으로 발급하고(J2), '유사도'와 '동일인'을 구분한다
(동명이인 함정): 유사도 CI는 evidence에 싣되, 동일인 신뢰도는 독립 신호 수의 CP로 낸다.
하드 신호가 하나라도 있으면 통계가 아니라 구조적으로 확실(CONFIRMED).

전부 일반 코드(AI 0회). 이미지 해시·문체·bio는 수집기가 attrs에 실어 준 것을 읽는다.
"""
from __future__ import annotations

from collections import defaultdict

from .model import Entity, Edge, EntityType, Certainty, Evidence, Graph
from .similarity import (MinHash, LSH, jaccard_ci, shingles, char_ngrams)
from .warrant import cp_lower
from .fusion import fuse, graded_lr
from .imagehash import hamming_hex

_IDENT = (EntityType.NAME, EntityType.USERNAME, EntityType.ACCOUNT)


def _handle(e: Entity) -> str:
    if e.type is EntityType.ACCOUNT:
        return str(e.attrs.get("handle") or e.value.split("/", 1)[-1])
    return e.value


class EntityResolver:
    def __init__(self, num_perm: int = 64, bands: int = 16, rows: int = 4,
                 sim_threshold: float = 0.5, alpha: float = 0.05,
                 phash_max_hamming: int = 8, use_fs: bool = False,
                 calibrator=None):
        self.mh = MinHash(num_perm=num_perm)
        self.mh_text = MinHash(num_perm=num_perm, k=4, seed=7)
        self.bands, self.rows = bands, rows
        self.sim_threshold = sim_threshold
        self.alpha = alpha
        self.phash_max_hamming = phash_max_hamming
        self.use_fs = use_fs              # Fellegi–Sunter m/u 융합 사용(증분 10)
        self.calibrator = calibrator      # PlattCalibrator 있으면 W→보정확률

    def correlate(self, graph: Graph) -> list[Edge]:
        idents = [e for e in graph.entities if e.type in _IDENT]
        if len(idents) < 2:
            return []
        sigs = {e.key: self.mh.sign_tokens(shingles(_handle(e), self.mh.k))
                for e in idents}
        text_sigs = {}
        for e in idents:
            txt = self._text_of(e)
            if txt:
                text_sigs[e.key] = self.mh_text.sign_tokens(char_ngrams(txt, 4))

        lsh = LSH(self.bands, self.rows)
        for e in idents:
            lsh.add(e.key, sigs[e.key])
        candidates = set(lsh.candidate_pairs())
        candidates |= self._shared_identifier_pairs(graph, idents)
        candidates |= self._image_pairs(idents)
        candidates |= self._face_pairs(idents)
        # 문체 후보(텍스트 있는 것끼리)
        tlsh = LSH(self.bands, self.rows)
        for k, s in text_sigs.items():
            tlsh.add(k, s)
        candidates |= tlsh.candidate_pairs()

        direct = set()
        for e in graph.edges:
            direct.add((e.src, e.dst)); direct.add((e.dst, e.src))

        by_key = {e.key: e for e in idents}
        added: list[Edge] = []
        seen_pairs = set()
        for ka, kb in candidates:
            if (ka, kb) in direct or (ka, kb) in seen_pairs:
                continue
            seen_pairs.add((ka, kb)); seen_pairs.add((kb, ka))
            a, b = by_key.get(ka), by_key.get(kb)
            if not a or not b:
                continue
            edge = self._judge(graph, a, b, sigs, text_sigs)
            if edge is not None:
                res = graph.link(edge)
                if res is not None:
                    added.append(res)
        return added

    # ---- 신호별 후보 ----
    def _shared_identifier_pairs(self, graph, idents):
        owner = defaultdict(list)
        idset = {e.key for e in idents}
        for e in idents:
            for nb in graph.neighbors(e.key):
                if nb.type in (EntityType.EMAIL, EntityType.PHONE, EntityType.DOB):
                    owner[nb.key].append(e.key)
        pairs = set()
        for keys in owner.values():
            keys = sorted(set(keys) & idset)
            if len(keys) < 2:
                continue
            if len(keys) <= 6:
                # 소규모: 전체 쌍(정확한 상관 신호)
                for i in range(len(keys)):
                    for j in range(i + 1, len(keys)):
                        pairs.add((keys[i], keys[j]))
            else:
                # 대규모: 스타(대표 1개에 연결) — 동일인은 전이적이라 n-1개면 충분,
                # O(n²) 헤어볼 방지(예: 아이디 하나에 계정 60개 → 1770쌍이 59개로).
                rep = keys[0]
                for k in keys[1:]:
                    pairs.add((rep, k))
        return pairs

    def _image_pairs(self, idents):
        """지각해시가 근접한 계정 쌍(같은 사진)."""
        withhash = [(e.key, e.attrs.get("image_phash")) for e in idents
                    if e.attrs.get("image_phash")]
        pairs = set()
        for i in range(len(withhash)):
            for j in range(i + 1, len(withhash)):
                ka, ha = withhash[i]; kb, hb = withhash[j]
                if hamming_hex(ha, hb) <= self.phash_max_hamming:
                    pairs.add(tuple(sorted((ka, kb))))
        return pairs

    def _face_pairs(self, idents):
        """얼굴 임베딩이 가까운 계정 쌍(같은 얼굴)."""
        from .face import same_face
        withf = [(e.key, e.attrs.get("face_encoding")) for e in idents
                 if e.attrs.get("face_encoding")]
        pairs = set()
        for i in range(len(withf)):
            for j in range(i + 1, len(withf)):
                ka, fa = withf[i]; kb, fb = withf[j]
                if same_face(fa, fb):
                    pairs.add(tuple(sorted((ka, kb))))
        return pairs

    # ---- 판정 (베이지안 신호 융합) ----
    def _judge(self, graph, a, b, sigs, text_sigs):
        hard_hits = []          # 구조적 확실 신호
        soft = []               # (name, lr) 융합 입력(기본)
        fs_signals = []         # (name, strength) FS 융합 입력(증분 10)
        detail = []             # evidence 문구

        if self._shared_neighbor(graph, a, b, EntityType.EMAIL):
            hard_hits.append("이메일 공유")
        if self._shared_neighbor(graph, a, b, EntityType.PHONE):
            hard_hits.append("전화 공유")

        ha, hb = a.attrs.get("image_phash"), b.attrs.get("image_phash")
        if ha and hb and hamming_hex(ha, hb) <= self.phash_max_hamming:
            hard_hits.append(f"동일 프로필 사진(해밍≤{self.phash_max_hamming})")

        # 얼굴 임베딩 — 다른 사진이라도 같은 얼굴 = 하드.
        fa, fb = a.attrs.get("face_encoding"), b.attrs.get("face_encoding")
        if fa and fb:
            from .face import same_face, distance
            if same_face(fa, fb):
                hard_hits.append(f"동일 얼굴(거리 {distance(fa, fb):.2f})")

        # 공유 고유 셀렉터(암호화폐 주소·PGP·SSH 키) — 재사용 = 하드.
        sel = self._shared_selector(graph, a, b)
        if sel:
            hard_hits.append(f"공유 고유 셀렉터({sel})")

        # 이름/핸들 유사도 CI(J2) — 등급 우도비로.
        ci = jaccard_ci(sigs[a.key], sigs[b.key], self.alpha)
        if ci["lower"] >= self.sim_threshold:
            soft.append(("name_sim", graded_lr("name_sim", ci["lower"])))
            fs_signals.append(("name_sim", ci["lower"]))
            detail.append(f"이름/핸들 유사도 {ci['point']:.2f} CI[{ci['lower']:.2f},{ci['upper']:.2f}]")

        if _handle(a) and _handle(a).casefold() == _handle(b).casefold():
            soft.append(("handle", graded_lr("handle")))
            fs_signals.append(("handle",))
            detail.append("동일 핸들")

        # 부재 지문(§6) — 두 신원이 "같은 곳들에 똑같이 없음".
        aa, ab = a.attrs.get("absent_sites"), b.attrs.get("absent_sites")
        if aa and ab:
            from .negative import absence_similarity
            asim = absence_similarity(set(aa), set(ab), alpha=self.alpha)
            if asim.get("applicable") and asim["lower"] >= 0.5:
                soft.append(("absence", graded_lr("absence", asim["lower"])))
                fs_signals.append(("absence", asim["lower"]))
                detail.append(f"부재 패턴 일치 {asim['point']:.2f}(≥{asim['lower']:.2f})")

        # 문체/ bio 재사용 — 텍스트 있을 때.
        # 하드 재사용(복붙)은 MinHash Jaccard CI로(집합 겹침 측정, J2), 소프트 동일저자
        # 경향은 문자 n-그램 TF-IDF 코사인으로(짧은 글에서 더 변별력 있음 — 증분 9 연구).
        if a.key in text_sigs and b.key in text_sigs:
            sci = jaccard_ci(text_sigs[a.key], text_sigs[b.key], self.alpha)
            if sci["lower"] >= 0.8:
                hard_hits.append(f"프로필 텍스트 재사용(유사도≥{sci['lower']:.2f})")
            else:
                from .stylometry import authorship_similarity
                sty = authorship_similarity(self._text_of(a), self._text_of(b))
                if sty >= 0.4:
                    soft.append(("stylometry", graded_lr("stylometry", sty)))
                    fs_signals.append(("stylometry", sty))
                    detail.append(f"문체(문자 n-그램) 유사도 {sty:.2f}")

        if hard_hits:
            return Edge(a.key, b.key, "동일인", Certainty.CONFIRMED,
                        evidence=[Evidence("동일인해소", "유일/구조 신호 — " + ", ".join(hard_hits + detail))])
        if not soft:
            return None
        if self.use_fs:
            # Fellegi–Sunter m/u 융합(증분 10) — 상관 신호 그룹 축약 + 독립성 가드.
            from .linkage import fuse_fs
            groups = {"visual": ["image", "face"],
                      "identity": ["handle", "name_sim", "stylometry"]}
            fr = fuse_fs(fs_signals, independent_groups=groups)
            conf = fr.posterior
            if self.calibrator is not None:
                conf = self.calibrator.predict(fr.total_weight)
            wtxt = "·".join(f"{b_['signal']}={b_['weight']}비트" for b_ in fr.breakdown)
            return Edge(a.key, b.key, "동일인?", Certainty.UNCONFIRMED, round(conf, 4),
                        evidence=[Evidence("동일인해소",
                                  f"{', '.join(detail)} → FS 사후확률 {conf:.3f} "
                                  f"(총가중 {fr.total_weight:.2f}비트, 독립신호 {fr.n_independent}, {wtxt})")])
        fused = fuse(soft)
        conf = fused["posterior"]
        lrtxt = "·".join(f"{s}×{lr}" for s, lr in
                         [(b_["signal"], b_["lr"]) for b_ in fused["breakdown"]])
        return Edge(a.key, b.key, "동일인?", Certainty.UNCONFIRMED, round(conf, 4),
                    evidence=[Evidence("동일인해소",
                                       f"{', '.join(detail)} → 융합 사후확률 {conf:.3f}"
                                       f"(사전 {fused['prior']}, 우도비 {lrtxt})")])

    def _text_of(self, e: Entity) -> str:
        parts = []
        if e.attrs.get("bio"):
            parts.append(str(e.attrs["bio"]))
        for t in (e.attrs.get("texts") or []):
            parts.append(str(t))
        return " ".join(parts)

    @staticmethod
    def _shared_neighbor(graph, a, b, t) -> bool:
        na = {nb.key for nb in graph.neighbors(a.key) if nb.type is t}
        nb_ = {nb.key for nb in graph.neighbors(b.key) if nb.type is t}
        return bool(na & nb_)

    @staticmethod
    def _shared_selector(graph, a, b) -> str:
        """공유하는 고유 셀렉터(암호화폐/PGP/SSH 키) 종류. 없으면 ''."""
        kinds = ("crypto", "pgp", "ssh_key")
        na = {nb.key: nb.attrs.get("kind") for nb in graph.neighbors(a.key)
              if nb.type is EntityType.TRACKER and nb.attrs.get("kind") in kinds}
        for nb in graph.neighbors(b.key):
            if nb.key in na and nb.type is EntityType.TRACKER:
                return na[nb.key]
        return ""


def correlate_owners(graph: Graph) -> list[Edge]:
    """같은 추적 ID(GA/AdSense/파비콘)를 쓰는 도메인 = 동일 운영자(구조적 확실)."""
    from collections import defaultdict
    tracker_users = defaultdict(list)
    for e in graph.entities:
        if e.type in (EntityType.DOMAIN, EntityType.URL):
            for nb in graph.neighbors(e.key):
                if nb.type is EntityType.TRACKER:
                    tracker_users[nb.key].append(e.key)
    added = []
    linked = set()
    for tid, doms in tracker_users.items():
        doms = sorted(set(doms))
        for i in range(len(doms)):
            for j in range(i + 1, len(doms)):
                pair = (doms[i], doms[j])
                if pair in linked:
                    continue
                linked.add(pair)
                edge = Edge(doms[i], doms[j], "동일 운영자", Certainty.CONFIRMED,
                            evidence=[Evidence("운영자상관", f"공유 추적 ID {tid.split(':')[-1]}")])
                r = graph.link(edge)
                if r is not None:
                    added.append(r)
    return added
