"""Neo4j 승격 백엔드 — 인메모리 그래프가 커지면 여기로.

기본은 메모리 그래프(core.model.Graph)다. 규모가 커지면 Neo4jStore.ingest(graph)로
Neo4j Community에 MERGE로 밀어넣고 Cypher로 질의한다. neo4j 드라이버가 없으면
available()=False — 파이프라인은 메모리 그래프로 계속 돈다(둘 다 지원).
"""
from __future__ import annotations

from .model import Graph, Certainty


class Neo4jStore:
    def __init__(self, uri: str = "bolt://127.0.0.1:7687",
                 user: str = "neo4j", password: str = "neo4j"):
        self.uri, self.user, self.password = uri, user, password
        self._driver = None

    def available(self) -> bool:
        try:
            import neo4j  # noqa: F401
            return True
        except Exception:
            return False

    def connect(self):
        from neo4j import GraphDatabase
        self._driver = GraphDatabase.driver(self.uri, auth=(self.user, self.password))
        return self

    def close(self):
        if self._driver:
            self._driver.close()

    def ingest(self, graph: Graph) -> dict:
        if self._driver is None:
            self.connect()
        n_nodes = n_edges = 0
        with self._driver.session() as s:
            s.run("CREATE INDEX artes_key IF NOT EXISTS FOR (n:Entity) ON (n.key)")
            for e in graph.entities:
                s.run(
                    "MERGE (n:Entity {key:$key}) "
                    "SET n.type=$type, n.value=$value, n.certainty=$cert, n.confidence=$conf",
                    key=e.key, type=e.type.value, value=e.value,
                    cert=e.certainty.value, conf=e.confidence)
                n_nodes += 1
            for ed in graph.edges:
                s.run(
                    "MATCH (a:Entity {key:$src}),(b:Entity {key:$dst}) "
                    "MERGE (a)-[r:REL {relation:$rel}]->(b) "
                    "SET r.certainty=$cert, r.confidence=$conf",
                    src=ed.src, dst=ed.dst, rel=ed.relation,
                    cert=ed.certainty.value, conf=ed.confidence)
                n_edges += 1
        return {"nodes": n_nodes, "edges": n_edges}

    def query(self, cypher: str, **params):
        if self._driver is None:
            self.connect()
        with self._driver.session() as s:
            return [r.data() for r in s.run(cypher, **params)]


def should_promote(graph: Graph, threshold: int = 50000) -> bool:
    """이 규모를 넘으면 Neo4j 승격 권장."""
    return len(graph.entities) + len(graph.edges) > threshold
