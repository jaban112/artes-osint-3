"""다크웹 수집기 — onionsearch(표적 관련 onion 수집) → torbot(크롤·분석).

모든 결과는 안전 필터(core.safety.FILTER)를 통과한다 — 불법 콘텐츠는
그래프·AI로 절대 들어가지 않는다. Tor는 TorManager가 자동 관리.
live 크롤은 사용자 VM에서(이 세션은 코드·구조만 검증).
"""
from __future__ import annotations

import csv
import glob
import io
import os
import tempfile

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from ..core.safety import FILTER
from ..collectors.base import Collector, CollectorResult
from ..collectors.proc import which, run_cmd
from .tor import TorManager


class OnionSearch(Collector):
    name = "onionsearch"
    accepts = {EntityType.EMAIL, EntityType.USERNAME, EntityType.NAME, EntityType.DOMAIN}
    timeout = 300.0

    def available(self) -> bool:
        return which("onionsearch") is not None

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        res = CollectorResult(source=self.name)
        with tempfile.TemporaryDirectory() as td:
            out_file = os.path.join(td, "onions.txt")
            rc, out, err = await run_cmd(
                ["onionsearch", value, "--output", out_file], timeout=self.timeout)
            rows = self._read(out_file)
        if rows is None and rc != 0:
            res.ok = False
            res.error = err.strip()[:200] or f"rc={rc}"
            return res
        base_key = f"{entity_type.value}:{value.lower()}"
        for engine, onion in (rows or []):
            if FILTER.is_blocked(onion) or FILTER.is_blocked(engine):
                continue                       # 불법 콘텐츠 지표 → 배제
            u = Entity(EntityType.URL, onion, Certainty.UNCONFIRMED, 0.5,
                       evidence=[Evidence(self.name,
                                          f"'{value}' 관련 onion(검색엔진 {engine})")],
                       attrs={"onion": True, "engine": engine})
            res.entities.append(u)
            res.edges.append(Edge(base_key, u.key, "다크웹 언급",
                                  Certainty.UNCONFIRMED, 0.5,
                                  evidence=[Evidence(self.name, "onionsearch 결과")]))
        return res

    @staticmethod
    def _read(path):
        if not os.path.exists(path):
            return None
        rows = []
        try:
            with open(path, encoding="utf-8", errors="replace") as f:
                for r in csv.reader(f):
                    if len(r) >= 2:
                        rows.append((r[0].strip(), r[1].strip()))
                    elif r and r[0].strip().startswith("http"):
                        rows.append(("?", r[0].strip()))
        except Exception:
            return None
        return rows


class Torbot(Collector):
    name = "torbot"
    accepts = {EntityType.URL}
    timeout = 240.0
    _tor = TorManager()

    def available(self) -> bool:
        return which("torbot") is not None

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        res = CollectorResult(source=self.name)
        if ".onion" not in value:
            res.skipped = True
            res.error = "onion 아님"
            return res
        if not self._tor.ensure():
            res.ok = False
            res.error = "Tor 미가용(9050)"
            return res
        rc, out, err = await run_cmd(["torbot", "-u", value, "--info", "-q"],
                                     timeout=self.timeout)
        if FILTER.is_blocked(out):
            res.skipped = True
            res.error = "불법 콘텐츠 지표 → 페이지 배제"
            return res
        if rc != 0 and not out:
            res.ok = False
            res.error = err.strip()[:200] or f"rc={rc}"
            return res
        # 크롤 텍스트에서 이메일만 안전하게 추출(그래프 확장 씨앗).
        import re
        for email in set(re.findall(r"[\w.\-+]+@[\w.\-]+\.\w+", out)):
            if FILTER.is_blocked(email):
                continue
            e = Entity(EntityType.EMAIL, email, Certainty.UNCONFIRMED, 0.4,
                       evidence=[Evidence(self.name, f"onion 페이지에서 발견")])
            res.entities.append(e)
            res.edges.append(Edge(f"url:{value.lower()}", e.key, "페이지 내 이메일",
                                  Certainty.UNCONFIRMED, 0.4,
                                  evidence=[Evidence(self.name, "torbot 크롤")]))
        return res


DEFAULTS = [OnionSearch(), Torbot()]
