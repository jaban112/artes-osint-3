"""Tor 라이프사이클 관리 — 내장 Tor 시작/정리, 9050 SOCKS 확인.

ARTES가 스스로 Tor를 띄우고(이미 떠 있으면 재사용), 종료 시 정리한다.
외부에 Tor를 따로 깔아둘 필요가 없게 하는 게 목표(자립형 번들).
"""
from __future__ import annotations

import shutil
import socket
import subprocess
import tempfile
import time
from pathlib import Path


def socks_open(host: str = "127.0.0.1", port: int = 9050, timeout: float = 1.0) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


class TorManager:
    def __init__(self, socks_port: int = 9050, control_port: int = 9051,
                 tor_bin: str | None = None):
        self.socks_port = socks_port
        self.control_port = control_port
        self.tor_bin = tor_bin or shutil.which("tor")
        self._proc: subprocess.Popen | None = None
        self._datadir: str | None = None
        self._started_by_us = False

    def available(self) -> bool:
        return self.tor_bin is not None

    def ensure(self, wait: float = 30.0) -> bool:
        """SOCKS가 열려 있으면 즉시 True. 아니면 Tor를 띄운다."""
        if socks_open(port=self.socks_port):
            return True
        if not self.available():
            return False
        self._datadir = tempfile.mkdtemp(prefix="artes-tor-")
        self._proc = subprocess.Popen(
            [self.tor_bin, "--SocksPort", str(self.socks_port),
             "--ControlPort", str(self.control_port),
             "--DataDirectory", self._datadir, "--quiet"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
        self._started_by_us = True
        deadline = time.time() + wait
        while time.time() < deadline:
            if socks_open(port=self.socks_port):
                return True
            time.sleep(0.5)
        self.stop()
        return False

    def proxies(self) -> dict:
        p = f"socks5h://127.0.0.1:{self.socks_port}"
        return {"http": p, "https": p}

    def stop(self) -> None:
        if self._proc and self._started_by_us:
            self._proc.terminate()
            try:
                self._proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self._proc.kill()
        if self._datadir:
            shutil.rmtree(self._datadir, ignore_errors=True)
        self._proc = None
        self._datadir = None

    def __enter__(self):
        self.ensure()
        return self

    def __exit__(self, *exc):
        self.stop()
