"""IP·인프라 확장 — 역DNS·ASN/BGP·IP 지오·HTTP 헤더 지문. 키 불필요.

- ReverseDNS: IP→호스트명(순수 socket).
- ASN: IP→소속 조직·대역(bgpview.io 키리스).
- IPGeo: IP→국가·도시·ISP(ip-api.com 키리스).
- HTTPHeaders: 도메인→서버·프레임워크·쿠키 지문.
"""
from __future__ import annotations

import asyncio
import socket

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from .base import Collector, CollectorResult
from .proc import get_json, get_text


class ReverseDNS(Collector):
    name = "revdns"
    accepts = {EntityType.IP}
    timeout = 15.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        res = CollectorResult(source=self.name)
        try:
            host, _, _ = await asyncio.wait_for(
                asyncio.get_event_loop().run_in_executor(None, socket.gethostbyaddr, value),
                timeout=10)
        except Exception:
            res.skipped = True
            res.error = "PTR 없음"
            return res
        h = Entity(EntityType.DOMAIN, host.lower(), Certainty.CONFIRMED,
                   evidence=[Evidence(self.name, f"{value}의 PTR")])
        res.entities.append(h)
        res.edges.append(Edge(f"ip:{value.lower()}", h.key, "역DNS(PTR)",
                              Certainty.CONFIRMED, evidence=[Evidence(self.name, "gethostbyaddr")]))
        return res


class ASNLookup(Collector):
    name = "asn"
    accepts = {EntityType.IP}
    timeout = 25.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        data = await get_json(f"https://api.bgpview.io/ip/{value}", self.timeout)
        if not data or data.get("status") != "ok":
            return CollectorResult(source=self.name, ok=False, error="bgpview 도달실패")
        return self.parse(data, value)

    def parse(self, data: dict, value: str) -> CollectorResult:
        res = CollectorResult(source=self.name)
        d = data.get("data", {})
        ikey = f"ip:{value.lower()}"
        seen = set()
        for pfx in d.get("prefixes", []):
            asn = pfx.get("asn", {})
            name = asn.get("name") or asn.get("description")
            num = asn.get("asn")
            if num and num not in seen:
                seen.add(num)
                res.entities.append(Entity(EntityType.IP, value, Certainty.CONFIRMED,
                    attrs={"asn": f"AS{num}", "asn_name": name,
                           "prefix": pfx.get("prefix")},
                    evidence=[Evidence(self.name, f"AS{num} {name} · {pfx.get('prefix','')}")]))
        return res


class IPGeo(Collector):
    name = "ipgeo"
    accepts = {EntityType.IP}
    timeout = 20.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        data = await get_json(
            f"http://ip-api.com/json/{value}?fields=status,country,city,isp,org,as,lat,lon",
            self.timeout)
        if not data or data.get("status") != "success":
            return CollectorResult(source=self.name, ok=False, error="ip-api 실패")
        return self.parse(data, value)

    def parse(self, data: dict, value: str) -> CollectorResult:
        res = CollectorResult(source=self.name)
        res.entities.append(Entity(EntityType.IP, value, Certainty.CONFIRMED,
            attrs={"country": data.get("country"), "city": data.get("city"),
                   "isp": data.get("isp"), "org": data.get("org"),
                   "geo": [data.get("lat"), data.get("lon")]},
            evidence=[Evidence(self.name,
                      f"{data.get('country','')} {data.get('city','')} · {data.get('isp','')}")]))
        return res


class HTTPHeaders(Collector):
    name = "httphdr"
    accepts = {EntityType.DOMAIN, EntityType.URL}
    timeout = 20.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        import urllib.request
        url = value if value.startswith("http") else f"https://{value}"

        def _headers():
            try:
                req = urllib.request.Request(url, method="HEAD",
                                             headers={"User-Agent": "artes/0.1"})
                with urllib.request.urlopen(req, timeout=12) as r:
                    return dict(r.headers)
            except Exception:
                return None
        hdrs = await asyncio.get_event_loop().run_in_executor(None, _headers)
        if not hdrs:
            return CollectorResult(source=self.name, ok=False, error="헤더 도달실패")
        return self.parse(hdrs, value, entity_type)

    def parse(self, hdrs: dict, value: str, entity_type=EntityType.DOMAIN) -> CollectorResult:
        res = CollectorResult(source=self.name)
        low = {k.lower(): v for k, v in hdrs.items()}
        tech = {k: low[k] for k in ("server", "x-powered-by", "x-generator", "via")
                if k in low}
        if tech:
            res.entities.append(Entity(entity_type, value.lower(), Certainty.CONFIRMED,
                attrs={"tech": tech},
                evidence=[Evidence(self.name, "기술 지문: " +
                          ", ".join(f"{k}={v}" for k, v in tech.items()))]))
        return res


class DoHDNS(Collector):
    """DNS over HTTPS(Cloudflare) — dnspython 없이 DNS 레코드. 키·의존 없음."""
    name = "doh"
    accepts = {EntityType.DOMAIN}
    timeout = 25.0
    _TYPES = {"A": 1, "AAAA": 28, "MX": 15, "NS": 2, "TXT": 16}

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        res = CollectorResult(source=self.name)
        base = f"domain:{value.lower()}"
        any_hit = False
        for rtype, num in self._TYPES.items():
            data = await get_json(
                f"https://cloudflare-dns.com/dns-query?name={value}&type={rtype}",
                self.timeout, headers={"Accept": "application/dns-json"})
            for ans in (data or {}).get("Answer", []):
                d = str(ans.get("data", "")).strip().strip('"')
                if not d:
                    continue
                any_hit = True
                if rtype in ("A", "AAAA"):
                    ip = Entity(EntityType.IP, d, Certainty.CONFIRMED,
                                evidence=[Evidence(self.name, f"{rtype}(DoH)")])
                    res.entities.append(ip)
                    res.edges.append(Edge(base, ip.key, rtype, Certainty.CONFIRMED,
                                          evidence=[Evidence(self.name, "DoH")]))
                elif rtype in ("MX", "NS"):
                    host = d.split()[-1].rstrip(".").lower()
                    h = Entity(EntityType.DOMAIN, host, Certainty.CONFIRMED,
                               evidence=[Evidence(self.name, f"{rtype}(DoH)")])
                    res.entities.append(h)
                    res.edges.append(Edge(base, h.key, rtype, Certainty.CONFIRMED,
                                          evidence=[Evidence(self.name, "DoH")]))
                else:  # TXT
                    res.entities.append(Entity(EntityType.DOMAIN, value.lower(),
                        Certainty.CONFIRMED, attrs={"txt": d[:200]},
                        evidence=[Evidence(self.name, f"TXT: {d[:80]}")]))
        if not any_hit:
            res.skipped = True
            res.error = "DoH 응답 없음"
        return res
