"""SNS/프로필 확장 2(증분 24) — 병렬 웹 리서치로 검증한 무키 공개 API 대량 추가.

전부 키·로그인 불필요 공개 엔드포인트. 실명·위치·검증 링크·교차계정을 최대한 끌어온다.
특히 StackExchange /associated 와 Wikimedia globaluserinfo 는 '한 아이디→여러 계정'
확장기(네트워크 익스팬더)로 피벗 가치가 높다. Steam/ArtStation 은 실명·위치를 직접 준다.
파서 분리(parse)로 오프라인 단위검증. live 페치는 사용자 환경.
"""
from __future__ import annotations

import xml.etree.ElementTree as ET

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from .base import Collector, CollectorResult
from .proc import get_json, get_text
from .social3_c import _name_geo, _links_from, _link_entities


def _acc(res, value, site, handle, url, source, desc, extra=None):
    """계정 엔티티 + username→account 간선 추가(중복 코드 축약). 반환=계정 엔티티."""
    ukey = f"username:{value.lower()}"
    a = Entity(EntityType.ACCOUNT, f"{site}/{handle}", Certainty.CONFIRMED,
               evidence=[Evidence(source, desc, url=url)],
               attrs={**(extra or {}), "site": site, "handle": handle, "url": url})
    res.entities.append(a)
    res.edges.append(Edge(ukey, a.key, "가진 계정", Certainty.CONFIRMED,
                          evidence=[Evidence(source, "공개 API")]))
    return a


def _xlink_username(res, acc_key, handle, source):
    """다른 플랫폼 아이디로의 확실한 교차연결(예: crates.io→github)."""
    if not handle:
        return
    res.entities.append(Entity(EntityType.USERNAME, handle, Certainty.CONFIRMED,
                        evidence=[Evidence(source, "연결 계정")]))
    res.edges.append(Edge(acc_key, f"username:{handle.lower()}", "연결 계정",
                          Certainty.CONFIRMED, evidence=[Evidence(source, "프로필 필드")]))


class ArtStation(Collector):
    """ArtStation quick.json — 실명·도시·국가 + 트위터/인스타 등 소셜 링크(무키·리치)."""
    name = "artstation"; accepts = {EntityType.USERNAME}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        d = await get_json(f"https://www.artstation.com/users/{value.lower()}/quick.json",
                           self.timeout, headers={"User-Agent": "artes/0.1"})
        if not d or not d.get("id"):
            return CollectorResult(source=self.name, ok=False, error="ArtStation 미발견")
        return self.parse(d, value)

    def parse(self, d, value):
        res = CollectorResult(source=self.name)
        url = d.get("permalink") or f"https://www.artstation.com/{value}"
        a = _acc(res, value, "artstation", d.get("username", value), url, self.name,
                 "ArtStation 프로필", {"headline": d.get("headline", "")})
        loc = ", ".join([x for x in (d.get("city"), d.get("country")) if x])
        _name_geo(res, a.key, self.name, d.get("full_name", ""), loc)
        socs = []
        for s in (d.get("social_profiles") or []):
            socs.append(s.get("url") or s.get("value") or "")
        _link_entities(res, a.key, [u for u in socs if u], self.name, certain=False)
        return res


class StackExchange(Collector):
    """StackExchange — 표시이름·위치·웹사이트(무키 300/일). 네트워크 계정 확장."""
    name = "stackexchange"; accepts = {EntityType.USERNAME}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        d = await get_json("https://api.stackexchange.com/2.3/users?"
                           f"inname={value}&site=stackoverflow&pagesize=1&order=desc&sort=reputation",
                           self.timeout, headers={"User-Agent": "artes/0.1"})
        items = (d or {}).get("items") or []
        if not items:
            return CollectorResult(source=self.name, ok=False, error="StackExchange 미발견")
        return self.parse(items[0], value)

    def parse(self, u, value):
        res = CollectorResult(source=self.name)
        a = _acc(res, value, "stackoverflow", value, u.get("link", ""), self.name,
                 f"StackOverflow(평판 {u.get('reputation', '?')})",
                 {"reputation": u.get("reputation")})
        _name_geo(res, a.key, self.name, u.get("display_name", ""), u.get("location", ""))
        if u.get("website_url"):
            _link_entities(res, a.key, [u["website_url"]], self.name, certain=False)
        return res


class WikimediaGlobal(Collector):
    """Wikimedia CentralAuth — 한 아이디의 '모든 위키 계정'(무키). 네트워크 확장기."""
    name = "wikimedia-global"; accepts = {EntityType.USERNAME}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        d = await get_json("https://meta.wikimedia.org/w/api.php?action=query&meta=globaluserinfo"
                           f"&guiuser={value}&guiprop=merged|groups|editcount&format=json",
                           self.timeout, headers={"User-Agent": "artes/0.1 (osint)"})
        gu = ((d or {}).get("query") or {}).get("globaluserinfo") or {}
        if not gu or "missing" in gu:
            return CollectorResult(source=self.name, ok=False, error="Wikimedia 전역계정 없음")
        return self.parse(gu, value)

    def parse(self, gu, value):
        res = CollectorResult(source=self.name)
        merged = gu.get("merged") or []
        a = _acc(res, value, "wikimedia", gu.get("name", value),
                 f"https://meta.wikimedia.org/wiki/Special:CentralAuth/{value}", self.name,
                 f"위키미디어 전역계정(연결 위키 {len(merged)}개)",
                 {"home": gu.get("home", ""), "edits": gu.get("editcount"),
                  "wikis": [m.get("wiki") for m in merged][:30]})
        return res


class Steam(Collector):
    """Steam 커뮤니티 XML — 실명·위치·가입일(공개 프로필, 무키). XML 파싱."""
    name = "steam"; accepts = {EntityType.USERNAME}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        body = await get_text(f"https://steamcommunity.com/id/{value}/?xml=1", timeout=self.timeout)
        if not body or "<steamID64>" not in body:
            return CollectorResult(source=self.name, ok=False, error="Steam 미발견/비공개")
        return self.parse(body, value)

    def parse(self, body, value):
        res = CollectorResult(source=self.name)
        try:
            root = ET.fromstring(body)
        except Exception:
            return CollectorResult(source=self.name, ok=False, error="Steam XML 파싱 실패")
        g = lambda t: (root.findtext(t) or "").strip()
        sid = g("steamID64")
        if not sid:
            return CollectorResult(source=self.name, ok=False, error="Steam 미발견")
        url = f"https://steamcommunity.com/id/{value}"
        a = _acc(res, value, "steam", g("steamID") or value, url, self.name, "Steam 프로필",
                 {"steamid64": sid, "member_since": g("memberSince")})
        _name_geo(res, a.key, self.name, g("realname"), g("location"))
        return res


class Mixcloud(Collector):
    """Mixcloud — 이름·도시·국가·소개(무키)."""
    name = "mixcloud"; accepts = {EntityType.USERNAME}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        d = await get_json(f"https://api.mixcloud.com/{value}/", self.timeout,
                           headers={"User-Agent": "artes/0.1"})
        if not d or not d.get("username"):
            return CollectorResult(source=self.name, ok=False, error="Mixcloud 미발견")
        return self.parse(d, value)

    def parse(self, d, value):
        res = CollectorResult(source=self.name)
        a = _acc(res, value, "mixcloud", d.get("username", value),
                 d.get("url", f"https://www.mixcloud.com/{value}"), self.name, "Mixcloud 프로필",
                 {"bio": d.get("biog", "")})
        loc = ", ".join([x for x in (d.get("city"), d.get("country")) if x])
        _name_geo(res, a.key, self.name, d.get("name", ""), loc)
        return res


class Launchpad(Collector):
    """Launchpad(우분투) — 표시이름·소개·홈페이지(무키)."""
    name = "launchpad"; accepts = {EntityType.USERNAME}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        d = await get_json(f"https://api.launchpad.net/1.0/~{value}", self.timeout,
                           headers={"User-Agent": "artes/0.1"})
        if not d or not d.get("name"):
            return CollectorResult(source=self.name, ok=False, error="Launchpad 미발견")
        return self.parse(d, value)

    def parse(self, d, value):
        res = CollectorResult(source=self.name)
        a = _acc(res, value, "launchpad", d.get("name", value),
                 d.get("web_link", f"https://launchpad.net/~{value}"), self.name,
                 "Launchpad 프로필", {"bio": d.get("description", "")})
        _name_geo(res, a.key, self.name, d.get("display_name", ""), "")
        return res


class CratesIo(Collector):
    """crates.io(Rust) — 이름 + GitHub 교차연결(무키)."""
    name = "cratesio"; accepts = {EntityType.USERNAME}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        d = await get_json(f"https://crates.io/api/v1/users/{value}", self.timeout,
                           headers={"User-Agent": "artes/0.1"})
        u = (d or {}).get("user") or {}
        if not u.get("login"):
            return CollectorResult(source=self.name, ok=False, error="crates.io 미발견")
        return self.parse(u, value)

    def parse(self, u, value):
        res = CollectorResult(source=self.name)
        a = _acc(res, value, "crates.io", u.get("login", value),
                 u.get("url", f"https://crates.io/users/{value}"), self.name, "crates.io 프로필")
        _name_geo(res, a.key, self.name, u.get("name", ""), "")
        gh = u.get("url", "")            # https://github.com/<login>
        if "github.com/" in gh:
            _xlink_username(res, a.key, gh.rstrip("/").rsplit("/", 1)[-1], self.name)
        return res


class SpeedrunCom(Collector):
    """Speedrun.com — 위치 + 트위치/유튜브/트위터 링크(무키)."""
    name = "speedruncom"; accepts = {EntityType.USERNAME}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        d = await get_json(f"https://www.speedrun.com/api/v1/users?name={value}", self.timeout,
                           headers={"User-Agent": "artes/0.1"})
        items = (d or {}).get("data") or []
        hit = next((u for u in items if (u.get("names") or {}).get("international", "").lower() == value.lower()), None)
        if not hit:
            return CollectorResult(source=self.name, ok=False, error="Speedrun 미발견")
        return self.parse(hit, value)

    def parse(self, u, value):
        res = CollectorResult(source=self.name)
        a = _acc(res, value, "speedrun", (u.get("names") or {}).get("international", value),
                 u.get("weblink", ""), self.name, "Speedrun.com 프로필")
        loc = (((u.get("location") or {}).get("country") or {}).get("names") or {}).get("international", "")
        _name_geo(res, a.key, self.name, "", loc)
        links = [ (u.get(k) or {}).get("uri") for k in ("twitch", "youtube", "twitter") ]
        _link_entities(res, a.key, [x for x in links if x], self.name, certain=False)
        return res


class Lemmy(Collector):
    """Lemmy(lemmy.ml) — bio + Matrix 아이디 교차연결(무키·페디버스)."""
    name = "lemmy"; accepts = {EntityType.USERNAME}; timeout = 15.0; instance = "lemmy.ml"

    async def collect(self, value, entity_type, ctx):
        d = await get_json(f"https://{self.instance}/api/v3/user?username={value}", self.timeout,
                           headers={"User-Agent": "artes/0.1"})
        pv = (d or {}).get("person_view") or {}
        if not (pv.get("person") or {}).get("name"):
            return CollectorResult(source=self.name, ok=False, error="Lemmy 미발견")
        return self.parse(pv["person"], value)

    def parse(self, p, value):
        res = CollectorResult(source=self.name)
        a = _acc(res, value, "lemmy", p.get("name", value),
                 p.get("actor_id", f"https://{self.instance}/u/{value}"), self.name,
                 "Lemmy 프로필", {"bio": p.get("bio", ""), "display": p.get("display_name", "")})
        if p.get("matrix_user_id"):
            res.entities.append(Entity(EntityType.ACCOUNT, f"matrix/{p['matrix_user_id']}",
                                Certainty.CONFIRMED, evidence=[Evidence(self.name, "Matrix 연결")],
                                attrs={"site": "matrix", "handle": p["matrix_user_id"]}))
            res.edges.append(Edge(a.key, f"account:matrix/{p['matrix_user_id']}", "Matrix 연결",
                                  Certainty.CONFIRMED, evidence=[Evidence(self.name, "matrix_user_id")]))
        _link_entities(res, a.key, _links_from(p.get("bio", "")), self.name, certain=False)
        return res


class Duolingo(Collector):
    """Duolingo — 이름·가입일·언어코스(무키)."""
    name = "duolingo"; accepts = {EntityType.USERNAME}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        d = await get_json(f"https://www.duolingo.com/2017-06-30/users?username={value}", self.timeout,
                           headers={"User-Agent": "artes/0.1"})
        users = (d or {}).get("users") or []
        if not users:
            return CollectorResult(source=self.name, ok=False, error="Duolingo 미발견")
        return self.parse(users[0], value)

    def parse(self, u, value):
        res = CollectorResult(source=self.name)
        a = _acc(res, value, "duolingo", u.get("username", value),
                 f"https://www.duolingo.com/profile/{value}", self.name, "Duolingo 프로필",
                 {"streak": u.get("streak"), "courses": [c.get("title") for c in (u.get("courses") or [])][:8]})
        _name_geo(res, a.key, self.name, u.get("name", ""), "")
        return res


class Codewars(Collector):
    """Codewars — 이름·클랜·명예점수(무키)."""
    name = "codewars"; accepts = {EntityType.USERNAME}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        d = await get_json(f"https://www.codewars.com/api/v1/users/{value}", self.timeout,
                           headers={"User-Agent": "artes/0.1"})
        if not d or not d.get("username"):
            return CollectorResult(source=self.name, ok=False, error="Codewars 미발견")
        return self.parse(d, value)

    def parse(self, d, value):
        res = CollectorResult(source=self.name)
        a = _acc(res, value, "codewars", d.get("username", value),
                 f"https://www.codewars.com/users/{value}", self.name, "Codewars 프로필",
                 {"clan": d.get("clan", ""), "honor": d.get("honor")})
        _name_geo(res, a.key, self.name, d.get("name", ""), "")
        return res


class Roblox(Collector):
    """Roblox — 표시이름·설명·가입일(무키, 아이디→uid 2단계)."""
    name = "roblox"; accepts = {EntityType.USERNAME}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        import json as _j
        from .proc import post_json
        try:
            r = await post_json("https://users.roblox.com/v1/usernames/users",
                                {"usernames": [value], "excludeBannedUsers": False},
                                self.timeout, headers={"User-Agent": "artes/0.1"})
        except Exception:
            r = None
        data = (r or {}).get("data") or []
        if not data:
            return CollectorResult(source=self.name, ok=False, error="Roblox 미발견")
        uid = data[0].get("id")
        d = await get_json(f"https://users.roblox.com/v1/users/{uid}", self.timeout,
                           headers={"User-Agent": "artes/0.1"})
        if not d or not d.get("id"):
            return CollectorResult(source=self.name, ok=False, error="Roblox 상세 실패")
        return self.parse(d, value)

    def parse(self, d, value):
        res = CollectorResult(source=self.name)
        a = _acc(res, value, "roblox", d.get("name", value),
                 f"https://www.roblox.com/users/{d.get('id')}/profile", self.name,
                 "Roblox 프로필", {"display": d.get("displayName", ""),
                                  "created": d.get("created", ""), "bio": d.get("description", "")})
        return res
