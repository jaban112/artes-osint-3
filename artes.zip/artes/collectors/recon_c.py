"""정찰 심화(키·계정 불필요) — Wayback CDX · HackerTarget 역방향IP · psbdmp 페이스트.

- WaybackCDX: 도메인의 아카이브된 URL 전수 → 죽은 서브도메인·옛 경로·노출 흔적.
- HackerTargetRecon: 역방향 IP(같은 IP에 공존하는 도메인) — 현 스택에 없던 능력.
  무료 상한(~50/day/IP)이 있어 best-effort(초과 시 우아하게 skip).
- Psbdmp: Pastebin 덤프 색인 검색 → 이메일/도메인 노출 페이스트.
모두 파서 분리로 단위검증 가능.
"""
from __future__ import annotations

from urllib.parse import urlparse

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from .base import Collector, CollectorResult
from .proc import get_json, get_text


class WaybackCDX(Collector):
    name = "wayback-cdx"
    accepts = {EntityType.DOMAIN}
    timeout = 30.0

    def __init__(self, limit: int = 500):
        self.limit = limit

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        url = (f"http://web.archive.org/cdx/search/cdx?url={value}/*&output=json"
               f"&fl=original&collapse=urlkey&limit={self.limit}")
        data = await get_json(url, self.timeout)
        if not isinstance(data, list):
            return CollectorResult(source=self.name, ok=False, error="CDX 도달 실패")
        return self.parse(data, value)

    def parse(self, rows: list, value: str) -> CollectorResult:
        res = CollectorResult(source=self.name)
        dkey = f"domain:{value.lower()}"
        subs, urls = set(), set()
        for row in rows:
            orig = row[0] if isinstance(row, list) and row else None
            if not orig or orig == "original":         # 헤더 행 건너뜀
                continue
            host = (urlparse(orig).hostname or "").lower()
            if host and host.endswith(value.lower()):
                if host != value.lower():
                    subs.add(host)
                urls.add(orig)
        for sub in sorted(subs):
            e = Entity(EntityType.DOMAIN, sub, Certainty.CONFIRMED,
                       evidence=[Evidence(self.name, "아카이브 기록 서브도메인")])
            res.entities.append(e)
            res.edges.append(Edge(dkey, e.key, "서브도메인", Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, "Wayback CDX")]))
        # 대표 URL 일부만(폭주 방지).
        for u in list(sorted(urls))[:40]:
            res.entities.append(Entity(EntityType.URL, u, Certainty.CONFIRMED,
                evidence=[Evidence(self.name, "아카이브된 URL")]))
        return res


class HackerTargetRecon(Collector):
    """역방향 IP — 같은 IP에 공존하는 도메인. 무료 상한 있어 best-effort."""
    name = "hackertarget"
    accepts = {EntityType.IP, EntityType.DOMAIN}
    timeout = 20.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        txt = await get_text(
            f"https://api.hackertarget.com/reverseiplookup/?q={value}", self.timeout)
        if txt is None:
            return CollectorResult(source=self.name, ok=False, error="도달 실패")
        return self.parse(txt, value, entity_type)

    def parse(self, txt: str, value: str, entity_type) -> CollectorResult:
        res = CollectorResult(source=self.name)
        low = txt.lower()
        if ("api count exceeded" in low or "error" in low[:40]
                or "no records" in low):
            res.skipped = True
            res.error = "상한 초과/무결과"
            return res
        src = f"{entity_type.value}:{value.lower()}"
        for line in txt.splitlines():
            host = line.strip().lower()
            if not host or " " in host or "." not in host:
                continue
            if host == value.lower():
                continue
            d = Entity(EntityType.DOMAIN, host, Certainty.CONFIRMED,
                       evidence=[Evidence(self.name, f"{value}와 IP 공존")])
            res.entities.append(d)
            res.edges.append(Edge(src, d.key, "IP 공존 도메인", Certainty.UNCONFIRMED, 0.5,
                                  evidence=[Evidence(self.name, "역방향 IP")]))
        return res


class Psbdmp(Collector):
    """psbdmp — Pastebin 덤프 색인 검색(이메일/도메인 노출). 키 불필요."""
    name = "psbdmp"
    accepts = {EntityType.EMAIL, EntityType.DOMAIN}
    timeout = 25.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        data = await get_json(f"https://psbdmp.ws/api/v3/search/{value}",
                              self.timeout, headers={"User-Agent": "artes/0.1"})
        if not isinstance(data, dict):
            return CollectorResult(source=self.name, ok=False, error="psbdmp 도달 실패")
        return self.parse(data, value, entity_type)

    def parse(self, data: dict, value: str, entity_type) -> CollectorResult:
        res = CollectorResult(source=self.name)
        src = f"{entity_type.value}:{value.lower()}"
        for row in (data.get("data") or [])[:50]:
            pid = row.get("id")
            if not pid:
                continue
            url = f"https://pastebin.com/{pid}"
            b = Entity(EntityType.BREACH, f"paste/{pid}", Certainty.CONFIRMED,
                       attrs={"paste_id": pid, "date": row.get("date"),
                              "length": row.get("length"), "url": url},
                       evidence=[Evidence(self.name, f"페이스트 {pid}에 노출", url=url)])
            res.entities.append(b)
            res.edges.append(Edge(src, b.key, "페이스트 노출", Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, "psbdmp 검색")]))
        return res
