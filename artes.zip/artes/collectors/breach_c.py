"""유출 노출 — XposedOrNot(키·계정 불필요 HIBP 대체). 이메일→유출 목록.

check-email 엔드포인트는 키 없이 이메일이 등장한 유출들의 이름을 준다. 기존 스택에
없던 '실제 유출 노출' 신호를 채운다(holehe는 가입여부, 이건 유출 노출). 파서 분리로 검증.
속도제한(~2req/s, 시간/일 상한)이 있으므로 POLICY의 rate-limit/백오프를 그대로 탄다.
도메인 breach POST만 키가 필요 — 그건 쓰지 않는다.
"""
from __future__ import annotations

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from .base import Collector, CollectorResult
from .proc import get_json


class XposedOrNot(Collector):
    name = "xposedornot"
    accepts = {EntityType.EMAIL}
    timeout = 25.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        data = await get_json(
            f"https://api.xposedornot.com/v1/check-email/{value}",
            self.timeout, headers={"User-Agent": "artes/0.1"})
        if data is None:
            return CollectorResult(source=self.name, ok=False, error="XON 도달 실패")
        return self.parse(data, value)

    def parse(self, data: dict, value: str) -> CollectorResult:
        res = CollectorResult(source=self.name)
        ekey = f"email:{value.lower()}"
        names = self._breach_names(data)
        for name in names:
            b = Entity(EntityType.BREACH, name, Certainty.CONFIRMED,
                       attrs={"email": value, "source": "xposedornot"},
                       evidence=[Evidence(self.name, f"'{name}' 유출에 이메일 노출")])
            res.entities.append(b)
            res.edges.append(Edge(ekey, b.key, "유출 노출", Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, "XposedOrNot check-email")]))
        return res

    @staticmethod
    def _breach_names(data: dict) -> list[str]:
        """check-email 응답 방어적 파싱 — {'breaches': [[...]]} 또는 유사 형태 모두 대응."""
        out: list[str] = []
        br = data.get("breaches")
        if isinstance(br, list):
            for item in br:
                if isinstance(item, list):
                    out += [str(x) for x in item if x]
                elif isinstance(item, str):
                    out.append(item)
                elif isinstance(item, dict) and item.get("breach"):
                    out.append(str(item["breach"]))
        # breach-analytics 형태(ExposedBreaches.breaches_details[*].breach) 대응.
        det = (data.get("ExposedBreaches") or {}).get("breaches_details")
        if isinstance(det, list):
            out += [str(d.get("breach")) for d in det if isinstance(d, dict) and d.get("breach")]
        # 중복 제거(순서 유지).
        seen, uniq = set(), []
        for n in out:
            if n and n.lower() not in seen:
                seen.add(n.lower()); uniq.append(n)
        return uniq
