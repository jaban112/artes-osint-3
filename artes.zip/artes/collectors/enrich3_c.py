"""사람 피벗 enrich(증분 24) — 한 조각을 여러 신원 필드로 확장. 무키·합법 공개만.

리서치 검증 최고 피벗원:
- Gravatar JSON: 이메일→실명·검증 링크·연결 계정(사용자 자기게시). 이메일 피벗 최강.
- GitHub 커밋 이메일 검색: 이메일→실명·아이디(공개 커밋 메타).
- ORCID/OpenAlex: 이름→연구자 신원(소속·저작·다른 ID). 저명인/연구자 한정.
정직: OpenCorporates 무키 폐지, 전화→실명·WhatsApp/Telegram 열거는 유료/ToS라 미도입.
"""
from __future__ import annotations

import hashlib

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from .base import Collector, CollectorResult
from .proc import get_json
from .social3_c import _links_from


class GravatarJSON(Collector):
    """Gravatar JSON — 이메일→실명·위치·연결된 계정/링크(무키, 사용자 자기게시)."""
    name = "gravatar-json"; accepts = {EntityType.EMAIL}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        h = hashlib.md5(value.strip().lower().encode()).hexdigest()
        d = await get_json(f"https://gravatar.com/{h}.json", self.timeout,
                           headers={"User-Agent": "artes/0.1"})
        if not isinstance(d, dict):          # 응답이 dict가 아니면(문자열 등) 안전 종료
            return CollectorResult(source=self.name, ok=False, error="Gravatar 프로필 없음")
        entry = (d.get("entry") or [None])[0]
        if not isinstance(entry, dict):
            return CollectorResult(source=self.name, ok=False, error="Gravatar 프로필 없음")
        return self.parse(entry, value)

    def parse(self, e, value):
        res = CollectorResult(source=self.name)
        ek = f"email:{value.lower()}"
        url = e.get("profileUrl", "")
        if e.get("displayName") or e.get("name"):
            nm = e.get("displayName") or (e.get("name") or {}).get("formatted", "")
            if nm:
                res.entities.append(Entity(EntityType.NAME, nm, Certainty.UNCONFIRMED,
                                    confidence=0.5, evidence=[Evidence(self.name, "Gravatar 이름", url=url)]))
                res.edges.append(Edge(ek, f"name:{nm.lower()}", "Gravatar 이름",
                                      Certainty.UNCONFIRMED, confidence=0.5,
                                      evidence=[Evidence(self.name, "displayName")]))
        # 사용자명(핸들)
        if e.get("preferredUsername"):
            u = e["preferredUsername"]
            res.entities.append(Entity(EntityType.USERNAME, u, Certainty.CONFIRMED,
                                evidence=[Evidence(self.name, "Gravatar 핸들", url=url)],
                                attrs={"thumbnail": e.get("thumbnailUrl", "")}))
            res.edges.append(Edge(ek, f"username:{u.lower()}", "Gravatar 핸들",
                                  Certainty.CONFIRMED, evidence=[Evidence(self.name, "preferredUsername")]))
        # 검증된 연결 계정(twitter/github 등)
        for a in (e.get("accounts") or []):
            u = a.get("url") or ""
            if u:
                cert = Certainty.CONFIRMED if a.get("verified") in (True, "true") else Certainty.UNCONFIRMED
                res.entities.append(Entity(EntityType.URL, u, cert,
                                    confidence=None if cert == Certainty.CONFIRMED else 0.5,
                                    evidence=[Evidence(self.name, f"연결 계정({a.get('shortname','')})", url=u)]))
                res.edges.append(Edge(ek, f"url:{u}", "연결 계정", cert,
                                      confidence=None if cert == Certainty.CONFIRMED else 0.5,
                                      evidence=[Evidence(self.name, "Gravatar accounts")]))
        # 자유 링크
        urls = [l.get("value") for l in (e.get("urls") or []) if l.get("value")]
        for u in urls:
            res.entities.append(Entity(EntityType.URL, u, Certainty.UNCONFIRMED, confidence=0.5,
                                evidence=[Evidence(self.name, "프로필 링크", url=u)]))
            res.edges.append(Edge(ek, f"url:{u}", "프로필 링크", Certainty.UNCONFIRMED,
                                  confidence=0.5, evidence=[Evidence(self.name, "urls")]))
        return res


class GitHubCommitEmail(Collector):
    """GitHub 커밋 이메일 검색 — 이메일→실명·아이디(공개 커밋 메타, 무키 저율)."""
    name = "github-commit-email"; accepts = {EntityType.EMAIL}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        d = await get_json(f"https://api.github.com/search/commits?q=author-email:{value}&per_page=5",
                           self.timeout, headers={"User-Agent": "artes/0.1",
                                                  "Accept": "application/vnd.github+json"})
        items = (d or {}).get("items") or []
        if not items:
            return CollectorResult(source=self.name, ok=False, error="GitHub 커밋 이메일 무결과")
        return self.parse(items, value)

    def parse(self, items, value):
        res = CollectorResult(source=self.name)
        ek = f"email:{value.lower()}"
        seen_name, seen_login = set(), set()
        for it in items:
            commit = it.get("commit") or {}
            author = commit.get("author") or {}
            nm = (author.get("name") or "").strip()
            if nm and nm.lower() not in seen_name and len(nm) <= 40:
                seen_name.add(nm.lower())
                res.entities.append(Entity(EntityType.NAME, nm, Certainty.UNCONFIRMED, confidence=0.55,
                                    evidence=[Evidence(self.name, "GitHub 커밋 작성자명")]))
                res.edges.append(Edge(ek, f"name:{nm.lower()}", "커밋 작성자", Certainty.UNCONFIRMED,
                                      confidence=0.55, evidence=[Evidence(self.name, "author.name")]))
            gh = (it.get("author") or {}).get("login")
            if gh and gh.lower() not in seen_login:
                seen_login.add(gh.lower())
                res.entities.append(Entity(EntityType.USERNAME, gh, Certainty.CONFIRMED,
                                    evidence=[Evidence(self.name, "GitHub 계정",
                                              url=f"https://github.com/{gh}")]))
                res.edges.append(Edge(ek, f"username:{gh.lower()}", "커밋한 GitHub 계정",
                                      Certainty.CONFIRMED, evidence=[Evidence(self.name, "author.login")]))
        return res


class ORCID(Collector):
    """ORCID — 이름→연구자 신원(소속·다른 ID). 저명 연구자 한정, 무키."""
    name = "orcid"; accepts = {EntityType.NAME}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        q = value.strip()
        if len(q) < 3 or " " not in q:      # 성+이름 형태만(소음 방지)
            return CollectorResult(source=self.name, ok=True)   # 조용히 빈 결과
        d = await get_json(f"https://pub.orcid.org/v3.0/expanded-search/?q={q.replace(' ', '+')}&rows=3",
                           self.timeout, headers={"User-Agent": "artes/0.1",
                                                  "Accept": "application/json"})
        results = (d or {}).get("expanded-result") or []
        if not results:
            return CollectorResult(source=self.name, ok=False, error="ORCID 무결과")
        return self.parse(results, value)

    def parse(self, results, value):
        res = CollectorResult(source=self.name)
        nk = f"name:{value.lower()}"
        for r in results[:3]:
            oid = r.get("orcid-id")
            if not oid:
                continue
            inst = (r.get("institution-name") or [""])[0] if r.get("institution-name") else ""
            url = f"https://orcid.org/{oid}"
            res.entities.append(Entity(EntityType.ACCOUNT, f"orcid/{oid}", Certainty.UNCONFIRMED,
                                confidence=0.4, evidence=[Evidence(self.name,
                                f"ORCID 연구자{(' · ' + inst) if inst else ''}", url=url)],
                                attrs={"site": "orcid", "handle": oid, "url": url, "institution": inst}))
            res.edges.append(Edge(nk, f"account:orcid/{oid}", "연구자 후보", Certainty.UNCONFIRMED,
                                  confidence=0.4, evidence=[Evidence(self.name, "이름 검색")]))
        return res


class OpenAlex(Collector):
    """OpenAlex — 이름→저자·소속(무키 10만/일). 저명 저자 한정."""
    name = "openalex"; accepts = {EntityType.NAME}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        if " " not in value.strip():
            return CollectorResult(source=self.name, ok=True)
        d = await get_json(f"https://api.openalex.org/authors?search={value.strip().replace(' ', '%20')}&per-page=3",
                           self.timeout, headers={"User-Agent": "artes/0.1 (osint)"})
        results = (d or {}).get("results") or []
        if not results:
            return CollectorResult(source=self.name, ok=False, error="OpenAlex 무결과")
        return self.parse(results, value)

    def parse(self, results, value):
        res = CollectorResult(source=self.name)
        nk = f"name:{value.lower()}"
        for a in results[:3]:
            aid = (a.get("id") or "").rsplit("/", 1)[-1]
            if not aid:
                continue
            inst = ((a.get("last_known_institution") or {}) or {}).get("display_name", "")
            orcid = a.get("orcid") or ""
            res.entities.append(Entity(EntityType.ACCOUNT, f"openalex/{aid}", Certainty.UNCONFIRMED,
                                confidence=0.4, evidence=[Evidence(self.name,
                                f"OpenAlex 저자{(' · ' + inst) if inst else ''}", url=a.get("id", ""))],
                                attrs={"site": "openalex", "handle": aid, "url": a.get("id", ""),
                                       "works": a.get("works_count"), "institution": inst}))
            res.edges.append(Edge(nk, f"account:openalex/{aid}", "저자 후보", Certainty.UNCONFIRMED,
                                  confidence=0.4, evidence=[Evidence(self.name, "이름 검색")]))
            if orcid:
                res.entities.append(Entity(EntityType.URL, orcid, Certainty.UNCONFIRMED, confidence=0.4,
                                    evidence=[Evidence(self.name, "ORCID 링크", url=orcid)]))
        return res
