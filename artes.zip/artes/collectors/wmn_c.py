"""WhatsMyName — 아이디로 700+ 사이트 존재확인(키·계정 불필요).

Sherlock/maigret를 보완하는 커뮤니티 데이터셋(wmn-data.json)을 직접 구동한다:
사이트별 uri_check에 아이디를 넣어 GET → e_string(존재 표식)과 e_code(HTTP 코드)로 판정.
사이트별 파이썬 모듈 없이 한 수집기가 데이터로 수백 사이트를 커버한다. 데이터는 1회
받아 캐시(주간 갱신 권장). 동시성·사이트 수 상한으로 폭주 방지.
"""
from __future__ import annotations

import asyncio

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from .base import Collector, CollectorResult
from .proc import get_json, get_text

_WMN_URL = ("https://raw.githubusercontent.com/WebBreacher/WhatsMyName/main/"
            "wmn-data.json")


class WhatsMyName(Collector):
    name = "whatsmyname"
    accepts = {EntityType.USERNAME}
    timeout = 8.0                          # 사이트당 요청 상한(짧게 — 느린 사이트 대기 최소화)

    _cache: list | None = None            # 프로세스 캐시(사이트 규칙)
    max_run = 70.0                        # base 블랭킷 타임아웃(hard_cap보다 넉넉히)

    def __init__(self, max_sites: int = 500, concurrency: int = 40,
                 hard_cap: float = 55.0,
                 cand_sites: int = 300, cand_concurrency: int = 25,
                 cand_hard_cap: float = 35.0, cand_budget: int = 5):
        # 씨앗: 최대 500곳 스윕. 후보(이름 생성물): 깨끗한 핵심 후보 5개까지 300곳 스윕.
        self.max_sites = max_sites         # 사이트 수 상한(폭주 방지)
        self.concurrency = concurrency
        self.hard_cap = hard_cap           # 이 수집기 1회 전체 시간 상한(초)
        self.cand_sites = cand_sites
        self.cand_concurrency = cand_concurrency
        self.cand_hard_cap = cand_hard_cap
        self._cand_left = cand_budget      # 후보 스윕 예산(스캔당, 인스턴스 1개라 자동 리셋)

    async def _load_sites(self) -> list:
        if WhatsMyName._cache is not None:
            return WhatsMyName._cache
        data = await get_json(_WMN_URL, self.timeout)
        sites = self.parse_dataset(data) if data else []
        WhatsMyName._cache = sites
        return sites

    @staticmethod
    def parse_dataset(data: dict) -> list:
        """wmn-data.json → 검사 규칙 목록(파서 분리, 검증 가능)."""
        out = []
        for s in (data or {}).get("sites", []):
            uri = s.get("uri_check")
            if not uri or "{account}" not in uri:
                continue
            out.append({
                "name": s.get("name", "?"),
                "uri": uri,
                "e_string": s.get("e_string"),
                "e_code": s.get("e_code", 200),
                "cat": s.get("cat", ""),
            })
        return out

    @staticmethod
    def match(rule: dict, status: int | None, body: str | None) -> bool:
        """존재 판정: HTTP 코드 일치 AND (e_string 있으면) 본문에 포함."""
        if status is None or body is None:
            return False
        if rule.get("e_code") and status != rule["e_code"]:
            return False
        es = rule.get("e_string")
        if es and es not in body:
            return False
        return True

    @staticmethod
    def _is_primary(value: str) -> bool:
        """스윕할 가치가 높은 '깨끗한' 후보인가 — 구분자·장식 없는 핵심 핸들만."""
        v = (value or "").strip()
        if not (2 <= len(v) <= 24):
            return False
        if any(c in v for c in "._-"):        # kim.jiwan 같은 변형은 제외(핵심형만)
            return False
        if v[-1:].isdigit() or v.startswith("_"):
            return False
        return True

    async def _check(self, rule: dict, username: str, sem: asyncio.Semaphore):
        url = rule["uri"].replace("{account}", username)
        async with sem:
            body = await get_text(url, timeout=self.timeout)
        # get_text는 코드 대신 본문/None만 준다 → 본문 존재를 200으로 간주(방어적).
        status = 200 if body is not None else None
        return rule, self.match(rule, status, body), url

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        res = CollectorResult(source=self.name)
        depth = (ctx or {}).get("depth", 0)
        if depth > 0:
            # 후보(이름 생성물)엔 예산 안에서 '핵심형'만 대량 스윕(폭주 방지).
            if self._cand_left <= 0 or not self._is_primary(value):
                res.skipped = True
                res.error = "후보 스윕 예산 소진/비핵심형"
                return res
            self._cand_left -= 1
            site_cap, conc, cap = self.cand_sites, self.cand_concurrency, self.cand_hard_cap
        else:
            site_cap, conc, cap = self.max_sites, self.concurrency, self.hard_cap
        sites = await self._load_sites()
        if not sites:
            res.ok = False
            res.error = "wmn-data 로드 실패(네트워크?)"
            return res
        sites = sites[:site_cap]
        sem = asyncio.Semaphore(conc)
        ukey = f"username:{value.lower()}"
        # 하드 시간 상한: as_completed(timeout=) 이 지나면 TimeoutError → 남은 것 취소.
        # 적응형 동시성 붕괴로 순차화되어도 이 수집기는 hard_cap 초를 넘지 않는다.
        tasks = [asyncio.ensure_future(self._check(r, value, sem)) for r in sites]
        try:
            for fut in asyncio.as_completed(tasks, timeout=cap):
                try:
                    rule, hit, url = await fut
                except Exception:
                    continue
                if not hit:
                    continue
                acc = Entity(EntityType.ACCOUNT, f"{rule['name']}/{value}",
                             Certainty.CONFIRMED,
                             attrs={"site": rule["name"], "handle": value, "url": url,
                                    "cat": rule["cat"]},
                             evidence=[Evidence(self.name,
                                       f"{rule['name']} 계정 존재(WhatsMyName)", url=url)])
                res.entities.append(acc)
                res.edges.append(Edge(ukey, acc.key, "계정 존재", Certainty.CONFIRMED,
                                      evidence=[Evidence(self.name, "WhatsMyName 규칙 일치")]))
        except (asyncio.TimeoutError, Exception):
            res.error = "시간 상한 도달(부분 결과)"
        finally:
            for t in tasks:
                if not t.done():
                    t.cancel()
        return res
