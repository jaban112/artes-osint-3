"""위협 인텔·인프라 심화 — Shodan InternetDB(키 없음!)·URLScan·certspotter.

- Shodan InternetDB: IP→열린 포트·호스트명·CPE·**알려진 취약점(CVE)**. 키 불필요.
- URLScan: 도메인의 과거 스캔·연관 도메인/IP. 키 불필요(속도제한).
- certspotter: 인증서 투명성 대체 소스(crt.sh 보강).
"""
from __future__ import annotations

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from .base import Collector, CollectorResult
from .proc import get_json


class ShodanInternetDB(Collector):
    """키 없는 Shodan — IP의 포트·취약점. internetdb.shodan.io."""
    name = "internetdb"
    accepts = {EntityType.IP}
    timeout = 20.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        data = await get_json(f"https://internetdb.shodan.io/{value}", self.timeout)
        if not data or "ip" not in data:
            return CollectorResult(source=self.name, ok=False, error="InternetDB 미발견")
        return self.parse(data, value)

    def parse(self, data: dict, value: str) -> CollectorResult:
        res = CollectorResult(source=self.name)
        ikey = f"ip:{value.lower()}"
        for port in data.get("ports", []):
            h = Entity(EntityType.HOST, f"{value}:{port}", Certainty.CONFIRMED,
                       attrs={"ip": value, "port": str(port)},
                       evidence=[Evidence(self.name, f"열린 포트 {port}")])
            res.entities.append(h)
            res.edges.append(Edge(ikey, h.key, "열린 포트", Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, "InternetDB")]))
        for host in data.get("hostnames", []):
            d = Entity(EntityType.DOMAIN, host.lower(), Certainty.CONFIRMED,
                       evidence=[Evidence(self.name, f"{value}의 호스트명")])
            res.entities.append(d)
            res.edges.append(Edge(ikey, d.key, "호스트명", Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, "InternetDB")]))
        vulns = data.get("vulns", [])
        if vulns:
            res.entities.append(Entity(EntityType.IP, value, Certainty.CONFIRMED,
                attrs={"vulns": vulns[:50], "cpes": data.get("cpes", [])[:20]},
                evidence=[Evidence(self.name, f"알려진 취약점 {len(vulns)}건: "
                          + ", ".join(vulns[:5]))]))
        return res


class URLScan(Collector):
    """URLScan.io 공개 검색 — 도메인의 과거 스캔·연관 IP. 키 불필요."""
    name = "urlscan"
    accepts = {EntityType.DOMAIN}
    timeout = 30.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        data = await get_json(
            f"https://urlscan.io/api/v1/search/?q=domain:{value}&size=20", self.timeout)
        if not data or "results" not in data:
            return CollectorResult(source=self.name, ok=False, error="URLScan 도달실패")
        return self.parse(data, value)

    def parse(self, data: dict, value: str) -> CollectorResult:
        res = CollectorResult(source=self.name)
        dkey = f"domain:{value.lower()}"
        seen_ip = set()
        for r in data.get("results", [])[:30]:
            page = r.get("page", {})
            ip = page.get("ip")
            if ip and ip not in seen_ip:
                seen_ip.add(ip)
                e = Entity(EntityType.IP, ip, Certainty.CONFIRMED,
                           evidence=[Evidence(self.name, f"{value} 호스팅 IP(URLScan)")])
                res.entities.append(e)
                res.edges.append(Edge(dkey, e.key, "호스팅 IP", Certainty.CONFIRMED,
                                      evidence=[Evidence(self.name, "URLScan")]))
        return res


class CertSpotter(Collector):
    """certspotter — 인증서 투명성 대체 소스(crt.sh 보강). 키 불필요."""
    name = "certspotter"
    accepts = {EntityType.DOMAIN}
    timeout = 30.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        data = await get_json(
            f"https://api.certspotter.com/v1/issuances?domain={value}"
            "&include_subdomains=true&expand=dns_names", self.timeout)
        if not isinstance(data, list):
            return CollectorResult(source=self.name, ok=False, error="certspotter 도달실패")
        return self.parse(data, value)

    def parse(self, data: list, value: str) -> CollectorResult:
        res = CollectorResult(source=self.name)
        dkey = f"domain:{value.lower()}"
        subs = set()
        for cert in data:
            for name in (cert.get("dns_names") or []):
                name = name.lstrip("*.").lower()
                if name.endswith(value.lower()) and name != value.lower():
                    subs.add(name)
        for sub in sorted(subs):
            s = Entity(EntityType.DOMAIN, sub, Certainty.CONFIRMED,
                       evidence=[Evidence(self.name, "인증서 로그 서브도메인")])
            res.entities.append(s)
            res.edges.append(Edge(dkey, s.key, "서브도메인", Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, "certspotter")]))
        return res
