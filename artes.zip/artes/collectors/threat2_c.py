"""위협 인텔·암호화폐·자격증명 — 키 없는 공개 피드/JSON(증분 13).

- FeodoTracker: IP → 봇넷 C2 매칭(정적 블록리스트 JSON). 무키.
- OpenPhish: URL/도메인 → 피싱 피드 매칭(정적 텍스트). 무키.
- URLhaus: 호스트 → 악성 URL(최근 CSV 정적 export). 무키(쿼리 API는 키 필요 → 피드만).
- BitcoinAddress: BTC 주소 → 잔액·거래(blockchain.info, mempool 폴백). 무키.
- ProxyNovaCOMB: 이메일/아이디 → 자격증명 노출 여부(COMB). 무키.
  ※ 안전: 평문 비밀번호는 저장하지 않는다 — 노출 사실·건수만 발급.

피드는 1회 받아 캐시(프로세스). 파서 분리로 단위검증.
"""
from __future__ import annotations

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from .base import Collector, CollectorResult
from .proc import get_json, get_text


class FeodoTracker(Collector):
    """abuse.ch Feodo — IP가 알려진 봇넷 C2인지(정적 블록리스트). 무키."""
    name = "feodo"
    accepts = {EntityType.IP}
    timeout = 25.0
    _feed: dict | None = None

    async def _load(self):
        if FeodoTracker._feed is not None:
            return FeodoTracker._feed
        data = await get_json(
            "https://feodotracker.abuse.ch/downloads/ipblocklist.json", self.timeout)
        idx = {}
        if isinstance(data, list):
            for row in data:
                if isinstance(row, dict) and row.get("ip_address"):
                    idx[row["ip_address"]] = row
        FeodoTracker._feed = idx
        return idx

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        feed = await self._load()
        if not feed:
            return CollectorResult(source=self.name, ok=False, error="Feodo 피드 미로드")
        return self.parse(feed.get(value), value)

    def parse(self, row, value) -> CollectorResult:
        res = CollectorResult(source=self.name)
        if not row:
            return res                              # 매칭 없음(정상)
        m = Entity(EntityType.MALWARE, f"c2/{value}", Certainty.CONFIRMED,
                   attrs={"malware": row.get("malware"), "status": row.get("status"),
                          "first_seen": row.get("first_seen")},
                   evidence=[Evidence(self.name, f"봇넷 C2({row.get('malware')})")])
        res.entities.append(m)
        res.edges.append(Edge(f"ip:{value.lower()}", m.key, "봇넷 C2",
                              Certainty.CONFIRMED, evidence=[Evidence(self.name, "Feodo Tracker")]))
        return res


class OpenPhish(Collector):
    """OpenPhish 커뮤니티 피드 — URL/도메인 피싱 매칭(정적 텍스트). 무키."""
    name = "openphish"
    accepts = {EntityType.URL, EntityType.DOMAIN}
    timeout = 25.0
    _feed: set | None = None

    async def _load(self):
        if OpenPhish._feed is not None:
            return OpenPhish._feed
        txt = await get_text("https://openphish.com/feed.txt", self.timeout)
        OpenPhish._feed = set((txt or "").split())
        return OpenPhish._feed

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        feed = await self._load()
        if not feed:
            return CollectorResult(source=self.name, ok=False, error="OpenPhish 피드 미로드")
        return self.parse(feed, value, entity_type)

    def parse(self, feed, value, entity_type) -> CollectorResult:
        res = CollectorResult(source=self.name)
        hit = any(value in url or (entity_type is EntityType.DOMAIN and value in url)
                  for url in feed) if entity_type is EntityType.DOMAIN else (value in feed)
        if hit:
            m = Entity(EntityType.MALWARE, f"phish/{value}", Certainty.CONFIRMED,
                       evidence=[Evidence(self.name, "OpenPhish 피싱 피드 등재")])
            res.entities.append(m)
            res.edges.append(Edge(f"{entity_type.value}:{value.lower()}", m.key, "피싱",
                                  Certainty.CONFIRMED, evidence=[Evidence(self.name, "OpenPhish")]))
        return res


class BitcoinAddress(Collector):
    """BTC 주소 → 잔액·거래수(blockchain.info, mempool 폴백). 무키."""
    name = "btc"
    accepts = {EntityType.CRYPTO}
    timeout = 25.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        data = await get_json(f"https://blockchain.info/rawaddr/{value}?limit=0",
                              self.timeout, headers={"User-Agent": "artes/0.1"})
        if data and "n_tx" in data:
            return self.parse_bci(data, value)
        mp = await get_json(f"https://mempool.space/api/address/{value}",
                            self.timeout, headers={"User-Agent": "artes/0.1"})
        if mp and "chain_stats" in mp:
            return self.parse_mempool(mp, value)
        return CollectorResult(source=self.name, ok=False, error="BTC 조회 실패")

    def parse_bci(self, data, value) -> CollectorResult:
        res = CollectorResult(source=self.name)
        res.entities.append(Entity(EntityType.CRYPTO, value, Certainty.CONFIRMED,
            attrs={"chain": "btc", "balance_sat": data.get("final_balance"),
                   "n_tx": data.get("n_tx"), "total_received": data.get("total_received")},
            evidence=[Evidence(self.name, f"BTC 거래 {data.get('n_tx')}건",
                      url=f"https://www.blockchain.com/btc/address/{value}")]))
        return res

    def parse_mempool(self, mp, value) -> CollectorResult:
        res = CollectorResult(source=self.name)
        cs = mp.get("chain_stats", {})
        ntx = cs.get("tx_count", 0)
        bal = cs.get("funded_txo_sum", 0) - cs.get("spent_txo_sum", 0)
        res.entities.append(Entity(EntityType.CRYPTO, value, Certainty.CONFIRMED,
            attrs={"chain": "btc", "balance_sat": bal, "n_tx": ntx},
            evidence=[Evidence(self.name, f"BTC 거래 {ntx}건(mempool)",
                      url=f"https://mempool.space/address/{value}")]))
        return res


class ProxyNovaCOMB(Collector):
    """ProxyNova COMB — 이메일/아이디 자격증명 노출 여부. 무키.

    안전: 평문 비밀번호는 저장하지 않는다. 노출 사실·건수만 발급한다.
    """
    name = "comb"
    accepts = {EntityType.EMAIL, EntityType.USERNAME}
    timeout = 25.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        data = await get_json(
            f"https://api.proxynova.com/comb?query={value}&start=0&limit=15",
            self.timeout, headers={"User-Agent": "artes/0.1"})
        if not data or "lines" not in data:
            return CollectorResult(source=self.name, ok=False, error="COMB 도달 실패")
        return self.parse(data, value, entity_type)

    def parse(self, data, value, entity_type) -> CollectorResult:
        res = CollectorResult(source=self.name)
        lines = data.get("lines") or []
        # 비밀번호 미저장 — 매칭 건수만. 로컬파트/이메일 노출 사실만.
        count = data.get("count", len(lines))
        if count:
            b = Entity(EntityType.BREACH, f"comb/{value.lower()}", Certainty.CONFIRMED,
                       attrs={"source": "COMB", "exposures": count},
                       evidence=[Evidence(self.name,
                                 f"COMB 자격증명 노출 {count}건(비밀번호 미저장)")])
            res.entities.append(b)
            res.edges.append(Edge(f"{entity_type.value}:{value.lower()}", b.key,
                                  "자격증명 노출", Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, "ProxyNova COMB")]))
        return res
