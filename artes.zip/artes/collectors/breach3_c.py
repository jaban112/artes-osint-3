"""유출 인텔 심화(증분 26) — 유출 '내용'이 아니라 '노출 실체'를 대규모로.

수사 실무 가치: 어느 유출·언제·무슨 '항목'(이메일·전화·생년·비밀번호 노출여부·해시형태)이
노출됐나 + 도메인 단위 감염/노출 통계. 평문 비밀번호 값·실시간 위치는 저장 안 함(불변 원칙).
- 무키: HIBP·XposedOrNot 유출 카탈로그로 발견된 유출명을 '노출 데이터 카테고리'로 보강,
  Hudson Rock 도메인 인포스틸러 통계.
- 선택 키(정식 수사자용): IntelX(유출 '참조' 메타만·본문 다운로드 안 함), LeakCheck Pro
  (출처·노출 필드 종류만). 키는 요청에만·로깅0·그래프0·동봉0.
"""
from __future__ import annotations

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from ..core.keys import KeyedCollector
from .base import Collector, CollectorResult
from .proc import get_json, post_json


def _norm_breach(name: str) -> str:
    return "".join(ch for ch in (name or "") if ch.isalnum())


class HIBPBreachInfo(Collector):
    """HIBP 유출 카탈로그(무키) — 발견된 유출명→노출 데이터 카테고리·규모·검증여부.

    이메일 조회(키 필요)가 아니라 '유출 사전' 조회. 이 유출이 무슨 항목을 노출했는지 알려준다.
    """
    name = "hibp-breach-info"; accepts = {EntityType.BREACH}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        # 감염/스캐너/제재 등 유출 아닌 BREACH 엔티티는 건너뜀
        if any(x in value for x in ("인포스틸러", "감염", "스캐너", "제재", "명단", "공격")):
            return CollectorResult(source=self.name, ok=True)
        nm = _norm_breach(value)
        if len(nm) < 2:
            return CollectorResult(source=self.name, ok=True)
        d = await get_json(f"https://haveibeenpwned.com/api/v3/breach/{nm}", self.timeout,
                           headers={"User-Agent": "artes"})
        if not d or not d.get("Name"):
            return CollectorResult(source=self.name, ok=False, error="HIBP 카탈로그 미매칭")
        return self.parse(d, value)

    def parse(self, d, value):
        res = CollectorResult(source=self.name)
        classes = d.get("DataClasses") or []
        res.entities.append(Entity(EntityType.BREACH, value, Certainty.CONFIRMED,
            evidence=[Evidence(self.name, f"HIBP: {d.get('BreachDate','')} · 노출항목 {', '.join(classes[:8])}",
                               url=f"https://haveibeenpwned.com/PwnedWebsites#{_norm_breach(value)}")],
            attrs={"breach_date": d.get("BreachDate", ""), "pwn_count": d.get("PwnCount"),
                   "data_classes": classes[:15], "verified": d.get("IsVerified"),
                   "sensitive": d.get("IsSensitive"), "domain": d.get("Domain", "")}))
        return res


class XposedBreachInfo(Collector):
    """XposedOrNot 유출 카탈로그(무키) — HIBP와 다른 커버리지의 유출 사전 보강."""
    name = "xposed-breach-info"; accepts = {EntityType.BREACH}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        if any(x in value for x in ("인포스틸러", "감염", "스캐너", "제재", "명단", "공격")):
            return CollectorResult(source=self.name, ok=True)
        d = await get_json(f"https://api.xposedornot.com/v1/breach-analytics?breach={value}",
                           self.timeout, headers={"User-Agent": "artes/0.1"})
        details = ((d or {}).get("ExposedBreaches") or {}).get("breaches_details") or []
        hit = next((b for b in details if _norm_breach(b.get("breach", "")) == _norm_breach(value)), None)
        if not hit:
            return CollectorResult(source=self.name, ok=False, error="XposedOrNot 카탈로그 미매칭")
        return self.parse(hit, value)

    def parse(self, b, value):
        res = CollectorResult(source=self.name)
        xdata = b.get("xposed_data", "")
        res.entities.append(Entity(EntityType.BREACH, value, Certainty.CONFIRMED,
            evidence=[Evidence(self.name, f"XposedOrNot: {b.get('xposed_date','')} · {xdata}")],
            attrs={"xposed_date": b.get("xposed_date", ""), "xposed_data": xdata,
                   "industry": b.get("industry", ""), "records": b.get("xposed_records")}))
        return res


class HudsonRockDomain(Collector):
    """Hudson Rock 도메인(무키) — 도메인의 인포스틸러 노출 통계(직원/사용자 감염 수, 마스킹)."""
    name = "hudsonrock-domain"; accepts = {EntityType.DOMAIN}; timeout = 20.0

    async def collect(self, value, entity_type, ctx):
        d = await get_json("https://cavalier.hudsonrock.com/api/json/v2/osint-tools/"
                           f"search-by-domain?domain={value}", self.timeout,
                           headers={"User-Agent": "artes/0.1"})
        if d is None:
            return CollectorResult(source=self.name, ok=False, error="HudsonRock 도메인 도달실패")
        return self.parse(d, value)

    def parse(self, d, value):
        res = CollectorResult(source=self.name)
        dk = f"domain:{value.lower()}"
        data = d.get("data") or d
        emp = data.get("employees") or data.get("total_employees")
        usr = data.get("users") or data.get("total_users")
        if not emp and not usr and not data.get("stats"):
            return res
        b = Entity(EntityType.BREACH, f"도메인 인포스틸러 노출: {value}", Certainty.CONFIRMED,
                   evidence=[Evidence(self.name, "Hudson Rock 도메인 통계(마스킹)")],
                   attrs={"employees_infected": emp, "users_infected": usr,
                          "exposure": True})
        res.entities.append(b)
        res.edges.append(Edge(dk, b.key, "인포스틸러 노출", Certainty.CONFIRMED,
                              evidence=[Evidence(self.name, "도메인 스틸러 통계")]))
        return res


class IntelXSearch(KeyedCollector, Collector):
    """IntelX(선택 키) — 유출 '참조' 메타만: 어느 소스·언제·버킷. 본문 다운로드 안 함.

    정식 수사자가 기관 키를 넣을 때만 동작. 키 없으면 skip. 유출 원문은 저장하지 않는다.
    """
    name = "intelx"; service = "intelx"
    accepts = {EntityType.EMAIL, EntityType.DOMAIN, EntityType.USERNAME, EntityType.PHONE}
    timeout = 30.0

    async def collect(self, value, entity_type, ctx):
        base = "https://2.intelx.io"
        hdr = {"x-key": self.api_key(), "User-Agent": "artes/1.0"}
        started = await post_json(f"{base}/intelligent/search",
                                  {"term": value, "maxresults": 20, "media": 0, "sort": 4},
                                  self.timeout, headers=hdr)
        sid = (started or {}).get("id")
        if not sid:
            return CollectorResult(source=self.name, ok=False, error="IntelX 검색 시작 실패")
        d = await get_json(f"{base}/intelligent/search/result?id={sid}&limit=20",
                           self.timeout, headers=hdr)
        records = (d or {}).get("records") or []
        if not records:
            return CollectorResult(source=self.name, ok=False, error="IntelX 무결과")
        return self.parse(records, value, entity_type)

    def parse(self, records, value, entity_type=EntityType.EMAIL):
        res = CollectorResult(source=self.name)
        subj = f"{entity_type.name.lower()}:{value.lower()}"
        seen = set()
        for r in records[:20]:
            src = (r.get("name") or r.get("bucket") or "미상 소스").strip()
            date = (r.get("date") or "")[:10]
            key = (src, date)
            if key in seen:
                continue
            seen.add(key)
            # 참조 메타만: 소스명·날짜·버킷. 본문/systemid 콘텐츠는 저장 안 함.
            b = Entity(EntityType.BREACH, f"IntelX 참조: {src}", Certainty.CONFIRMED,
                       evidence=[Evidence(self.name, f"IntelX{(' · ' + date) if date else ''}"
                                          f"{' · ' + r.get('bucket','') if r.get('bucket') else ''}")],
                       attrs={"source": src, "date": date, "bucket": r.get("bucket", ""),
                              "exposure": True})
            res.entities.append(b)
            res.edges.append(Edge(subj, b.key, "유출 참조(IntelX)", Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, "검색 참조")]))
        return res


class LeakCheckPro(KeyedCollector, Collector):
    """LeakCheck Pro(선택 키) — 출처·노출 필드 '종류'만. 평문 값(비번 등) 저장 안 함."""
    name = "leakcheck-pro"; service = "leakcheck"
    accepts = {EntityType.EMAIL, EntityType.USERNAME}; timeout = 25.0

    async def collect(self, value, entity_type, ctx):
        typ = "email" if entity_type == EntityType.EMAIL else "username"
        d = await get_json(f"https://leakcheck.io/api/v2/query/{value}?type={typ}", self.timeout,
                           headers={"X-API-Key": self.api_key(), "User-Agent": "artes/1.0"})
        if not d or not d.get("success"):
            return CollectorResult(source=self.name, ok=False, error="LeakCheck Pro 무결과/키오류")
        return self.parse(d, value, entity_type)

    def parse(self, d, value, entity_type=EntityType.EMAIL):
        res = CollectorResult(source=self.name)
        subj = f"{'email' if entity_type == EntityType.EMAIL else 'username'}:{value.lower()}"
        for r in (d.get("result") or [])[:40]:
            src = r.get("source") or {}
            nm = (src.get("name") if isinstance(src, dict) else str(src)) or "미상 유출"
            date = src.get("breach_date", "") if isinstance(src, dict) else ""
            # 노출 필드 '종류'만(값 아님) — password 값·라인 원문은 절대 저장 안 함
            field_types = [k for k in r.keys()
                           if k not in ("source", "line", "password", "sha1", "sha256", "md5",
                                        "hash", "salt")]
            exposed_password = any(k in r for k in ("password", "sha1", "sha256", "md5", "hash"))
            b = Entity(EntityType.BREACH, nm, Certainty.CONFIRMED,
                       evidence=[Evidence(self.name, f"LeakCheck Pro{(' · ' + date) if date else ''}"
                                          f"{' · 비밀번호 노출' if exposed_password else ''}")],
                       attrs={"breach_date": date, "exposed_fields": field_types[:15],
                              "password_exposed": exposed_password, "exposure": True})
            res.entities.append(b)
            res.edges.append(Edge(subj, b.key, "노출됨(LeakCheck Pro)", Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, "정식 조회")]))
        return res
