"""유출/노출 확장(증분 24) — 무키·무가입 공개 소스만. 평문 비밀번호 절대 미저장.

리서치 검증: LeakCheck 공개 API·Hudson Rock Cavalier(인포스틸러 감염, 다른 데이터 클래스)·
XposedOrNot 상세 분석. 전부 '노출 메타데이터'(어느 유출·언제·어떤 항목)만 — 비밀번호 원문 X.
정직: HIBP 이메일조회·IntelX·BreachDirectory·Leak-Lookup은 키/유료라 제외. 전화 유출은
무키 커버리지가 약함(리서치 확인).
"""
from __future__ import annotations

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from .base import Collector, CollectorResult
from .proc import get_json


def _breach_entity(res, subj_key, name, source, detail, url=""):
    b = Entity(EntityType.BREACH, name, Certainty.CONFIRMED,
               evidence=[Evidence(source, detail, url=url)], attrs={"exposure": True})
    res.entities.append(b)
    res.edges.append(Edge(subj_key, b.key, "노출됨", Certainty.CONFIRMED,
                          evidence=[Evidence(source, detail)]))


class LeakCheckPublic(Collector):
    """LeakCheck 공개 API — 이메일/아이디의 유출 출처·노출 항목(무키). 원문 X."""
    name = "leakcheck"; accepts = {EntityType.EMAIL, EntityType.USERNAME}; timeout = 20.0

    async def collect(self, value, entity_type, ctx):
        d = await get_json(f"https://leakcheck.io/api/public?check={value}", self.timeout,
                           headers={"User-Agent": "artes/0.1"})
        if not d or not d.get("success"):
            return CollectorResult(source=self.name, ok=False, error="LeakCheck 무결과/도달실패")
        return self.parse(d, value, entity_type)

    def parse(self, d, value, entity_type=EntityType.EMAIL):
        res = CollectorResult(source=self.name)
        subj = f"{'email' if entity_type == EntityType.EMAIL else 'username'}:{value.lower()}"
        n = d.get("found", 0)
        if not n:
            return res
        srcs = d.get("sources") or []
        for s in srcs[:40]:
            nm = s.get("name") if isinstance(s, dict) else str(s)
            date = s.get("date", "") if isinstance(s, dict) else ""
            _breach_entity(res, subj, nm or "미상 유출", self.name,
                           f"LeakCheck 노출{(' · ' + date) if date else ''}")
        # 노출된 데이터 '유형'만(값 아님)
        fields = d.get("fields") or []
        if fields:
            res.entities[0].attrs.setdefault("exposed_fields", fields[:20]) if res.entities else None
        return res


class HudsonRock(Collector):
    """Hudson Rock Cavalier(무키 osint-tools) — 인포스틸러 감염 여부(유출과 다른 데이터 클래스).

    이메일/아이디가 악성코드(스틸러)에 감염된 기기에서 유출됐는지 — 감염일·스틸러계열·건수(마스킹).
    """
    name = "hudsonrock"; accepts = {EntityType.EMAIL, EntityType.USERNAME}; timeout = 20.0

    async def collect(self, value, entity_type, ctx):
        kind = "email" if entity_type == EntityType.EMAIL else "username"
        d = await get_json("https://cavalier.hudsonrock.com/api/json/v2/osint-tools/"
                           f"search-by-{kind}?{kind}={value}", self.timeout,
                           headers={"User-Agent": "artes/0.1"})
        if d is None:
            return CollectorResult(source=self.name, ok=False, error="HudsonRock 도달실패")
        return self.parse(d, value, entity_type)

    def parse(self, d, value, entity_type=EntityType.EMAIL):
        res = CollectorResult(source=self.name)
        subj = f"{'email' if entity_type == EntityType.EMAIL else 'username'}:{value.lower()}"
        stealers = d.get("stealers") or d.get("data", {}).get("stealers") or []
        if not stealers and not d.get("message", "").lower().startswith("this"):
            # 감염 없음(또는 응답형태 다름) — 조용히 빈 결과
            return res
        for s in (stealers or [])[:20]:
            fam = s.get("stealer_family") or s.get("family") or "스틸러"
            date = s.get("date_compromised") or s.get("computer_name") or ""
            _breach_entity(res, subj, f"인포스틸러 감염({fam})", self.name,
                           f"Hudson Rock 인포스틸러{(' · ' + str(date)) if date else ''}")
        return res


class XposedAnalytics(Collector):
    """XposedOrNot 상세 분석 — 위험점수·노출 데이터 카테고리·연도별(무키). 메타데이터만."""
    name = "xposed-analytics"; accepts = {EntityType.EMAIL}; timeout = 20.0

    async def collect(self, value, entity_type, ctx):
        d = await get_json(f"https://api.xposedornot.com/v1/breach-analytics?email={value}",
                           self.timeout, headers={"User-Agent": "artes/0.1"})
        if not d or ("BreachMetrics" not in d and "ExposedBreaches" not in d):
            return CollectorResult(source=self.name, ok=False, error="XposedOrNot 무결과")
        return self.parse(d, value)

    def parse(self, d, value):
        res = CollectorResult(source=self.name)
        subj = f"email:{value.lower()}"
        exposed = ((d.get("ExposedBreaches") or {}).get("breaches_details")) or []
        for b in exposed[:40]:
            nm = b.get("breach") or "미상"
            xdata = b.get("xposed_data", "")
            _breach_entity(res, subj, nm, self.name,
                           f"XposedOrNot{(' · ' + xdata) if xdata else ''}")
        # 위험 요약(값 아님)
        risk = (d.get("BreachMetrics") or {}).get("risk") or []
        if exposed and res.entities:
            res.entities[0].attrs["risk"] = risk[0] if risk else ""
        return res
