"""네트워크 축 — nmap(포트·서비스), Wayback(과거 스냅샷).

nmap 스캔은 능동(active) 조사다 — 대상 권한이 있을 때만. 엔진의 first-run 고지가 관할.
"""
from __future__ import annotations

import asyncio
import json
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from .base import Collector, CollectorResult
from .proc import which, run_cmd


class Nmap(Collector):
    name = "nmap"
    accepts = {EntityType.IP, EntityType.DOMAIN, EntityType.HOST}
    timeout = 300.0

    def available(self) -> bool:
        return which("nmap") is not None

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        res = CollectorResult(source=self.name)
        # 빠른 상위 포트 + 서비스/버전. XML을 표준출력으로.
        rc, out, err = await run_cmd(
            ["nmap", "-Pn", "-T4", "--top-ports", "200", "-sV", "-oX", "-", value],
            timeout=self.timeout,
        )
        if not out.strip():
            res.ok = False
            res.error = err.strip()[:200] or f"rc={rc}"
            return res
        return self.parse_xml(out, value, entity_type)

    def parse_xml(self, out: str, value: str, entity_type) -> CollectorResult:
        res = CollectorResult(source=self.name)
        try:
            root = ET.fromstring(out)
        except ET.ParseError as e:
            res.ok = False
            res.error = f"xml parse: {e}"
            return res
        base_key = f"{entity_type.value}:{value.lower()}"
        for host in root.findall("host"):
            addr = None
            a = host.find("address")
            if a is not None:
                addr = a.get("addr")
            for port in host.findall("./ports/port"):
                state = port.find("state")
                if state is None or state.get("state") != "open":
                    continue
                pid = port.get("portid")
                proto = port.get("protocol", "tcp")
                svc = port.find("service")
                sname = svc.get("name", "") if svc is not None else ""
                sver = (svc.get("product", "") + " " + svc.get("version", "")).strip() \
                    if svc is not None else ""
                label = f"{value}:{pid}/{proto}"
                h = Entity(EntityType.HOST, label, Certainty.CONFIRMED,
                           evidence=[Evidence(self.name,
                                              f"열린 포트 {pid}/{proto} {sname} {sver}".strip())],
                           attrs={"ip": addr, "port": pid, "proto": proto,
                                  "service": sname, "version": sver})
                res.entities.append(h)
                res.edges.append(Edge(base_key, h.key, "열린 포트",
                                      Certainty.CONFIRMED,
                                      evidence=[Evidence(self.name, "nmap -sV")]))
        return res


class Wayback(Collector):
    name = "wayback"
    accepts = {EntityType.DOMAIN, EntityType.URL}
    timeout = 40.0

    def available(self) -> bool:
        return True                      # 바이너리 불필요(archive.org CDX API)

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        res = CollectorResult(source=self.name)
        host = value
        if entity_type is EntityType.URL:
            host = urllib.parse.urlparse(value).netloc or value
        url = ("http://web.archive.org/cdx/search/cdx?url="
               + urllib.parse.quote(host)
               + "*&output=json&fl=original,timestamp&collapse=urlkey&limit=500")
        rows = await asyncio.get_event_loop().run_in_executor(None, self._fetch, url)
        if rows is None:
            res.ok = False
            res.error = "archive.org 도달 실패"
            return res
        base_key = f"{entity_type.value}:{value.lower()}"
        seen = set()
        for row in rows[1:]:              # 첫 행은 헤더
            original = row[0]
            if original in seen:
                continue
            seen.add(original)
            u = Entity(EntityType.URL, original, Certainty.CONFIRMED,
                       evidence=[Evidence(self.name, f"과거 스냅샷 존재(ts {row[1]})")],
                       attrs={"timestamp": row[1]})
            res.entities.append(u)
            res.edges.append(Edge(base_key, u.key, "과거 URL", Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, "Wayback CDX")]))
        return res

    @staticmethod
    def _fetch(url: str):
        try:
            with urllib.request.urlopen(url, timeout=30) as r:
                return json.loads(r.read().decode("utf-8", "replace"))
        except Exception:
            return None
