"""gap2 — 이름/이메일 → 실신원 강화(무키 공개 소스).

정직 스코프: 전화→실명 역조회는 무키로 불가(Truecaller·Sync.me 등 전부 유료/ToS)라
넣지 않는다. 대신 무키·합법으로 실제 신원을 좁히는 공개 경로를 강화한다:
- EmailRep(emailrep.io): 이메일→평판·가입 플랫폼 목록·실명(있으면). 키 불필요.
- GitHub 사용자 검색: 실명(성+이름)→같은 이름의 GitHub 계정 후보(아바타 포함 → pHash 대조로 자동 교차검증).
Keybase(암호학 검증 연결)는 이미 keybase_c에 있음 — 여기선 중복하지 않는다.
"""
from __future__ import annotations

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from .base import Collector, CollectorResult
from .proc import get_json


class EmailRepIO(Collector):
    """EmailRep — 이메일→평판·가입 플랫폼·실명(무키, 레이트리밋). 평문 자격증명 미저장."""
    name = "emailrep"; accepts = {EntityType.EMAIL}; timeout = 20.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        d = await get_json(f"https://emailrep.io/{value.strip().lower()}",
                           self.timeout,
                           headers={"User-Agent": "Mozilla/5.0 (ARTES OSINT)",
                                    "Accept": "application/json"})
        if not isinstance(d, dict) or "email" not in d:
            return CollectorResult(source=self.name, ok=False, error="EmailRep 미응답/미발견")
        return self.parse(d, value)

    def parse(self, d: dict, value: str) -> CollectorResult:
        res = CollectorResult(source=self.name)
        ek = f"email:{value.lower()}"
        details = d.get("details") or {}
        # 실명(제공될 때만) — 불확실 후보
        nm = (details.get("name") or "").strip()
        if nm and len(nm) <= 60:
            res.entities.append(Entity(EntityType.NAME, nm, Certainty.UNCONFIRMED, 0.5,
                                evidence=[Evidence(self.name, "EmailRep 연결 실명")]))
            res.edges.append(Edge(ek, f"name:{nm.lower()}", "연결 이름", Certainty.UNCONFIRMED,
                                  0.5, evidence=[Evidence(self.name, "details.name")]))
        # 가입 플랫폼 목록(핸들은 미상 — 어디를 볼지 알려주는 단서)
        for plat in (details.get("profiles") or [])[:12]:
            p = str(plat).lower().strip()
            if not p:
                continue
            key = f"account:{p}/(이메일 가입)"
            res.entities.append(Entity(EntityType.ACCOUNT, f"{p}/(이메일 가입)",
                                Certainty.UNCONFIRMED, 0.35,
                                evidence=[Evidence(self.name, f"EmailRep: 이 이메일이 {p}에 가입됨(핸들 미상)")],
                                attrs={"site": p, "handle": "", "variant": True,
                                       "note": "EmailRep 가입 플랫폼(핸들 미확인)"}))
            res.edges.append(Edge(ek, key, "가입 플랫폼(핸들미상)", Certainty.UNCONFIRMED, 0.35,
                                  evidence=[Evidence(self.name, "details.profiles")]))
        # 유출 노출 여부(메타만 — 평문·해시 절대 미저장)
        if details.get("credentials_leaked") or details.get("data_breach"):
            res.entities.append(Entity(EntityType.BREACH, f"emailrep:{value.lower()}",
                                Certainty.CONFIRMED,
                                evidence=[Evidence(self.name, "EmailRep: 자격증명 유출 이력(메타)")],
                                attrs={"credentials_leaked": bool(details.get("credentials_leaked")),
                                       "data_breach": bool(details.get("data_breach")),
                                       "first_seen": details.get("first_seen", ""),
                                       "last_seen": details.get("last_seen", "")}))
            res.edges.append(Edge(ek, f"breach:emailrep:{value.lower()}", "유출 노출(메타)",
                                  Certainty.CONFIRMED, evidence=[Evidence(self.name, "EmailRep details")]))
        return res


class GitHubUserSearch(Collector):
    """실명(성+이름) → 같은 이름의 GitHub 계정 후보(무키, 저율). 아바타 포함 → pHash 자동 대조."""
    name = "github-user-search"; accepts = {EntityType.NAME}; timeout = 20.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        q = value.strip()
        if len(q) < 4 or " " not in q:          # 성+이름 형태만(동명이인 소음 억제)
            return CollectorResult(source=self.name, ok=True)   # 조용히 빈 결과
        d = await get_json(
            f"https://api.github.com/search/users?q={q.replace(' ', '+')}+in:fullname&per_page=5",
            self.timeout, headers={"User-Agent": "artes/0.1",
                                   "Accept": "application/vnd.github+json"})
        items = (d or {}).get("items") or []
        if not items:
            return CollectorResult(source=self.name, ok=False, error="GitHub 사용자 무결과")
        return self.parse(items, value)

    def parse(self, items, value) -> CollectorResult:
        res = CollectorResult(source=self.name)
        nk = f"name:{value.lower()}"
        for it in items[:5]:
            login = (it.get("login") or "").strip()
            if not login:
                continue
            url = it.get("html_url") or f"https://github.com/{login}"
            res.entities.append(Entity(EntityType.ACCOUNT, f"github/{login}",
                                Certainty.UNCONFIRMED, 0.3,
                                evidence=[Evidence(self.name, "이름 검색 GitHub 후보", url=url)],
                                attrs={"site": "github", "handle": login, "url": url,
                                       "variant": True,
                                       "avatar": it.get("avatar_url", "")}))
            # 이름→계정은 약한 단서(동명이인). 아바타 pHash·다른 앵커로 승격됨.
            res.edges.append(Edge(nk, f"account:github/{login}", "이름 검색 후보",
                                  Certainty.UNCONFIRMED, 0.3,
                                  evidence=[Evidence(self.name, "search/users in:fullname")]))
        return res
