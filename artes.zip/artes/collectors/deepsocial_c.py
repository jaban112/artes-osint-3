"""쿠키 심층 수집기(증분 35) — 본인 인증 세션 쿠키로 벽 안쪽 프로필 메타.

InstagramAuth와 동일 원칙: '본인이 로그인한 본인 계정'의 쿠키로만 동작(인가 수사 전제). 쿠키
없으면 skip → 일반 스캔엔 영향 0. 프로필 메타(실명·바이오·팔로워/팔로잉·위치·링크·인증여부)
까지만 — DM·비공개 콘텐츠·실시간 위치는 다루지 않는다(불변). ToS 위반·계정정지 위험은 사용자 책임.

정직: 이 플랫폼들은 봇 차단(서명·CSRF·안티봇)이 강해 취약도가 제각각이다. Reddit(about.json)·
LinkedIn(og)·TikTok(임베드 JSON)은 비교적 안정, Twitter/X(GraphQL queryId 변동)·Facebook(mbasic)은
취약. 실패해도 조용히 넘어가고(스캔 보존), 응답 구조가 바뀌면 파서만 갱신하면 된다.
"""
from __future__ import annotations

import json
import re

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from ..core.cookies import CookieCollector
from .base import Collector, CollectorResult
from .proc import get_text, get_json
from .social3_c import _links_from, _link_entities, _name_geo
from .social4_c import _acc


def _h(v: str) -> str:
    return v.lstrip("@").strip()


def _og(html, prop):
    m = re.search(rf'<meta[^>]+(?:property|name)=["\']{re.escape(prop)}["\'][^>]+content=["\']([^"\']*)["\']',
                  html or "")
    return (m.group(1).strip() if m else "")


def _cookie_val(cookiestr: str, name: str) -> str:
    m = re.search(rf'(?:^|;\s*){re.escape(name)}=([^;]+)', cookiestr or "")
    return m.group(1) if m else ""


# ══════════ TikTok (sessionid) ══════════
class TikTokAuth(CookieCollector, Collector):
    """TikTok 심층(sessionid) — 표시이름·바이오·팔로워/팔로잉·좋아요·인증·지역."""
    name = "tiktok-auth"; site = "tiktok"; accepts = {EntityType.USERNAME}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        h = _h(value)
        html = await get_text(f"https://www.tiktok.com/@{h}", timeout=self.timeout,
                              headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
                                       "Cookie": self.cookie() or ""})
        m = re.search(r'__UNIVERSAL_DATA_FOR_REHYDRATION__[^>]*>(\{.*?\})</script>', html or "", re.S)
        if not m:
            return CollectorResult(source=self.name, ok=False, error="TikTok 심층 실패(쿠키/구조)")
        try:
            data = json.loads(m.group(1))
            info = data["__DEFAULT_SCOPE__"]["webapp.user-detail"]["userInfo"]
        except Exception:
            return CollectorResult(source=self.name, ok=False, error="TikTok JSON 파싱 실패")
        return self.parse(info, value)

    def parse(self, info, value):
        res = CollectorResult(source=self.name)
        h = _h(value)
        u = info.get("user") or {}
        st = info.get("stats") or {}
        a = _acc(res, value, "tiktok", u.get("uniqueId", h), f"https://www.tiktok.com/@{h}",
                 self.name, "TikTok 심층(인증)",
                 {"display": u.get("nickname", ""), "bio": (u.get("signature") or "")[:300],
                  "followers": st.get("followerCount"), "following": st.get("followingCount"),
                  "hearts": st.get("heartCount"), "videos": st.get("videoCount"),
                  "verified": u.get("verified"), "region": u.get("region", ""),
                  "tiktok_id": u.get("id"),
                  "avatar": u.get("avatarLarger") or u.get("avatarMedium", "")})
        _name_geo(res, a.key, self.name, u.get("nickname", ""), u.get("region", ""))
        _link_entities(res, a.key, _links_from(u.get("signature", "") or "")
                       + ([u.get("bioLink", {}).get("link")] if u.get("bioLink") else []),
                       self.name, certain=False)
        return res


# ══════════ Twitter / X (auth_token + ct0) ══════════
class TwitterAuth(CookieCollector, Collector):
    """X(트위터) 심층(auth_token+ct0) — 실명·바이오·팔로워/팔로잉·위치·가입일·인증.

    취약: GraphQL queryId가 수시로 바뀜. 실패 시 env ARTES_X_QUERYID로 최신값 지정 가능.
    """
    name = "twitter-auth"; site = "twitter"; accepts = {EntityType.USERNAME}; timeout = 15.0
    _BEARER = ("AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D"
               "1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA")

    async def collect(self, value, entity_type, ctx):
        import os
        import urllib.parse
        h = _h(value)
        ck = self.cookie() or ""
        ct0 = _cookie_val(ck, "ct0")
        qid = os.environ.get("ARTES_X_QUERYID", "G3KGOASz96M-Qu0nwmGXNg")   # UserByScreenName
        variables = json.dumps({"screen_name": h, "withSafetyModeUserFields": True})
        features = json.dumps({"hidden_profile_likes_enabled": True, "responsive_web_graphql_exclude_directive_enabled": True,
                               "verified_phone_label_enabled": False, "subscriptions_verification_info_is_identity_verified_enabled": True,
                               "highlights_tweets_tab_ui_enabled": True, "creator_subscriptions_tweet_preview_api_enabled": True,
                               "responsive_web_graphql_timeline_navigation_enabled": True})
        url = (f"https://api.x.com/graphql/{qid}/UserByScreenName?"
               f"variables={urllib.parse.quote(variables)}&features={urllib.parse.quote(features)}")
        d = await get_json(url, self.timeout, headers={
            "Authorization": f"Bearer {self._BEARER}", "x-csrf-token": ct0,
            "Cookie": ck, "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
            "x-twitter-auth-type": "OAuth2Session", "x-twitter-active-user": "yes"})
        user = (((d or {}).get("data") or {}).get("user") or {}).get("result")
        if not user:
            return CollectorResult(source=self.name, ok=False, error="X 심층 실패(쿠키/queryId)")
        return self.parse(user, value)

    def parse(self, user, value):
        res = CollectorResult(source=self.name)
        h = _h(value)
        lg = user.get("legacy") or {}
        a = _acc(res, value, "twitter", lg.get("screen_name", h), f"https://x.com/{h}",
                 self.name, "X 심층(인증)",
                 {"display": lg.get("name", ""), "bio": (lg.get("description") or "")[:300],
                  "followers": lg.get("followers_count"), "following": lg.get("friends_count"),
                  "tweets": lg.get("statuses_count"), "verified": user.get("is_blue_verified") or lg.get("verified"),
                  "created": lg.get("created_at", ""), "x_id": user.get("rest_id"),
                  "profile_image_url_https": (lg.get("profile_image_url_https") or "").replace("_normal","")})
        _name_geo(res, a.key, self.name, lg.get("name", ""), lg.get("location", ""))
        links = _links_from(lg.get("description", "") or "")
        ent_url = (((lg.get("entities") or {}).get("url") or {}).get("urls") or [])
        links += [x.get("expanded_url") for x in ent_url if x.get("expanded_url")]
        _link_entities(res, a.key, links, self.name, certain=False)
        return res


# ══════════ Facebook (c_user + xs) ══════════
class FacebookAuth(CookieCollector, Collector):
    """Facebook 심층(c_user+xs) — mbasic 프로필서 실명·기본정보. 취약(구조 변동)."""
    name = "facebook-auth"; site = "facebook"; accepts = {EntityType.USERNAME}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        h = _h(value)
        html = await get_text(f"https://mbasic.facebook.com/{h}", timeout=self.timeout,
                              headers={"User-Agent": "Mozilla/5.0 (Android 12; Mobile)",
                                       "Cookie": self.cookie() or ""})
        if not html or ("mbasic_logout_button" not in html and "og:title" not in html):
            return CollectorResult(source=self.name, ok=False, error="Facebook 심층 실패(쿠키/구조)")
        return self.parse(html, value)

    def parse(self, html, value):
        res = CollectorResult(source=self.name)
        h = _h(value)
        title = _og(html, "og:title") or (re.search(r"<title>([^<]+)</title>", html or "") or [None, ""])[1]
        name = (title or "").split("|")[0].strip()
        a = _acc(res, value, "facebook", h, f"https://www.facebook.com/{h}", self.name,
                 "Facebook 심층(인증·mbasic)", {"display": name})
        _name_geo(res, a.key, self.name, name if " " in name else "", "")
        _link_entities(res, a.key, _links_from(_og(html, "og:description")), self.name, certain=False)
        return res


# ══════════ LinkedIn (li_at) ══════════
class LinkedInAuth(CookieCollector, Collector):
    """LinkedIn 심층(li_at) — 공개 프로필서 실명·헤드라인·위치(og). 비교적 안정."""
    name = "linkedin-auth"; site = "linkedin"; accepts = {EntityType.USERNAME}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        h = _h(value)
        html = await get_text(f"https://www.linkedin.com/in/{h}/", timeout=self.timeout,
                              headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
                                       "Cookie": self.cookie() or ""})
        title = _og(html or "", "og:title")
        if not title or "linkedin" == title.strip().lower():
            return CollectorResult(source=self.name, ok=False, error="LinkedIn 심층 실패(쿠키/로그인벽)")
        return self.parse(html, value, title)

    def parse(self, html, value, title=""):
        res = CollectorResult(source=self.name)
        h = _h(value)
        title = title or _og(html or "", "og:title")
        desc = _og(html or "", "og:description")
        # og:title = "이름 - 헤드라인 | LinkedIn"
        name = title.split(" - ")[0].split("|")[0].strip()
        headline = ""
        if " - " in title:
            headline = title.split(" - ", 1)[1].rsplit("|", 1)[0].strip()
        a = _acc(res, value, "linkedin", h, f"https://www.linkedin.com/in/{h}/", self.name,
                 "LinkedIn 심층(인증)", {"display": name, "headline": headline, "about": desc[:200]})
        _name_geo(res, a.key, self.name, name, "")
        return res


# ══════════ Naver (NID_AUT + NID_SES) ══════════
class NaverAuth(CookieCollector, Collector):
    """네이버 심층(NID_AUT+NID_SES) — 블로그/프로필 표시명·소개(로그인 상태로 더 접근)."""
    name = "naver-auth"; site = "naver"; accepts = {EntityType.USERNAME}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        h = _h(value)
        html = await get_text(f"https://m.blog.naver.com/{h}", timeout=self.timeout,
                              headers={"User-Agent": "Mozilla/5.0 (Android 12; Mobile)",
                                       "Cookie": self.cookie() or ""})
        title = _og(html or "", "og:title")
        if not title or "네이버" == title.strip():
            return CollectorResult(source=self.name, ok=False, error="네이버 심층 실패(쿠키/미발견)")
        return self.parse(html, value, title)

    def parse(self, html, value, title=""):
        res = CollectorResult(source=self.name)
        h = _h(value)
        title = title or _og(html or "", "og:title")
        desc = _og(html or "", "og:description")
        _acc(res, value, "naver", h, f"https://blog.naver.com/{h}", self.name,
             "네이버 심층(인증)", {"blog": title, "about": desc[:200]})
        return res


# ══════════ Reddit (reddit_session) ══════════
class RedditAuth(CookieCollector, Collector):
    """Reddit 심층(reddit_session) — 카르마·가입일·소개(2026 무인증 차단 우회, 로그인 쿠키)."""
    name = "reddit-auth"; site = "reddit"; accepts = {EntityType.USERNAME}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        h = _h(value)
        d = await get_json(f"https://www.reddit.com/user/{h}/about.json", self.timeout,
                           headers={"User-Agent": "Mozilla/5.0 artes/1.0",
                                    "Cookie": self.cookie() or ""})
        data = (d or {}).get("data")
        if not data:
            return CollectorResult(source=self.name, ok=False, error="Reddit 심층 실패(쿠키/미발견)")
        return self.parse(data, value)

    def parse(self, data, value):
        res = CollectorResult(source=self.name)
        h = _h(value)
        sr = data.get("subreddit") or {}
        a = _acc(res, value, "reddit", data.get("name", h),
                 f"https://www.reddit.com/user/{h}", self.name, "Reddit 심층(인증)",
                 {"total_karma": data.get("total_karma"), "link_karma": data.get("link_karma"),
                  "comment_karma": data.get("comment_karma"), "created": data.get("created_utc"),
                  "verified": data.get("verified"), "employee": data.get("is_employee"),
                  "bio": (sr.get("public_description") or "")[:300],
                  "icon_img": (data.get("icon_img") or sr.get("icon_img") or "").split("?")[0]})
        _link_entities(res, a.key, _links_from(sr.get("public_description", "") or ""),
                       self.name, certain=False)
        return res
