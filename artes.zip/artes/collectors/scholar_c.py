"""학술·전문·명단 피벗(증분 25) — 이름→저자/저작/소속/명단(무키 공개 API).

ORCID·OpenAlex(증분24)를 보강하는 4개. 이름 매칭이라 저신뢰(불확실)·소음방지 위해
'성+이름'(공백 포함)만 질의. OpenSanctions는 제재·PEP·워치리스트 스크리닝(합법 컴플라이언스).
"""
from __future__ import annotations

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from .base import Collector, CollectorResult
from .proc import get_json


def _needs_fullname(value):
    v = (value or "").strip()
    return len(v) >= 3 and " " in v


class Crossref(Collector):
    """Crossref — 이름→논문·소속·ORCID(무키). 학술 신원 피벗."""
    name = "crossref"; accepts = {EntityType.NAME}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        if not _needs_fullname(value):
            return CollectorResult(source=self.name, ok=True)
        d = await get_json("https://api.crossref.org/works?"
                           f"query.author={value.strip().replace(' ', '+')}&rows=5",
                           self.timeout, headers={"User-Agent": "artes/0.1 (osint; mailto:osint@example.com)"})
        items = (((d or {}).get("message") or {}).get("items")) or []
        if not items:
            return CollectorResult(source=self.name, ok=False, error="Crossref 무결과")
        return self.parse(items, value)

    def parse(self, items, value):
        res = CollectorResult(source=self.name)
        nk = f"name:{value.lower()}"
        seen_orcid, seen_aff = set(), set()
        for it in items[:5]:
            for au in (it.get("author") or []):
                orcid = (au.get("ORCID") or "").rstrip("/").rsplit("/", 1)[-1]
                if orcid and orcid not in seen_orcid:
                    seen_orcid.add(orcid)
                    url = f"https://orcid.org/{orcid}"
                    res.entities.append(Entity(EntityType.ACCOUNT, f"orcid/{orcid}",
                        Certainty.UNCONFIRMED, confidence=0.45,
                        evidence=[Evidence(self.name, "Crossref 공저 ORCID", url=url)],
                        attrs={"site": "orcid", "handle": orcid, "url": url}))
                    res.edges.append(Edge(nk, f"account:orcid/{orcid}", "학술 저자 후보",
                        Certainty.UNCONFIRMED, confidence=0.45,
                        evidence=[Evidence(self.name, "저자명 검색")]))
                for aff in (au.get("affiliation") or []):
                    nm = aff.get("name", "")
                    if nm and nm.lower() not in seen_aff and len(nm) <= 80:
                        seen_aff.add(nm.lower())
                        res.entities.append(Entity(EntityType.ORG, nm, Certainty.UNCONFIRMED,
                            confidence=0.4, evidence=[Evidence(self.name, "소속(논문 메타)")]))
                        res.edges.append(Edge(nk, f"org:{nm.lower()}", "소속 후보",
                            Certainty.UNCONFIRMED, confidence=0.4,
                            evidence=[Evidence(self.name, "affiliation")]))
        return res


class SemanticScholar(Collector):
    """Semantic Scholar — 이름→저자·소속·홈페이지·외부ID(무키)."""
    name = "semanticscholar"; accepts = {EntityType.NAME}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        if not _needs_fullname(value):
            return CollectorResult(source=self.name, ok=True)
        d = await get_json("https://api.semanticscholar.org/graph/v1/author/search?"
                           f"query={value.strip().replace(' ', '+')}"
                           "&fields=name,affiliations,homepage,paperCount,externalIds",
                           self.timeout, headers={"User-Agent": "artes/0.1"})
        data = (d or {}).get("data") or []
        if not data:
            return CollectorResult(source=self.name, ok=False, error="SemanticScholar 무결과")
        return self.parse(data, value)

    def parse(self, data, value):
        res = CollectorResult(source=self.name)
        nk = f"name:{value.lower()}"
        for a in data[:3]:
            aid = a.get("authorId")
            if not aid:
                continue
            url = f"https://www.semanticscholar.org/author/{aid}"
            affs = a.get("affiliations") or []
            res.entities.append(Entity(EntityType.ACCOUNT, f"semanticscholar/{aid}",
                Certainty.UNCONFIRMED, confidence=0.4,
                evidence=[Evidence(self.name, "S2 저자", url=url)],
                attrs={"site": "semanticscholar", "handle": aid, "url": url,
                       "papers": a.get("paperCount"), "affiliations": affs[:5]}))
            res.edges.append(Edge(nk, f"account:semanticscholar/{aid}", "학술 저자 후보",
                Certainty.UNCONFIRMED, confidence=0.4, evidence=[Evidence(self.name, "이름 검색")]))
            if a.get("homepage"):
                res.entities.append(Entity(EntityType.URL, a["homepage"], Certainty.UNCONFIRMED,
                    confidence=0.4, evidence=[Evidence(self.name, "저자 홈페이지", url=a["homepage"])]))
        return res


class OpenLibrary(Collector):
    """OpenLibrary — 이름→저자·주요저작(무키). 저자 신원 피벗."""
    name = "openlibrary"; accepts = {EntityType.NAME}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        if not _needs_fullname(value):
            return CollectorResult(source=self.name, ok=True)
        d = await get_json(f"https://openlibrary.org/search/authors.json?q={value.strip().replace(' ', '+')}",
                           self.timeout, headers={"User-Agent": "artes/0.1"})
        docs = (d or {}).get("docs") or []
        if not docs:
            return CollectorResult(source=self.name, ok=False, error="OpenLibrary 무결과")
        return self.parse(docs, value)

    def parse(self, docs, value):
        res = CollectorResult(source=self.name)
        nk = f"name:{value.lower()}"
        for a in docs[:3]:
            key = a.get("key")
            if not key:
                continue
            url = f"https://openlibrary.org/authors/{key}"
            res.entities.append(Entity(EntityType.ACCOUNT, f"openlibrary/{key}",
                Certainty.UNCONFIRMED, confidence=0.4,
                evidence=[Evidence(self.name, f"OpenLibrary 저자 · {a.get('top_work','')}", url=url)],
                attrs={"site": "openlibrary", "handle": key, "url": url,
                       "works": a.get("work_count"), "top_work": a.get("top_work", "")}))
            res.edges.append(Edge(nk, f"account:openlibrary/{key}", "저자 후보",
                Certainty.UNCONFIRMED, confidence=0.4, evidence=[Evidence(self.name, "이름 검색")]))
        return res


class OpenSanctions(Collector):
    """OpenSanctions(yente) — 이름→제재·PEP·워치리스트 매칭(무키). 합법 스크리닝."""
    name = "opensanctions"; accepts = {EntityType.NAME}; timeout = 20.0

    async def collect(self, value, entity_type, ctx):
        if not _needs_fullname(value):
            return CollectorResult(source=self.name, ok=True)
        d = await get_json("https://api.opensanctions.org/search/default?"
                           f"q={value.strip().replace(' ', '%20')}&limit=5",
                           self.timeout, headers={"User-Agent": "artes/0.1"})
        results = (d or {}).get("results") or []
        if not results:
            return CollectorResult(source=self.name, ok=False, error="OpenSanctions 무결과")
        return self.parse(results, value)

    def parse(self, results, value):
        res = CollectorResult(source=self.name)
        nk = f"name:{value.lower()}"
        for r in results[:5]:
            score = r.get("score", 0)
            if score and score < 0.6:      # 약매칭 제외(소음 방지)
                continue
            schema = r.get("schema", "")
            datasets = r.get("datasets") or []
            caption = r.get("caption") or "미상"
            rid = r.get("id", "")
            b = Entity(EntityType.BREACH, f"제재/명단: {caption}", Certainty.UNCONFIRMED,
                       confidence=round(float(score or 0.6), 2),
                       evidence=[Evidence(self.name, f"OpenSanctions {schema} · {','.join(datasets[:3])}",
                                          url=f"https://www.opensanctions.org/entities/{rid}/")],
                       attrs={"kind": "sanctions/pep", "schema": schema, "datasets": datasets[:5]})
            res.entities.append(b)
            res.edges.append(Edge(nk, b.key, "명단 매칭(후보)", Certainty.UNCONFIRMED,
                confidence=round(float(score or 0.6), 2),
                evidence=[Evidence(self.name, "이름 스크리닝")]))
        return res
