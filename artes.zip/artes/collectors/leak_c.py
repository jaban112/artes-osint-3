"""h8mail 로컬 유출 래퍼 — 로컬 유출 파일에서 이메일 매칭(키·계정 불필요).

로컬 모드만 쓴다(API/키 소스 배제). 유출 파일 경로는 ctx['breach_path'] 또는
환경변수 ARTES_BREACH_DIR 로 준다. 경로가 없으면 우아하게 skip.
"""
from __future__ import annotations

import json
import os
import tempfile

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from ..core.safety import FILTER
from .base import Collector, CollectorResult
from .proc import which, run_cmd


class H8mail(Collector):
    name = "h8mail"
    accepts = {EntityType.EMAIL}
    timeout = 180.0

    def _breach_path(self, ctx) -> str | None:
        return (ctx or {}).get("breach_path") or os.environ.get("ARTES_BREACH_DIR")

    def available(self) -> bool:
        return which("h8mail") is not None

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        res = CollectorResult(source=self.name)
        bp = self._breach_path(ctx)
        if not bp or not os.path.exists(bp):
            res.skipped = True
            res.error = "로컬 유출 경로 없음(ARTES_BREACH_DIR)"
            return res
        with tempfile.TemporaryDirectory() as td:
            out_json = os.path.join(td, "h8.json")
            rc, out, err = await run_cmd(
                ["h8mail", "-t", value, "-lb", bp, "--json", out_json, "-q"],
                timeout=self.timeout,
            )
            data = self._read(out_json)
        hits = self._extract(data, value)
        if not hits and rc != 0:
            res.ok = False
            res.error = err.strip()[:200] or f"rc={rc}"
            return res
        ekey = f"email:{value.lower()}"
        for source_name, extra in hits:
            if FILTER.is_blocked(source_name) or FILTER.is_blocked(extra):
                continue
            b = Entity(EntityType.BREACH, f"{source_name}:{value}",
                       Certainty.CONFIRMED,
                       evidence=[Evidence(self.name, f"로컬 유출 '{source_name}'에서 매칭")],
                       attrs={"breach": source_name, "extra": extra})
            res.entities.append(b)
            res.edges.append(Edge(ekey, b.key, "유출 노출", Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, "h8mail 로컬 매칭")]))
        return res

    @staticmethod
    def _read(path):
        try:
            return json.loads(open(path, encoding="utf-8").read())
        except Exception:
            return None

    @staticmethod
    def _extract(data, email):
        """h8mail json 구조는 버전따라 다르므로 방어적으로 훑는다."""
        hits = []
        if not data:
            return hits
        targets = data.get("targets", data) if isinstance(data, dict) else data
        if isinstance(targets, dict):
            targets = [targets]
        for t in (targets or []):
            if not isinstance(t, dict):
                continue
            for item in t.get("data", []) or []:
                s = item if isinstance(item, str) else json.dumps(item, ensure_ascii=False)
                parts = s.split(":", 1)
                hits.append((parts[0][:60], (parts[1][:80] if len(parts) > 1 else "")))
        return hits
