"""수집기 레지스트리 — 전 축 기본 구성.

축: 표층 · 전화 · 네트워크 · 인프라(RDAP·crt.sh·DNS) · 개발자(GitHub) ·
웹지문(분석ID·파비콘) · 능동확장(순열·Gravatar·이름추정) · 다크웹 · 유출.
real=True 면 실제 도구/HTTP 래퍼(미가용이면 자동 skip),
include_mock=True 면 오프라인 목도(테스트/데모). 다크웹은 enable_darkweb=True.
"""
from __future__ import annotations

from .base import Collector
from .holehe_c import Holehe
from .maigret_c import Maigret
from .sherlock_c import Sherlock
from .blackbird_c import Blackbird
from .theharvester_c import TheHarvester
from .phone_c import PhoneInfoga, Ignorant, Phunter
from .phone2_c import PhoneInfo
from .net_c import Nmap, Wayback
from .net2_c import ReverseDNS, ASNLookup, IPGeo, HTTPHeaders, DoHDNS
from .leak_c import H8mail
from .infra_c import RDAP, CrtSh, DNSEnum
from .dev_c import GitHubDev
from .dev2_c import GitHubKeys, GitHubGists, NpmMaintainer
from .keybase_c import Keybase
from .social_c import HackerNews, GitLab, WebFinger  # Reddit: 2026 무인증 JSON 차단→제외
from .social3_c import (Bluesky, ChessCom, Lichess, DevTo, DockerHub, Wikipedia,
                        Codeberg)  # Mastodon lookup: 인증 필요화→제외(WebFinger로 대체)
from .social4_c import (ArtStation, StackExchange, WikimediaGlobal, Steam, Mixcloud,
                        Launchpad, CratesIo, SpeedrunCom, Lemmy, Duolingo, Codewars,
                        Roblox)  # 증분24: 무키 공개 API 대량 추가(실명·위치·교차계정)
from .breach2_c import LeakCheckPublic, HudsonRock, XposedAnalytics  # 증분24: 유출/감염 메타
from .enrich3_c import GravatarJSON, GitHubCommitEmail, ORCID, OpenAlex  # 증분24: 사람 피벗
from .social5_c import (Minecraft, JikanMAL, AniList, Kitsu, TetrIO, Scratch, Discogs,
                        SourceForge, Hashnode, Packagist, Bitbucket, Telegram)  # 증분25: SNS+
from .scholar_c import Crossref, SemanticScholar, OpenLibrary, OpenSanctions  # 증분25: 학술/명단
from .verify_c import (KickboxOpen, Disify, IPWhois, GreyNoiseCommunity,
                       SANSISC)  # 증분25: 이메일 품질·IP 위협
from .breach3_c import (HIBPBreachInfo, XposedBreachInfo, HudsonRockDomain,
                        IntelXSearch, LeakCheckPro)  # 증분26: 유출 인텔 심화(메타만)
from .media_c import WebFingerprint
from .web2_c import URLUnshorten, SiteFiles
from .threat_c import ShodanInternetDB, URLScan, CertSpotter
from .enrich_c import PermuteUsernames, EmailInferName, Gravatar, GravatarProfile
from .breach_c import XposedOrNot
from .wmn_c import WhatsMyName
from .recon_c import WaybackCDX, HackerTargetRecon, Psbdmp
from .infra2_c import RIPEstat, OTXPassiveDNS, AnubisSubs, ColumbusSubs, RapidDNS
from .enrich2_c import Nominatim, WikidataEnrich, SECEdgar, GLEIF, OpenPGPKeys
from .threat2_c import FeodoTracker, OpenPhish, BitcoinAddress, ProxyNovaCOMB
from .kali_c import (Subfinder, Assetfinder, Amass, Dnsx, Dnstwist, Gau, Waybackurls,
                     WhatWeb, ExifToolMeta, Nexfil, Mailcat, Zehef)
from .keyed_c import (ShodanFull, HIBP, VirusTotalDomain, GreyNoiseIP, AbuseIPDB,
                      HunterDomain)
from . import mock


def default_collectors(real: bool = True, include_mock: bool = False,
                       enable_darkweb: bool = False) -> list[Collector]:
    out: list[Collector] = []
    if real:
        out += [
            # 표층
            Maigret(), Sherlock(), Blackbird(), WhatsMyName(), Holehe(), TheHarvester(),
            # 소셜·활동
            HackerNews(), GitLab(), WebFinger(),
            Bluesky(), ChessCom(), Lichess(), DevTo(), DockerHub(), Wikipedia(), Codeberg(),
            # 소셜·프로필 확장2(증분24, 무키 공개 API — 실명·위치·교차계정)
            ArtStation(), StackExchange(), WikimediaGlobal(), Steam(), Mixcloud(),
            Launchpad(), CratesIo(), SpeedrunCom(), Lemmy(), Duolingo(), Codewars(), Roblox(),
            # 사람 피벗 enrich(증분24, 한 조각→여러 신원)
            GravatarJSON(), GitHubCommitEmail(), ORCID(), OpenAlex(),
            # SNS/프로필 확장3(증분25, start.me·awesome-osint 무키 공개 API)
            Minecraft(), JikanMAL(), AniList(), Kitsu(), TetrIO(), Scratch(), Discogs(),
            SourceForge(), Hashnode(), Packagist(), Bitbucket(), Telegram(),
            # 학술·전문·명단 피벗(증분25, 이름→저자/소속/제재명단)
            Crossref(), SemanticScholar(), OpenLibrary(), OpenSanctions(),
            # 이메일 품질·IP 위협 보강(증분25, 무키)
            KickboxOpen(), Disify(), IPWhois(), GreyNoiseCommunity(), SANSISC(),
            # 유출 노출(키 없음)
            XposedOrNot(), LeakCheckPublic(), HudsonRock(), XposedAnalytics(),
            # 유출 인텔 심화(증분26 — 유출명→노출항목·도메인 통계, 전부 메타데이터)
            HIBPBreachInfo(), XposedBreachInfo(), HudsonRockDomain(),
            # 선택 키(정식 수사자용 — 키 없으면 skip, 메타데이터만 저장)
            IntelXSearch(), LeakCheckPro(),
            # 전화
            PhoneInfo(), PhoneInfoga(), Ignorant(), Phunter(),
            # 네트워크·IP
            Nmap(), Wayback(), WaybackCDX(), ReverseDNS(), ASNLookup(), IPGeo(),
            HTTPHeaders(), ShodanInternetDB(), HackerTargetRecon(),
            # 인프라
            RDAP(), CrtSh(), CertSpotter(), DNSEnum(), DoHDNS(), URLScan(), Psbdmp(),
            # 개발자·검증 신원
            GitHubDev(), GitHubKeys(), GitHubGists(), NpmMaintainer(), Keybase(),
            # 웹 지문·보강
            WebFingerprint(), URLUnshorten(), SiteFiles(),
            # 능동 확장(순수 코드 위주)
            PermuteUsernames(), EmailInferName(), Gravatar(), GravatarProfile(),
            # 유출(로컬)
            H8mail(),
            # 인프라 심화(키 없는 공개 JSON)
            RIPEstat(), OTXPassiveDNS(), AnubisSubs(), ColumbusSubs(), RapidDNS(),
            # 신원·조직 enrichment(공개 지식/등기)
            Nominatim(), WikidataEnrich(), SECEdgar(), GLEIF(), OpenPGPKeys(),
            # 위협 인텔·암호화폐·자격증명(키 없음)
            FeodoTracker(), OpenPhish(), BitcoinAddress(), ProxyNovaCOMB(),
            # Kali/GitHub CLI 도구(설치 시 동작, 없으면 skip)
            Subfinder(), Assetfinder(), Amass(), Dnsx(), Dnstwist(), Gau(),
            Waybackurls(), WhatWeb(), ExifToolMeta(), Nexfil(), Mailcat(), Zehef(),
            # 선택적 키 수집기(키 있을 때만 활성, 없으면 skip)
            ShodanFull(), HIBP(), VirusTotalDomain(), GreyNoiseIP(), AbuseIPDB(),
            HunterDomain(),
        ]
        if enable_darkweb:
            from ..darkweb.collectors import OnionSearch, Torbot
            out += [OnionSearch(), Torbot()]
    if include_mock:
        out += mock.DEFAULTS
    return out
