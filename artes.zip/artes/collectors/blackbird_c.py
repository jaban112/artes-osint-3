"""blackbird 래퍼 — 아이디·이메일 계정 탐색(키 불필요).

blackbird는 git-clone 도구라 보통 PATH에 없다 → available()=False 로 자동 skip.
설치돼 있으면 JSON 결과를 우선 파싱하고, 없으면 stdout '[+]' 라인을 읽는다.
"""
from __future__ import annotations

import glob
import json
import os
import re
import tempfile

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from .base import Collector, CollectorResult
from .proc import which, run_cmd

_HIT = re.compile(r"\[\+\]\s+(.+?)\s*[:\-]\s*(https?://\S+)")


class Blackbird(Collector):
    name = "blackbird"
    accepts = {EntityType.USERNAME, EntityType.EMAIL}
    timeout = 180.0

    def available(self) -> bool:
        return which("blackbird") is not None

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        res = CollectorResult(source=self.name)
        flag = "--email" if entity_type is EntityType.EMAIL else "-u"
        with tempfile.TemporaryDirectory() as td:
            rc, out, err = await run_cmd(
                ["blackbird", flag, value, "--no-nsfw"], timeout=self.timeout)
            data = self._read_json(td) or self._read_json(os.getcwd())
        src_key = f"{entity_type.value}:{value.lower()}"
        found = []
        if isinstance(data, dict):
            for item in data.get("results", data.get("sites", [])) or []:
                if isinstance(item, dict) and item.get("url"):
                    found.append((item.get("app", item.get("name", "site")), item["url"]))
        if not found:
            for line in out.splitlines():
                m = _HIT.search(line)
                if m:
                    found.append((m.group(1).strip(), m.group(2).strip()))
        if rc != 0 and not found:
            res.ok = False
            res.error = err.strip()[:200] or f"rc={rc}"
            return res
        for site, url in found:
            acc = Entity(EntityType.ACCOUNT, f"{site}/{value}", Certainty.CONFIRMED,
                         evidence=[Evidence(self.name, f"{site}에 '{value}'", url=url)],
                         attrs={"site": site, "url": url})
            res.entities.append(acc)
            res.edges.append(Edge(src_key, acc.key, "가진 계정", Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, "blackbird 확인", url=url)]))
        return res

    @staticmethod
    def _read_json(folder: str) -> dict | None:
        for path in sorted(glob.glob(os.path.join(folder, "**", "*.json"), recursive=True),
                           key=os.path.getmtime, reverse=True):
            try:
                obj = json.loads(open(path, encoding="utf-8").read())
                if isinstance(obj, dict):
                    return obj
            except Exception:
                continue
        return None
