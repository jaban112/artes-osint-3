"""서브프로세스·HTTP 실행 헬퍼 — 비동기, 타임아웃, 실패 안전."""
from __future__ import annotations

import asyncio
import json as _json
import shutil
import urllib.request
import urllib.error


def which(binary: str) -> str | None:
    return shutil.which(binary)


async def run_cmd(cmd: list[str], timeout: float = 30.0,
                  stdin: str | None = None) -> tuple[int, str, str]:
    """(returncode, stdout, stderr). 타임아웃이면 rc=-1, stderr='timeout'."""
    proc = await asyncio.create_subprocess_exec(
        *cmd,
        stdin=asyncio.subprocess.PIPE if stdin is not None else None,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    try:
        out, err = await asyncio.wait_for(
            proc.communicate(stdin.encode() if stdin is not None else None),
            timeout=timeout,
        )
    except asyncio.TimeoutError:
        try:
            proc.kill()
        except ProcessLookupError:
            pass
        await proc.wait()
        return -1, "", "timeout"
    return proc.returncode, out.decode("utf-8", "replace"), err.decode("utf-8", "replace")


def _build_opener(proxy: str | None):
    if not proxy:
        return urllib.request.build_opener()
    if proxy.startswith("socks"):
        try:
            import socks  # PySocks
            from urllib.parse import urlparse as _up
            u = _up(proxy)
            import socket as _s
            socks.set_default_proxy(socks.SOCKS5, u.hostname, u.port or 9050, rdns=True)
            _s.socket = socks.socksocket   # 프로세스 전역(단순화)
            return urllib.request.build_opener()
        except Exception:
            return urllib.request.build_opener()
    return urllib.request.build_opener(
        urllib.request.ProxyHandler({"http": proxy, "https": proxy}))


# 속도 계층(증분 11): 인메모리 TTL 캐시 + 요청 합류(동일 URL in-flight 1회로).
from ..core.adaptive import SingleFlight as _SingleFlight, TTLCache as _TTLCache
_MEMCACHE = _TTLCache(maxsize=8192, ttl=300.0)
_SINGLEFLIGHT = _SingleFlight()

# 속도 대개조(증분 31): httpx 연결풀(keep-alive)+HTTP/2로 매 요청 TCP+TLS 핸드셰이크 제거.
# 선택 의존성 — 없으면 urllib 폴백(기능 동일, 느림). 프록시(Tor) 설정 시엔 프록시-aware urllib 사용.
try:
    import httpx as _httpx
    _HAS_HTTPX = True
    try:
        import h2 as _h2  # noqa: F401  — 있으면 HTTP/2 멀티플렉싱까지
        _HTTP2 = True
    except Exception:
        _HTTP2 = False
except Exception:
    _HAS_HTTPX = False
    _HTTP2 = False

_HX_CLIENT = None
_HX_LOOP = None

# 디스크 캐시(증분36): 스캔 간에도 같은 URL 재조회 0초. 디스크 아끼려 env로 켬(ARTES_DISK_CACHE=1).
import hashlib as _hashlib
import os as _os
from pathlib import Path as _Path
_DISK_ON = _os.environ.get("ARTES_DISK_CACHE") == "1"
_DISK_DIR = _Path.home() / ".artes" / "httpcache"
_DISK_TTL = 86400.0        # 24시간
_DISK_MAX = 262144         # 256KB 초과 응답은 캐시 안 함


def _disk_path(url: str) -> "_Path":
    h = _hashlib.sha256(url.encode("utf-8")).hexdigest()
    return _DISK_DIR / h[:2] / f"{h}.txt"


def _disk_get(url: str):
    if not _DISK_ON:
        return None
    p = _disk_path(url)
    try:
        if p.exists() and (time.time() - p.stat().st_mtime) < _DISK_TTL:
            return p.read_text("utf-8")
    except Exception:
        pass
    return None


def _disk_put(url: str, text: str) -> None:
    if not _DISK_ON or text is None or len(text) > _DISK_MAX:
        return
    try:
        p = _disk_path(url)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text, "utf-8")
    except Exception:
        pass


import time
# 회로차단기(증분34): 반복 실패(도달불가·타임아웃)한 호스트는 잠시 즉시-None 처리 →
# launchpad 등 죽은 호스트를 후보마다 10~45초씩 기다리던 낭비 제거.
import time as _time
_CB: dict[str, list] = {}          # host -> [연속실패수, open_until_ts]
_CB_THRESHOLD = 4                  # 이만큼 연속 실패하면 회로 열림
_CB_COOLDOWN = 90.0               # 열린 회로 유지(초)


def _cb_open(host: str) -> bool:
    st = _CB.get(host)
    return bool(st and st[1] > _time.monotonic())


def _cb_record(host: str, ok: bool) -> None:
    st = _CB.get(host)
    if ok:
        if st:
            _CB[host] = [0, 0.0]
        return
    if not st:
        _CB[host] = [1, 0.0]
    else:
        st[0] += 1
        if st[0] >= _CB_THRESHOLD:
            st[1] = _time.monotonic() + _CB_COOLDOWN     # 회로 열기


def _hx_client():
    """이벤트루프별 공유 AsyncClient(연결 재사용). asyncio.run 새 루프면 재생성."""
    global _HX_CLIENT, _HX_LOOP
    loop = asyncio.get_event_loop()
    if _HX_CLIENT is None or _HX_LOOP is not loop or _HX_CLIENT.is_closed:
        limits = _httpx.Limits(max_connections=512, max_keepalive_connections=128,
                               keepalive_expiry=60.0)
        _HX_CLIENT = _httpx.AsyncClient(http2=_HTTP2, limits=limits, follow_redirects=True,
                                        headers={"User-Agent": "artes/0.1"})
        _HX_LOOP = loop
    return _HX_CLIENT


def _use_httpx() -> bool:
    from ..core.politeness import POLICY
    return _HAS_HTTPX and not getattr(POLICY, "proxies", None)


def _retryable_status(code: int) -> bool:
    """이 HTTP 상태가 '재시도할 가치가 있나'. 429·5xx만 일시 실패로 본다.
    404/403/410 등 4xx는 '확정 부재'(그 사이트에 없음)라 재시도=순수 낭비 → 즉시 종료."""
    return code == 429 or code >= 500


async def _hx_text_cls(url, timeout, headers):
    """분류형 httpx GET. 반환=(텍스트|None, 재시도가치). 부재(4xx)면 재시도 안 함."""
    try:
        r = await _hx_client().get(url, timeout=timeout, headers=headers or {})
        if r.status_code < 400:
            return r.text, False
        return None, _retryable_status(r.status_code)     # 4xx 확정부재→False, 429/5xx→True
    except Exception:
        return None, True                                  # 타임아웃·연결오류=일시→재시도


async def _hx_text(url, timeout, headers):
    txt, _ = await _hx_text_cls(url, timeout, headers)
    return txt


async def _hx_bytes(url, timeout, headers, max_bytes):
    try:
        r = await _hx_client().get(url, timeout=timeout, headers=headers or {})
        return r.content[:max_bytes]
    except Exception:
        return None


async def _hx_post_json(url, body, timeout, headers):
    try:
        r = await _hx_client().post(url, content=body, timeout=timeout, headers=headers or {})
        return r.text
    except Exception:
        return None


async def get_text(url: str, timeout: float = 30.0,
                   headers: dict | None = None, use_memcache: bool = True) -> str | None:
    """비동기 HTTP GET(텍스트). 메모리캐시→합류→(rate-limit+백오프+프록시) 네트워크.

    고정점 반복이 같은 URL을 반복 조회해도 메모리캐시/합류로 네트워크는 1회만.
    """
    if use_memcache:
        cached = _MEMCACHE.get(url)
        if cached is not None:
            return cached if cached != "\x00None" else None
        disk = _disk_get(url)                      # 스캔 간 디스크 캐시(env로 켤 때만)
        if disk is not None:
            _MEMCACHE.put(url, disk)
            return disk

    from ..core.politeness import POLICY, host_of

    host = host_of(url)
    if _cb_open(host):          # 회로차단기: 반복 실패한 호스트는 즉시 None(대기 없음)
        return None

    def _fetch_cls():
        """분류형 urllib GET. 반환=(텍스트|None, 재시도가치)."""
        proxy = POLICY.next_proxy()
        opener = _build_opener(proxy)
        req = urllib.request.Request(url, headers=headers or {"User-Agent": "artes/0.1"})
        try:
            with opener.open(req, timeout=timeout) as r:
                return r.read().decode("utf-8", "replace"), False
        except urllib.error.HTTPError as e:               # 4xx 확정부재→재시도 안 함
            return None, _retryable_status(getattr(e, "code", 0) or 0)
        except Exception:
            return None, True                              # 타임아웃·연결오류=일시

    async def _do():
        await POLICY.limiter.acquire(host)
        loop = asyncio.get_event_loop()
        # 재시도는 '일시 실패'(429/5xx/타임아웃)에만. 확정 부재(404 등)는 즉시 종료 —
        # OSINT는 대상이 대부분 사이트에 '없음'이라, 부재를 3번 재시도하던 게 최대 낭비였다.
        for attempt in range(POLICY.retries + 1):
            if _use_httpx():                               # 연결풀 재사용(빠름)
                text, retryable = await _hx_text_cls(url, timeout, headers)
            else:
                text, retryable = await loop.run_in_executor(None, _fetch_cls)
            if text is not None:
                return text
            if not retryable or attempt >= POLICY.retries:
                return None
            await asyncio.sleep(POLICY.backoff(attempt))
        return None

    result = await _SINGLEFLIGHT.do(url, _do)
    _cb_record(host, result is not None)           # 호스트 성공/실패 기록(회로차단기)
    if result is not None:
        _disk_put(url, result)                     # 성공 응답 디스크 캐시
    if use_memcache:
        _MEMCACHE.put(url, result if result is not None else "\x00None")
    return result


async def get_json(url: str, timeout: float = 30.0, headers: dict | None = None):
    """비동기 HTTP GET(JSON). 실패 시 None."""
    txt = await get_text(url, timeout, headers)
    if txt is None:
        return None
    try:
        return _json.loads(txt)
    except Exception:
        return None


async def post_json(url: str, payload: dict, timeout: float = 20.0,
                    headers: dict | None = None):
    """비동기 HTTP POST(JSON 본문→JSON 응답). 실패 시 None. (Roblox 등 POST API용)"""
    from ..core.politeness import POLICY, host_of, with_retry
    body = _json.dumps(payload).encode("utf-8")
    h = {"Content-Type": "application/json", "User-Agent": "artes/0.1"}
    if headers:
        h.update(headers)

    def _fetch():
        opener = _build_opener(POLICY.next_proxy())
        req = urllib.request.Request(url, data=body, headers=h, method="POST")
        try:
            with opener.open(req, timeout=timeout) as r:
                return r.read().decode("utf-8", "replace")
        except Exception:
            return None

    async def _once():
        if _use_httpx():
            return await _hx_post_json(url, body, timeout, h)
        return await asyncio.get_event_loop().run_in_executor(None, _fetch)
    await POLICY.limiter.acquire(host_of(url))
    txt = await with_retry(_once)
    if not txt:
        return None
    try:
        return _json.loads(txt)
    except Exception:
        return None


async def get_bytes(url: str, timeout: float = 20.0,
                    max_bytes: int = 5_000_000) -> bytes | None:
    """비동기 HTTP GET(바이너리, 이미지 등). 실패 시 None."""
    if _use_httpx():
        return await _hx_bytes(url, timeout, {"User-Agent": "artes/0.1"}, max_bytes)

    def _fetch():
        req = urllib.request.Request(url, headers={"User-Agent": "artes/0.1"})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.read(max_bytes)
        except Exception:
            return None
    return await asyncio.get_event_loop().run_in_executor(None, _fetch)
