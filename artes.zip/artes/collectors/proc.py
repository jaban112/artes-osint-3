"""서브프로세스·HTTP 실행 헬퍼 — 비동기, 타임아웃, 실패 안전."""
from __future__ import annotations

import asyncio
import json as _json
import shutil
import urllib.request


def which(binary: str) -> str | None:
    return shutil.which(binary)


async def run_cmd(cmd: list[str], timeout: float = 30.0,
                  stdin: str | None = None) -> tuple[int, str, str]:
    """(returncode, stdout, stderr). 타임아웃이면 rc=-1, stderr='timeout'."""
    proc = await asyncio.create_subprocess_exec(
        *cmd,
        stdin=asyncio.subprocess.PIPE if stdin is not None else None,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    try:
        out, err = await asyncio.wait_for(
            proc.communicate(stdin.encode() if stdin is not None else None),
            timeout=timeout,
        )
    except asyncio.TimeoutError:
        try:
            proc.kill()
        except ProcessLookupError:
            pass
        await proc.wait()
        return -1, "", "timeout"
    return proc.returncode, out.decode("utf-8", "replace"), err.decode("utf-8", "replace")


def _build_opener(proxy: str | None):
    if not proxy:
        return urllib.request.build_opener()
    if proxy.startswith("socks"):
        try:
            import socks  # PySocks
            from urllib.parse import urlparse as _up
            u = _up(proxy)
            import socket as _s
            socks.set_default_proxy(socks.SOCKS5, u.hostname, u.port or 9050, rdns=True)
            _s.socket = socks.socksocket   # 프로세스 전역(단순화)
            return urllib.request.build_opener()
        except Exception:
            return urllib.request.build_opener()
    return urllib.request.build_opener(
        urllib.request.ProxyHandler({"http": proxy, "https": proxy}))


# 속도 계층(증분 11): 인메모리 TTL 캐시 + 요청 합류(동일 URL in-flight 1회로).
from ..core.adaptive import SingleFlight as _SingleFlight, TTLCache as _TTLCache
_MEMCACHE = _TTLCache(maxsize=8192, ttl=300.0)
_SINGLEFLIGHT = _SingleFlight()

# 속도 대개조(증분 31): httpx 연결풀(keep-alive)+HTTP/2로 매 요청 TCP+TLS 핸드셰이크 제거.
# 선택 의존성 — 없으면 urllib 폴백(기능 동일, 느림). 프록시(Tor) 설정 시엔 프록시-aware urllib 사용.
try:
    import httpx as _httpx
    _HAS_HTTPX = True
    try:
        import h2 as _h2  # noqa: F401  — 있으면 HTTP/2 멀티플렉싱까지
        _HTTP2 = True
    except Exception:
        _HTTP2 = False
except Exception:
    _HAS_HTTPX = False
    _HTTP2 = False

_HX_CLIENT = None
_HX_LOOP = None


def _hx_client():
    """이벤트루프별 공유 AsyncClient(연결 재사용). asyncio.run 새 루프면 재생성."""
    global _HX_CLIENT, _HX_LOOP
    loop = asyncio.get_event_loop()
    if _HX_CLIENT is None or _HX_LOOP is not loop or _HX_CLIENT.is_closed:
        limits = _httpx.Limits(max_connections=256, max_keepalive_connections=64,
                               keepalive_expiry=30.0)
        _HX_CLIENT = _httpx.AsyncClient(http2=_HTTP2, limits=limits, follow_redirects=True,
                                        headers={"User-Agent": "artes/0.1"})
        _HX_LOOP = loop
    return _HX_CLIENT


def _use_httpx() -> bool:
    from ..core.politeness import POLICY
    return _HAS_HTTPX and not getattr(POLICY, "proxies", None)


async def _hx_text(url, timeout, headers):
    try:
        r = await _hx_client().get(url, timeout=timeout, headers=headers or {})
        return r.text
    except Exception:
        return None


async def _hx_bytes(url, timeout, headers, max_bytes):
    try:
        r = await _hx_client().get(url, timeout=timeout, headers=headers or {})
        return r.content[:max_bytes]
    except Exception:
        return None


async def _hx_post_json(url, body, timeout, headers):
    try:
        r = await _hx_client().post(url, content=body, timeout=timeout, headers=headers or {})
        return r.text
    except Exception:
        return None


async def get_text(url: str, timeout: float = 30.0,
                   headers: dict | None = None, use_memcache: bool = True) -> str | None:
    """비동기 HTTP GET(텍스트). 메모리캐시→합류→(rate-limit+백오프+프록시) 네트워크.

    고정점 반복이 같은 URL을 반복 조회해도 메모리캐시/합류로 네트워크는 1회만.
    """
    if use_memcache:
        cached = _MEMCACHE.get(url)
        if cached is not None:
            return cached if cached != "\x00None" else None

    from ..core.politeness import POLICY, host_of, with_retry

    def _fetch():
        proxy = POLICY.next_proxy()
        opener = _build_opener(proxy)
        req = urllib.request.Request(url, headers=headers or {"User-Agent": "artes/0.1"})
        try:
            with opener.open(req, timeout=timeout) as r:
                return r.read().decode("utf-8", "replace")
        except Exception:
            return None

    async def _do():
        await POLICY.limiter.acquire(host_of(url))

        async def _once():
            if _use_httpx():                       # 연결풀 재사용(빠름)
                return await _hx_text(url, timeout, headers)
            return await asyncio.get_event_loop().run_in_executor(None, _fetch)
        return await with_retry(_once)

    result = await _SINGLEFLIGHT.do(url, _do)
    if use_memcache:
        _MEMCACHE.put(url, result if result is not None else "\x00None")
    return result


async def get_json(url: str, timeout: float = 30.0, headers: dict | None = None):
    """비동기 HTTP GET(JSON). 실패 시 None."""
    txt = await get_text(url, timeout, headers)
    if txt is None:
        return None
    try:
        return _json.loads(txt)
    except Exception:
        return None


async def post_json(url: str, payload: dict, timeout: float = 20.0,
                    headers: dict | None = None):
    """비동기 HTTP POST(JSON 본문→JSON 응답). 실패 시 None. (Roblox 등 POST API용)"""
    from ..core.politeness import POLICY, host_of, with_retry
    body = _json.dumps(payload).encode("utf-8")
    h = {"Content-Type": "application/json", "User-Agent": "artes/0.1"}
    if headers:
        h.update(headers)

    def _fetch():
        opener = _build_opener(POLICY.next_proxy())
        req = urllib.request.Request(url, data=body, headers=h, method="POST")
        try:
            with opener.open(req, timeout=timeout) as r:
                return r.read().decode("utf-8", "replace")
        except Exception:
            return None

    async def _once():
        if _use_httpx():
            return await _hx_post_json(url, body, timeout, h)
        return await asyncio.get_event_loop().run_in_executor(None, _fetch)
    await POLICY.limiter.acquire(host_of(url))
    txt = await with_retry(_once)
    if not txt:
        return None
    try:
        return _json.loads(txt)
    except Exception:
        return None


async def get_bytes(url: str, timeout: float = 20.0,
                    max_bytes: int = 5_000_000) -> bytes | None:
    """비동기 HTTP GET(바이너리, 이미지 등). 실패 시 None."""
    if _use_httpx():
        return await _hx_bytes(url, timeout, {"User-Agent": "artes/0.1"}, max_bytes)

    def _fetch():
        req = urllib.request.Request(url, headers={"User-Agent": "artes/0.1"})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.read(max_bytes)
        except Exception:
            return None
    return await asyncio.get_event_loop().run_in_executor(None, _fetch)
