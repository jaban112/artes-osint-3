"""소셜·활동 축 — Reddit·HackerNews·GitLab·WebFinger(페디버스). 키 불필요.

공개 JSON API만 쓴다. 파서 분리로 검증 가능. live 페치는 사용자 VM.
"""
from __future__ import annotations

from datetime import datetime, timezone as _tz

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from .base import Collector, CollectorResult
from .proc import get_json


class Reddit(Collector):
    name = "reddit"
    accepts = {EntityType.USERNAME}
    timeout = 25.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        data = await get_json(f"https://www.reddit.com/user/{value}/about.json", self.timeout,
                              headers={"User-Agent": "artes/0.1"})
        if not data or "data" not in data:
            return CollectorResult(source=self.name, ok=False, error="Reddit 미발견/도달실패")
        return self.parse(data, value)

    def parse(self, data: dict, value: str) -> CollectorResult:
        res = CollectorResult(source=self.name)
        d = data.get("data", {})
        ukey = f"username:{value.lower()}"
        url = f"https://reddit.com/user/{value}"
        created = ""
        if d.get("created_utc"):
            created = datetime.fromtimestamp(d["created_utc"], _tz.utc).date().isoformat()
        acc = Entity(EntityType.ACCOUNT, f"reddit/{value}", Certainty.CONFIRMED,
                     evidence=[Evidence(self.name, f"Reddit 계정(karma {d.get('total_karma','?')})", url=url)],
                     attrs={"site": "reddit", "handle": value, "url": url,
                            "created_at": created,
                            "bio": (d.get("subreddit") or {}).get("public_description", "")})
        res.entities.append(acc)
        res.edges.append(Edge(ukey, acc.key, "가진 계정", Certainty.CONFIRMED,
                              evidence=[Evidence(self.name, "about.json")]))
        return res


class HackerNews(Collector):
    name = "hackernews"
    accepts = {EntityType.USERNAME}
    timeout = 25.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        data = await get_json(f"https://hacker-news.firebaseio.com/v0/user/{value}.json", self.timeout)
        if not data or not data.get("id"):
            return CollectorResult(source=self.name, ok=False, error="HN 미발견")
        return self.parse(data, value)

    def parse(self, data: dict, value: str) -> CollectorResult:
        res = CollectorResult(source=self.name)
        ukey = f"username:{value.lower()}"
        created = ""
        if data.get("created"):
            created = datetime.fromtimestamp(data["created"], _tz.utc).date().isoformat()
        url = f"https://news.ycombinator.com/user?id={value}"
        acc = Entity(EntityType.ACCOUNT, f"hackernews/{value}", Certainty.CONFIRMED,
                     evidence=[Evidence(self.name, f"HN 계정(karma {data.get('karma','?')})", url=url)],
                     attrs={"site": "hackernews", "handle": value, "url": url,
                            "created_at": created, "bio": data.get("about", "")})
        res.entities.append(acc)
        res.edges.append(Edge(ukey, acc.key, "가진 계정", Certainty.CONFIRMED,
                              evidence=[Evidence(self.name, "HN API")]))
        return res


class GitLab(Collector):
    name = "gitlab"
    accepts = {EntityType.USERNAME}
    timeout = 25.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        data = await get_json(f"https://gitlab.com/api/v4/users?username={value}", self.timeout)
        if not data:
            return CollectorResult(source=self.name, ok=False, error="GitLab 미발견/도달실패")
        return self.parse(data, value)

    def parse(self, data, value: str) -> CollectorResult:
        res = CollectorResult(source=self.name)
        ukey = f"username:{value.lower()}"
        users = data if isinstance(data, list) else [data]
        for u in users:
            if not isinstance(u, dict) or not u.get("username"):
                continue
            url = u.get("web_url", f"https://gitlab.com/{value}")
            acc = Entity(EntityType.ACCOUNT, f"gitlab/{u['username']}", Certainty.CONFIRMED,
                         evidence=[Evidence(self.name, "GitLab 공개 프로필", url=url)],
                         attrs={"site": "gitlab", "handle": u["username"], "url": url,
                                "bio": u.get("bio", "")})
            res.entities.append(acc)
            res.edges.append(Edge(ukey, acc.key, "가진 계정", Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, "GitLab API")]))
            if u.get("name"):
                n = Entity(EntityType.NAME, u["name"], Certainty.UNCONFIRMED, 0.6,
                           evidence=[Evidence(self.name, "GitLab 표시 이름")])
                res.entities.append(n)
                res.edges.append(Edge(acc.key, n.key, "표시 이름", Certainty.UNCONFIRMED, 0.6,
                                      evidence=[Evidence(self.name, "프로필")]))
        return res


class WebFinger(Collector):
    """WebFinger(RFC 7033) — 이메일 도메인이 페디버스(Mastodon 등)면 프로필·연결 계정."""
    name = "webfinger"
    accepts = {EntityType.EMAIL}
    timeout = 20.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        domain = value.split("@")[-1]
        data = await get_json(
            f"https://{domain}/.well-known/webfinger?resource=acct:{value}", self.timeout)
        if not data or "links" not in data:
            return CollectorResult(source=self.name, ok=False, error="WebFinger 없음")
        return self.parse(data, value)

    def parse(self, data: dict, value: str) -> CollectorResult:
        res = CollectorResult(source=self.name)
        ekey = f"email:{value.lower()}"
        for link in data.get("links", []):
            href = link.get("href", "")
            rel = link.get("rel", "")
            if rel in ("self", "http://webfinger.net/rel/profile-page") and href.startswith("http"):
                u = Entity(EntityType.URL, href, Certainty.CONFIRMED,
                           evidence=[Evidence(self.name, f"페디버스 프로필({rel})")],
                           attrs={"fediverse": True})
                res.entities.append(u)
                res.edges.append(Edge(ekey, u.key, "페디버스 계정", Certainty.CONFIRMED,
                                      evidence=[Evidence(self.name, "WebFinger")]))
        return res
