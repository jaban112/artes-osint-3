"""인프라 축 — RDAP(WHOIS 후신)·crt.sh 인증서로그·DNS·ASN. 전부 키 불필요.

파싱 로직은 fetch와 분리(parse_* 메서드) — 합성 데이터로 단위검증 가능.
live 조회는 사용자 VM(이 컨테이너는 allowlist).
"""
from __future__ import annotations

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from .base import Collector, CollectorResult
from .proc import get_json


class RDAP(Collector):
    """도메인/IP 등록정보 — rdap.org(JSON, 키 불필요)."""
    name = "rdap"
    accepts = {EntityType.DOMAIN, EntityType.IP}
    timeout = 30.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        kind = "ip" if entity_type is EntityType.IP else "domain"
        data = await get_json(f"https://rdap.org/{kind}/{value}", self.timeout)
        if data is None:
            return CollectorResult(source=self.name, ok=False, error="RDAP 도달 실패")
        return self.parse(data, value, entity_type)

    def parse(self, data: dict, value: str, entity_type) -> CollectorResult:
        res = CollectorResult(source=self.name)
        base = f"{entity_type.value}:{value.lower()}"
        # 등록/생성일
        for ev in (data.get("events") or []):
            if ev.get("eventAction") in ("registration", "last changed", "registered"):
                base_ent = Entity(entity_type, value, Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name,
                                            f"{ev['eventAction']}: {ev.get('eventDate','')}")],
                                  attrs={ev["eventAction"]: ev.get("eventDate", "")})
                res.entities.append(base_ent)
        # 네임서버 → 호스트
        for ns in (data.get("nameservers") or []):
            name = ns.get("ldhName")
            if name:
                h = Entity(EntityType.DOMAIN, name.lower(), Certainty.CONFIRMED,
                           evidence=[Evidence(self.name, "네임서버")])
                res.entities.append(h)
                res.edges.append(Edge(base, h.key, "네임서버", Certainty.CONFIRMED,
                                      evidence=[Evidence(self.name, "RDAP")]))
        # 등록자/연락 이메일(vcard)
        for ent in (data.get("entities") or []):
            for item in self._vcard_items(ent):
                if item[0] == "email" and "@" in item[1]:
                    e = Entity(EntityType.EMAIL, item[1].lower(), Certainty.CONFIRMED,
                               evidence=[Evidence(self.name, "등록 연락 이메일")])
                    res.entities.append(e)
                    res.edges.append(Edge(base, e.key, "등록 연락처",
                                          Certainty.CONFIRMED,
                                          evidence=[Evidence(self.name, "RDAP vcard")]))
                elif item[0] == "org" or item[0] == "fn":
                    res.entities.append(Entity(entity_type, value, Certainty.CONFIRMED,
                        evidence=[Evidence(self.name, f"소유/조직: {item[1]}")],
                        attrs={"org": item[1]}))
        return res

    @staticmethod
    def _vcard_items(entity: dict):
        out = []
        va = entity.get("vcardArray")
        if isinstance(va, list) and len(va) == 2:
            for field in va[1]:
                if isinstance(field, list) and len(field) >= 4:
                    out.append((field[0], str(field[3])))
        return out


class CrtSh(Collector):
    """인증서 투명성 로그 — crt.sh(JSON). 숨은 서브도메인 발굴."""
    name = "crtsh"
    accepts = {EntityType.DOMAIN}
    timeout = 60.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        data = await get_json(f"https://crt.sh/?q=%25.{value}&output=json", self.timeout)
        if data is None:
            return CollectorResult(source=self.name, ok=False, error="crt.sh 도달 실패")
        return self.parse(data, value)

    def parse(self, data: list, value: str) -> CollectorResult:
        res = CollectorResult(source=self.name)
        base = f"domain:{value.lower()}"
        subs = set()
        for row in (data or []):
            for nm in str(row.get("name_value", "")).split("\n"):
                nm = nm.strip().lstrip("*.").lower()
                if nm.endswith(value.lower()) and nm != value.lower():
                    subs.add(nm)
        for sub in sorted(subs):
            s = Entity(EntityType.DOMAIN, sub, Certainty.CONFIRMED,
                       evidence=[Evidence(self.name, "인증서 로그의 서브도메인")])
            res.entities.append(s)
            res.edges.append(Edge(base, s.key, "서브도메인", Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, "crt.sh")]))
        return res


class DNSEnum(Collector):
    """DNS 전 레코드 열거 — dnspython 있으면 A/AAAA/MX/NS/TXT."""
    name = "dns"
    accepts = {EntityType.DOMAIN}
    timeout = 30.0

    def available(self) -> bool:
        try:
            import dns.resolver  # noqa
            return True
        except Exception:
            return False

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        import dns.resolver
        res = CollectorResult(source=self.name)
        base = f"domain:{value.lower()}"
        for rtype in ("A", "AAAA", "MX", "NS", "TXT"):
            try:
                answers = dns.resolver.resolve(value, rtype, lifetime=8)
            except Exception:
                continue
            for a in answers:
                txt = a.to_text().strip('"')
                if rtype in ("A", "AAAA"):
                    ip = Entity(EntityType.IP, txt, Certainty.CONFIRMED,
                                evidence=[Evidence(self.name, f"{rtype} 레코드")])
                    res.entities.append(ip)
                    res.edges.append(Edge(base, ip.key, rtype, Certainty.CONFIRMED,
                                          evidence=[Evidence(self.name, "DNS")]))
                elif rtype in ("MX", "NS"):
                    host = txt.split()[-1].rstrip(".").lower()
                    h = Entity(EntityType.DOMAIN, host, Certainty.CONFIRMED,
                               evidence=[Evidence(self.name, f"{rtype} 레코드")])
                    res.entities.append(h)
                    res.edges.append(Edge(base, h.key, rtype, Certainty.CONFIRMED,
                                          evidence=[Evidence(self.name, "DNS")]))
                else:  # TXT — SPF/DKIM/검증토큰 등 attrs로
                    res.entities.append(Entity(EntityType.DOMAIN, value.lower(),
                        Certainty.CONFIRMED, attrs={"txt": txt[:200]},
                        evidence=[Evidence(self.name, f"TXT: {txt[:80]}")]))
        return res
