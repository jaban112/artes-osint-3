"""이메일 품질·IP 위협 보강(증분 25) — 무키 공개 API. 값 판별·위험 신호만.

이메일: Kickbox open·Disify(일회용/배달가능/역할계정/오타교정). IP: ipwho.is(ASN·ISP·조직)·
GreyNoise community(스캐너/양성 분류)·SANS ISC(공격 신고 수). 전부 무키.
"""
from __future__ import annotations

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from .base import Collector, CollectorResult
from .proc import get_json


class KickboxOpen(Collector):
    """Kickbox open — 이메일 배달가능·일회용·역할계정·오타교정(무키)."""
    name = "kickbox-open"; accepts = {EntityType.EMAIL}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        d = await get_json(f"https://open.kickbox.com/v1/check?email={value}", self.timeout,
                           headers={"User-Agent": "artes/0.1"})
        if not d or "result" not in d:
            return CollectorResult(source=self.name, ok=False, error="Kickbox 무응답")
        return self.parse(d, value)

    def parse(self, d, value):
        res = CollectorResult(source=self.name)
        ek = f"email:{value.lower()}"
        attrs = {"deliverable": d.get("result"), "disposable": d.get("disposable"),
                 "role": d.get("role"), "free": d.get("free"), "mx": d.get("mx_found")}
        res.entities.append(Entity(EntityType.EMAIL, value, Certainty.CONFIRMED,
            evidence=[Evidence(self.name, f"Kickbox: {d.get('result','?')}"
                               f"{' · 일회용' if d.get('disposable') else ''}"
                               f"{' · 역할계정' if d.get('role') else ''}")],
            attrs={k: v for k, v in attrs.items() if v is not None}))
        # 오타 교정 제안 → 대체 이메일 후보
        dym = d.get("did_you_mean")
        if dym and dym.lower() != value.lower():
            res.entities.append(Entity(EntityType.EMAIL, dym, Certainty.UNCONFIRMED, confidence=0.4,
                evidence=[Evidence(self.name, "오타 교정 제안(did_you_mean)")]))
            res.edges.append(Edge(ek, f"email:{dym.lower()}", "오타 교정 후보",
                Certainty.UNCONFIRMED, confidence=0.4, evidence=[Evidence(self.name, "did_you_mean")]))
        return res


class Disify(Collector):
    """Disify — 이메일 형식·DNS·일회용 판별(무키)."""
    name = "disify"; accepts = {EntityType.EMAIL}; timeout = 12.0

    async def collect(self, value, entity_type, ctx):
        d = await get_json(f"https://www.disify.com/api/email/{value}", self.timeout,
                           headers={"User-Agent": "artes/0.1"})
        if not d or "format" not in d:
            return CollectorResult(source=self.name, ok=False, error="Disify 무응답")
        return self.parse(d, value)

    def parse(self, d, value):
        res = CollectorResult(source=self.name)
        res.entities.append(Entity(EntityType.EMAIL, value, Certainty.CONFIRMED,
            evidence=[Evidence(self.name, f"Disify: format={d.get('format')} dns={d.get('dns')}"
                               f"{' · 일회용' if d.get('disposable') else ''}")],
            attrs={"format_ok": d.get("format"), "dns": d.get("dns"),
                   "disposable": d.get("disposable")}))
        return res


class IPWhois(Collector):
    """ipwho.is — IP→국가·도시·ASN·ISP·조직(무키 HTTPS). IPGeo 보강·상관."""
    name = "ipwhois"; accepts = {EntityType.IP}; timeout = 12.0

    async def collect(self, value, entity_type, ctx):
        d = await get_json(f"https://ipwho.is/{value}", self.timeout,
                           headers={"User-Agent": "artes/0.1"})
        if not d or d.get("success") is False:
            return CollectorResult(source=self.name, ok=False, error="ipwho.is 실패")
        return self.parse(d, value)

    def parse(self, d, value):
        res = CollectorResult(source=self.name)
        ipk = f"ip:{value}"
        conn = d.get("connection") or {}
        loc = ", ".join([x for x in (d.get("city"), d.get("region"), d.get("country")) if x])
        if loc:
            res.entities.append(Entity(EntityType.GEO, loc, Certainty.UNCONFIRMED, confidence=0.6,
                evidence=[Evidence(self.name, "ipwho.is 위치")]))
            res.edges.append(Edge(ipk, f"geo:{loc.lower()}", "IP 위치", Certainty.UNCONFIRMED,
                confidence=0.6, evidence=[Evidence(self.name, "geo")]))
        asn = conn.get("asn")
        if asn:
            akey = f"asn:AS{asn}"
            res.entities.append(Entity(EntityType.ASN, f"AS{asn}", Certainty.CONFIRMED,
                evidence=[Evidence(self.name, conn.get("org", "") or conn.get("isp", ""))],
                attrs={"org": conn.get("org", ""), "isp": conn.get("isp", ""),
                       "domain": conn.get("domain", "")}))
            res.edges.append(Edge(ipk, akey, "소속 ASN", Certainty.CONFIRMED,
                evidence=[Evidence(self.name, "connection.asn")]))
        return res


class GreyNoiseCommunity(Collector):
    """GreyNoise community — IP가 인터넷 스캐너/양성인지 분류(무키 커뮤니티)."""
    name = "greynoise-community"; accepts = {EntityType.IP}; timeout = 12.0

    async def collect(self, value, entity_type, ctx):
        d = await get_json(f"https://api.greynoise.io/v3/community/{value}", self.timeout,
                           headers={"User-Agent": "artes/0.1", "Accept": "application/json"})
        if not d or ("noise" not in d and "classification" not in d):
            return CollectorResult(source=self.name, ok=False, error="GreyNoise community 무결과")
        return self.parse(d, value)

    def parse(self, d, value):
        res = CollectorResult(source=self.name)
        ipk = f"ip:{value}"
        cls = d.get("classification", "unknown")
        res.entities.append(Entity(EntityType.IP, value, Certainty.CONFIRMED,
            evidence=[Evidence(self.name, f"GreyNoise: {cls}"
                               f"{' · RIOT(양성 인프라)' if d.get('riot') else ''}"
                               f"{' · 스캐너' if d.get('noise') else ''}",
                               url=d.get("link", ""))],
            attrs={"gn_classification": cls, "gn_noise": d.get("noise"),
                   "gn_riot": d.get("riot"), "gn_name": d.get("name", "")}))
        if cls == "malicious":
            b = Entity(EntityType.MALWARE, f"악성 스캐너: {value}", Certainty.UNCONFIRMED,
                       confidence=0.6, evidence=[Evidence(self.name, "GreyNoise 악성 분류")])
            res.entities.append(b)
            res.edges.append(Edge(ipk, b.key, "위협 분류", Certainty.UNCONFIRMED, confidence=0.6,
                evidence=[Evidence(self.name, "classification=malicious")]))
        return res


class SANSISC(Collector):
    """SANS ISC(DShield) — IP 공격 신고 수·대상 포트(무키 위협 피드)."""
    name = "sans-isc"; accepts = {EntityType.IP}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        d = await get_json(f"https://isc.sans.edu/api/ip/{value}?json", self.timeout,
                           headers={"User-Agent": "artes/0.1"})
        ip = (d or {}).get("ip") or {}
        if not ip:
            return CollectorResult(source=self.name, ok=False, error="SANS ISC 무결과")
        return self.parse(ip, value)

    def parse(self, ip, value):
        res = CollectorResult(source=self.name)
        ipk = f"ip:{value}"
        count = ip.get("count") or ip.get("attacks") or 0
        try:
            count = int(count)
        except (TypeError, ValueError):
            count = 0
        res.entities.append(Entity(EntityType.IP, value, Certainty.CONFIRMED,
            evidence=[Evidence(self.name, f"SANS ISC 공격신고 {count}건")],
            attrs={"isc_reports": count, "isc_asname": ip.get("asname", "")}))
        if count > 0:
            b = Entity(EntityType.MALWARE, f"공격원 신고: {value}", Certainty.UNCONFIRMED,
                       confidence=min(0.4 + count / 1000, 0.9),
                       evidence=[Evidence(self.name, f"DShield {count}건 신고")])
            res.entities.append(b)
            res.edges.append(Edge(ipk, b.key, "공격 신고 이력", Certainty.UNCONFIRMED,
                confidence=min(0.4 + count / 1000, 0.9),
                evidence=[Evidence(self.name, "DShield 피드")]))
        return res
