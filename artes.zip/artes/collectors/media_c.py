"""웹 지문 — 분석/광고 ID·파비콘 해시로 동일 운영자 상관(7권 유사도 계열).

여러 사이트가 같은 Google Analytics/AdSense ID 또는 같은 파비콘을 쓰면 동일 운영자
신호다(강력). 파서 분리(parse_html)로 검증 가능. live 페치는 사용자 VM.
"""
from __future__ import annotations

import hashlib
import re

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from .base import Collector, CollectorResult
from .proc import get_text

_PATTERNS = {
    "GA": re.compile(r"\bUA-\d{4,10}-\d{1,4}\b"),
    "GA4": re.compile(r"\bG-[A-Z0-9]{6,12}\b"),
    "AdSense": re.compile(r"\bca-pub-\d{10,20}\b"),
    "GTM": re.compile(r"\bGTM-[A-Z0-9]{4,10}\b"),
}


class WebFingerprint(Collector):
    name = "webfp"
    accepts = {EntityType.DOMAIN, EntityType.URL}
    timeout = 30.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        url = value if value.startswith("http") else f"https://{value}"
        html = await get_text(url, self.timeout)
        if html is None:
            return CollectorResult(source=self.name, ok=False, error="페이지 도달 실패")
        res = self.parse_html(html, value, entity_type)
        fav = await get_text(url.rstrip("/") + "/favicon.ico", 15)
        if fav:
            self._favicon(res, value, entity_type, fav.encode("utf-8", "replace"))
        return res

    def parse_html(self, html: str, value: str, entity_type=EntityType.DOMAIN) -> CollectorResult:
        res = CollectorResult(source=self.name)
        base = f"{entity_type.value}:{value.lower()}"
        found = set()
        for label, pat in _PATTERNS.items():
            for m in set(pat.findall(html)):
                found.add((label, m))
        for label, tid in sorted(found):
            t = Entity(EntityType.TRACKER, tid, Certainty.CONFIRMED,
                       evidence=[Evidence(self.name, f"{label} 추적 ID")],
                       attrs={"kind": label})
            res.entities.append(t)
            res.edges.append(Edge(base, t.key, "추적 ID", Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, f"{label} 페이지 내")]))
        return res

    def _favicon(self, res, value, entity_type, content: bytes):
        h = hashlib.md5(content).hexdigest()
        base = f"{entity_type.value}:{value.lower()}"
        t = Entity(EntityType.TRACKER, f"favicon:{h}", Certainty.CONFIRMED,
                   evidence=[Evidence(self.name, "파비콘 해시")], attrs={"kind": "favicon"})
        res.entities.append(t)
        res.edges.append(Edge(base, t.key, "파비콘", Certainty.CONFIRMED,
                              evidence=[Evidence(self.name, "favicon.ico md5")]))
