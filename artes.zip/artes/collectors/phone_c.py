"""전화번호 축 수집기 — phoneinfoga·ignorant·phunter (키 불필요).

번호 분해(국가코드/국내번호)는 phonenumbers 라이브러리가 있으면 정확히,
없으면 보수적으로 건너뛴다(잘못 쪼개 잘못된 조회를 하지 않는다).
"""
from __future__ import annotations

import re

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from .base import Collector, CollectorResult
from .proc import which, run_cmd


def _split_number(raw: str):
    """(국가코드, 국내번호) 또는 None. phonenumbers 없으면 None."""
    try:
        import phonenumbers
    except Exception:
        return None
    try:
        num = phonenumbers.parse(raw if raw.strip().startswith("+") else "+" + raw, None)
        if not phonenumbers.is_valid_number(num):
            return None
        return str(num.country_code), str(num.national_number)
    except Exception:
        return None


class PhoneInfoga(Collector):
    name = "phoneinfoga"
    accepts = {EntityType.PHONE}
    timeout = 60.0

    def available(self) -> bool:
        return which("phoneinfoga") is not None

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        res = CollectorResult(source=self.name)
        rc, out, err = await run_cmd(["phoneinfoga", "scan", "-n", value],
                                     timeout=self.timeout)
        if rc != 0 and not out:
            res.ok = False
            res.error = err.strip()[:200] or f"rc={rc}"
            return res
        pkey = f"phone:{_norm(value)}"
        attrs = {}
        for key, pat in (("country", r"Country:\s*(.+)"),
                         ("carrier", r"Carrier:\s*(.+)"),
                         ("local_format", r"Local:\s*(.+)")):
            m = re.search(pat, out)
            if m:
                attrs[key] = m.group(1).strip()
        if attrs:
            ent = res_entity_for_phone(pkey, value, attrs, self.name)
            res.entities.append(ent)
        return res


class Ignorant(Collector):
    name = "ignorant"
    accepts = {EntityType.PHONE}
    timeout = 90.0

    def available(self) -> bool:
        return which("ignorant") is not None and _split_number("+821012345678") is not None

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        res = CollectorResult(source=self.name)
        parts = _split_number(value)
        if not parts:
            res.skipped = True
            res.ok = False
            res.error = "번호 분해 불가(phonenumbers 필요)"
            return res
        cc, national = parts
        rc, out, err = await run_cmd(["ignorant", cc, national], timeout=self.timeout)
        if rc != 0 and not out:
            res.ok = False
            res.error = err.strip()[:200] or f"rc={rc}"
            return res
        pkey = f"phone:{_norm(value)}"
        for line in out.splitlines():
            m = re.match(r"^\[\+\]\s+(\S+)", line.strip())
            if not m:
                continue
            site = m.group(1).rstrip(":")
            acc = Entity(EntityType.ACCOUNT, f"{site}/{value}", Certainty.CONFIRMED,
                         evidence=[Evidence(self.name, f"{site}에 번호 가입")],
                         attrs={"site": site})
            res.entities.append(acc)
            res.edges.append(Edge(pkey, acc.key, "가입 사이트", Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, "ignorant 확인")]))
        return res


class Phunter(Collector):
    name = "phunter"
    accepts = {EntityType.PHONE}
    timeout = 90.0

    def available(self) -> bool:
        return which("phunter") is not None

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        res = CollectorResult(source=self.name)
        rc, out, err = await run_cmd(["phunter", "-t", value], timeout=self.timeout)
        if rc != 0 and not out:
            res.ok = False
            res.error = err.strip()[:200] or f"rc={rc}"
            return res
        pkey = f"phone:{_norm(value)}"
        attrs = {}
        for app in ("whatsapp", "telegram"):
            if re.search(rf"{app}.*(registered|found|yes|✓)", out, re.I):
                attrs[app] = True
        if attrs:
            res.entities.append(res_entity_for_phone(pkey, value, attrs, self.name))
        return res


def _norm(v: str) -> str:
    plus = v.strip().startswith("+")
    d = re.sub(r"\D", "", v)
    return ("+" + d) if plus else d


def res_entity_for_phone(pkey, value, attrs, source) -> Entity:
    return Entity(EntityType.PHONE, value, Certainty.CONFIRMED,
                  evidence=[Evidence(source, "번호 정보: " +
                                     ", ".join(f"{k}={v}" for k, v in attrs.items()))],
                  attrs=attrs)


DEFAULTS = [PhoneInfoga(), Ignorant(), Phunter()]
