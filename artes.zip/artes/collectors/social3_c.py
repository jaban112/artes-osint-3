"""SNS 확장 축(증분 20) — 최신 플랫폼의 '풍부한' 공개 프로필. 키·계정 불필요.

기존 축(maigret·sherlock·WhatsMyName)은 수백 사이트의 '존재 여부'를 본다면, 여기선
공개 API로 실명·bio·검증된 외부링크·팔로워 같은 **실제 당사자 정보**를 공개 소스에서
끌어온다. bio 속 URL과 Mastodon의 rel=me(검증) 링크는 다른 계정/도메인으로의 교차연결이
되어 사람 프로파일을 넓힌다. 전부 공개 엔드포인트 — 로그인·스크래핑 우회 없음.

- Bluesky: public.api.bsky.app getProfile(무인증) — 표시이름·설명·팔로워·게시물수.
- Mastodon: mastodon.social accounts/lookup — 표시이름·bio·검증 필드(rel=me 링크).
- Chess.com: api.chess.com pub/player — 실명·지역·국가(공개 프로필).
파서 분리(parse)로 오프라인 단위검증. live 페치는 사용자 환경.
"""
from __future__ import annotations

import html
import re

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from .base import Collector, CollectorResult
from .proc import get_json

_URL_RE = re.compile(r"https?://[^\s\"'<>)]+", re.I)
_TAG_RE = re.compile(r"<[^>]+>")


def _strip_html(s: str) -> str:
    return html.unescape(_TAG_RE.sub("", s or "")).strip()


def _links_from(*texts) -> list[str]:
    """여러 텍스트에서 URL 추출(중복 제거, 최대 8개)."""
    out = []
    for t in texts:
        for m in _URL_RE.findall(t or ""):
            u = m.rstrip(".,);")
            if u not in out:
                out.append(u)
    return out[:8]


def _link_entities(res: CollectorResult, src_key: str, links: list[str],
                   source: str, certain: bool):
    """bio/검증 링크를 URL 엔티티 + 교차연결 간선으로. certain=검증(rel=me)이면 확실."""
    cert = Certainty.CONFIRMED if certain else Certainty.UNCONFIRMED
    for u in links:
        ent = Entity(EntityType.URL, u, cert,
                     confidence=None if certain else 0.5,
                     evidence=[Evidence(source, "프로필 링크", url=u)])
        res.entities.append(ent)
        res.edges.append(Edge(src_key, ent.key,
                              "검증 링크" if certain else "프로필 링크", cert,
                              confidence=None if certain else 0.5,
                              evidence=[Evidence(source, "rel=me" if certain else "bio/필드")]))


class Bluesky(Collector):
    """Bluesky(AT Protocol) 공개 프로필 — 무인증 AppView."""
    name = "bluesky"
    accepts = {EntityType.USERNAME}
    timeout = 20.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        # 핸들 후보: 그대로, 그리고 도트 없으면 <핸들>.bsky.social
        cands = [value]
        if "." not in value:
            cands.append(f"{value}.bsky.social")
        for actor in cands:
            data = await get_json(
                f"https://public.api.bsky.app/xrpc/app.bsky.actor.getProfile?actor={actor}",
                self.timeout, headers={"User-Agent": "artes/0.1"})
            if data and data.get("did"):
                return self.parse(data, value)
        return CollectorResult(source=self.name, ok=False, error="Bluesky 미발견")

    def parse(self, data: dict, value: str) -> CollectorResult:
        res = CollectorResult(source=self.name)
        ukey = f"username:{value.lower()}"
        handle = data.get("handle", value)
        url = f"https://bsky.app/profile/{handle}"
        bio = data.get("description", "") or ""
        acc = Entity(EntityType.ACCOUNT, f"bluesky/{handle}", Certainty.CONFIRMED,
                     evidence=[Evidence(self.name,
                               f"Bluesky(팔로워 {data.get('followersCount','?')})", url=url)],
                     attrs={"site": "bluesky", "handle": handle, "url": url,
                            "did": data.get("did", ""),
                            "display_name": data.get("displayName", ""),
                            "bio": bio,
                            "followers": data.get("followersCount"),
                            "posts": data.get("postsCount")})
        res.entities.append(acc)
        res.edges.append(Edge(ukey, acc.key, "가진 계정", Certainty.CONFIRMED,
                              evidence=[Evidence(self.name, "getProfile")]))
        # 표시이름이 실명형이면 이름 후보(불확실)
        dn = (data.get("displayName") or "").strip()
        if dn and " " in dn and len(dn) <= 40:
            nm = Entity(EntityType.NAME, dn, Certainty.UNCONFIRMED, confidence=0.4,
                        evidence=[Evidence(self.name, "Bluesky 표시이름")])
            res.entities.append(nm)
            res.edges.append(Edge(acc.key, nm.key, "표시이름", Certainty.UNCONFIRMED,
                                  confidence=0.4, evidence=[Evidence(self.name, "displayName")]))
        _link_entities(res, acc.key, _links_from(bio), self.name, certain=False)
        return res


class Mastodon(Collector):
    """Mastodon(mastodon.social) 공개 계정 — 검증 필드(rel=me)는 확실한 교차연결."""
    name = "mastodon"
    accepts = {EntityType.USERNAME}
    timeout = 20.0
    instance = "mastodon.social"

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        data = await get_json(
            f"https://{self.instance}/api/v1/accounts/lookup?acct={value}",
            self.timeout, headers={"User-Agent": "artes/0.1"})
        if not data or not data.get("id"):
            return CollectorResult(source=self.name, ok=False, error="Mastodon 미발견")
        return self.parse(data, value)

    def parse(self, data: dict, value: str) -> CollectorResult:
        res = CollectorResult(source=self.name)
        ukey = f"username:{value.lower()}"
        url = data.get("url", f"https://{self.instance}/@{value}")
        bio = _strip_html(data.get("note", ""))
        acc = Entity(EntityType.ACCOUNT, f"mastodon/{value}", Certainty.CONFIRMED,
                     evidence=[Evidence(self.name,
                               f"Mastodon(팔로워 {data.get('followers_count','?')})", url=url)],
                     attrs={"site": "mastodon", "handle": value, "url": url,
                            "display_name": data.get("display_name", ""),
                            "bio": bio, "followers": data.get("followers_count")})
        res.entities.append(acc)
        res.edges.append(Edge(ukey, acc.key, "가진 계정", Certainty.CONFIRMED,
                              evidence=[Evidence(self.name, "accounts/lookup")]))
        # 검증 필드(rel=me) → 확실한 교차연결 링크
        verified, plain = [], []
        for f in data.get("fields", []) or []:
            v = f.get("value", "")
            links = _links_from(v)
            if f.get("verified_at"):
                verified += links
            else:
                plain += links
        _link_entities(res, acc.key, verified, self.name, certain=True)
        _link_entities(res, acc.key, plain + _links_from(bio), self.name, certain=False)
        return res


class ChessCom(Collector):
    """Chess.com 공개 프로필 — 실명·지역이 공개된 경우 사람 정보 확장."""
    name = "chesscom"
    accepts = {EntityType.USERNAME}
    timeout = 20.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        data = await get_json(
            f"https://api.chess.com/pub/player/{value.lower()}",
            self.timeout, headers={"User-Agent": "artes/0.1"})
        if not data or not data.get("player_id"):
            return CollectorResult(source=self.name, ok=False, error="Chess.com 미발견")
        return self.parse(data, value)

    def parse(self, data: dict, value: str) -> CollectorResult:
        res = CollectorResult(source=self.name)
        ukey = f"username:{value.lower()}"
        url = data.get("url", f"https://www.chess.com/member/{value}")
        acc = Entity(EntityType.ACCOUNT, f"chesscom/{value.lower()}", Certainty.CONFIRMED,
                     evidence=[Evidence(self.name, "Chess.com 공개 프로필", url=url)],
                     attrs={"site": "chess.com", "handle": value, "url": url,
                            "name": data.get("name", ""),
                            "location": data.get("location", ""),
                            "country": (data.get("country", "") or "").rsplit("/", 1)[-1]})
        res.entities.append(acc)
        res.edges.append(Edge(ukey, acc.key, "가진 계정", Certainty.CONFIRMED,
                              evidence=[Evidence(self.name, "pub/player")]))
        nm = (data.get("name") or "").strip()
        if nm and len(nm) <= 40:
            ne = Entity(EntityType.NAME, nm, Certainty.UNCONFIRMED, confidence=0.4,
                        evidence=[Evidence(self.name, "Chess.com 실명 필드")])
            res.entities.append(ne)
            res.edges.append(Edge(acc.key, ne.key, "이름", Certainty.UNCONFIRMED,
                                  confidence=0.4, evidence=[Evidence(self.name, "name")]))
        loc = (data.get("location") or "").strip()
        if loc and len(loc) <= 60:
            ge = Entity(EntityType.GEO, loc, Certainty.UNCONFIRMED, confidence=0.4,
                        evidence=[Evidence(self.name, "Chess.com 지역")])
            res.entities.append(ge)
            res.edges.append(Edge(acc.key, ge.key, "지역", Certainty.UNCONFIRMED,
                                  confidence=0.4, evidence=[Evidence(self.name, "location")]))
        return res


# ── 증분 23: 추가 공개 API 수집기(전부 무키, 리치 프로필) ──
def _name_geo(res, acc_key, source, name="", loc=""):
    """실명·지역을 엔티티+간선으로(불확실 후보)."""
    name = (name or "").strip()
    if name and len(name) <= 40:
        ne = Entity(EntityType.NAME, name, Certainty.UNCONFIRMED, confidence=0.4,
                    evidence=[Evidence(source, "실명 필드")])
        res.entities.append(ne)
        res.edges.append(Edge(acc_key, ne.key, "이름", Certainty.UNCONFIRMED,
                              confidence=0.4, evidence=[Evidence(source, "name")]))
    loc = (loc or "").strip()
    if loc and len(loc) <= 60:
        ge = Entity(EntityType.GEO, loc, Certainty.UNCONFIRMED, confidence=0.4,
                    evidence=[Evidence(source, "지역")])
        res.entities.append(ge)
        res.edges.append(Edge(acc_key, ge.key, "지역", Certainty.UNCONFIRMED,
                              confidence=0.4, evidence=[Evidence(source, "location")]))


class Lichess(Collector):
    """Lichess 공개 프로필 — bio·국가·검증 링크(무키)."""
    name = "lichess"; accepts = {EntityType.USERNAME}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        d = await get_json(f"https://lichess.org/api/user/{value}", self.timeout,
                           headers={"User-Agent": "artes/0.1"})
        if not d or not d.get("id") or d.get("disabled"):
            return CollectorResult(source=self.name, ok=False, error="Lichess 미발견")
        return self.parse(d, value)

    def parse(self, d, value):
        res = CollectorResult(source=self.name); ukey = f"username:{value.lower()}"
        url = d.get("url", f"https://lichess.org/@/{value}"); prof = d.get("profile") or {}
        acc = Entity(EntityType.ACCOUNT, f"lichess/{d.get('username', value)}", Certainty.CONFIRMED,
                     evidence=[Evidence(self.name, "Lichess 프로필", url=url)],
                     attrs={"site": "lichess", "handle": d.get("username", value), "url": url,
                            "bio": prof.get("bio", "")})
        res.entities.append(acc)
        res.edges.append(Edge(ukey, acc.key, "가진 계정", Certainty.CONFIRMED,
                              evidence=[Evidence(self.name, "api/user")]))
        _name_geo(res, acc.key, self.name, prof.get("realName", ""), prof.get("location", "") or prof.get("country", ""))
        _link_entities(res, acc.key, _links_from(prof.get("links", ""), prof.get("bio", "")), self.name, certain=False)
        return res


class DevTo(Collector):
    """dev.to 공개 프로필 — 실명·위치·트위터/깃허브 교차연결(무키)."""
    name = "devto"; accepts = {EntityType.USERNAME}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        d = await get_json(f"https://dev.to/api/users/by_username?url={value}", self.timeout,
                           headers={"User-Agent": "artes/0.1"})
        if not d or not d.get("id"):
            return CollectorResult(source=self.name, ok=False, error="dev.to 미발견")
        return self.parse(d, value)

    def parse(self, d, value):
        res = CollectorResult(source=self.name); ukey = f"username:{value.lower()}"
        url = f"https://dev.to/{d.get('username', value)}"
        acc = Entity(EntityType.ACCOUNT, f"devto/{d.get('username', value)}", Certainty.CONFIRMED,
                     evidence=[Evidence(self.name, "dev.to 프로필", url=url)],
                     attrs={"site": "dev.to", "handle": d.get("username", value), "url": url,
                            "bio": d.get("summary", "")})
        res.entities.append(acc)
        res.edges.append(Edge(ukey, acc.key, "가진 계정", Certainty.CONFIRMED,
                              evidence=[Evidence(self.name, "api/users")]))
        _name_geo(res, acc.key, self.name, d.get("name", ""), d.get("location", ""))
        for h in (d.get("twitter_username"), d.get("github_username")):
            if h:
                res.entities.append(Entity(EntityType.USERNAME, h, Certainty.CONFIRMED,
                                    evidence=[Evidence(self.name, "dev.to 연결 계정")]))
                res.edges.append(Edge(acc.key, f"username:{h.lower()}", "연결 계정",
                                      Certainty.CONFIRMED, evidence=[Evidence(self.name, "프로필 필드")]))
        if d.get("website_url"):
            _link_entities(res, acc.key, [d["website_url"]], self.name, certain=False)
        return res


class DockerHub(Collector):
    """Docker Hub 공개 프로필 — 실명·회사·위치(무키)."""
    name = "dockerhub"; accepts = {EntityType.USERNAME}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        d = await get_json(f"https://hub.docker.com/v2/users/{value.lower()}/", self.timeout,
                           headers={"User-Agent": "artes/0.1"})
        if not d or not d.get("id"):
            return CollectorResult(source=self.name, ok=False, error="DockerHub 미발견")
        return self.parse(d, value)

    def parse(self, d, value):
        res = CollectorResult(source=self.name); ukey = f"username:{value.lower()}"
        url = f"https://hub.docker.com/u/{d.get('username', value)}"
        acc = Entity(EntityType.ACCOUNT, f"dockerhub/{d.get('username', value)}", Certainty.CONFIRMED,
                     evidence=[Evidence(self.name, "Docker Hub 프로필", url=url)],
                     attrs={"site": "dockerhub", "handle": d.get("username", value), "url": url,
                            "company": d.get("company", "")})
        res.entities.append(acc)
        res.edges.append(Edge(ukey, acc.key, "가진 계정", Certainty.CONFIRMED,
                              evidence=[Evidence(self.name, "v2/users")]))
        _name_geo(res, acc.key, self.name, d.get("full_name", ""), d.get("location", ""))
        return res


class Wikipedia(Collector):
    """Wikipedia(영문) 사용자 — 존재·편집수·가입일(무키). PII 약함, 활동 확인용."""
    name = "wikipedia"; accepts = {EntityType.USERNAME}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        d = await get_json("https://en.wikipedia.org/w/api.php?action=query&list=users"
                           f"&ususers={value}&usprop=editcount|registration|groups&format=json",
                           self.timeout, headers={"User-Agent": "artes/0.1 (osint)"})
        users = ((d or {}).get("query") or {}).get("users") or []
        if not users or "missing" in users[0] or users[0].get("editcount") is None:
            return CollectorResult(source=self.name, ok=False, error="Wikipedia 미발견")
        return self.parse(users[0], value)

    def parse(self, u, value):
        res = CollectorResult(source=self.name); ukey = f"username:{value.lower()}"
        url = f"https://en.wikipedia.org/wiki/User:{value}"
        acc = Entity(EntityType.ACCOUNT, f"wikipedia/{u.get('name', value)}", Certainty.CONFIRMED,
                     evidence=[Evidence(self.name, f"위키백과(편집 {u.get('editcount','?')})", url=url)],
                     attrs={"site": "wikipedia", "handle": u.get("name", value), "url": url,
                            "edits": u.get("editcount"), "registered": u.get("registration", "")})
        res.entities.append(acc)
        res.edges.append(Edge(ukey, acc.key, "가진 계정", Certainty.CONFIRMED,
                              evidence=[Evidence(self.name, "list=users")]))
        return res


class Codeberg(Collector):
    """Codeberg(Gitea) 공개 프로필 — 실명·이메일·위치·웹사이트(무키). 이메일 공개 시 강한 단서."""
    name = "codeberg"; accepts = {EntityType.USERNAME}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        d = await get_json(f"https://codeberg.org/api/v1/users/{value}", self.timeout,
                           headers={"User-Agent": "artes/0.1"})
        if not d or not d.get("id"):
            return CollectorResult(source=self.name, ok=False, error="Codeberg 미발견")
        return self.parse(d, value)

    def parse(self, d, value):
        res = CollectorResult(source=self.name); ukey = f"username:{value.lower()}"
        url = d.get("html_url", f"https://codeberg.org/{value}")
        acc = Entity(EntityType.ACCOUNT, f"codeberg/{d.get('login', value)}", Certainty.CONFIRMED,
                     evidence=[Evidence(self.name, "Codeberg 프로필", url=url)],
                     attrs={"site": "codeberg", "handle": d.get("login", value), "url": url,
                            "bio": d.get("description", "")})
        res.entities.append(acc)
        res.edges.append(Edge(ukey, acc.key, "가진 계정", Certainty.CONFIRMED,
                              evidence=[Evidence(self.name, "api/v1/users")]))
        _name_geo(res, acc.key, self.name, d.get("full_name", ""), d.get("location", ""))
        em = (d.get("email") or "").strip()
        if em and "@" in em:
            res.entities.append(Entity(EntityType.EMAIL, em.lower(), Certainty.CONFIRMED,
                                evidence=[Evidence(self.name, "공개 이메일", url=url)]))
            res.edges.append(Edge(acc.key, f"email:{em.lower()}", "공개 이메일",
                                  Certainty.CONFIRMED, evidence=[Evidence(self.name, "email 필드")]))
        if d.get("website"):
            _link_entities(res, acc.key, [d["website"]], self.name, certain=False)
        return res
