"""gap3 — 팔로워 관계망·게시물(무키 공개 API).

기존 SNS 수집기는 '팔로워 수'만 봤다. 여기선 실제 **누가 팔로우하는지(간선)**·**최근 게시물**을
공개 엔드포인트에서 끌어와 사람↔사람 관계망과 활동을 그린다. 로그인·스크래핑 우회 없음.

- GitHub: /users/{u}/followers·/following(무인증 60/시)·/events/public(활동 저장소).
- Bluesky(AT Protocol): app.bsky.graph.getFollowers/getFollows·app.bsky.feed.getAuthorFeed(무인증 AppView).

정직/안전: 팔로워는 상한(각 50)까지만·비확장(계정 후보 폭발 방지, ACCOUNT로 emit해 자동확장 안 함).
비공개·DM·위치는 안 다룬다. 게시물은 공개 타임라인 원문 링크·스니펫까지.
"""
from __future__ import annotations

import re

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from .base import Collector, CollectorResult
from .proc import get_json

_MAX_EDGE = 50          # 방향별 팔로워/팔로잉 상한
_MAX_POSTS = 25
_POST_URL_RE = re.compile(r"https?://[^\s\"'<>)]+", re.I)


def _acc(res: CollectorResult, site: str, handle: str, avatar: str = "",
         url: str = "") -> str:
    """팔로워/팔로잉 계정을 ACCOUNT 엔티티로 추가(비확장). 반환=키."""
    handle = handle.strip()
    ent = Entity(EntityType.ACCOUNT, f"{site}/{handle}", Certainty.CONFIRMED,
                 evidence=[Evidence("socialgraph", f"{site} 관계망 계정",
                                    url=url or f"https://{site}")],
                 attrs={"site": site, "handle": handle, "url": url,
                        "avatar": avatar, "rel_node": True})   # 관계망 노드 — pHash 대상 아님(속도)
    res.entities.append(ent)
    return ent.key


class GitHubSocial(Collector):
    """GitHub 팔로워/팔로잉 관계망(무키). 사람↔사람 간선."""
    name = "github-social"; accepts = {EntityType.USERNAME}; timeout = 25.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        u = value.strip().lstrip("@")
        hdr = {"User-Agent": "artes/0.1", "Accept": "application/vnd.github+json"}
        followers = await get_json(f"https://api.github.com/users/{u}/followers?per_page={_MAX_EDGE}",
                                   self.timeout, headers=hdr)
        following = await get_json(f"https://api.github.com/users/{u}/following?per_page={_MAX_EDGE}",
                                   self.timeout, headers=hdr)
        if not isinstance(followers, list) and not isinstance(following, list):
            return CollectorResult(source=self.name, ok=False, error="GitHub 관계망 미발견")
        return self.parse(u, followers if isinstance(followers, list) else [],
                          following if isinstance(following, list) else [])

    def parse(self, u: str, followers: list, following: list) -> CollectorResult:
        res = CollectorResult(source=self.name)
        me = f"account:github/{u.lower()}"
        # 대상 계정 자체(간선 앵커)
        res.entities.append(Entity(EntityType.ACCOUNT, f"github/{u}", Certainty.CONFIRMED,
                            evidence=[Evidence(self.name, "GitHub 계정",
                                      url=f"https://github.com/{u}")],
                            attrs={"site": "github", "handle": u,
                                   "url": f"https://github.com/{u}"}))
        for it in (followers or [])[:_MAX_EDGE]:
            login = (it or {}).get("login")
            if not login:
                continue
            k = _acc(res, "github", login, (it or {}).get("avatar_url", ""),
                     (it or {}).get("html_url", ""))
            res.edges.append(Edge(k, me, "팔로워", Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, "followers")]))
        for it in (following or [])[:_MAX_EDGE]:
            login = (it or {}).get("login")
            if not login:
                continue
            k = _acc(res, "github", login, (it or {}).get("avatar_url", ""),
                     (it or {}).get("html_url", ""))
            res.edges.append(Edge(me, k, "팔로잉", Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, "following")]))
        return res


class GitHubActivity(Collector):
    """GitHub 공개 활동 — 최근 기여/작업 저장소(무키). 게시물 대용 활동 신호."""
    name = "github-activity"; accepts = {EntityType.USERNAME}; timeout = 20.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        u = value.strip().lstrip("@")
        d = await get_json(f"https://api.github.com/users/{u}/events/public?per_page=30",
                           self.timeout, headers={"User-Agent": "artes/0.1",
                                                  "Accept": "application/vnd.github+json"})
        if not isinstance(d, list) or not d:
            return CollectorResult(source=self.name, ok=False, error="GitHub 활동 무결과")
        return self.parse(u, d)

    def parse(self, u: str, events: list) -> CollectorResult:
        res = CollectorResult(source=self.name)
        me = f"account:github/{u.lower()}"
        seen = set()
        for ev in events[:30]:
            repo = ((ev or {}).get("repo") or {}).get("name")   # "owner/repo"
            if not repo or repo in seen:
                continue
            seen.add(repo)
            url = f"https://github.com/{repo}"
            res.entities.append(Entity(EntityType.URL, url, Certainty.CONFIRMED,
                                evidence=[Evidence(self.name,
                                          f"GitHub 활동({(ev or {}).get('type','')})", url=url)],
                                attrs={"kind": "activity", "repo": repo,
                                       "ts": (ev or {}).get("created_at", "")}))
            res.edges.append(Edge(me, f"url:{url}", "활동 저장소", Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, "events/public")]))
            if len(seen) >= 20:
                break
        return res


class BlueskyGraph(Collector):
    """Bluesky 팔로워/팔로잉 관계망(무인증 AppView). 사람↔사람 간선."""
    name = "bluesky-graph"; accepts = {EntityType.USERNAME}; timeout = 25.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        actor = value.strip().lstrip("@")
        if "." not in actor:
            actor = f"{actor}.bsky.social"
        base = "https://public.api.bsky.app/xrpc"
        hdr = {"User-Agent": "artes/0.1"}
        fo = await get_json(f"{base}/app.bsky.graph.getFollowers?actor={actor}&limit={_MAX_EDGE}",
                            self.timeout, headers=hdr)
        fg = await get_json(f"{base}/app.bsky.graph.getFollows?actor={actor}&limit={_MAX_EDGE}",
                            self.timeout, headers=hdr)
        fo_l = (fo or {}).get("followers") if isinstance(fo, dict) else None
        fg_l = (fg or {}).get("follows") if isinstance(fg, dict) else None
        if not fo_l and not fg_l:
            return CollectorResult(source=self.name, ok=False, error="Bluesky 관계망 미발견")
        return self.parse(actor, fo_l or [], fg_l or [])

    def parse(self, actor: str, followers: list, follows: list) -> CollectorResult:
        res = CollectorResult(source=self.name)
        me = f"account:bluesky/{actor.lower()}"
        res.entities.append(Entity(EntityType.ACCOUNT, f"bluesky/{actor}", Certainty.CONFIRMED,
                            evidence=[Evidence(self.name, "Bluesky 계정",
                                      url=f"https://bsky.app/profile/{actor}")],
                            attrs={"site": "bluesky", "handle": actor}))
        for it in (followers or [])[:_MAX_EDGE]:
            h = (it or {}).get("handle")
            if not h:
                continue
            k = _acc(res, "bluesky", h, (it or {}).get("avatar", ""),
                     f"https://bsky.app/profile/{h}")
            res.edges.append(Edge(k, me, "팔로워", Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, "getFollowers")]))
        for it in (follows or [])[:_MAX_EDGE]:
            h = (it or {}).get("handle")
            if not h:
                continue
            k = _acc(res, "bluesky", h, (it or {}).get("avatar", ""),
                     f"https://bsky.app/profile/{h}")
            res.edges.append(Edge(me, k, "팔로잉", Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, "getFollows")]))
        return res


class BlueskyFeed(Collector):
    """Bluesky 최근 게시물(무인증 AppView) — 공개 타임라인 원문·링크."""
    name = "bluesky-feed"; accepts = {EntityType.USERNAME}; timeout = 20.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        actor = value.strip().lstrip("@")
        if "." not in actor:
            actor = f"{actor}.bsky.social"
        d = await get_json(
            f"https://public.api.bsky.app/xrpc/app.bsky.feed.getAuthorFeed?actor={actor}&limit={_MAX_POSTS}",
            self.timeout, headers={"User-Agent": "artes/0.1"})
        feed = (d or {}).get("feed") if isinstance(d, dict) else None
        if not feed:
            return CollectorResult(source=self.name, ok=False, error="Bluesky 피드 무결과")
        return self.parse(actor, feed)

    def parse(self, actor: str, feed: list) -> CollectorResult:
        res = CollectorResult(source=self.name)
        me = f"account:bluesky/{actor.lower()}"
        for item in feed[:_MAX_POSTS]:
            post = (item or {}).get("post") or {}
            uri = post.get("uri", "")
            rkey = uri.rsplit("/", 1)[-1] if uri else ""
            if not rkey:
                continue
            rec = post.get("record") or {}
            text = (rec.get("text") or "").strip()
            url = f"https://bsky.app/profile/{actor}/post/{rkey}"
            res.entities.append(Entity(EntityType.URL, url, Certainty.CONFIRMED,
                                evidence=[Evidence(self.name, "Bluesky 게시물", url=url)],
                                attrs={"kind": "post", "text": text[:280],
                                       "ts": rec.get("createdAt", ""),
                                       "likes": post.get("likeCount"),
                                       "reposts": post.get("repostCount")}))
            res.edges.append(Edge(me, f"url:{url}", "게시물", Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, "getAuthorFeed")]))
            # 강화: 본인이 게시물에 직접 올린 외부 링크 = 소유·관심 신호(교차연결 단서)
            for link in _POST_URL_RE.findall(text)[:3]:
                lu = link.rstrip(".,);]")
                if "bsky.app" in lu:
                    continue
                res.entities.append(Entity(EntityType.URL, lu, Certainty.CONFIRMED,
                                    evidence=[Evidence(self.name, "게시물 속 공유 링크", url=lu)],
                                    attrs={"kind": "shared_link"}))
                res.edges.append(Edge(me, f"url:{lu}", "게시물 공유 링크", Certainty.CONFIRMED,
                                      evidence=[Evidence(self.name, "post text")]))
        return res
