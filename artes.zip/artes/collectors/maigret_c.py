"""maigret 래퍼 — 아이디(username)로 계정 탐색(키 불필요).

stdout 정규식 대신 maigret의 JSON 리포트 스키마로 파싱한다(견고).
maigret 상태 enum: CLAIMED(존재)·AVAILABLE(미사용)·UNKNOWN·ILLEGAL.
CLAIMED 만 확실한 계정으로 취한다.
"""
from __future__ import annotations

import glob
import json
import os
import tempfile

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from .base import Collector, CollectorResult
from .proc import which, run_cmd


class Maigret(Collector):
    name = "maigret"
    accepts = {EntityType.USERNAME}
    timeout = 60.0
    max_run = 70.0

    def available(self) -> bool:
        return which("maigret") is not None

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        res = CollectorResult(source=self.name)
        if (ctx or {}).get("depth", 0) > 0:   # 순열/확장엔 대량 스윕 안 돌림(속도)
            res.skipped = True
            res.error = "씨앗 입력 전용(대량 스윕)"
            return res
        with tempfile.TemporaryDirectory() as td:
            rc, out, err = await run_cmd(
                ["maigret", value, "-J", "simple", "-fo", td,
                 "--no-progressbar", "--no-color", "--timeout", "20"],
                timeout=self.timeout,
            )
            data = self._read_report(td)
        if data is None:
            res.ok = False
            res.error = (err or out).strip()[:200] or f"rc={rc}"
            return res
        return self.parse_report(data, value)

    def parse_report(self, data: dict, value: str) -> CollectorResult:
        res = CollectorResult(source=self.name)
        src_key = f"username:{value.lower()}"
        absent, checked = [], 0
        for site, info in data.items():
            if isinstance(info, dict):
                st = str(info.get("status", "")).upper()
                if st in ("CLAIMED", "AVAILABLE"):
                    checked += 1
                if "AVAIL" in st:
                    absent.append(site)
        if checked:
            # 부재 패턴(§6)을 씨앗 아이디에 실어 준다(동일인 해소가 읽음).
            res.entities.append(Entity(
                EntityType.USERNAME, value, Certainty.CONFIRMED,
                evidence=[Evidence(self.name, f"{checked}곳 확인, {len(absent)}곳 부재")],
                attrs={"absent_sites": absent[:200], "checked": checked}))
        for site, info in data.items():
            if not isinstance(info, dict):
                continue
            status = str(info.get("status", "")).upper()
            if "CLAIM" not in status:                 # CLAIMED 만
                continue
            url = info.get("url_user", "") or ""
            acc = Entity(
                type=EntityType.ACCOUNT, value=f"{site}/{value}",
                certainty=Certainty.CONFIRMED,
                evidence=[Evidence(self.name, f"{site}에 '{value}' 계정", url=url)],
                attrs={"site": site, "handle": value, "url": url,
                       "extra": info.get("ids", {})},
            )
            res.entities.append(acc)
            res.edges.append(Edge(src=src_key, dst=acc.key, relation="가진 계정",
                                  certainty=Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, "maigret CLAIMED", url=url)]))
            # 계정에서 나온 부수 식별자(이름·이메일 등)를 확장 씨앗으로.
            for k, v in (info.get("ids", {}) or {}).items():
                self._maybe_seed(res, acc.key, k, v)
        return res

    @staticmethod
    def _read_report(folder: str) -> dict | None:
        cands = glob.glob(os.path.join(folder, "**", "*.json"), recursive=True)
        for path in cands:
            try:
                obj = json.loads(open(path, encoding="utf-8").read())
                if isinstance(obj, dict):
                    return obj
            except Exception:
                continue
        return None

    @staticmethod
    def _maybe_seed(res, src_key, key, val) -> None:
        key = str(key).lower()
        vals = val if isinstance(val, (list, tuple, set)) else [val]
        for v in vals:
            v = str(v).strip()
            if not v:
                continue
            if "email" in key and "@" in v:
                e = Entity(EntityType.EMAIL, v, Certainty.UNCONFIRMED, 0.7,
                           evidence=[Evidence("maigret", f"프로필에서 노출: {v}")])
                res.entities.append(e)
                res.edges.append(Edge(src_key, e.key, "프로필 이메일",
                                      Certainty.UNCONFIRMED, 0.7,
                                      evidence=[Evidence("maigret", "프로필 필드")]))
            elif key in ("fullname", "name") and len(v) <= 60:
                n = Entity(EntityType.NAME, v, Certainty.UNCONFIRMED, 0.6,
                           evidence=[Evidence("maigret", f"프로필 이름: {v}")])
                res.entities.append(n)
                res.edges.append(Edge(src_key, n.key, "프로필 이름",
                                      Certainty.UNCONFIRMED, 0.6,
                                      evidence=[Evidence("maigret", "프로필 필드")]))
