"""SNS/프로필 확장 3(증분 25) — start.me·awesome-osint 정독 후 무키 공개 API 추가.

사용자 제공 컬렉션(start.me Ultimate OSINT·LinkedIn·Reddit)과 병렬 리서치로 검증한
무키·무로그인 공개 프로필 API만. 아이디→실명·위치·가입일·교차계정을 최대한 확장.
GraphQL(POST)은 post_json 사용. 파서 분리로 오프라인 단위검증.
"""
from __future__ import annotations

import re

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from .base import Collector, CollectorResult
from .proc import get_json, post_json, get_text
from .social3_c import _name_geo, _links_from, _link_entities
from .social4_c import _acc, _xlink_username, _dob


class Minecraft(Collector):
    """Mojang — 아이디→UUID(계정 존재·피벗). 무키."""
    name = "minecraft"; accepts = {EntityType.USERNAME}; timeout = 12.0

    async def collect(self, value, entity_type, ctx):
        d = await get_json(f"https://api.mojang.com/users/profiles/minecraft/{value}",
                           self.timeout, headers={"User-Agent": "artes/0.1"})
        if not d or not d.get("id"):
            return CollectorResult(source=self.name, ok=False, error="Minecraft 미발견")
        return self.parse(d, value)

    def parse(self, d, value):
        res = CollectorResult(source=self.name)
        _acc(res, value, "minecraft", d.get("name", value),
             f"https://namemc.com/profile/{d.get('name', value)}", self.name,
             "Minecraft 계정", {"uuid": d.get("id")})
        return res


class JikanMAL(Collector):
    """MyAnimeList(Jikan) — 아이디→위치·가입일·통계(무키). 실명 없음."""
    name = "myanimelist"; accepts = {EntityType.USERNAME}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        d = await get_json(f"https://api.jikan.moe/v4/users/{value}/full", self.timeout,
                           headers={"User-Agent": "artes/0.1"})
        u = (d or {}).get("data") or {}
        if not u.get("username"):
            return CollectorResult(source=self.name, ok=False, error="MAL 미발견")
        return self.parse(u, value)

    def parse(self, u, value):
        res = CollectorResult(source=self.name)
        a = _acc(res, value, "myanimelist", u.get("username", value), u.get("url", ""),
                 self.name, "MyAnimeList 프로필", {"joined": u.get("joined", "")})
        _name_geo(res, a.key, self.name, "", u.get("location", ""))
        _dob(res, a.key, u.get("birthday", "") or "", self.name)
        _link_entities(res, a.key, _links_from(u.get("about", "") or ""), self.name, certain=False)
        return res


class AniList(Collector):
    """AniList — 아이디→표시이름·소개 링크(무키 GraphQL)."""
    name = "anilist"; accepts = {EntityType.USERNAME}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        q = "query($n:String){User(name:$n){id name about siteUrl createdAt}}"
        d = await post_json("https://graphql.anilist.co", {"query": q, "variables": {"n": value}},
                            self.timeout, headers={"User-Agent": "artes/0.1"})
        u = ((d or {}).get("data") or {}).get("User") or {}
        if not u.get("id"):
            return CollectorResult(source=self.name, ok=False, error="AniList 미발견")
        return self.parse(u, value)

    def parse(self, u, value):
        res = CollectorResult(source=self.name)
        a = _acc(res, value, "anilist", u.get("name", value),
                 u.get("siteUrl", f"https://anilist.co/user/{value}"), self.name,
                 "AniList 프로필", {"created": u.get("createdAt")})
        _link_entities(res, a.key, _links_from(u.get("about", "") or ""), self.name, certain=False)
        return res


class Kitsu(Collector):
    """Kitsu — 아이디→이름·위치·가입(무키 JSON:API)."""
    name = "kitsu"; accepts = {EntityType.USERNAME}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        d = await get_json(f"https://kitsu.io/api/edge/users?filter[slug]={value}", self.timeout,
                           headers={"User-Agent": "artes/0.1", "Accept": "application/vnd.api+json"})
        data = (d or {}).get("data") or []
        if not data:
            return CollectorResult(source=self.name, ok=False, error="Kitsu 미발견")
        return self.parse(data[0], value)

    def parse(self, item, value):
        res = CollectorResult(source=self.name)
        attr = item.get("attributes") or {}
        a = _acc(res, value, "kitsu", attr.get("slug", value),
                 f"https://kitsu.io/users/{value}", self.name, "Kitsu 프로필",
                 {"joined": attr.get("createdAt", "")})
        _name_geo(res, a.key, self.name, attr.get("name", ""), attr.get("location", ""))
        _dob(res, a.key, attr.get("birthday", "") or "", self.name)
        _link_entities(res, a.key, _links_from(attr.get("about", "") or ""), self.name, certain=False)
        return res


class TetrIO(Collector):
    """TETR.IO — 아이디→국가·XP·전적(무키)."""
    name = "tetrio"; accepts = {EntityType.USERNAME}; timeout = 12.0

    async def collect(self, value, entity_type, ctx):
        d = await get_json(f"https://ch.tetr.io/api/users/{value.lower()}", self.timeout,
                           headers={"User-Agent": "artes/0.1"})
        u = ((d or {}).get("data") or {}).get("user") or (d or {}).get("data") or {}
        if not u or not u.get("username"):
            return CollectorResult(source=self.name, ok=False, error="TETR.IO 미발견")
        return self.parse(u, value)

    def parse(self, u, value):
        res = CollectorResult(source=self.name)
        a = _acc(res, value, "tetrio", u.get("username", value),
                 f"https://ch.tetr.io/u/{value}", self.name, "TETR.IO 프로필",
                 {"xp": u.get("xp"), "games": u.get("gamesplayed")})
        _name_geo(res, a.key, self.name, "", (u.get("country") or ""))
        return res


class Scratch(Collector):
    """Scratch(MIT) — 아이디→국가·가입·소개(무키 공개 프로필)."""
    name = "scratch"; accepts = {EntityType.USERNAME}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        d = await get_json(f"https://api.scratch.mit.edu/users/{value}", self.timeout,
                           headers={"User-Agent": "artes/0.1"})
        if not d or not d.get("username"):
            return CollectorResult(source=self.name, ok=False, error="Scratch 미발견")
        return self.parse(d, value)

    def parse(self, d, value):
        res = CollectorResult(source=self.name)
        prof = d.get("profile") or {}
        hist = d.get("history") or {}
        a = _acc(res, value, "scratch", d.get("username", value),
                 f"https://scratch.mit.edu/users/{value}", self.name, "Scratch 프로필",
                 {"joined": hist.get("joined", "")})
        _name_geo(res, a.key, self.name, "", prof.get("country", ""))
        _link_entities(res, a.key, _links_from(prof.get("bio", "") or "", prof.get("status", "") or ""),
                       self.name, certain=False)
        return res


class Discogs(Collector):
    """Discogs — 아이디→실명·위치·홈페이지(무키, 음악 커뮤니티)."""
    name = "discogs"; accepts = {EntityType.USERNAME}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        d = await get_json(f"https://api.discogs.com/users/{value}", self.timeout,
                           headers={"User-Agent": "artes/0.1"})
        if not d or not d.get("username"):
            return CollectorResult(source=self.name, ok=False, error="Discogs 미발견")
        return self.parse(d, value)

    def parse(self, d, value):
        res = CollectorResult(source=self.name)
        a = _acc(res, value, "discogs", d.get("username", value),
                 d.get("uri", f"https://www.discogs.com/user/{value}"), self.name,
                 "Discogs 프로필")
        _name_geo(res, a.key, self.name, d.get("name", ""), d.get("location", ""))
        if d.get("home_page"):
            _link_entities(res, a.key, [d["home_page"]], self.name, certain=False)
        return res


class SourceForge(Collector):
    """SourceForge — 아이디→실명·가입·연결 소셜계정(무키). 저평가 피벗."""
    name = "sourceforge"; accepts = {EntityType.USERNAME}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        d = await get_json(f"https://sourceforge.net/rest/u/{value}", self.timeout,
                           headers={"User-Agent": "artes/0.1"})
        if not d or not d.get("username"):
            return CollectorResult(source=self.name, ok=False, error="SourceForge 미발견")
        return self.parse(d, value)

    def parse(self, d, value):
        res = CollectorResult(source=self.name)
        a = _acc(res, value, "sourceforge", d.get("username", value),
                 f"https://sourceforge.net/u/{value}", self.name, "SourceForge 프로필",
                 {"joined": d.get("joined", "")})
        _name_geo(res, a.key, self.name, d.get("name", ""), "")
        socs = [s.get("accounturl") for s in (d.get("socialnetworks") or []) if s.get("accounturl")]
        _link_entities(res, a.key, socs, self.name, certain=False)
        return res


class Hashnode(Collector):
    """Hashnode — 아이디→이름·위치·소셜링크(무키 GraphQL)."""
    name = "hashnode"; accepts = {EntityType.USERNAME}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        q = ("query($u:String!){user(username:$u){name tagline "
             "socialMediaLinks{website github twitter linkedin} location followersCount}}")
        d = await post_json("https://gql.hashnode.com/", {"query": q, "variables": {"u": value}},
                            self.timeout, headers={"User-Agent": "artes/0.1"})
        u = ((d or {}).get("data") or {}).get("user") or {}
        if not u.get("name"):
            return CollectorResult(source=self.name, ok=False, error="Hashnode 미발견")
        return self.parse(u, value)

    def parse(self, u, value):
        res = CollectorResult(source=self.name)
        a = _acc(res, value, "hashnode", value, f"https://hashnode.com/@{value}", self.name,
                 "Hashnode 프로필", {"followers": u.get("followersCount")})
        _name_geo(res, a.key, self.name, u.get("name", ""), u.get("location", ""))
        sml = u.get("socialMediaLinks") or {}
        links = [sml.get(k) for k in ("website", "github", "twitter", "linkedin")]
        _link_entities(res, a.key, [x for x in links if x], self.name, certain=False)
        return res


class Packagist(Collector):
    """Packagist(PHP) — 아이디→패키지·작성자 이메일 단서(무키)."""
    name = "packagist"; accepts = {EntityType.USERNAME}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        d = await get_json(f"https://packagist.org/users/{value}/packages.json", self.timeout,
                           headers={"User-Agent": "artes/0.1"})
        pkgs = (d or {}).get("packages") or []
        if not pkgs:
            return CollectorResult(source=self.name, ok=False, error="Packagist 미발견")
        return self.parse(pkgs, value)

    def parse(self, pkgs, value):
        res = CollectorResult(source=self.name)
        names = [p.get("name") for p in pkgs if p.get("name")][:20]
        _acc(res, value, "packagist", value, f"https://packagist.org/users/{value}/",
             self.name, f"Packagist({len(names)}개 패키지)", {"packages": names})
        return res


class Bitbucket(Collector):
    """Bitbucket — 워크스페이스 공개 저장소·표시이름(무키, 공개 워크스페이스 한정)."""
    name = "bitbucket"; accepts = {EntityType.USERNAME}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        d = await get_json(f"https://api.bitbucket.org/2.0/repositories/{value}?pagelen=5",
                           self.timeout, headers={"User-Agent": "artes/0.1"})
        vals = (d or {}).get("values")
        if vals is None:
            return CollectorResult(source=self.name, ok=False, error="Bitbucket 미발견/비공개")
        return self.parse(d, value)

    def parse(self, d, value):
        res = CollectorResult(source=self.name)
        vals = d.get("values") or []
        owner = (vals[0].get("owner") if vals else {}) or {}
        a = _acc(res, value, "bitbucket", value, f"https://bitbucket.org/{value}/", self.name,
                 f"Bitbucket 워크스페이스({len(vals)}+ 공개 저장소)",
                 {"repos": [r.get("name") for r in vals][:10]})
        _name_geo(res, a.key, self.name, owner.get("display_name", ""), "")
        return res


def _og(html, prop):
    """og:/meta content 추출(가벼운 정규식, 공개 프리뷰 전용)."""
    m = re.search(rf'<meta[^>]+property=["\']{re.escape(prop)}["\'][^>]+content=["\']([^"\']*)["\']', html or "")
    if not m:
        m = re.search(rf'<meta[^>]+name=["\']{re.escape(prop)}["\'][^>]+content=["\']([^"\']*)["\']', html or "")
    return (m.group(1).strip() if m else "")


class Telegram(Collector):
    """Telegram 공개 프리뷰(t.me) — 아이디→표시이름·소개·채널여부(무키·공개 페이지만).

    로그인/봇토큰 없이 텔레그램이 공개로 제공하는 프리뷰 카드만 읽는다. 비공개 계정은 안 나옴.
    """
    name = "telegram"; accepts = {EntityType.USERNAME}; timeout = 12.0

    async def collect(self, value, entity_type, ctx):
        html = await get_text(f"https://t.me/{value}", timeout=self.timeout,
                              headers={"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) artes/1.0"})
        if not html or "tgme_page" not in html and "og:title" not in html:
            return CollectorResult(source=self.name, ok=False, error="Telegram 공개 프리뷰 없음")
        return self.parse(html, value)

    def parse(self, html, value):
        res = CollectorResult(source=self.name)
        title = _og(html, "og:title")
        desc = _og(html, "og:description")
        if not title or title.lower() == "telegram":
            return CollectorResult(source=self.name, ok=False, error="Telegram 미발견")
        is_channel = "subscribers" in (html or "") or "tgme_page_extra" in (html or "")
        a = _acc(res, value, "telegram", value, f"https://t.me/{value}", self.name,
                 "Telegram 공개 프리뷰", {"kind": "channel/group" if is_channel else "user",
                                          "preview": desc[:200]})
        # 표시이름(실명 후보 아님 — 채널명일 수 있어 계정 속성으로만)
        _link_entities(res, a.key, _links_from(desc), self.name, certain=False)
        return res
