"""오타·유사 도메인 수집기 — 생성 후 등록(DNS 해석)된 것만 사칭 의심으로.

생성은 순수 코드, 존재 확인은 DNS 해석(사용자 VM 네트워크). 등록된 lookalike는
피싱/사칭 후보다.
"""
from __future__ import annotations

import asyncio
import socket

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from ..core.typosquat import generate_variants
from .base import Collector, CollectorResult


class Typosquat(Collector):
    name = "typosquat"
    accepts = {EntityType.DOMAIN}
    timeout = 60.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        res = CollectorResult(source=self.name)
        variants = generate_variants(value, max_variants=50)
        loop = asyncio.get_event_loop()

        async def resolves(d):
            try:
                await asyncio.wait_for(
                    loop.run_in_executor(None, socket.gethostbyname, d), timeout=3)
                return d
            except Exception:
                return None

        results = await asyncio.gather(*[resolves(d) for d in variants])
        base = f"domain:{value.lower()}"
        for d in filter(None, results):
            ent = Entity(EntityType.DOMAIN, d, Certainty.UNCONFIRMED, 0.5,
                         evidence=[Evidence(self.name, f"'{value}' 유사·등록됨(사칭 의심)")],
                         attrs={"lookalike_of": value})
            res.entities.append(ent)
            res.edges.append(Edge(base, ent.key, "유사 도메인(사칭 의심)",
                                  Certainty.UNCONFIRMED, 0.5,
                                  evidence=[Evidence(self.name, "오타 생성+DNS 확인")]))
        return res
