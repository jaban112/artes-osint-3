"""인프라 심화 — 키 없는 공개 JSON 엔드포인트(증분 13).

- RIPEstat: IP/ASN → 프리픽스·ASN·홀더·악용신고 연락처·역DNS. 무료·무키.
- OTX passive DNS: 도메인/IP → 과거 호스트↔IP(수동 DNS). 읽기 무키.
- Anubis(jldc)·Columbus: 도메인 → 서브도메인(CT 로그 기반 DB). 무키.
- RapidDNS: 도메인 → 서브도메인, IP → 공존 도메인(역IP 2차 소스). HTML 파싱.

전부 파서 분리로 네트워크 없이 단위검증. 도달 실패 시 우아하게 skip.
"""
from __future__ import annotations

import re

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from .base import Collector, CollectorResult
from .proc import get_json, get_text


class RIPEstat(Collector):
    """RIPEstat network-info + abuse-contact — IP→ASN·프리픽스·악용연락처. 무키."""
    name = "ripestat"
    accepts = {EntityType.IP, EntityType.DOMAIN}
    timeout = 25.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        ni = await get_json(
            f"https://stat.ripe.net/data/network-info/data.json?resource={value}&sourceapp=artes",
            self.timeout)
        ab = await get_json(
            f"https://stat.ripe.net/data/abuse-contact-finder/data.json?resource={value}&sourceapp=artes",
            self.timeout)
        if not ni and not ab:
            return CollectorResult(source=self.name, ok=False, error="RIPEstat 도달 실패")
        return self.parse(ni or {}, ab or {}, value, entity_type)

    def parse(self, ni, ab, value, entity_type) -> CollectorResult:
        res = CollectorResult(source=self.name)
        src = f"{entity_type.value}:{value.lower()}"
        data = ni.get("data", {})
        for asn in (data.get("asns") or []):
            a = Entity(EntityType.ASN, f"AS{asn}", Certainty.CONFIRMED,
                       evidence=[Evidence(self.name, f"{value}의 소속 ASN")])
            res.entities.append(a)
            res.edges.append(Edge(src, a.key, "소속 ASN", Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, "RIPEstat network-info")]))
        pref = data.get("prefix")
        if pref:
            res.entities.append(Entity(EntityType.IP, pref, Certainty.CONFIRMED,
                attrs={"prefix": True}, evidence=[Evidence(self.name, "BGP 프리픽스")]))
        contacts = (ab.get("data", {}).get("abuse_contacts") or [])
        for em in contacts:
            if "@" in em:
                e = Entity(EntityType.EMAIL, em.lower(), Certainty.CONFIRMED,
                           attrs={"role": "abuse"},
                           evidence=[Evidence(self.name, "악용신고 연락처")])
                res.entities.append(e)
                res.edges.append(Edge(src, e.key, "악용신고 연락처", Certainty.CONFIRMED,
                                      evidence=[Evidence(self.name, "RIPEstat abuse-contact")]))
        return res


class OTXPassiveDNS(Collector):
    """AlienVault OTX 수동 DNS — 도메인/IP의 과거 호스트↔IP. 읽기 무키."""
    name = "otx-pdns"
    accepts = {EntityType.DOMAIN, EntityType.IP}
    timeout = 25.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        ind = "IPv4" if entity_type is EntityType.IP else "domain"
        data = await get_json(
            f"https://otx.alienvault.com/api/v1/indicators/{ind}/{value}/passive_dns",
            self.timeout, headers={"User-Agent": "artes/0.1"})
        if not data or "passive_dns" not in data:
            return CollectorResult(source=self.name, ok=False, error="OTX 도달 실패")
        return self.parse(data, value, entity_type)

    def parse(self, data, value, entity_type) -> CollectorResult:
        res = CollectorResult(source=self.name)
        src = f"{entity_type.value}:{value.lower()}"
        seen_h, seen_ip = set(), set()
        for rec in data.get("passive_dns", [])[:200]:
            host = (rec.get("hostname") or "").lower().strip(".")
            ip = rec.get("address") or ""
            if host and host not in seen_h and "." in host:
                seen_h.add(host)
                h = Entity(EntityType.DOMAIN, host, Certainty.CONFIRMED,
                           attrs={"first": rec.get("first"), "last": rec.get("last")},
                           evidence=[Evidence(self.name, "수동 DNS 호스트")])
                res.entities.append(h)
                res.edges.append(Edge(src, h.key, "수동 DNS", Certainty.CONFIRMED,
                                      evidence=[Evidence(self.name, "OTX passive_dns")]))
            if ip and ip not in seen_ip and re.match(r"^\d+\.\d+\.\d+\.\d+$", ip):
                seen_ip.add(ip)
                res.entities.append(Entity(EntityType.IP, ip, Certainty.CONFIRMED,
                    evidence=[Evidence(self.name, "수동 DNS IP")]))
        return res


class AnubisSubs(Collector):
    """jldc/Anubis — 도메인 서브도메인(CT 기반). 무키."""
    name = "anubis"
    accepts = {EntityType.DOMAIN}
    timeout = 20.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        data = await get_json(f"https://jldc.me/anubis/subdomains/{value}", self.timeout)
        if not isinstance(data, list):
            return CollectorResult(source=self.name, ok=False, error="Anubis 도달 실패")
        return self.parse(data, value)

    def parse(self, subs, value) -> CollectorResult:
        res = CollectorResult(source=self.name)
        dkey = f"domain:{value.lower()}"
        for s in subs:
            s = str(s).lower().strip()
            if s and s.endswith(value.lower()) and s != value.lower():
                e = Entity(EntityType.DOMAIN, s, Certainty.CONFIRMED,
                           evidence=[Evidence(self.name, "Anubis 서브도메인")])
                res.entities.append(e)
                res.edges.append(Edge(dkey, e.key, "서브도메인", Certainty.CONFIRMED,
                                      evidence=[Evidence(self.name, "jldc/Anubis")]))
        return res


class ColumbusSubs(Collector):
    """Columbus(elmasy) — 도메인 서브도메인(CT DB). 무키."""
    name = "columbus"
    accepts = {EntityType.DOMAIN}
    timeout = 20.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        data = await get_json(f"https://columbus.elmasy.com/api/lookup/{value}",
                              self.timeout, headers={"User-Agent": "artes/0.1"})
        if not isinstance(data, list):
            return CollectorResult(source=self.name, ok=False, error="Columbus 도달 실패")
        return self.parse(data, value)

    def parse(self, labels, value) -> CollectorResult:
        res = CollectorResult(source=self.name)
        dkey = f"domain:{value.lower()}"
        for lbl in labels:
            full = f"{lbl}.{value}".lower() if lbl else value.lower()
            if full != value.lower():
                e = Entity(EntityType.DOMAIN, full, Certainty.CONFIRMED,
                           evidence=[Evidence(self.name, "Columbus 서브도메인")])
                res.entities.append(e)
                res.edges.append(Edge(dkey, e.key, "서브도메인", Certainty.CONFIRMED,
                                      evidence=[Evidence(self.name, "Columbus")]))
        return res


class RapidDNS(Collector):
    """RapidDNS — 도메인 서브도메인 / IP 공존 도메인. HTML 테이블 파싱, 무키."""
    name = "rapiddns"
    accepts = {EntityType.DOMAIN, EntityType.IP}
    timeout = 25.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        if entity_type is EntityType.IP:
            url = f"https://rapiddns.io/sameip/{value}?full=1"
        else:
            url = f"https://rapiddns.io/subdomain/{value}?full=1"
        html = await get_text(url, self.timeout, headers={"User-Agent": "Mozilla/5.0 artes"})
        if not html:
            return CollectorResult(source=self.name, ok=False, error="RapidDNS 도달 실패")
        return self.parse(html, value, entity_type)

    def parse(self, html, value, entity_type) -> CollectorResult:
        res = CollectorResult(source=self.name)
        src = f"{entity_type.value}:{value.lower()}"
        # 첫 번째 <td> 컬럼(도메인/호스트)만 추출.
        cells = re.findall(r"<td>([^<]+)</td>", html)
        seen = set()
        for c in cells:
            c = c.strip().lower()
            if "." in c and " " not in c and c != value.lower() and c not in seen:
                # 도메인처럼 보이는 것만.
                if re.match(r"^[a-z0-9.\-]+\.[a-z]{2,}$", c):
                    seen.add(c)
                    e = Entity(EntityType.DOMAIN, c, Certainty.CONFIRMED,
                               evidence=[Evidence(self.name, "RapidDNS 결과")])
                    res.entities.append(e)
                    rel = "공존 도메인" if entity_type is EntityType.IP else "서브도메인"
                    res.edges.append(Edge(src, e.key, rel, Certainty.CONFIRMED,
                                          evidence=[Evidence(self.name, "RapidDNS")]))
        return res
