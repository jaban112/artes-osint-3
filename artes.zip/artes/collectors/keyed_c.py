"""선택적 키 수집기 — 키 있으면 유료/제한 소스 개방, 없으면 skip(증분 14).

전부 KeyedCollector 게이트: KEYS.has(service) 일 때만 available(). 키는 요청에만 쓰고
그래프·근거·로그엔 남기지 않는다. 파서 분리로 단위검증.
"""
from __future__ import annotations

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from ..core.keys import KeyedCollector
from .base import Collector, CollectorResult
from .proc import get_json


class ShodanFull(KeyedCollector, Collector):
    """Shodan 정식 API(키) — IP 상세(포트·배너·취약점·조직). InternetDB보다 풍부."""
    name = "shodan"; service = "shodan"
    accepts = {EntityType.IP}; timeout = 25.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        data = await get_json(
            f"https://api.shodan.io/shodan/host/{value}?key={self.api_key()}", self.timeout)
        if not data or "ip_str" not in data:
            return CollectorResult(source=self.name, ok=False, error="Shodan 무결과")
        return self.parse(data, value)

    def parse(self, data, value) -> CollectorResult:
        res = CollectorResult(source=self.name)
        ikey = f"ip:{value.lower()}"
        for port in data.get("ports", []):
            h = Entity(EntityType.HOST, f"{value}:{port}", Certainty.CONFIRMED,
                       attrs={"ip": value, "port": str(port)},
                       evidence=[Evidence(self.name, f"열린 포트 {port}(Shodan)")])
            res.entities.append(h)
            res.edges.append(Edge(ikey, h.key, "열린 포트", Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, "Shodan")]))
        for host in data.get("hostnames", []):
            res.entities.append(Entity(EntityType.DOMAIN, host.lower(), Certainty.CONFIRMED,
                evidence=[Evidence(self.name, "Shodan 호스트명")]))
        if data.get("org"):
            res.entities.append(Entity(EntityType.ORG, data["org"], Certainty.UNCONFIRMED, 0.7,
                attrs={"asn": data.get("asn")}, evidence=[Evidence(self.name, "Shodan 조직")]))
        return res


class HIBP(KeyedCollector, Collector):
    """Have I Been Pwned(키) — 이메일 유출 목록."""
    name = "hibp"; service = "hibp"
    accepts = {EntityType.EMAIL}; timeout = 25.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        data = await get_json(
            f"https://haveibeenpwned.com/api/v3/breachedaccount/{value}?truncateResponse=false",
            self.timeout, headers={"hibp-api-key": self.api_key(), "User-Agent": "artes"})
        if not isinstance(data, list):
            return CollectorResult(source=self.name, ok=False, error="HIBP 무결과")
        return self.parse(data, value)

    def parse(self, data, value) -> CollectorResult:
        res = CollectorResult(source=self.name)
        ekey = f"email:{value.lower()}"
        for br in data:
            name = br.get("Name") or br.get("Title")
            if not name:
                continue
            b = Entity(EntityType.BREACH, str(name), Certainty.CONFIRMED,
                       attrs={"email": value, "date": br.get("BreachDate"),
                              "data_classes": br.get("DataClasses", [])[:10]},
                       evidence=[Evidence(self.name, f"HIBP 유출 {name}")])
            res.entities.append(b)
            res.edges.append(Edge(ekey, b.key, "유출 노출", Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, "HIBP")]))
        return res


class VirusTotalDomain(KeyedCollector, Collector):
    """VirusTotal(키) — 도메인/IP 평판·연관 리졸루션·탐지."""
    name = "virustotal"; service = "virustotal"
    accepts = {EntityType.DOMAIN, EntityType.IP}; timeout = 25.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        kind = "ip_addresses" if entity_type is EntityType.IP else "domains"
        data = await get_json(
            f"https://www.virustotal.com/api/v3/{kind}/{value}",
            self.timeout, headers={"x-apikey": self.api_key()})
        if not data or "data" not in data:
            return CollectorResult(source=self.name, ok=False, error="VT 무결과")
        return self.parse(data, value, entity_type)

    def parse(self, data, value, entity_type) -> CollectorResult:
        res = CollectorResult(source=self.name)
        attrs = data.get("data", {}).get("attributes", {})
        stats = attrs.get("last_analysis_stats", {})
        mal = stats.get("malicious", 0)
        src = f"{entity_type.value}:{value.lower()}"
        if mal:
            m = Entity(EntityType.MALWARE, f"vt/{value}", Certainty.CONFIRMED,
                       attrs={"malicious_votes": mal, "reputation": attrs.get("reputation")},
                       evidence=[Evidence(self.name, f"VT 악성 탐지 {mal}건")])
            res.entities.append(m)
            res.edges.append(Edge(src, m.key, "악성 평판", Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, "VirusTotal")]))
        return res


class GreyNoiseIP(KeyedCollector, Collector):
    """GreyNoise(키) — IP 스캐너/노이즈 분류."""
    name = "greynoise"; service = "greynoise"
    accepts = {EntityType.IP}; timeout = 20.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        data = await get_json(
            f"https://api.greynoise.io/v3/community/{value}",
            self.timeout, headers={"key": self.api_key()})
        if not data or "classification" not in data:
            return CollectorResult(source=self.name, ok=False, error="GreyNoise 무결과")
        return self.parse(data, value)

    def parse(self, data, value) -> CollectorResult:
        res = CollectorResult(source=self.name)
        res.entities.append(Entity(EntityType.IP, value, Certainty.CONFIRMED,
            attrs={"gn_classification": data.get("classification"),
                   "gn_name": data.get("name"), "gn_last_seen": data.get("last_seen")},
            evidence=[Evidence(self.name, f"GreyNoise: {data.get('classification')}")]))
        return res


class AbuseIPDB(KeyedCollector, Collector):
    """AbuseIPDB(키) — IP 악용 신고 점수."""
    name = "abuseipdb"; service = "abuseipdb"
    accepts = {EntityType.IP}; timeout = 20.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        data = await get_json(
            f"https://api.abuseipdb.com/api/v2/check?ipAddress={value}",
            self.timeout, headers={"Key": self.api_key(), "Accept": "application/json"})
        if not data or "data" not in data:
            return CollectorResult(source=self.name, ok=False, error="AbuseIPDB 무결과")
        return self.parse(data, value)

    def parse(self, data, value) -> CollectorResult:
        res = CollectorResult(source=self.name)
        d = data.get("data", {})
        score = d.get("abuseConfidenceScore", 0)
        attrs = {"abuse_score": score, "country": d.get("countryCode"),
                 "isp": d.get("isp"), "total_reports": d.get("totalReports")}
        cert = Certainty.CONFIRMED if score >= 50 else Certainty.UNCONFIRMED
        res.entities.append(Entity(EntityType.IP, value, cert, None if cert is Certainty.CONFIRMED else 0.5,
            attrs=attrs, evidence=[Evidence(self.name, f"AbuseIPDB 점수 {score}")]))
        return res


class HunterDomain(KeyedCollector, Collector):
    """Hunter.io(키) — 도메인 → 이메일·이름·직책."""
    name = "hunter"; service = "hunter"
    accepts = {EntityType.DOMAIN}; timeout = 25.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        data = await get_json(
            f"https://api.hunter.io/v2/domain-search?domain={value}&api_key={self.api_key()}",
            self.timeout)
        if not data or "data" not in data:
            return CollectorResult(source=self.name, ok=False, error="Hunter 무결과")
        return self.parse(data, value)

    def parse(self, data, value) -> CollectorResult:
        res = CollectorResult(source=self.name)
        dkey = f"domain:{value.lower()}"
        for em in data.get("data", {}).get("emails", [])[:50]:
            addr = em.get("value")
            if not addr or "@" not in addr:
                continue
            e = Entity(EntityType.EMAIL, addr.lower(), Certainty.CONFIRMED,
                       evidence=[Evidence(self.name, "Hunter.io 도메인 이메일")])
            res.entities.append(e)
            res.edges.append(Edge(dkey, e.key, "도메인 이메일", Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, "Hunter.io")]))
            nm = " ".join(x for x in (em.get("first_name"), em.get("last_name")) if x)
            if nm:
                n = Entity(EntityType.NAME, nm, Certainty.UNCONFIRMED, 0.6,
                           evidence=[Evidence(self.name, "Hunter.io 이름")])
                res.entities.append(n)
                res.edges.append(Edge(e.key, n.key, "소유자 추정", Certainty.UNCONFIRMED, 0.6,
                                      evidence=[Evidence(self.name, "Hunter.io")]))
        return res
