"""오프라인 목(mock) 수집기 — 테스트·데모용. 네트워크 0, AI 0.

진짜 도구 없이도 엔진·그래프·확장·출력을 end-to-end로 검증할 수 있게 한다.
실제 사람을 조회하지 않는다 — 입력값을 그대로 가공한 합성 결과만 낸다.
"""
from __future__ import annotations

import asyncio
from typing import Any

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from .base import Collector, CollectorResult


class MockAccounts(Collector):
    name = "mock-accounts"
    accepts = {EntityType.USERNAME, EntityType.NAME}
    needs_network = False

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        await asyncio.sleep(0.01)
        res = CollectorResult(source=self.name)
        src_key = f"{entity_type.value}:{value.lower()}"
        for site in ("github", "instagram"):
            acc = Entity(
                type=EntityType.ACCOUNT,
                value=f"{site}/{value}",
                certainty=Certainty.CONFIRMED,
                evidence=[Evidence(self.name, f"{site}에 '{value}' 계정 존재",
                                   url=f"https://{site}.com/{value}")],
                attrs={"site": site, "handle": value},
            )
            res.entities.append(acc)
            res.edges.append(Edge(src=src_key, dst=acc.key, relation="가진 계정",
                                  certainty=Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, "계정 확인")]))
        return res


class MockEmailFacts(Collector):
    name = "mock-email"
    accepts = {EntityType.EMAIL}
    needs_network = False

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        await asyncio.sleep(0.01)
        res = CollectorResult(source=self.name)
        local = value.split("@", 1)[0]
        src_key = f"email:{value.lower()}"
        uname = Entity(
            type=EntityType.USERNAME, value=local,
            certainty=Certainty.UNCONFIRMED, confidence=0.6,
            evidence=[Evidence(self.name, f"이메일 로컬파트에서 추정: {local}")],
        )
        res.entities.append(uname)
        res.edges.append(Edge(src=src_key, dst=uname.key, relation="추정 아이디",
                              certainty=Certainty.UNCONFIRMED, confidence=0.6,
                              evidence=[Evidence(self.name, "로컬파트 = 아이디 추정")]))
        return res


DEFAULTS = [MockAccounts(), MockEmailFacts()]
