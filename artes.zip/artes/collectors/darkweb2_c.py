"""다크웹/딥웹 clearnet 수집(증분 32) — Tor 없이 접근 가능한 무키 다크웹 인텔.

리서치 검증(2026): 다수 다크웹/랜섬웨어 소스가 clearnet API로 무키 접근 가능.
- RansomwareLive v2·RansomLook·ransomwatch: 랜섬웨어 그룹·피해자·유출사이트 게시 메타(공개 인덱스).
- Ahmia(clearnet): .onion 검색 결과(URL·제목) — 다크웹 축(enable_darkweb)에서만, 안전필터 통과.
정직: 전부 '메타/인덱스'까지 — 도난 원문·평문 자격증명·마켓 거래는 다루지 않는다. CSAM 등 불법
콘텐츠는 core.safety.FILTER로 차단(불변). ransomware.live/RansomLook은 Tor 불필요라 기본 축에 포함.
"""
from __future__ import annotations

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from ..core.safety import FILTER
from .base import Collector, CollectorResult
from .proc import get_json, get_text


def _ransom_entity(res, subj_key, victim, group, date, url, source):
    name = f"랜섬웨어 피해 공개: {victim}" + (f" ({group})" if group else "")
    if FILTER.is_blocked(name):
        return
    b = Entity(EntityType.BREACH, name, Certainty.CONFIRMED,
               evidence=[Evidence(source, f"랜섬웨어 유출사이트 게시{(' · ' + date) if date else ''}", url=url or "")],
               attrs={"kind": "ransomware", "group": group, "date": date,
                      "leak_url": url or "", "exposure": True})
    res.entities.append(b)
    res.edges.append(Edge(subj_key, b.key, "랜섬웨어 노출(공개)", Certainty.CONFIRMED,
                          evidence=[Evidence(source, "유출사이트 게시 인덱스")]))


class RansomwareLive(Collector):
    """ransomware.live v2(무키·Tor불필요) — 도메인/조직/이름이 랜섬웨어 피해로 공개됐는지."""
    name = "ransomware-live"; timeout = 20.0
    accepts = {EntityType.DOMAIN, EntityType.ORG, EntityType.NAME}

    async def collect(self, value, entity_type, ctx):
        kw = value.strip()
        d = await get_json(f"https://api.ransomware.live/v2/searchvictims/{kw}", self.timeout,
                           headers={"User-Agent": "artes/1.0"})
        rows = d if isinstance(d, list) else (d or {}).get("victims") if d else None
        if not rows:
            return CollectorResult(source=self.name, ok=False, error="랜섬웨어 피해 없음")
        return self.parse(rows, value)

    def parse(self, rows, value):
        res = CollectorResult(source=self.name)
        subj = f"{__import__('artes.core.types', fromlist=['detect']).detect(value).value}:{value.lower()}"
        for r in (rows or [])[:30]:
            _ransom_entity(res, subj, r.get("victim") or r.get("post_title") or "미상",
                           r.get("group") or r.get("group_name", ""),
                           (r.get("discovered") or r.get("published") or "")[:10],
                           r.get("url") or r.get("website", ""), self.name)
        return res


class RansomLook(Collector):
    """RansomLook.io(무키·Tor불필요) — 랜섬웨어/유출 게시·행위자 검색."""
    name = "ransomlook"; timeout = 20.0
    accepts = {EntityType.DOMAIN, EntityType.ORG, EntityType.NAME}

    async def collect(self, value, entity_type, ctx):
        d = await get_json(f"https://www.ransomlook.io/api/search/{value.strip()}", self.timeout,
                           headers={"User-Agent": "artes/1.0"})
        rows = d if isinstance(d, list) else (d or {}).get("results") if d else None
        if not rows:
            return CollectorResult(source=self.name, ok=False, error="RansomLook 무결과")
        return self.parse(rows, value)

    def parse(self, rows, value):
        res = CollectorResult(source=self.name)
        subj = f"{__import__('artes.core.types', fromlist=['detect']).detect(value).value}:{value.lower()}"
        for r in (rows or [])[:30]:
            _ransom_entity(res, subj, r.get("post_title") or r.get("victim") or r.get("title") or "미상",
                           r.get("group") or r.get("group_name", ""),
                           (r.get("discovered") or r.get("date") or "")[:10],
                           r.get("link") or r.get("url", ""), self.name)
        return res


class Ahmia(Collector):
    """Ahmia clearnet(무키) — .onion 다크웹 검색 결과(URL·제목). 다크웹 축 전용, 안전필터 통과.

    Tor 없이 clearnet에서 .onion 인덱스를 검색. 결과는 참조 URL까지(열람은 Tor 필요). robots·
    레이트리밋 존중을 위해 씨앗 전용·저빈도. CSAM 등은 FILTER로 차단.
    """
    name = "ahmia"; timeout = 20.0; max_run = 25.0
    accepts = {EntityType.NAME, EntityType.EMAIL, EntityType.USERNAME, EntityType.DOMAIN}

    async def collect(self, value, entity_type, ctx):
        if (ctx or {}).get("depth", 0) > 0:
            return CollectorResult(source=self.name, ok=True, skipped=True)
        import urllib.parse
        html = await get_text(f"https://ahmia.fi/search/?q={urllib.parse.quote(value.strip())}",
                              timeout=self.timeout,
                              headers={"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) artes/1.0"})
        if not html or ".onion" not in html:
            return CollectorResult(source=self.name, ok=False, error="Ahmia 무결과/차단")
        return self.parse(html, value, entity_type)

    def parse(self, html, value, entity_type=EntityType.NAME):
        import re
        res = CollectorResult(source=self.name)
        subj = f"{entity_type.value}:{value.lower()}"
        seen = set()
        # Ahmia 결과의 onion 링크(리다이렉트 형태 포함) 추출
        for m in re.finditer(r'(?:redirect_url=)?(https?://[a-z2-7]{16,56}\.onion[^\s"\'<>]*)',
                             html, re.I):
            url = m.group(1)
            if url in seen:
                continue
            seen.add(url)
            if FILTER.is_blocked(url):          # 불법 인디케이터 차단(불변)
                continue
            res.entities.append(Entity(EntityType.URL, url, Certainty.UNCONFIRMED, confidence=0.35,
                                evidence=[Evidence(self.name, "Ahmia 다크웹 검색 결과(.onion)", url=url)],
                                attrs={"darkweb": True, "onion": True}))
            res.edges.append(Edge(subj, f"url:{url}", "다크웹 언급(.onion)", Certainty.UNCONFIRMED,
                                  confidence=0.35, evidence=[Evidence(self.name, "Ahmia")]))
            if len(seen) >= 25:
                break
        if not res.entities:
            return CollectorResult(source=self.name, ok=False, error="Ahmia 유효 결과 없음")
        return res
