"""능동 확장 수집기 — 순열·이름추정·Gravatar. 대부분 순수 코드(AI 0회).

PermuteUsernames는 씨앗(depth 0)에서만 순열을 뿌린다(폭발 방지) — 생성된 변형은
엔진이 maigret·sherlock·holehe로 조회한다(커버리지 몇 배).
"""
from __future__ import annotations

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from ..core.enrich import (username_variants, infer_name_from_email,
                           gravatar_url, gravatar_hash)
from ..core.imagehash import phash_bytes
from .base import Collector, CollectorResult
from .proc import run_cmd, get_bytes, get_json


class PermuteUsernames(Collector):
    name = "username-perms"
    accepts = {EntityType.USERNAME, EntityType.NAME}
    needs_network = False

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        res = CollectorResult(source=self.name)
        if (ctx or {}).get("depth", 0) != 0:        # 씨앗에서만(폭발 방지)
            res.skipped = True
            res.error = "씨앗 아님(순열 미전개)"
            return res
        src_key = f"{entity_type.value}:{value.lower()}"
        for v in username_variants(value):
            if v.lower() == value.lower():
                continue
            u = Entity(EntityType.USERNAME, v, Certainty.UNCONFIRMED, 0.3,
                       evidence=[Evidence(self.name, f"'{value}' 순열 후보")],
                       attrs={"variant": True})
            res.entities.append(u)
            res.edges.append(Edge(src_key, u.key, "아이디 순열",
                                  Certainty.UNCONFIRMED, 0.3,
                                  evidence=[Evidence(self.name, "규칙 기반 생성")]))
        return res


class EmailInferName(Collector):
    name = "email-name"
    accepts = {EntityType.EMAIL}
    needs_network = False

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        res = CollectorResult(source=self.name)
        local = value.split("@", 1)[0]
        name = infer_name_from_email(local)
        if name:
            n = Entity(EntityType.NAME, name, Certainty.UNCONFIRMED, 0.4,
                       evidence=[Evidence(self.name, f"이메일 로컬파트에서 추정: {name}")])
            res.entities.append(n)
            res.edges.append(Edge(f"email:{value.lower()}", n.key, "추정 이름",
                                  Certainty.UNCONFIRMED, 0.4,
                                  evidence=[Evidence(self.name, "로컬파트 역산")]))
        return res


class Gravatar(Collector):
    name = "gravatar"
    accepts = {EntityType.EMAIL}
    needs_network = True
    timeout = 20.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        res = CollectorResult(source=self.name)
        url = gravatar_url(value)
        # d=404: 그라바타 없으면 404. curl HEAD로 확인(네트워크 되면).
        rc, out, err = await run_cmd(
            ["curl", "-s", "-o", "/dev/null", "-w", "%{http_code}", "-I", "-m", "10", url],
            timeout=self.timeout)
        code = (out or "").strip()
        ekey = f"email:{value.lower()}"
        if code == "200":
            h = gravatar_hash(value)
            img_url = f"https://www.gravatar.com/avatar/{h}?s=256"
            attrs = {"site": "gravatar", "avatar_url": img_url}
            data = await get_bytes(img_url)             # 아바타 받아 지각해시+얼굴
            if data:
                ph = phash_bytes(data)
                if ph:
                    attrs["image_phash"] = ph            # 같은 사진=동일인 신호
                from ..core.face import encode as _face_encode
                fe = _face_encode(data)                  # 얼굴 임베딩(모델 있을 때)
                if fe:
                    attrs["face_encoding"] = fe
            acc = Entity(EntityType.ACCOUNT, f"gravatar/{h}", Certainty.CONFIRMED,
                         evidence=[Evidence(self.name, "Gravatar 아바타 존재", url=img_url)],
                         attrs=attrs)
            res.entities.append(acc)
            res.edges.append(Edge(ekey, acc.key, "Gravatar", Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, "HTTP 200", url=img_url)]))
        elif code != "404":                          # 네트워크 불가 등 → 미확인 URL만
            res.skipped = True
            res.error = f"확인 불가(code={code or 'net'})"
        return res


class GravatarProfile(Collector):
    """Gravatar 프로필 JSON — 검증된 연결 계정·이름·URL(이메일→다중 신원). 키 불필요."""
    name = "gravatar-profile"
    accepts = {EntityType.EMAIL}
    timeout = 20.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        data = await get_json(f"https://www.gravatar.com/{gravatar_hash(value)}.json",
                              self.timeout, headers={"User-Agent": "artes/0.1"})
        if not data or "entry" not in data:
            return CollectorResult(source=self.name, ok=False, error="Gravatar 프로필 없음")
        return self.parse(data, value)

    def parse(self, data: dict, value: str) -> CollectorResult:
        res = CollectorResult(source=self.name)
        ekey = f"email:{value.lower()}"
        for entry in data.get("entry", []):
            disp = entry.get("displayName") or (entry.get("name") or {}).get("formatted")
            if disp:
                n = Entity(EntityType.NAME, disp, Certainty.UNCONFIRMED, 0.7,
                           evidence=[Evidence(self.name, "Gravatar 표시 이름")])
                res.entities.append(n)
                res.edges.append(Edge(ekey, n.key, "표시 이름", Certainty.UNCONFIRMED, 0.7,
                                      evidence=[Evidence(self.name, "프로필")]))
            for acc in entry.get("accounts", []):
                svc = acc.get("shortname") or acc.get("domain", "?")
                handle = acc.get("username") or acc.get("display", "")
                url = acc.get("url", "")
                verified = str(acc.get("verified", "")).lower() == "true"
                cert = Certainty.CONFIRMED if verified else Certainty.UNCONFIRMED
                a = Entity(EntityType.ACCOUNT, f"{svc}/{handle}", cert,
                           None if verified else 0.6,
                           evidence=[Evidence(self.name,
                                     f"Gravatar 연결 {svc}" + (" (검증)" if verified else ""), url=url)],
                           attrs={"site": svc, "handle": handle, "url": url, "verified": verified})
                res.entities.append(a)
                res.edges.append(Edge(ekey, a.key,
                                      "검증된 연결" if verified else "연결 계정",
                                      cert, None if verified else 0.6,
                                      evidence=[Evidence(self.name, "Gravatar accounts")]))
        return res
