"""theHarvester 래퍼 — 도메인에서 이메일·호스트 수집(키 없는 소스만)."""
from __future__ import annotations

import json
import os
import tempfile
from typing import Any

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from .base import Collector, CollectorResult
from .proc import which, run_cmd

# 키/계정 필요 없는 공개 소스만.
_SOURCES = "crtsh,duckduckgo,bing,certspotter,hackertarget,rapiddns,anubis,threatminer"


class TheHarvester(Collector):
    name = "theHarvester"
    accepts = {EntityType.DOMAIN}
    timeout = 180.0

    def available(self) -> bool:
        return which("theHarvester") is not None

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        res = CollectorResult(source=self.name)
        with tempfile.TemporaryDirectory() as td:
            base = os.path.join(td, "out")
            rc, out, err = await run_cmd(
                ["theHarvester", "-d", value, "-b", _SOURCES, "-f", base],
                timeout=self.timeout,
            )
            data = self._read_json(base)
        if data is None:
            res.ok = False
            res.error = (err or out).strip()[:200] or f"rc={rc}"
            return res
        dkey = f"domain:{value.lower()}"
        for email in sorted(set(data.get("emails", []) or [])):
            e = Entity(type=EntityType.EMAIL, value=email,
                       certainty=Certainty.CONFIRMED,
                       evidence=[Evidence(self.name, f"{value} 도메인에서 발견")])
            res.entities.append(e)
            res.edges.append(Edge(src=dkey, dst=e.key, relation="도메인 이메일",
                                  certainty=Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, "theHarvester 수집")]))
        for host in sorted(set(data.get("hosts", []) or [])):
            hostname = host.split(":")[0]
            h = Entity(type=EntityType.HOST, value=hostname,
                       certainty=Certainty.CONFIRMED,
                       evidence=[Evidence(self.name, f"{value} 하위 호스트")])
            res.entities.append(h)
            res.edges.append(Edge(src=dkey, dst=h.key, relation="하위 호스트",
                                  certainty=Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, "theHarvester 수집")]))
        return res

    @staticmethod
    def _read_json(base: str) -> dict | None:
        for path in (base + ".json", base):
            if os.path.exists(path):
                try:
                    return json.loads(open(path, encoding="utf-8").read())
                except Exception:
                    continue
        return None
