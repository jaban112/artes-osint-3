"""신원·조직 enrichment — 키 없는 공개 지식/등기 API(증분 13).

- Nominatim: 지명 → 좌표·주소(OSM). GPS 역지오코딩. 무키(UA 필수, 1req/s).
- Wikidata/Wikipedia: 이름/조직 → 구조화 사실(별칭·생일·고용주·공식사이트·핸들). 무키.
- SEC EDGAR: 회사명 → CIK·공시. 무키(UA 필수).
- GLEIF LEI: 법인명 → LEI·주소·모/자회사(소유 그래프). 무키.
- keys.openpgp.org: 이메일 → PGP 키·실명 UID·연결 이메일. 순수 HTTP 무키.

파서 분리로 단위검증. 실패 시 우아하게 skip.
"""
from __future__ import annotations

import re

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from .base import Collector, CollectorResult
from .proc import get_json, get_text

_UA = {"User-Agent": "artes-osint/0.1 (research; contact via github)"}


class Nominatim(Collector):
    """OSM Nominatim — 지명 → 좌표·주소. 무키(UA 필수)."""
    name = "nominatim"
    accepts = {EntityType.GEO}
    timeout = 20.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        data = await get_json(
            f"https://nominatim.openstreetmap.org/search?q={value}&format=jsonv2&limit=3",
            self.timeout, headers=_UA)
        if not isinstance(data, list) or not data:
            return CollectorResult(source=self.name, ok=False, error="Nominatim 무결과")
        return self.parse(data, value)

    def parse(self, data, value) -> CollectorResult:
        res = CollectorResult(source=self.name)
        top = data[0]
        res.entities.append(Entity(EntityType.GEO, value, Certainty.CONFIRMED,
            attrs={"lat": top.get("lat"), "lon": top.get("lon"),
                   "display_name": top.get("display_name"),
                   "osm_type": top.get("osm_type")},
            evidence=[Evidence(self.name, top.get("display_name", ""),
                      url=f"https://www.openstreetmap.org/{top.get('osm_type','')}/{top.get('osm_id','')}")]))
        return res


class WikidataEnrich(Collector):
    """Wikidata/Wikipedia — 이름/조직 → 구조화 사실. 무키."""
    name = "wikidata"
    accepts = {EntityType.NAME, EntityType.ORG}
    timeout = 20.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        srch = await get_json(
            "https://www.wikidata.org/w/api.php?action=wbsearchentities&format=json"
            f"&language=en&limit=1&search={value}", self.timeout, headers=_UA)
        hits = (srch or {}).get("search") or []
        if not hits:
            return CollectorResult(source=self.name, ok=False, error="Wikidata 무결과")
        qid = hits[0]["id"]
        ent = await get_json(
            f"https://www.wikidata.org/wiki/Special:EntityData/{qid}.json",
            self.timeout, headers=_UA)
        return self.parse(hits[0], ent or {}, value, entity_type, qid)

    def parse(self, hit, ent, value, entity_type, qid) -> CollectorResult:
        res = CollectorResult(source=self.name)
        src = f"{entity_type.value}:{value.lower()}"
        desc = hit.get("description", "")
        node = Entity(entity_type, value, Certainty.UNCONFIRMED, 0.6,
                      attrs={"wikidata": qid, "description": desc,
                             "label": hit.get("label")},
                      evidence=[Evidence(self.name, f"Wikidata {qid}: {desc}",
                                url=f"https://www.wikidata.org/wiki/{qid}")])
        res.entities.append(node)
        # 공식 사이트(P856)·트위터(P2002)·깃허브(P2037) 등 셀렉터 추출.
        claims = (ent.get("entities", {}).get(qid, {}) or {}).get("claims", {})
        prop_map = {"P856": ("url", EntityType.URL, "공식 사이트"),
                    "P2002": ("username", EntityType.ACCOUNT, "twitter"),
                    "P2037": ("username", EntityType.ACCOUNT, "github")}
        for pid, (_kind, etype, label) in prop_map.items():
            for claim in claims.get(pid, [])[:3]:
                try:
                    val = claim["mainsnak"]["datavalue"]["value"]
                except (KeyError, TypeError):
                    continue
                if etype is EntityType.URL:
                    e = Entity(EntityType.URL, str(val), Certainty.CONFIRMED,
                               evidence=[Evidence(self.name, "Wikidata 공식 사이트")])
                else:
                    e = Entity(EntityType.ACCOUNT, f"{label}/{val}", Certainty.CONFIRMED,
                               attrs={"site": label, "handle": str(val)},
                               evidence=[Evidence(self.name, f"Wikidata 연결 {label}")])
                res.entities.append(e)
                res.edges.append(Edge(src, e.key, label, Certainty.CONFIRMED,
                                      evidence=[Evidence(self.name, "Wikidata claim")]))
        return res


class SECEdgar(Collector):
    """SEC EDGAR — 회사명 → CIK·공시. 무키(UA 필수)."""
    name = "sec-edgar"
    accepts = {EntityType.ORG}
    timeout = 25.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        data = await get_json(
            f"https://efts.sec.gov/LATEST/search-index?q=%22{value}%22",
            self.timeout, headers=_UA)
        # 대체: 회사 티커 매핑 파일에서 이름 매칭.
        if not data:
            tickers = await get_json("https://www.sec.gov/files/company_tickers.json",
                                     self.timeout, headers=_UA)
            if tickers:
                return self.parse_tickers(tickers, value)
            return CollectorResult(source=self.name, ok=False, error="EDGAR 도달 실패")
        return self.parse_tickers({}, value)

    def parse_tickers(self, tickers, value) -> CollectorResult:
        res = CollectorResult(source=self.name)
        vl = value.lower()
        for row in (tickers.values() if isinstance(tickers, dict) else []):
            title = str(row.get("title", "")).lower()
            if vl in title or title in vl:
                cik = str(row.get("cik_str", "")).zfill(10)
                res.entities.append(Entity(EntityType.ORG, row.get("title", value),
                    Certainty.CONFIRMED,
                    attrs={"cik": cik, "ticker": row.get("ticker")},
                    evidence=[Evidence(self.name, f"SEC 등록사 CIK {cik}",
                              url=f"https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK={cik}")]))
                if len(res.entities) >= 5:
                    break
        if not res.entities:
            res.ok = False
            res.error = "SEC 매칭 없음"
        return res


class GLEIF(Collector):
    """GLEIF LEI — 법인명 → LEI·주소·모/자회사. 무키."""
    name = "gleif"
    accepts = {EntityType.ORG}
    timeout = 25.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        data = await get_json(
            f"https://api.gleif.org/api/v1/lei-records?filter[entity.legalName]={value}&page[size]=3",
            self.timeout, headers=_UA)
        if not data or "data" not in data:
            return CollectorResult(source=self.name, ok=False, error="GLEIF 도달 실패")
        return self.parse(data, value)

    def parse(self, data, value) -> CollectorResult:
        res = CollectorResult(source=self.name)
        for rec in data.get("data", [])[:3]:
            attrs = rec.get("attributes", {})
            ent = attrs.get("entity", {})
            lei = attrs.get("lei") or rec.get("id")
            legal = ent.get("legalName", {}).get("name", value)
            addr = ent.get("legalAddress", {})
            res.entities.append(Entity(EntityType.ORG, legal, Certainty.CONFIRMED,
                attrs={"lei": lei, "country": addr.get("country"),
                       "city": addr.get("city"), "status": ent.get("status")},
                evidence=[Evidence(self.name, f"GLEIF LEI {lei}",
                          url=f"https://search.gleif.org/#/record/{lei}")]))
        return res


class OpenPGPKeys(Collector):
    """keys.openpgp.org VKS — 이메일 → PGP 키·실명 UID. 순수 HTTP 무키."""
    name = "openpgp"
    accepts = {EntityType.EMAIL}
    timeout = 20.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        armored = await get_text(
            f"https://keys.openpgp.org/vks/v1/by-email/{value}",
            self.timeout, headers={"User-Agent": "artes/0.1"})
        if not armored or "BEGIN PGP" not in armored:
            return CollectorResult(source=self.name, ok=False, error="PGP 키 없음")
        return self.parse(armored, value)

    def parse(self, armored, value) -> CollectorResult:
        res = CollectorResult(source=self.name)
        ekey = f"email:{value.lower()}"
        # 셀렉터로서 PGP 키 지문(있으면) — 재사용=동일인 하드신호.
        acc = Entity(EntityType.TRACKER, f"pgp/{value.lower()}", Certainty.CONFIRMED,
                     attrs={"kind": "pgp", "source": "keys.openpgp.org"},
                     evidence=[Evidence(self.name, "공개 PGP 키 존재",
                               url=f"https://keys.openpgp.org/search?q={value}")])
        res.entities.append(acc)
        res.edges.append(Edge(ekey, acc.key, "PGP 키", Certainty.CONFIRMED,
                              evidence=[Evidence(self.name, "VKS by-email")]))
        return res
