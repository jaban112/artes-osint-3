"""웹 보강 — URL 단축 확장·security.txt·robots.txt. 키 불필요.

- URLUnshorten: 단축 URL의 리다이렉트 사슬을 따라 원본 복원(§53).
- SiteFiles: /security.txt(보안 연락처)·/robots.txt(숨은 경로) 파싱(§33/34).
파서 분리로 검증 가능. live 페치는 사용자 VM.
"""
from __future__ import annotations

import re

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from .base import Collector, CollectorResult
from .proc import run_cmd, get_text

_SHORTENERS = ("bit.ly", "t.co", "goo.gl", "tinyurl.com", "ow.ly", "buff.ly",
               "is.gd", "cutt.ly", "rebrand.ly", "t.ly", "lnkd.in")


class URLUnshorten(Collector):
    name = "unshorten"
    accepts = {EntityType.URL}
    timeout = 25.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        res = CollectorResult(source=self.name)
        if not any(s in value for s in _SHORTENERS):
            res.skipped = True
            res.error = "단축 URL 아님"
            return res
        rc, out, err = await run_cmd(
            ["curl", "-s", "-o", "/dev/null", "-w", "%{url_effective}",
             "-L", "--max-redirs", "10", "-m", "20", value], timeout=self.timeout)
        final = (out or "").strip()
        if final and final != value:
            u = Entity(EntityType.URL, final, Certainty.CONFIRMED,
                       evidence=[Evidence(self.name, f"단축 확장: {value} → {final}")])
            res.entities.append(u)
            res.edges.append(Edge(f"url:{value.lower()}", u.key, "원본 URL",
                                  Certainty.CONFIRMED, evidence=[Evidence(self.name, "리다이렉트")]))
        return res


class SiteFiles(Collector):
    name = "sitefiles"
    accepts = {EntityType.DOMAIN}
    timeout = 30.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        res = CollectorResult(source=self.name)
        base = f"https://{value}"
        sec = await get_text(base + "/.well-known/security.txt", 15) \
            or await get_text(base + "/security.txt", 15)
        robots = await get_text(base + "/robots.txt", 15)
        self.parse_security(res, value, sec or "")
        self.parse_robots(res, value, robots or "")
        if not res.entities:
            res.skipped = True
            res.error = "security.txt/robots.txt 없음"
        return res

    def parse_security(self, res, value, text):
        dkey = f"domain:{value.lower()}"
        for m in re.findall(r"Contact:\s*(?:mailto:)?([\w.\-+]+@[\w.\-]+\.\w+)", text, re.I):
            e = Entity(EntityType.EMAIL, m.lower(), Certainty.CONFIRMED,
                       evidence=[Evidence(self.name, "security.txt 보안 연락처")])
            res.entities.append(e)
            res.edges.append(Edge(dkey, e.key, "보안 연락처", Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, "security.txt")]))

    def parse_robots(self, res, value, text):
        dkey = f"domain:{value.lower()}"
        paths = sorted(set(re.findall(r"(?:Disallow|Allow):\s*(\S+)", text, re.I)))
        for p in paths[:30]:
            if p in ("/", ""):
                continue
            u = Entity(EntityType.URL, f"https://{value}{p}", Certainty.UNCONFIRMED, 0.5,
                       evidence=[Evidence(self.name, "robots.txt 경로(숨은 구조 단서)")])
            res.entities.append(u)
            res.edges.append(Edge(dkey, u.key, "robots 경로", Certainty.UNCONFIRMED, 0.5,
                                  evidence=[Evidence(self.name, "robots.txt")]))
