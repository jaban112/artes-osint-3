"""holehe 래퍼 — 이메일이 어느 사이트에 가입돼 있는지(키 불필요).

미설치면 available()=False로 우아하게 건너뛴다.
"""
from __future__ import annotations

import re
from typing import Any

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from .base import Collector, CollectorResult
from .proc import which, run_cmd

_HIT = re.compile(r"^\[\+\]\s+(\S+)")


class Holehe(Collector):
    name = "holehe"
    accepts = {EntityType.EMAIL}
    timeout = 60.0

    def available(self) -> bool:
        return which("holehe") is not None

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        res = CollectorResult(source=self.name)
        rc, out, err = await run_cmd(["holehe", "--only-used", value],
                                     timeout=self.timeout)
        if rc != 0 and not out:
            res.ok = False
            res.error = err.strip()[:200] or f"rc={rc}"
            return res
        src_key = f"email:{value.lower()}"
        for line in out.splitlines():
            m = _HIT.match(line.strip())
            if not m:
                continue
            site = m.group(1).rstrip(":")
            acc = Entity(
                type=EntityType.ACCOUNT, value=f"{site}/{value}",
                certainty=Certainty.CONFIRMED,
                evidence=[Evidence(self.name, f"{site}에 이메일 가입 확인")],
                attrs={"site": site, "email": value},
            )
            res.entities.append(acc)
            res.edges.append(Edge(src=src_key, dst=acc.key, relation="가입 사이트",
                                  certainty=Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, "holehe 확인")]))
        return res
