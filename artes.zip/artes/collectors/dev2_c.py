"""개발자 축 확장 — GitHub SSH/GPG 키·gist, npm 메인테이너. 키 불필요.

- GitHub {user}.keys: 공개 SSH 키(지문=강한 피벗 셀렉터, 재사용 추적).
- GitHub gists: 공개 스니펫(설명·파일명에 실명·이메일 노출 흔함).
- npm: 메인테이너의 패키지(개발자→프로젝트·이메일).
"""
from __future__ import annotations

import base64
import hashlib

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from .base import Collector, CollectorResult
from .proc import get_json, get_text


def _ssh_fingerprint(line: str) -> str | None:
    parts = line.split()
    if len(parts) >= 2:
        try:
            blob = base64.b64decode(parts[1])
            return "SHA256:" + base64.b64encode(hashlib.sha256(blob).digest()).decode().rstrip("=")
        except Exception:
            return None
    return None


class GitHubKeys(Collector):
    name = "github-keys"
    accepts = {EntityType.USERNAME}
    timeout = 25.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        res = CollectorResult(source=self.name)
        keys = await get_text(f"https://github.com/{value}.keys", self.timeout)
        ukey = f"account:github/{value.lower()}"
        found = False
        for line in (keys or "").splitlines():
            fp = _ssh_fingerprint(line.strip())
            if fp:
                found = True
                t = Entity(EntityType.TRACKER, fp, Certainty.CONFIRMED,
                           attrs={"kind": "ssh_key"},
                           evidence=[Evidence(self.name, "공개 SSH 키 지문(피벗 셀렉터)")])
                res.entities.append(t)
                res.edges.append(Edge(ukey, t.key, "SSH 키", Certainty.CONFIRMED,
                                      evidence=[Evidence(self.name, f"github.com/{value}.keys")]))
        if not found:
            res.skipped = True
            res.error = "공개 키 없음"
        return res


class GitHubGists(Collector):
    name = "github-gists"
    accepts = {EntityType.USERNAME}
    timeout = 25.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        data = await get_json(f"https://api.github.com/users/{value}/gists", self.timeout)
        if not isinstance(data, list):
            return CollectorResult(source=self.name, ok=False, error="gist 도달실패")
        return self.parse(data, value)

    def parse(self, data, value: str) -> CollectorResult:
        res = CollectorResult(source=self.name)
        ukey = f"account:github/{value.lower()}"
        import re
        for g in data[:30]:
            if not isinstance(g, dict):
                continue
            desc = str(g.get("description") or "")
            files = " ".join((g.get("files") or {}).keys())
            blob = desc + " " + files
            u = Entity(EntityType.URL, g.get("html_url", ""), Certainty.CONFIRMED,
                       evidence=[Evidence(self.name, f"gist: {desc[:60] or files[:60]}")],
                       attrs={"kind": "gist"})
            if g.get("html_url"):
                res.entities.append(u)
                res.edges.append(Edge(ukey, u.key, "gist", Certainty.CONFIRMED,
                                      evidence=[Evidence(self.name, "public gist")]))
            for em in set(re.findall(r"[\w.\-+]+@[\w.\-]+\.\w+", blob)):
                e = Entity(EntityType.EMAIL, em.lower(), Certainty.UNCONFIRMED, 0.5,
                           evidence=[Evidence(self.name, "gist에서 발견")])
                res.entities.append(e)
                res.edges.append(Edge(ukey, e.key, "gist 이메일", Certainty.UNCONFIRMED, 0.5,
                                      evidence=[Evidence(self.name, "gist")]))
        return res


class NpmMaintainer(Collector):
    name = "npm"
    accepts = {EntityType.USERNAME}
    timeout = 25.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        data = await get_json(
            f"https://registry.npmjs.org/-/v1/search?text=maintainer:{value}&size=20", self.timeout)
        if not data or "objects" not in data:
            return CollectorResult(source=self.name, ok=False, error="npm 도달실패")
        return self.parse(data, value)

    def parse(self, data: dict, value: str) -> CollectorResult:
        res = CollectorResult(source=self.name)
        ukey = f"username:{value.lower()}"
        for obj in data.get("objects", []):
            pkg = obj.get("package", {})
            name = pkg.get("name")
            if not name:
                continue
            url = (pkg.get("links") or {}).get("npm", f"https://www.npmjs.com/package/{name}")
            u = Entity(EntityType.URL, url, Certainty.CONFIRMED,
                       evidence=[Evidence(self.name, f"npm 패키지 {name} (메인테이너)")],
                       attrs={"kind": "npm_package", "package": name})
            res.entities.append(u)
            res.edges.append(Edge(ukey, u.key, "npm 패키지", Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, "registry search")]))
            em = (pkg.get("author") or {}).get("email")
            if em:
                e = Entity(EntityType.EMAIL, em.lower(), Certainty.UNCONFIRMED, 0.6,
                           evidence=[Evidence(self.name, f"npm author ({name})")])
                res.entities.append(e)
                res.edges.append(Edge(ukey, e.key, "npm author 이메일",
                                      Certainty.UNCONFIRMED, 0.6, evidence=[Evidence(self.name, "npm")]))
        return res
