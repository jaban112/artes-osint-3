"""큰 SNS 존재확인 + 경량 공개데이터(증분 27) — 이름→아이디 후보를 실제로 검증.

핵심: username-perms가 만든 후보('김지완'→'지완'/'jiwan')를 인스타·틱톡·유튜브 등에서
실제로 확인한다. 이 수집기들은 씨앗뿐 아니라 생성 후보에도 돈다(whatsmyname처럼 씨앗-한정
아님). 무키·공개 페이지/oEmbed만 사용. 로그인·스크래핑·ToS 위반 없음.

정직: 인스타/틱톡의 팔로워·게시물 등 리치 데이터는 무키로 못 가져온다(로그인벽). 여기선
'그 핸들이 그 플랫폼에 존재하는가 + 공개 표시이름/링크'까지. 이름 기반 후보의 계정 존재는
확실(핸들 존재)이되, '그게 대상 본인인가'는 상위 아이디 후보의 불확실성으로 표현된다.
"""
from __future__ import annotations

import re

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from ..core.cookies import CookieCollector
from .base import Collector, CollectorResult
from .proc import get_json, get_text
from .social3_c import _links_from, _link_entities, _name_geo
from .social4_c import _acc


def _og(html, prop):
    m = re.search(rf'<meta[^>]+property=["\']{re.escape(prop)}["\'][^>]+content=["\']([^"\']*)["\']', html or "")
    if not m:
        m = re.search(rf'<meta[^>]+name=["\']{re.escape(prop)}["\'][^>]+content=["\']([^"\']*)["\']', html or "")
    return (m.group(1).strip() if m else "")


def _h(value: str) -> str:
    return value.lstrip("@").strip()


class TikTokProfile(Collector):
    """TikTok oEmbed(무키) — 핸들 존재 + 표시이름·아바타. 리치데이터는 로그인벽이라 제외."""
    name = "tiktok"; accepts = {EntityType.USERNAME}; timeout = 12.0

    async def collect(self, value, entity_type, ctx):
        h = _h(value)
        d = await get_json(f"https://www.tiktok.com/oembed?url=https://www.tiktok.com/@{h}",
                           self.timeout, headers={"User-Agent": "Mozilla/5.0 artes/1.0"})
        if not d or not d.get("author_name") and not d.get("author_unique_id"):
            return CollectorResult(source=self.name, ok=False, error="TikTok 미발견/비공개")
        return self.parse(d, value)

    def parse(self, d, value):
        res = CollectorResult(source=self.name)
        h = _h(value)
        a = _acc(res, value, "tiktok", h, f"https://www.tiktok.com/@{h}", self.name,
                 "TikTok 계정(존재)", {"display": d.get("author_name", "")})
        return res


class YouTubeHandle(Collector):
    """YouTube @핸들(무키) — 채널 존재 + 채널명·설명 링크."""
    name = "youtube"; accepts = {EntityType.USERNAME}; timeout = 12.0

    async def collect(self, value, entity_type, ctx):
        h = _h(value)
        html = await get_text(f"https://www.youtube.com/@{h}", timeout=self.timeout,
                              headers={"User-Agent": "Mozilla/5.0 artes/1.0"})
        title = _og(html or "", "og:title")
        if not title or title.strip().lower() == "youtube":
            return CollectorResult(source=self.name, ok=False, error="YouTube 채널 없음")
        return self.parse(html, value, title)

    def parse(self, html, value, title=""):
        res = CollectorResult(source=self.name)
        h = _h(value)
        title = title or _og(html or "", "og:title")
        desc = _og(html or "", "og:description")
        a = _acc(res, value, "youtube", h, f"https://www.youtube.com/@{h}", self.name,
                 "YouTube 채널(존재)", {"channel": title, "about": desc[:200]})
        _link_entities(res, a.key, _links_from(desc), self.name, certain=False)
        return res


class InstagramProfile(Collector):
    """Instagram 공개 프로필(무키·베스트에포트) — 핸들 존재 + og 표시이름·소개.

    리치데이터(팔로워·게시물)는 로그인벽이라 불가. 공개계정의 og 태그만 파싱, 없으면 조용히 실패.
    """
    name = "instagram"; accepts = {EntityType.USERNAME}; timeout = 12.0

    async def collect(self, value, entity_type, ctx):
        h = _h(value)
        html = await get_text(f"https://www.instagram.com/{h}/", timeout=self.timeout,
                              headers={"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) artes/1.0"})
        title = _og(html or "", "og:title")
        # IG는 로그인벽/일반페이지를 200으로 주기도 함 — 프로필성 og만 신뢰
        if not html or "instagram.com" not in html or not title or \
           title.strip().lower() in ("instagram", "login • instagram"):
            return CollectorResult(source=self.name, ok=False, error="Instagram 미발견/비공개/로그인벽")
        return self.parse(html, value, title)

    def parse(self, html, value, title=""):
        res = CollectorResult(source=self.name)
        h = _h(value)
        title = title or _og(html or "", "og:title")
        desc = _og(html or "", "og:description")
        a = _acc(res, value, "instagram", h, f"https://www.instagram.com/{h}/", self.name,
                 "Instagram 계정(공개 프리뷰)",
                 {"display": title.split("(")[0].strip(), "bio": desc[:200],
                  "note": "핸들 존재 — 소유자 확인 필요"})
        _link_entities(res, a.key, _links_from(desc), self.name, certain=False)
        return res


class ThreadsProfile(Collector):
    """Threads(@핸들, 인스타와 동일 핸들계) — 존재 + og 표시이름."""
    name = "threads"; accepts = {EntityType.USERNAME}; timeout = 12.0

    async def collect(self, value, entity_type, ctx):
        h = _h(value)
        html = await get_text(f"https://www.threads.net/@{h}", timeout=self.timeout,
                              headers={"User-Agent": "Mozilla/5.0 artes/1.0"})
        title = _og(html or "", "og:title")
        if not title or title.strip().lower() in ("threads", ""):
            return CollectorResult(source=self.name, ok=False, error="Threads 미발견")
        return self.parse(html, value, title)

    def parse(self, html, value, title=""):
        res = CollectorResult(source=self.name)
        h = _h(value)
        desc = _og(html or "", "og:description")
        _acc(res, value, "threads", h, f"https://www.threads.net/@{h}", self.name,
             "Threads 계정(존재)", {"display": (title or "").replace("(@%s)" % h, "").strip(),
                                   "bio": desc[:200]})
        return res


class PinterestProfile(Collector):
    """Pinterest(무키) — 핸들 존재 + og 표시이름."""
    name = "pinterest"; accepts = {EntityType.USERNAME}; timeout = 12.0

    async def collect(self, value, entity_type, ctx):
        h = _h(value)
        html = await get_text(f"https://www.pinterest.com/{h}/", timeout=self.timeout,
                              headers={"User-Agent": "Mozilla/5.0 artes/1.0"})
        title = _og(html or "", "og:title")
        if not title or title.strip().lower() in ("pinterest", ""):
            return CollectorResult(source=self.name, ok=False, error="Pinterest 미발견")
        return self.parse(html, value, title)

    def parse(self, html, value, title=""):
        res = CollectorResult(source=self.name)
        h = _h(value)
        _acc(res, value, "pinterest", h, f"https://www.pinterest.com/{h}/", self.name,
             "Pinterest 계정(존재)", {"display": title})
        return res


class SnapchatProfile(Collector):
    """Snapchat 공개 프로필(무키) — 핸들 존재 + 표시이름."""
    name = "snapchat"; accepts = {EntityType.USERNAME}; timeout = 12.0

    async def collect(self, value, entity_type, ctx):
        h = _h(value)
        html = await get_text(f"https://www.snapchat.com/add/{h}", timeout=self.timeout,
                              headers={"User-Agent": "Mozilla/5.0 artes/1.0"})
        title = _og(html or "", "og:title")
        if not title or "snapchat" == title.strip().lower() or "page not found" in (html or "").lower():
            return CollectorResult(source=self.name, ok=False, error="Snapchat 미발견")
        return self.parse(html, value, title)

    def parse(self, html, value, title=""):
        res = CollectorResult(source=self.name)
        h = _h(value)
        _acc(res, value, "snapchat", h, f"https://www.snapchat.com/add/{h}", self.name,
             "Snapchat 계정(존재)", {"display": (title or "").replace("on Snapchat", "").strip()})
        return res


class NaverBlog(Collector):
    """네이버 블로그(무키) — 한국 핵심. blog.naver.com/{id} 존재 + 블로그명·소개."""
    name = "naver-blog"; accepts = {EntityType.USERNAME}; timeout = 12.0

    async def collect(self, value, entity_type, ctx):
        h = _h(value)
        html = await get_text(f"https://blog.naver.com/{h}", timeout=self.timeout,
                              headers={"User-Agent": "Mozilla/5.0 artes/1.0"})
        title = _og(html or "", "og:title")
        if not html or not title or "네이버" == title.strip() or \
           "존재하지 않" in (html or "") or "blogView" not in (html or "") and "og:title" not in (html or ""):
            return CollectorResult(source=self.name, ok=False, error="네이버 블로그 미발견")
        return self.parse(html, value, title)

    def parse(self, html, value, title=""):
        res = CollectorResult(source=self.name)
        h = _h(value)
        title = title or _og(html or "", "og:title")
        desc = _og(html or "", "og:description")
        _acc(res, value, "naver-blog", h, f"https://blog.naver.com/{h}", self.name,
             "네이버 블로그(존재)", {"blog": title, "about": desc[:200]})
        return res


class GoogleAccountHint(Collector):
    """구글 계정 힌트(이메일) — 무키로 가능한 범위만 정직하게.

    무키로 '구글 계정 존재' 확정 조회는 불가(GHunt는 로그인 쿠키 필요). 여기선 도메인 신호만:
    gmail/googlemail 주소는 구글 계정을 시사(로그인·연동 조사 착수점). 심층(연동 서비스·이름·
    사진·리뷰)은 인증 도구(GHunt) 경로 안내.
    """
    name = "google-account-hint"; accepts = {EntityType.EMAIL}; timeout = 5.0
    needs_network = False

    async def collect(self, value, entity_type, ctx):
        dom = value.split("@")[-1].lower()
        if dom not in ("gmail.com", "googlemail.com"):
            return CollectorResult(source=self.name, ok=True)   # 구글 신호 없음(조용히)
        return self.parse(value)

    def parse(self, value):
        res = CollectorResult(source=self.name)
        ek = f"email:{value.lower()}"
        a = Entity(EntityType.ACCOUNT, f"google/{value.lower()}", Certainty.UNCONFIRMED,
                   confidence=0.6,
                   evidence=[Evidence(self.name, "Gmail 주소 — 구글 계정 시사(연동 조사 착수점). "
                                      "심층 확인은 인증 도구(GHunt) 필요")],
                   attrs={"site": "google", "handle": value.lower(),
                          "note": "무키로는 존재 시사만 — 연동 서비스/이름/사진은 인증 필요"})
        res.entities.append(a)
        res.edges.append(Edge(ek, a.key, "구글 계정(시사)", Certainty.UNCONFIRMED, confidence=0.6,
                              evidence=[Evidence(self.name, "gmail 도메인")]))
        return res


class Linktree(Collector):
    """Linktree(무키) — 한 핸들의 '연결된 모든 소셜/링크' 집합. 최고 교차연결 피벗."""
    name = "linktree"; accepts = {EntityType.USERNAME}; timeout = 12.0

    async def collect(self, value, entity_type, ctx):
        h = _h(value)
        html = await get_text(f"https://linktr.ee/{h}", timeout=self.timeout,
                              headers={"User-Agent": "Mozilla/5.0 artes/1.0"})
        title = _og(html or "", "og:title")
        if not html or not title or "linktree" == title.strip().lower() or \
           "page not found" in (html or "").lower():
            return CollectorResult(source=self.name, ok=False, error="Linktree 미발견")
        return self.parse(html, value)

    def parse(self, html, value):
        res = CollectorResult(source=self.name)
        h = _h(value)
        a = _acc(res, value, "linktree", h, f"https://linktr.ee/{h}", self.name,
                 "Linktree(연결 링크 모음)")
        # 페이지의 모든 외부 링크 → URL 엔티티(연결 계정 피벗)
        urls = re.findall(r'"url":"(https?://[^"]+)"', html or "")
        urls += _links_from(html or "")
        clean = [u for u in dict.fromkeys(urls) if "linktr.ee" not in u][:20]
        _link_entities(res, a.key, clean, self.name, certain=False)
        return res


class InstagramAuth(CookieCollector, Collector):
    """Instagram 심층(본인 세션 쿠키) — 실명·바이오·팔로워수·외부링크·공개여부.

    쿠키 없으면 skip. '본인이 로그인한 본인 계정'의 sessionid로만 동작(인가 수사 전제).
    ToS 위반·계정정지 위험은 사용자 책임. DM·비공개 콘텐츠·위치는 다루지 않는다.
    """
    name = "instagram-auth"; site = "instagram"
    accepts = {EntityType.USERNAME}; timeout = 15.0

    async def collect(self, value, entity_type, ctx):
        h = _h(value)
        d = await get_json(
            f"https://i.instagram.com/api/v1/users/web_profile_info/?username={h}",
            self.timeout,
            headers={"User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X)",
                     "X-IG-App-ID": "936619743392459",
                     "Cookie": self.cookie() or ""})
        user = ((d or {}).get("data") or {}).get("user")
        if not user:
            return CollectorResult(source=self.name, ok=False, error="IG 심층 실패(쿠키 만료/미발견)")
        return self.parse(user, value)

    def parse(self, u, value):
        res = CollectorResult(source=self.name)
        h = _h(value)
        followers = ((u.get("edge_followed_by") or {}).get("count"))
        a = _acc(res, value, "instagram", h, f"https://www.instagram.com/{h}/", self.name,
                 "Instagram 심층(인증)",
                 {"display": u.get("full_name", ""), "bio": (u.get("biography") or "")[:300],
                  "followers": followers,
                  "following": ((u.get("edge_follow") or {}).get("count")),
                  "private": u.get("is_private"), "verified": u.get("is_verified"),
                  "category": u.get("category_name", ""), "ig_id": u.get("id")})
        # 실명(표시이름)·외부링크
        _name_geo(res, a.key, self.name, u.get("full_name", ""), "")
        ext = u.get("external_url") or ""
        links = _links_from(u.get("biography", "") or "")
        if ext:
            links = [ext] + links
        _link_entities(res, a.key, links, self.name, certain=False)
        return res
