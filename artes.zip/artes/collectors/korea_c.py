"""gap4 — 한국 공공기록(공개·합법 범위).

정직: 한국은 개인정보보호법으로 '개인'을 이름으로 조회하는 공개 레지스트리가 사실상 없다.
공개된 것은 **법인·사업체·저명인** 기록이다. 그래서 여기서 다루는 건:
- OpenDART(금융감독원 전자공시): 회사명→대표자·주소·전화·사업자/법인번호·업종(개방 API, 무료 키).
  한국 사용자는 opendart.fss.or.kr에서 즉시 무료 발급. 키 없으면 조용히 skip.
- 한국어 위키백과: 저명인(공적 인물) 이름→직업·설명·문서 링크(무키). 일반인은 안 나옴(정상).

전화→실명, 주민등록·주소 조회 등은 법으로 공개 불가 → 미구현(정식 수사는 영장·기관 채널).
파서(parse_*)는 순수 함수로 분리해 합성 응답으로 오프라인 단위검증.
"""
from __future__ import annotations

import html
import json
import os
import re
import zipfile
from io import BytesIO
from pathlib import Path

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from ..core.keys import KEYS, KeyedCollector
from .base import Collector, CollectorResult
from .proc import get_json, get_bytes

_TAG_RE = re.compile(r"<[^>]+>")
_CORP_CACHE = Path.home() / ".artes" / "dart_corp.json"


def _strip(s: str) -> str:
    return html.unescape(_TAG_RE.sub("", s or "")).strip()


class OpenDartCompany(KeyedCollector, Collector):
    """OpenDART 기업개황 — 회사명→대표자·주소·전화·사업자번호·업종. 개방 API(무료 키), 없으면 skip."""
    name = "opendart-company"; service = "opendart"
    accepts = {EntityType.ORG}; timeout = 20.0; max_run = 60.0

    async def _resolve_corp_code(self, name: str, key: str) -> str | None:
        """회사명→8자리 고유번호. 8자리 입력이면 그대로. 아니면 corpCode 색인(캐시)에서."""
        v = name.strip()
        if re.fullmatch(r"\d{8}", v):
            return v
        idx = self._load_index()
        if idx is None:
            idx = await self._build_index(key)
        if not idx:
            return None
        return idx.get(v) or idx.get(v.replace(" ", ""))

    def _load_index(self) -> dict | None:
        try:
            if _CORP_CACHE.exists():
                return json.loads(_CORP_CACHE.read_text("utf-8"))
        except Exception:
            pass
        return None

    async def _build_index(self, key: str) -> dict | None:
        """corpCode.xml(zip) 1회 다운로드→회사명:고유번호 캐시. 실패시 None(수집기 skip)."""
        try:
            raw = await get_bytes(f"https://opendart.fss.or.kr/api/corpCode.xml?crtfc_key={key}",
                                  timeout=self.timeout, max_bytes=30_000_000)
            if not raw:
                return None
            with zipfile.ZipFile(BytesIO(raw)) as z:
                xml = z.read(z.namelist()[0]).decode("utf-8", "ignore")
            idx = {}
            for m in re.finditer(r"<list>(.*?)</list>", xml, re.S):
                blk = m.group(1)
                cc = re.search(r"<corp_code>(.*?)</corp_code>", blk)
                cn = re.search(r"<corp_name>(.*?)</corp_name>", blk)
                if cc and cn:
                    idx[_strip(cn.group(1))] = _strip(cc.group(1))
            _CORP_CACHE.parent.mkdir(parents=True, exist_ok=True)
            _CORP_CACHE.write_text(json.dumps(idx, ensure_ascii=False), "utf-8")
            return idx
        except Exception:
            return None

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        key = self.api_key()
        if not key:
            return CollectorResult(source=self.name, ok=False, skipped=True, error="opendart 키 없음")
        code = await self._resolve_corp_code(value, key)
        if not code:
            return CollectorResult(source=self.name, ok=False, error="회사 고유번호 미해결")
        d = await get_json(f"https://opendart.fss.or.kr/api/company.json?crtfc_key={key}&corp_code={code}",
                           self.timeout)
        if not isinstance(d, dict) or d.get("status") != "000":
            return CollectorResult(source=self.name, ok=False,
                                   error=f"OpenDART {(d or {}).get('status','?')}")
        return self.parse_company(d, value)

    def parse_company(self, d: dict, value: str) -> CollectorResult:
        res = CollectorResult(source=self.name)
        ok = f"org:{value.lower()}"
        corp = _strip(d.get("corp_name", "")) or value
        url = "https://dart.fss.or.kr"
        # 대표자→이름
        ceo = _strip(d.get("ceo_nm", ""))
        if ceo:
            for nm in re.split(r"[,/·]", ceo):     # 공동대표 분리
                nm = nm.strip()
                if not nm:
                    continue
                res.entities.append(Entity(EntityType.NAME, nm, Certainty.CONFIRMED,
                                    evidence=[Evidence(self.name, f"{corp} 대표자(전자공시)", url=url)]))
                res.edges.append(Edge(ok, f"name:{nm.lower()}", "대표자", Certainty.CONFIRMED,
                                      evidence=[Evidence(self.name, "ceo_nm")]))
        # 전화
        phn = _strip(d.get("phn_no", ""))
        if phn:
            res.entities.append(Entity(EntityType.PHONE, phn, Certainty.CONFIRMED,
                                evidence=[Evidence(self.name, f"{corp} 대표전화(전자공시)", url=url)]))
            res.edges.append(Edge(ok, f"phone:{re.sub(r'[^0-9+]', '', phn)}", "대표 전화",
                                  Certainty.CONFIRMED, evidence=[Evidence(self.name, "phn_no")]))
        # 주소→위치
        adr = _strip(d.get("adres", ""))
        if adr:
            res.entities.append(Entity(EntityType.GEO, adr, Certainty.CONFIRMED,
                                evidence=[Evidence(self.name, f"{corp} 본점 소재지", url=url)],
                                attrs={"address": adr}))
            res.edges.append(Edge(ok, f"geo:{adr.lower()}", "본점 소재지", Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, "adres")]))
        # 홈페이지→도메인
        hm = _strip(d.get("hm_url", ""))
        if hm:
            dom = re.sub(r"^https?://", "", hm).split("/")[0].lower()
            if dom:
                res.entities.append(Entity(EntityType.DOMAIN, dom, Certainty.CONFIRMED,
                                    evidence=[Evidence(self.name, f"{corp} 홈페이지", url=hm)]))
                res.edges.append(Edge(ok, f"domain:{dom}", "회사 홈페이지", Certainty.CONFIRMED,
                                      evidence=[Evidence(self.name, "hm_url")]))
        # 조직 자체(사업자·법인번호·업종·설립일 속성)
        res.entities.append(Entity(EntityType.ORG, corp, Certainty.CONFIRMED,
                            evidence=[Evidence(self.name, "OpenDART 기업개황", url=url)],
                            attrs={"biz_no": _strip(d.get("bizr_no", "")),
                                   "corp_reg_no": _strip(d.get("jurir_no", "")),
                                   "industry": _strip(d.get("induty_code", "")),
                                   "established": _strip(d.get("est_dt", "")),
                                   "corp_cls": _strip(d.get("corp_cls", "")),
                                   "stock_code": _strip(d.get("stock_code", ""))}))
        return res


class KoreanWikipedia(Collector):
    """한국어 위키백과 — 저명인 이름→직업·설명·문서(무키). 일반인은 미발견(정상)."""
    name = "wikipedia-ko"; accepts = {EntityType.NAME}; timeout = 15.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        q = value.strip()
        if len(q) < 2:
            return CollectorResult(source=self.name, ok=True)
        d = await get_json(
            "https://ko.wikipedia.org/w/api.php?action=query&format=json&list=search"
            f"&srsearch={q}&srlimit=3&srprop=snippet",
            self.timeout, headers={"User-Agent": "artes/0.1 (osint)"})
        hits = (((d or {}).get("query") or {}).get("search")) or []
        if not hits:
            return CollectorResult(source=self.name, ok=False, error="한국어 위키 무결과")
        return self.parse(hits, value)

    def parse(self, hits: list, value: str) -> CollectorResult:
        res = CollectorResult(source=self.name)
        nk = f"name:{value.lower()}"
        vnorm = value.strip().replace(" ", "")
        for h in hits[:3]:
            title = (h or {}).get("title", "").strip()
            if not title:
                continue
            # 제목이 이름과 정확/근접해야 채택(동음 문서 소음 억제). 괄호 주석은 무시.
            base = re.sub(r"\s*\(.*?\)\s*$", "", title).replace(" ", "")
            exact = base == vnorm
            url = "https://ko.wikipedia.org/wiki/" + title.replace(" ", "_")
            snippet = _strip((h or {}).get("snippet", ""))
            cert = Certainty.CONFIRMED if exact else Certainty.UNCONFIRMED
            res.entities.append(Entity(EntityType.URL, url, cert,
                                confidence=None if exact else 0.4,
                                evidence=[Evidence(self.name,
                                          f"한국어 위키백과: {title}" + (f" — {snippet}" if snippet else ""),
                                          url=url)],
                                attrs={"kind": "wiki", "title": title, "snippet": snippet}))
            res.edges.append(Edge(nk, f"url:{url}", "위키백과 문서" + ("(정확)" if exact else "(후보)"),
                                  cert, confidence=None if exact else 0.4,
                                  evidence=[Evidence(self.name, "ko.wikipedia search")]))
            if exact:
                break
        return res
