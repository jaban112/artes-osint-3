"""Keybase 래퍼 — 아이디/이메일로 암호학적으로 검증된 연결 계정(키 불필요).

Keybase proof는 사용자가 서명으로 증명한 계정 연결이라 **교차플랫폼 동일인이 확실**이다
(트위터·깃허브·레딧·도메인 등). 강한 동일인 근거. 파서 분리로 검증 가능.
"""
from __future__ import annotations

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from .base import Collector, CollectorResult
from .proc import get_json


class Keybase(Collector):
    name = "keybase"
    accepts = {EntityType.USERNAME, EntityType.EMAIL}
    timeout = 30.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        field = "emails" if entity_type is EntityType.EMAIL else "usernames"
        data = await get_json(
            f"https://keybase.io/_/api/1.0/user/lookup.json?{field}={value}&fields=basics,profile,proofs_summary",
            self.timeout)
        if not data or data.get("status", {}).get("code") not in (0, None):
            return CollectorResult(source=self.name, ok=False, error="Keybase 도달/미발견")
        return self.parse(data, value, entity_type)

    def parse(self, data: dict, value: str, entity_type) -> CollectorResult:
        res = CollectorResult(source=self.name)
        them = data.get("them")
        users = them if isinstance(them, list) else [them] if them else []
        base = f"{entity_type.value}:{value.lower()}"
        for u in users:
            if not u:
                continue
            kb = (u.get("basics") or {}).get("username")
            kbkey = base
            if kb:
                acc = Entity(EntityType.ACCOUNT, f"keybase/{kb}", Certainty.CONFIRMED,
                             evidence=[Evidence(self.name, "Keybase 프로필",
                                                url=f"https://keybase.io/{kb}")],
                             attrs={"site": "keybase", "handle": kb})
                res.entities.append(acc); kbkey = acc.key
                res.edges.append(Edge(base, acc.key, "Keybase", Certainty.CONFIRMED,
                                      evidence=[Evidence(self.name, "lookup")]))
            prof = u.get("profile") or {}
            if prof.get("full_name"):
                n = Entity(EntityType.NAME, prof["full_name"], Certainty.UNCONFIRMED, 0.7,
                           evidence=[Evidence(self.name, "Keybase 실명")])
                res.entities.append(n)
                res.edges.append(Edge(kbkey, n.key, "표시 이름", Certainty.UNCONFIRMED, 0.7,
                                      evidence=[Evidence(self.name, "프로필")]))
            for pr in ((u.get("proofs_summary") or {}).get("all") or []):
                svc = pr.get("proof_type", "?")
                handle = pr.get("nametag", "")
                url = pr.get("service_url", "")
                acc = Entity(EntityType.ACCOUNT, f"{svc}/{handle}", Certainty.CONFIRMED,
                             evidence=[Evidence(self.name,
                                       f"Keybase 검증 연결({svc})", url=url)],
                             attrs={"site": svc, "handle": handle, "url": url,
                                    "verified": True})
                res.entities.append(acc)
                # 검증된 연결 = 확실한 동일인 링크.
                res.edges.append(Edge(kbkey, acc.key, "검증된 연결", Certainty.CONFIRMED,
                                      evidence=[Evidence(self.name, "암호학적 proof", url=url)]))
        return res
