"""개발자 축 — GitHub 공개 활동. 커밋 메타데이터에서 실명·이메일(키 불필요, 금맥).

아이디 하나로 공개 프로필의 실명·회사·블로그, 그리고 공개 PushEvent 커밋의
author 이메일(실명 이메일이 그대로 박힌 경우 흔함)을 뽑는다. 파서 분리로 검증 가능.
공개 REST는 인증 없이 시간당 60회 제한 — 그 안에서만.
"""
from __future__ import annotations

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from ..core.imagehash import phash_bytes
from .base import Collector, CollectorResult
from .proc import get_json, get_bytes


class GitHubDev(Collector):
    name = "github"
    accepts = {EntityType.USERNAME}
    timeout = 30.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        user = await get_json(f"https://api.github.com/users/{value}", self.timeout)
        if not user or user.get("message") == "Not Found":
            return CollectorResult(source=self.name, ok=False, error="GitHub 사용자 없음/도달 실패")
        events = await get_json(f"https://api.github.com/users/{value}/events/public",
                                self.timeout) or []
        res = self.parse_user(user, value)
        self.parse_events(res, events, value)
        # 아바타 지각해시 → 같은 사진 동일인 신호.
        if user.get("avatar_url"):
            data = await get_bytes(user["avatar_url"])
            if data:
                ph = phash_bytes(data)
                from ..core.face import encode as _face_encode
                fe = _face_encode(data)
                for e in res.entities:
                    if e.type is EntityType.ACCOUNT and e.attrs.get("site") == "github":
                        if ph:
                            e.attrs["image_phash"] = ph
                        if fe:
                            e.attrs["face_encoding"] = fe
        return res

    def parse_user(self, user: dict, value: str) -> CollectorResult:
        res = CollectorResult(source=self.name)
        akey = f"account:github/{value.lower()}"
        acc = Entity(EntityType.ACCOUNT, f"github/{value}", Certainty.CONFIRMED,
                     evidence=[Evidence(self.name, "GitHub 공개 프로필",
                                        url=user.get("html_url", ""))],
                     attrs={"site": "github", "handle": value,
                            "company": user.get("company"), "blog": user.get("blog"),
                            "location": user.get("location"),
                            "bio": user.get("bio")})
        res.entities.append(acc)
        if user.get("name"):
            n = Entity(EntityType.NAME, user["name"], Certainty.UNCONFIRMED, 0.7,
                       evidence=[Evidence(self.name, "GitHub 표시 이름")])
            res.entities.append(n)
            res.edges.append(Edge(akey, n.key, "표시 이름", Certainty.UNCONFIRMED, 0.7,
                                  evidence=[Evidence(self.name, "프로필")]))
        if user.get("email") and "@" in str(user["email"]):
            e = Entity(EntityType.EMAIL, user["email"].lower(), Certainty.CONFIRMED,
                       evidence=[Evidence(self.name, "GitHub 공개 이메일")])
            res.entities.append(e)
            res.edges.append(Edge(akey, e.key, "공개 이메일", Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, "프로필")]))
        blog = str(user.get("blog") or "").strip()
        if blog.startswith("http"):
            res.entities.append(Entity(EntityType.URL, blog, Certainty.CONFIRMED,
                evidence=[Evidence(self.name, "프로필 블로그/사이트")]))
        return res

    def parse_events(self, res: CollectorResult, events: list, value: str) -> None:
        akey = f"account:github/{value.lower()}"
        emails = set()
        for ev in (events or []):
            if ev.get("type") != "PushEvent":
                continue
            for c in ev.get("payload", {}).get("commits", []):
                em = (c.get("author") or {}).get("email", "")
                if "@" in em and not em.endswith("noreply.github.com"):
                    emails.add(em.lower())
        for em in sorted(emails):
            e = Entity(EntityType.EMAIL, em, Certainty.CONFIRMED,
                       evidence=[Evidence(self.name, "공개 커밋 author 이메일")])
            res.entities.append(e)
            res.edges.append(Edge(akey, e.key, "커밋 이메일", Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, "PushEvent 커밋")]))
