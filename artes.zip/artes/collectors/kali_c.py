"""Kali/GitHub CLI 도구 래퍼 — 설치돼 있으면 쓰고 없으면 우아하게 skip(증분 13).

전부 키 불필요 도구. available()가 which()로 존재 확인 → 이 컨테이너엔 없어 skip,
사용자 Kali VM엔 있어 동작. 파서(parse_*)는 도구 출력 샘플로 네트워크 없이 단위검증.

능동(크롤·스캔) 도구는 aggression 최소/기본만 — 배포 동의 게이트 하에 사용.
"""
from __future__ import annotations

import json
import re

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from .base import Collector, CollectorResult
from .proc import which, run_cmd


class _CliTool(Collector):
    """공통 CLI 래퍼 — bin 존재 확인 + 실행 + parse()."""
    bin_name = ""

    def available(self) -> bool:
        return which(self.bin_name) is not None


# ---------------- 서브도메인 ----------------
class Subfinder(_CliTool):
    name = "subfinder"; bin_name = "subfinder"
    accepts = {EntityType.DOMAIN}; timeout = 120.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        rc, out, err = await run_cmd(
            ["subfinder", "-d", value, "-silent", "-all"], timeout=self.timeout)
        return self.parse(out, value)

    def parse(self, out, value) -> CollectorResult:
        res = CollectorResult(source=self.name)
        dkey = f"domain:{value.lower()}"
        for line in (out or "").splitlines():
            s = line.strip().lower()
            if s.endswith(value.lower()) and s != value.lower() and "." in s:
                e = Entity(EntityType.DOMAIN, s, Certainty.CONFIRMED,
                           evidence=[Evidence(self.name, "subfinder 서브도메인")])
                res.entities.append(e)
                res.edges.append(Edge(dkey, e.key, "서브도메인", Certainty.CONFIRMED,
                                      evidence=[Evidence(self.name, "subfinder")]))
        return res


class Assetfinder(_CliTool):
    name = "assetfinder"; bin_name = "assetfinder"
    accepts = {EntityType.DOMAIN}; timeout = 90.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        rc, out, err = await run_cmd(["assetfinder", "--subs-only", value],
                                     timeout=self.timeout)
        return Subfinder.parse(self, out, value)       # 동일 라인 파서 재사용


class Amass(_CliTool):
    name = "amass"; bin_name = "amass"
    accepts = {EntityType.DOMAIN}; timeout = 300.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        rc, out, err = await run_cmd(
            ["amass", "enum", "-passive", "-d", value, "-silent"], timeout=self.timeout)
        return Subfinder.parse(self, out, value)


# ---------------- DNS 확인/레코드 ----------------
class Dnsx(_CliTool):
    name = "dnsx"; bin_name = "dnsx"
    accepts = {EntityType.DOMAIN}; timeout = 60.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        rc, out, err = await run_cmd(
            ["dnsx", "-d", value, "-a", "-resp", "-silent", "-json"], timeout=self.timeout)
        return self.parse(out, value)

    def parse(self, out, value) -> CollectorResult:
        res = CollectorResult(source=self.name)
        dkey = f"domain:{value.lower()}"
        for line in (out or "").splitlines():
            try:
                rec = json.loads(line)
            except Exception:
                continue
            for ip in (rec.get("a") or []):
                res.entities.append(Entity(EntityType.IP, ip, Certainty.CONFIRMED,
                    evidence=[Evidence(self.name, "dnsx A 레코드")]))
                res.edges.append(Edge(dkey, f"ip:{ip}", "A 레코드", Certainty.CONFIRMED,
                                      evidence=[Evidence(self.name, "dnsx")]))
        return res


class Dnstwist(_CliTool):
    name = "dnstwist"; bin_name = "dnstwist"
    accepts = {EntityType.DOMAIN}; timeout = 120.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        rc, out, err = await run_cmd(
            ["dnstwist", "--format", "json", "--registered", value], timeout=self.timeout)
        return self.parse(out, value)

    def parse(self, out, value) -> CollectorResult:
        res = CollectorResult(source=self.name)
        dkey = f"domain:{value.lower()}"
        try:
            rows = json.loads(out or "[]")
        except Exception:
            return CollectorResult(source=self.name, ok=False, error="dnstwist 파싱 실패")
        for r in rows:
            dom = (r.get("domain") or "").lower()
            if dom and dom != value.lower():
                e = Entity(EntityType.DOMAIN, dom, Certainty.CONFIRMED,
                           attrs={"fuzzer": r.get("fuzzer"), "impersonation": True},
                           evidence=[Evidence(self.name, f"유사도메인({r.get('fuzzer')})")])
                res.entities.append(e)
                res.edges.append(Edge(dkey, e.key, "사칭 유사도메인",
                                      Certainty.UNCONFIRMED, 0.5,
                                      evidence=[Evidence(self.name, "dnstwist")]))
        return res


# ---------------- URL/크롤 ----------------
class Gau(_CliTool):
    name = "gau"; bin_name = "gau"
    accepts = {EntityType.DOMAIN}; timeout = 120.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        rc, out, err = await run_cmd(["gau", "--subs", value], timeout=self.timeout,
                                     stdin=None)
        return self.parse(out, value)

    def parse(self, out, value) -> CollectorResult:
        res = CollectorResult(source=self.name)
        dkey = f"domain:{value.lower()}"
        seen = set()
        for line in (out or "").splitlines()[:500]:
            u = line.strip()
            if u.startswith("http") and u not in seen:
                seen.add(u)
                res.entities.append(Entity(EntityType.URL, u, Certainty.CONFIRMED,
                    evidence=[Evidence(self.name, "gau 과거 URL")]))
        return res


class Waybackurls(_CliTool):
    name = "waybackurls"; bin_name = "waybackurls"
    accepts = {EntityType.DOMAIN}; timeout = 90.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        rc, out, err = await run_cmd(["waybackurls", value], timeout=self.timeout)
        return Gau.parse(self, out, value)


# ---------------- 웹 지문 ----------------
class WhatWeb(_CliTool):
    name = "whatweb"; bin_name = "whatweb"
    accepts = {EntityType.DOMAIN, EntityType.URL}; timeout = 60.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        url = value if str(value).startswith("http") else f"https://{value}"
        rc, out, err = await run_cmd(
            ["whatweb", "--log-json=-", "-a", "1", url], timeout=self.timeout)
        return self.parse(out, value)

    def parse(self, out, value) -> CollectorResult:
        res = CollectorResult(source=self.name)
        dkey = f"domain:{value.lower()}"
        techs = []
        for line in (out or "").splitlines():
            try:
                rec = json.loads(line)
            except Exception:
                continue
            plugins = rec.get("plugins", {})
            techs.extend(plugins.keys())
        if techs:
            res.entities.append(Entity(EntityType.DOMAIN, value.lower(), Certainty.CONFIRMED,
                attrs={"technologies": sorted(set(techs))[:40]},
                evidence=[Evidence(self.name, f"기술 {len(set(techs))}종 탐지")]))
        return res


# ---------------- 문서/이미지 메타데이터 ----------------
class ExifToolMeta(_CliTool):
    name = "exiftool"; bin_name = "exiftool"
    accepts = set()                                    # 파일 경로 대상(엔진 자동 라우팅 밖)
    timeout = 30.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        rc, out, err = await run_cmd(["exiftool", "-json", "-a", "-n", value],
                                     timeout=self.timeout)
        return self.parse(out, value)

    def parse(self, out, value) -> CollectorResult:
        res = CollectorResult(source=self.name)
        try:
            rows = json.loads(out or "[]")
        except Exception:
            return CollectorResult(source=self.name, ok=False, error="exiftool 파싱 실패")
        for meta in rows:
            author = meta.get("Author") or meta.get("Creator")
            if author:
                res.entities.append(Entity(EntityType.NAME, str(author),
                    Certainty.UNCONFIRMED, 0.6,
                    evidence=[Evidence(self.name, "문서 작성자 메타데이터")]))
            lat, lon = meta.get("GPSLatitude"), meta.get("GPSLongitude")
            if lat and lon:
                res.entities.append(Entity(EntityType.GEO, f"{lat},{lon}",
                    Certainty.CONFIRMED, attrs={"lat": lat, "lon": lon},
                    evidence=[Evidence(self.name, "EXIF GPS 좌표")]))
        return res


# ---------------- 사용자/이메일/전화(GitHub 도구) ----------------
class Nexfil(_CliTool):
    name = "nexfil"; bin_name = "nexfil"
    accepts = {EntityType.USERNAME}; timeout = 120.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        rc, out, err = await run_cmd(["nexfil", "-u", value, "--json"], timeout=self.timeout)
        return self.parse(out, value)

    def parse(self, out, value) -> CollectorResult:
        res = CollectorResult(source=self.name)
        ukey = f"username:{value.lower()}"
        urls = re.findall(r"https?://\S+", out or "")
        for u in urls[:100]:
            res.entities.append(Entity(EntityType.URL, u.rstrip(",\"'"), Certainty.CONFIRMED,
                evidence=[Evidence(self.name, "nexfil 프로필 발견")]))
        return res


class Mailcat(_CliTool):
    name = "mailcat"; bin_name = "mailcat"
    accepts = {EntityType.USERNAME}; timeout = 90.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        rc, out, err = await run_cmd(["mailcat", value], timeout=self.timeout)
        return self.parse(out, value)

    def parse(self, out, value) -> CollectorResult:
        res = CollectorResult(source=self.name)
        ukey = f"username:{value.lower()}"
        for em in set(re.findall(r"[\w.\-]+@[\w.\-]+\.\w+", out or "")):
            e = Entity(EntityType.EMAIL, em.lower(), Certainty.UNCONFIRMED, 0.5,
                       evidence=[Evidence(self.name, "mailcat 후보 이메일")])
            res.entities.append(e)
            res.edges.append(Edge(ukey, e.key, "후보 이메일", Certainty.UNCONFIRMED, 0.5,
                                  evidence=[Evidence(self.name, "mailcat")]))
        return res


class Zehef(_CliTool):
    name = "zehef"; bin_name = "zehef"
    accepts = {EntityType.EMAIL}; timeout = 120.0

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        rc, out, err = await run_cmd(["zehef", value], timeout=self.timeout)
        return self.parse(out, value)

    def parse(self, out, value) -> CollectorResult:
        res = CollectorResult(source=self.name)
        ekey = f"email:{value.lower()}"
        # 발견 사이트(간단 라인 파싱).
        for m in re.findall(r"\[\+\]\s*([A-Za-z0-9]+)", out or ""):
            acc = Entity(EntityType.ACCOUNT, f"{m.lower()}/{value}", Certainty.CONFIRMED,
                         attrs={"site": m.lower(), "email": value},
                         evidence=[Evidence(self.name, f"{m} 계정(zehef)")])
            res.entities.append(acc)
            res.edges.append(Edge(ekey, acc.key, "가입 사이트", Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, "zehef")]))
        return res
