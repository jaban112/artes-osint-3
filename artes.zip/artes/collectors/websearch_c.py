"""실시간 웹 검색 수집(증분 29) — 검색엔진으로 대상 언급·프로필·유출 언급을 실시간 수집.

무키. DuckDuckGo HTML 엔드포인트로 실제 검색을 돌려 결과(제목·URL·스니펫)를 엔티티로:
- 소셜 도메인 URL → 계정 엔티티(+아이디 교차연결)
- 스니펫 속 이메일 → 이메일 엔티티
- 유출/페이스트 언급 검색 → 그 '페이지 URL'을 노출 참조로(평문 자격증명 아님 — 검토용 링크만)

씨앗 전용(depth 0)으로 비용을 묶는다(생성 후보마다 검색하면 폭주). 검색엔진 스크래핑은
rate-limit·차단될 수 있어 방어적으로(실패 시 조용히 빈 결과).
"""
from __future__ import annotations

import asyncio
import json as _json
import re
import urllib.parse

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from .base import Collector, CollectorResult
from .proc import get_text

# 소셜 도메인 → (사이트명, 핸들 추출 정규식)
_SOCIAL = [
    ("instagram", re.compile(r"instagram\.com/([A-Za-z0-9._]{2,40})/?$")),
    ("twitter", re.compile(r"(?:twitter|x)\.com/([A-Za-z0-9_]{2,30})/?$")),
    ("tiktok", re.compile(r"tiktok\.com/@([A-Za-z0-9._]{2,40})")),
    ("facebook", re.compile(r"facebook\.com/([A-Za-z0-9.]{3,50})/?$")),
    ("linkedin", re.compile(r"linkedin\.com/in/([A-Za-z0-9\-]{2,60})")),
    ("youtube", re.compile(r"youtube\.com/@([A-Za-z0-9._\-]{2,40})")),
    ("github", re.compile(r"github\.com/([A-Za-z0-9\-]{2,39})/?$")),
    ("telegram", re.compile(r"t\.me/([A-Za-z0-9_]{4,32})")),
    ("naver-blog", re.compile(r"blog\.naver\.com/([A-Za-z0-9_]{2,40})")),
    ("threads", re.compile(r"threads\.net/@([A-Za-z0-9._]{2,40})")),
]
_EMAIL_RE = re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}")


def _phone_formats(v: str) -> list[str]:
    """전화번호를 여러 표기로(E164·국제·국내·원본) — 검색 매칭률↑. phonenumbers 없으면 원본만."""
    out = [v]
    try:
        import phonenumbers as pn
        num = pn.parse(v if v.strip().startswith("+") else "+" + v, None)
        if pn.is_valid_number(num):
            F = pn.PhoneNumberFormat
            for f in (F.E164, F.INTERNATIONAL, F.NATIONAL):
                s = pn.format_number(num, f)
                if s and s not in out:
                    out.append(s)
    except Exception:
        pass
    return out


async def ddg_search(query: str, timeout: float = 12.0, limit: int = 10) -> list[dict]:
    """DuckDuckGo HTML 검색(무키). [{url, title, snippet}]. 실패 시 []."""
    q = urllib.parse.quote(query)
    html = await get_text(f"https://html.duckduckgo.com/html/?q={q}", timeout=timeout,
                          headers={"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) artes/1.0"})
    return parse_ddg(html or "")[:limit]


def parse_ddg(html: str) -> list[dict]:
    """DDG HTML → 결과 목록(파서 분리, 오프라인 검증)."""
    out = []
    # 결과 링크: <a class="result__a" href="...uddg=<encoded>...">TITLE</a>
    for m in re.finditer(r'<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>(.*?)</a>',
                         html, re.S):
        href, title = m.group(1), re.sub(r"<[^>]+>", "", m.group(2)).strip()
        url = _decode_ddg(href)
        if url:
            out.append({"url": url, "title": title, "snippet": ""})
    # 스니펫 매칭(순서 대응, 있는 만큼)
    snips = [re.sub(r"<[^>]+>", "", s).strip() for s in
             re.findall(r'<a[^>]+class="result__snippet"[^>]*>(.*?)</a>', html, re.S)]
    for i, s in enumerate(snips):
        if i < len(out):
            out[i]["snippet"] = s
    return out


def _decode_ddg(href: str) -> str:
    if "uddg=" in href:
        try:
            q = urllib.parse.parse_qs(urllib.parse.urlparse(href).query)
            return urllib.parse.unquote(q.get("uddg", [""])[0])
        except Exception:
            return ""
    if href.startswith("http"):
        return href
    return ""


# ── 다중 검색엔진(무키) — 병렬로 동시에 긁어 결과 합집합·중복제거 ──
_SEARX_INSTANCES = [
    "https://searx.be", "https://searx.tiekoetter.com", "https://search.rhscz.eu",
    "https://baresearch.org", "https://priv.au",
]


def parse_searx(obj) -> list[dict]:
    out = []
    for r in (obj or {}).get("results", []):
        u = r.get("url")
        if u:
            out.append({"url": u, "title": r.get("title", ""), "snippet": r.get("content", "")})
    return out


def parse_mojeek(html: str) -> list[dict]:
    out = []
    for m in re.finditer(r'<a[^>]+class="[^"]*ob[^"]*"[^>]+href="(https?://[^"]+)"[^>]*>(.*?)</a>',
                         html or "", re.S):
        out.append({"url": m.group(1), "title": re.sub(r"<[^>]+>", "", m.group(2)).strip(),
                    "snippet": ""})
    if not out:   # 폴백: results 블록의 외부 링크
        for m in re.finditer(r'<a[^>]+href="(https?://(?!www\.mojeek)[^"]+)"[^>]*>(.*?)</a>',
                             html or "", re.S):
            out.append({"url": m.group(1), "title": re.sub(r"<[^>]+>", "", m.group(2)).strip(),
                        "snippet": ""})
    return out


def parse_marginalia(obj) -> list[dict]:
    out = []
    for r in (obj or {}).get("results", []):
        u = r.get("url")
        if u:
            out.append({"url": u, "title": r.get("title", ""),
                        "snippet": r.get("description", "")})
    return out


async def _engine_ddg(q, timeout, limit):
    return (await ddg_search(q, timeout, limit))


async def _engine_mojeek(q, timeout, limit):
    html = await get_text(f"https://www.mojeek.com/search?q={urllib.parse.quote(q)}",
                          timeout=timeout, headers={"User-Agent": "Mozilla/5.0 artes/1.0"})
    return parse_mojeek(html or "")[:limit]


async def _one_searx(inst, q, timeout, limit):
    txt = await get_text(f"{inst.rstrip('/')}/search?q={urllib.parse.quote(q)}&format=json",
                         timeout=timeout, headers={"User-Agent": "Mozilla/5.0 artes/1.0"})
    if not txt:
        return []
    try:
        return parse_searx(_json.loads(txt))[:limit]
    except Exception:
        return []


async def _engine_searx(q, timeout, limit):
    """랭킹된 SearXNG 인스턴스 다수를 '동시에' 조회(각 인스턴스=수십 upstream 엔진). 합집합."""
    from ..core.searchpool import load_ranked
    insts = load_ranked(default_k=10)
    batches = await asyncio.gather(*[_one_searx(i, q, timeout, limit) for i in insts],
                                   return_exceptions=True)
    out, seen = [], set()
    for b in batches:
        if isinstance(b, Exception) or not b:
            continue
        for r in b:
            u = (r.get("url") or "").rstrip("/")
            if u and u not in seen:
                seen.add(u)
                out.append(r)
    return out[: limit * 4]


async def _engine_marginalia(q, timeout, limit):
    txt = await get_text("https://api.marginalia.nu/public/search/"
                         f"{urllib.parse.quote(q)}?count={limit}", timeout=timeout,
                         headers={"User-Agent": "artes/1.0"})
    if not txt:
        return []
    try:
        return parse_marginalia(_json.loads(txt))[:limit]
    except Exception:
        return []


async def multi_search(query: str, timeout: float = 12.0, limit: int = 12) -> list[dict]:
    """여러 검색엔진을 병렬로 동시에 조회 → 합집합·URL 중복제거. 훨씬 많은 결과·빠름."""
    engines = [_engine_ddg, _engine_searx, _engine_mojeek, _engine_marginalia]
    results = await asyncio.gather(*[e(query, timeout, limit) for e in engines],
                                   return_exceptions=True)
    merged, seen = [], set()
    for r in results:
        if isinstance(r, Exception) or not r:
            continue
        for item in r:
            u = (item.get("url") or "").rstrip("/")
            if u and u not in seen:
                seen.add(u)
                merged.append(item)
    return merged


def _emit_results(res, subj_key, results, source, tag):
    """검색 결과 → URL 엔티티 + 소셜계정·이메일 추출."""
    for r in results:
        url = r.get("url", "")
        if not url:
            continue
        res.entities.append(Entity(EntityType.URL, url, Certainty.UNCONFIRMED, confidence=0.4,
                            evidence=[Evidence(source, f"{tag}: {r.get('title','')[:80]}", url=url)]))
        res.edges.append(Edge(subj_key, f"url:{url}", tag, Certainty.UNCONFIRMED,
                              confidence=0.4, evidence=[Evidence(source, "검색 결과")]))
        # 소셜 계정 추출
        for site, rx in _SOCIAL:
            m = rx.search(url)
            if m:
                handle = m.group(1)
                a = Entity(EntityType.ACCOUNT, f"{site}/{handle}", Certainty.UNCONFIRMED,
                           confidence=0.5,
                           evidence=[Evidence(source, f"검색서 발견한 {site} 프로필", url=url)],
                           attrs={"site": site, "handle": handle, "url": url})
                res.entities.append(a)
                res.edges.append(Edge(subj_key, a.key, "검색 발견 계정", Certainty.UNCONFIRMED,
                                      confidence=0.5, evidence=[Evidence(source, tag)]))
                res.entities.append(Entity(EntityType.USERNAME, handle, Certainty.UNCONFIRMED,
                                    confidence=0.4, evidence=[Evidence(source, "검색 발견 아이디")]))
                break
        # 스니펫 속 이메일
        for em in set(_EMAIL_RE.findall(r.get("snippet", "") or "")):
            res.entities.append(Entity(EntityType.EMAIL, em.lower(), Certainty.UNCONFIRMED,
                                confidence=0.4, evidence=[Evidence(source, "검색 스니펫 이메일")]))
            res.edges.append(Edge(subj_key, f"email:{em.lower()}", "검색 발견 이메일",
                                  Certainty.UNCONFIRMED, confidence=0.4,
                                  evidence=[Evidence(source, tag)]))


class WebMentions(Collector):
    """실시간 웹 검색 — 대상 언급·프로필·이메일 수집(무키 DuckDuckGo). 씨앗 전용."""
    name = "web-mentions"; timeout = 12.0
    accepts = {EntityType.NAME, EntityType.EMAIL, EntityType.USERNAME, EntityType.PHONE}

    def _queries(self, value, et):
        v = value.strip()
        if et == EntityType.NAME:
            return [f'"{v}"', f'"{v}" instagram OR twitter OR linkedin OR facebook']
        if et == EntityType.EMAIL:
            return [f'"{v}"', f'"{v}" profile OR account']
        if et == EntityType.USERNAME:
            return [f'"{v}"', f'"{v}" instagram OR tiktok OR github OR twitter']
        if et == EntityType.PHONE:
            # 여러 표기(국내·국제·E164)로 검색 → 유출 목록·업체록·게시글서 더 많이 매칭.
            return [f'"{f}"' for f in _phone_formats(v)][:4] or [f'"{v}"']
        return [f'"{v}"']

    async def collect(self, value, entity_type, ctx):
        res = CollectorResult(source=self.name)
        if (ctx or {}).get("depth", 0) > 0:      # 씨앗만(후보마다 검색 방지)
            res.skipped = True; res.error = "씨앗 전용(검색)"
            return res
        subj = f"{entity_type.value}:{value.lower()}"
        # 여러 검색어 × 여러 엔진을 전부 병렬로(빠르고 대량).
        batches = await asyncio.gather(
            *[multi_search(q, self.timeout, limit=12) for q in self._queries(value, entity_type)],
            return_exceptions=True)
        got, seen = False, set()
        for results in batches:
            if isinstance(results, Exception) or not results:
                continue
            dedup = [r for r in results if (r.get("url") or "").rstrip("/") not in seen]
            for r in dedup:
                seen.add((r.get("url") or "").rstrip("/"))
            if dedup:
                got = True
                _emit_results(res, subj, dedup, self.name, "웹 언급")
        if not got:
            res.ok = False; res.error = "검색 무결과/차단"
        return res

    def parse(self, html, value, entity_type=EntityType.NAME):
        """오프라인 검증용: DDG HTML + subj로 엔티티 생성."""
        res = CollectorResult(source=self.name)
        subj = f"{entity_type.value}:{value.lower()}"
        _emit_results(res, subj, parse_ddg(html), self.name, "웹 언급")
        return res


class LeakMentions(Collector):
    """유출/페이스트 '언급' 실시간 검색(무키) — 노출된 페이지 URL(검토용). 평문 자격증명 아님.

    '이 이메일/아이디가 유출·페이스트·덤프 페이지에 언급됐는가'를 검색으로 표면화. 결과는
    그 페이지 링크(노출 참조)만 — ARTES는 원문 비밀번호를 가져오거나 저장하지 않는다.
    """
    name = "leak-mentions"; timeout = 12.0
    accepts = {EntityType.EMAIL, EntityType.USERNAME}

    async def collect(self, value, entity_type, ctx):
        res = CollectorResult(source=self.name)
        if (ctx or {}).get("depth", 0) > 0:
            res.skipped = True; res.error = "씨앗 전용(검색)"
            return res
        subj = f"{entity_type.value}:{value.lower()}"
        # 유출/페이스트 언급 검색어 여러 개를 다중 엔진 병렬로.
        queries = [
            f'"{value.strip()}" (leak OR breach OR pastebin OR dump OR combolist)',
            f'"{value.strip()}" (paste OR leaked OR "데이터 유출")',
        ]
        batches = await asyncio.gather(
            *[multi_search(q, self.timeout, limit=12) for q in queries],
            return_exceptions=True)
        seen, any_hit = set(), False
        for results in batches:
            if isinstance(results, Exception) or not results:
                continue
            dedup = [r for r in results if (r.get("url") or "").rstrip("/") not in seen]
            for r in dedup:
                seen.add((r.get("url") or "").rstrip("/"))
            if dedup:
                any_hit = True
                self._emit(res, subj, dedup)
        if not any_hit:
            res.ok = False; res.error = "유출 언급 무결과/차단"
        return res

    def _emit(self, res, subj, results):
        for r in results:
            url = r.get("url", "")
            if not url:
                continue
            res.entities.append(Entity(EntityType.URL, url, Certainty.UNCONFIRMED, confidence=0.4,
                                evidence=[Evidence(self.name, f"유출 언급(검토 필요): {r.get('title','')[:70]}",
                                                   url=url)], attrs={"leak_reference": True}))
            res.edges.append(Edge(subj, f"url:{url}", "유출 언급(후보)", Certainty.UNCONFIRMED,
                                  confidence=0.4, evidence=[Evidence(self.name, "검색 표면화")]))

    def parse(self, html, value, entity_type=EntityType.EMAIL):
        res = CollectorResult(source=self.name)
        subj = f"{entity_type.value}:{value.lower()}"
        self._emit(res, subj, parse_ddg(html))
        return res
