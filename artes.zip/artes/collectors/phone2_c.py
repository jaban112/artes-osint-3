"""전화 정보(순수) — phonenumbers 라이브러리. 바이너리·네트워크·키 불필요, 오프라인.

번호에서 국가·통신사·회선종류(휴대/유선/VoIP)·시간대를 뽑는다. phoneinfoga 없이도
동작하고, 시간대는 활동 추론·번호 국가는 밴딧 라우팅(그 나라 SNS 우선)에 쓰인다.
"""
from __future__ import annotations

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from .base import Collector, CollectorResult


class PhoneInfo(Collector):
    name = "phoneinfo"
    accepts = {EntityType.PHONE}
    needs_network = False

    def available(self) -> bool:
        try:
            import phonenumbers  # noqa
            return True
        except Exception:
            return False

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        import phonenumbers
        from phonenumbers import carrier, geocoder, timezone, number_type, PhoneNumberType
        res = CollectorResult(source=self.name)
        try:
            num = phonenumbers.parse(value if value.strip().startswith("+") else "+" + value, None)
        except Exception:
            res.ok = False
            res.error = "번호 파싱 실패"
            return res
        if not phonenumbers.is_valid_number(num):
            res.skipped = True
            res.error = "유효하지 않은 번호"
            return res
        types = {PhoneNumberType.MOBILE: "휴대폰", PhoneNumberType.FIXED_LINE: "유선",
                 PhoneNumberType.VOIP: "VoIP", PhoneNumberType.FIXED_LINE_OR_MOBILE: "유선/휴대",
                 PhoneNumberType.TOLL_FREE: "무료전화", PhoneNumberType.PREMIUM_RATE: "프리미엄"}
        fmt = phonenumbers.format_number
        F = phonenumbers.PhoneNumberFormat
        region_code = phonenumbers.region_code_for_number(num) or ""
        geo = (geocoder.description_for_number(num, "ko") or
               geocoder.description_for_number(num, "en") or "")
        carr = carrier.name_for_number(num, "en") or carrier.name_for_number(num, "ko") or ""
        attrs = {
            "country": geo,
            "region_code": region_code,
            "carrier": carr,
            "line_type": types.get(number_type(num), "기타"),
            "timezones": list(timezone.time_zones_for_number(num)),
            "country_code": str(num.country_code),
            "e164": fmt(num, F.E164),
            "national": fmt(num, F.NATIONAL),
            "international": fmt(num, F.INTERNATIONAL),
            "rfc3966": fmt(num, F.RFC3966),
        }
        ent = Entity(EntityType.PHONE, value, Certainty.CONFIRMED,
                     evidence=[Evidence(self.name,
                               f"{geo or region_code} · {carr or '통신사미상'} · "
                               f"{attrs['line_type']} · {', '.join(attrs['timezones'][:2])}")],
                     attrs=attrs)
        res.entities.append(ent)
        pkey = ent.key
        # 지역 → GEO 엔티티(위치 상관에 사용). 통신사 → ORG(같은 통신사 신호).
        if geo:
            res.entities.append(Entity(EntityType.GEO, geo, Certainty.UNCONFIRMED, confidence=0.6,
                                evidence=[Evidence(self.name, "번호 등록 지역")]))
            res.edges.append(Edge(pkey, f"geo:{geo.lower()}", "번호 지역", Certainty.UNCONFIRMED,
                                  confidence=0.6, evidence=[Evidence(self.name, "phonenumbers")]))
        if carr:
            res.entities.append(Entity(EntityType.ORG, carr, Certainty.CONFIRMED,
                                evidence=[Evidence(self.name, "통신사")], attrs={"kind": "carrier"}))
            res.edges.append(Edge(pkey, f"org:{carr.lower()}", "통신사", Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, "phonenumbers")]))
        return res
