"""전화 정보(순수) — phonenumbers 라이브러리. 바이너리·네트워크·키 불필요, 오프라인.

번호에서 국가·통신사·회선종류(휴대/유선/VoIP)·시간대를 뽑는다. phoneinfoga 없이도
동작하고, 시간대는 활동 추론·번호 국가는 밴딧 라우팅(그 나라 SNS 우선)에 쓰인다.
"""
from __future__ import annotations

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from .base import Collector, CollectorResult


class PhoneInfo(Collector):
    name = "phoneinfo"
    accepts = {EntityType.PHONE}
    needs_network = False

    def available(self) -> bool:
        try:
            import phonenumbers  # noqa
            return True
        except Exception:
            return False

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        import phonenumbers
        from phonenumbers import carrier, geocoder, timezone, number_type, PhoneNumberType
        res = CollectorResult(source=self.name)
        try:
            num = phonenumbers.parse(value if value.strip().startswith("+") else "+" + value, None)
        except Exception:
            res.ok = False
            res.error = "번호 파싱 실패"
            return res
        if not phonenumbers.is_valid_number(num):
            res.skipped = True
            res.error = "유효하지 않은 번호"
            return res
        types = {PhoneNumberType.MOBILE: "휴대폰", PhoneNumberType.FIXED_LINE: "유선",
                 PhoneNumberType.VOIP: "VoIP", PhoneNumberType.FIXED_LINE_OR_MOBILE: "유선/휴대",
                 PhoneNumberType.TOLL_FREE: "무료전화", PhoneNumberType.PREMIUM_RATE: "프리미엄"}
        attrs = {
            "country": geocoder.description_for_number(num, "ko") or
                       geocoder.description_for_number(num, "en"),
            "carrier": carrier.name_for_number(num, "en") or "",
            "line_type": types.get(number_type(num), "기타"),
            "timezones": list(timezone.time_zones_for_number(num)),
            "country_code": str(num.country_code),
            "e164": phonenumbers.format_number(num, phonenumbers.PhoneNumberFormat.E164),
        }
        pkey = f"phone:{attrs['e164'] if attrs['e164'].startswith('+') else value}"
        ent = Entity(EntityType.PHONE, value, Certainty.CONFIRMED,
                     evidence=[Evidence(self.name,
                               f"{attrs['country']} · {attrs['carrier'] or '통신사미상'} · "
                               f"{attrs['line_type']}")],
                     attrs=attrs)
        res.entities.append(ent)
        return res
