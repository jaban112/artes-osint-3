"""평가 하네스 + 신뢰도 교정 — "신뢰도 0.7"이 진짜 0.7이 되게.

라벨된 합성 케이스(정답 동일인 쌍을 아는)로 동일인 해소의 정밀도/재현율/F1을
임계값별로 측정하고, 각 신호의 우도비(LR)를 데이터에서 경험적으로 교정한다.
"""
from __future__ import annotations

import random
from itertools import combinations

from .core.model import Graph, Entity, Edge, EntityType, Certainty, Evidence
from .core.resolve import EntityResolver


def build_eval_graph(n_people: int = 8, seed: int = 0) -> tuple[Graph, set]:
    """합성 그래프 + 정답 동일인 쌍(entity key frozenset 집합)."""
    rng = random.Random(seed)
    g = Graph()
    gold = set()
    first = ["jiwan", "minsu", "alex", "sara", "kim", "lee", "park", "hana",
             "tom", "yuna", "raj", "mei"]
    for i in range(n_people):
        base = first[i % len(first)] + str(i)
        email = f"{base}@mail{i}.com"
        em = g.add(Entity(EntityType.EMAIL, email, Certainty.CONFIRMED, evidence=[Evidence("t", "")]))
        keys = []
        n_acc = rng.randint(2, 4)
        for j in range(n_acc):
            site = ["github", "twitter", "reddit", "gitlab"][j % 4]
            # 절반은 이메일 공유(하드), 절반은 이름유사만(소프트)
            share_email = (j % 2 == 0)
            handle = base if j == 0 else base + ("_" + str(j) if rng.random() < .5 else str(j))
            acc = g.add(Entity(EntityType.ACCOUNT, f"{site}/{handle}", Certainty.CONFIRMED,
                               attrs={"handle": handle}, evidence=[Evidence("t", "")]))
            keys.append(acc.key)
            if share_email:
                g.link(Edge(em.key, acc.key, "가진 계정", Certainty.CONFIRMED,
                            evidence=[Evidence("t", "")]))
        for a, b in combinations(keys, 2):
            gold.add(frozenset((a, b)))
    return g, gold


def predicted_pairs(graph: Graph, threshold: float) -> set:
    pairs = set()
    for e in graph.edges:
        if e.relation == "동일인":
            pairs.add(frozenset((e.src, e.dst)))
        elif e.relation == "동일인?" and (e.confidence or 0) >= threshold:
            pairs.add(frozenset((e.src, e.dst)))
    return pairs


def evaluate(graph: Graph, gold: set, threshold: float = 0.5) -> dict:
    EntityResolver().correlate(graph)
    pred = predicted_pairs(graph, threshold)
    tp = len(pred & gold)
    fp = len(pred - gold)
    fn = len(gold - pred)
    prec = tp / (tp + fp) if (tp + fp) else 1.0
    rec = tp / (tp + fn) if (tp + fn) else 1.0
    f1 = 2 * prec * rec / (prec + rec) if (prec + rec) else 0.0
    return {"threshold": threshold, "tp": tp, "fp": fp, "fn": fn,
            "precision": round(prec, 3), "recall": round(rec, 3), "f1": round(f1, 3)}


def sweep(n_people: int = 8, seed: int = 0,
          thresholds=(0.1, 0.3, 0.5, 0.7, 0.9)) -> list[dict]:
    out = []
    for t in thresholds:
        g, gold = build_eval_graph(n_people, seed)
        out.append(evaluate(g, gold, t))
    return out


def calibrate_lr(n_people: int = 20, seed: int = 1) -> dict:
    """각 신호의 경험적 우도비 LR = P(신호|동일)/P(신호|타인)."""
    from .core.similarity import MinHash, jaccard_ci, shingles
    g, gold = build_eval_graph(n_people, seed)
    idents = [e for e in g.entities if e.type in (EntityType.NAME, EntityType.USERNAME, EntityType.ACCOUNT)]
    mh = MinHash()
    sigs = {e.key: mh.sign_tokens(shingles(str(e.attrs.get("handle") or e.value), 3)) for e in idents}
    same_hits = diff_hits = same_tot = diff_tot = 0
    for a, b in combinations(idents, 2):
        is_same = frozenset((a.key, b.key)) in gold
        sim = jaccard_ci(sigs[a.key], sigs[b.key])["lower"]
        hit = sim >= 0.5
        if is_same:
            same_tot += 1; same_hits += hit
        else:
            diff_tot += 1; diff_hits += hit
    p_same = (same_hits + 1) / (same_tot + 2)
    p_diff = (diff_hits + 1) / (diff_tot + 2)
    return {"signal": "name_sim", "p_given_same": round(p_same, 3),
            "p_given_diff": round(p_diff, 3),
            "empirical_lr": round(p_same / p_diff, 2) if p_diff else None}
