"""HyperLogLog·Count-Min 스케치 — 7권 축 2. 규모 파악 전용(확실 아님).

두 구조 다 오차가 구조적으로 0이 아니다 → ARTES의 "확실" 판정엔 못 쓴다.
"고유 계정 수 약 X", "이 아이디 언급 대략 Y" 같은 **규모 파악**에만 쓰고,
결과는 항상 불확실로 라벨한다(5권 M3 축 분리 계승).
"""
from __future__ import annotations

import hashlib
import math


def _hash64(item: str) -> int:
    return int.from_bytes(hashlib.blake2b(item.encode("utf-8"), digest_size=8).digest(), "big")


class HyperLogLog:
    """고유 개수 추정. 상대표준오차 ≈ 1.04/√m (m = 2^p)."""

    def __init__(self, p: int = 14):
        self.p = p
        self.m = 1 << p
        self.reg = bytearray(self.m)
        if self.m == 16:
            self.alpha = 0.673
        elif self.m == 32:
            self.alpha = 0.697
        elif self.m == 64:
            self.alpha = 0.709
        else:
            self.alpha = 0.7213 / (1 + 1.079 / self.m)

    def add(self, item: str) -> None:
        x = _hash64(item)
        idx = x >> (64 - self.p)
        rest = x & ((1 << (64 - self.p)) - 1)       # 인덱스 뒤 남은 비트
        # rho = 남은 (64-p)비트에서 최좌 1의 위치(선행 0 개수 + 1).
        rho = (64 - self.p) - rest.bit_length() + 1 if rest else (64 - self.p + 1)
        if rho > self.reg[idx]:
            self.reg[idx] = rho

    def count(self) -> int:
        s = sum(2.0 ** (-r) for r in self.reg)
        e = self.alpha * self.m * self.m / s
        if e <= 2.5 * self.m:                       # 소범위 선형 카운팅 보정
            zeros = self.reg.count(0)
            if zeros:
                e = self.m * math.log(self.m / zeros)
        return int(round(e))

    def relative_std_error(self) -> float:
        return 1.04 / math.sqrt(self.m)


class CountMin:
    """빈도 근사(과대추정만). P(ĉ−c ≤ εN) ≥ 1−δ."""

    def __init__(self, epsilon: float = 0.001, delta: float = 0.01):
        self.w = max(2, math.ceil(math.e / epsilon))
        self.d = max(1, math.ceil(math.log(1 / delta)))
        self.table = [[0] * self.w for _ in range(self.d)]
        self.epsilon, self.delta = epsilon, delta
        self.total = 0

    def _cols(self, item: str):
        h = hashlib.blake2b(item.encode("utf-8"), digest_size=16).digest()
        h1 = int.from_bytes(h[:8], "big")
        h2 = int.from_bytes(h[8:], "big") | 1
        for i in range(self.d):
            yield (h1 + i * h2) % self.w

    def add(self, item: str, count: int = 1) -> None:
        for i, c in enumerate(self._cols(item)):
            self.table[i][c] += count
        self.total += count

    def estimate(self, item: str) -> int:
        return min(self.table[i][c] for i, c in enumerate(self._cols(item)))

    def error_bound(self) -> float:
        return self.epsilon * self.total
