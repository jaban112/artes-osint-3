"""Aho-Corasick 다중 패턴 매칭 — 7권 축 3.

표적의 이름·이메일·아이디·번호 수백 개를 대량 텍스트(다크웹 크롤·유출 덤프)에서
**단 한 번의 스캔**으로 전부 찾는다. 선형 시간 O(|T|+Σ|p|+z), 위음성 0·위양성 0.
아카이빙(2권) 접미사 오토마톤과 같은 결정적 전이 계열.
"""
from __future__ import annotations

from collections import deque


class AhoCorasick:
    def __init__(self, patterns=None, case_insensitive: bool = True):
        self.ci = case_insensitive
        self.goto = [{}]            # 상태별 전이
        self.fail = [0]
        self.out = [[]]             # 상태에서 끝나는 패턴 인덱스
        self.patterns: list[str] = []
        self._built = False
        for p in (patterns or []):
            self.add(p)

    def _norm(self, s: str) -> str:
        return s.casefold() if self.ci else s

    def add(self, pattern: str) -> None:
        if not pattern:
            return
        idx = len(self.patterns)
        self.patterns.append(pattern)
        s = 0
        for ch in self._norm(pattern):
            nxt = self.goto[s].get(ch)
            if nxt is None:
                nxt = len(self.goto)
                self.goto.append({}); self.fail.append(0); self.out.append([])
                self.goto[s][ch] = nxt
            s = nxt
        self.out[s].append(idx)
        self._built = False

    def build(self) -> "AhoCorasick":
        q = deque()
        for ch, s in self.goto[0].items():
            self.fail[s] = 0
            q.append(s)
        while q:
            r = q.popleft()
            for ch, s in self.goto[r].items():
                q.append(s)
                f = self.fail[r]
                while f and ch not in self.goto[f]:
                    f = self.fail[f]
                self.fail[s] = self.goto[f].get(ch, 0) if f or ch in self.goto[0] else 0
                if self.fail[s] == s:
                    self.fail[s] = 0
                self.out[s] += self.out[self.fail[s]]
        self._built = True
        return self

    def search(self, text: str):
        """(끝위치, 패턴, 패턴인덱스) 목록. 한 번의 스캔."""
        if not self._built:
            self.build()
        hits = []
        s = 0
        for i, ch in enumerate(self._norm(text)):
            while s and ch not in self.goto[s]:
                s = self.fail[s]
            s = self.goto[s].get(ch, 0)
            for idx in self.out[s]:
                hits.append((i, self.patterns[idx], idx))
        return hits

    def found_patterns(self, text: str) -> set[str]:
        return {self.patterns[idx] for _, _, idx in self.search(text)}
