"""Bloom 필터 — 7권 축 4. 위음성 0(구성), 위양성 인증.

ARTES 재귀 확장에서 "이 값 이미 조회했나"를 극소 메모리로 즉답 → 무한루프·중복조회
차단. 위음성 0이므로 조회한 것을 "안 했다"고 오판하지 않는다(루프 차단 보장).
최적 해시 수 k* = (m/n)ln2, 위양성률 ≈ 0.6185^(m/n).
"""
from __future__ import annotations

import hashlib
import math


class BloomFilter:
    def __init__(self, capacity: int = 100000, error_rate: float = 0.01):
        capacity = max(1, capacity)
        # m = -n ln p / (ln2)^2, k = (m/n) ln2 (정리 B4 최적)
        self.m = max(8, int(-capacity * math.log(error_rate) / (math.log(2) ** 2)))
        self.k = max(1, round((self.m / capacity) * math.log(2)))
        self.capacity = capacity
        self.n = 0
        self.bits = bytearray((self.m + 7) // 8)

    def _hashes(self, item: str):
        h = hashlib.blake2b(item.encode("utf-8"), digest_size=16).digest()
        h1 = int.from_bytes(h[:8], "big")
        h2 = int.from_bytes(h[8:], "big") | 1
        for i in range(self.k):
            yield (h1 + i * h2) % self.m

    def add(self, item: str) -> None:
        for pos in self._hashes(item):
            self.bits[pos >> 3] |= (1 << (pos & 7))
        self.n += 1

    def __contains__(self, item: str) -> bool:
        return all(self.bits[pos >> 3] & (1 << (pos & 7)) for pos in self._hashes(item))

    def add_if_absent(self, item: str) -> bool:
        """없으면 추가하고 True(=새것), 이미 있으면 False. dedup 원자연산."""
        if item in self:
            return False
        self.add(item)
        return True

    def expected_fp_rate(self) -> float:
        if self.n == 0:
            return 0.0
        return (1 - math.exp(-self.k * self.n / self.m)) ** self.k

    def stats(self) -> dict:
        return {"m_bits": self.m, "k": self.k, "n": self.n,
                "fp_rate": round(self.expected_fp_rate(), 6)}
