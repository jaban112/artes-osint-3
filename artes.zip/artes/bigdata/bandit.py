"""다중 슬롯머신 라우팅 — 7권 축 5. 첫 유효결과까지 시간 단축.

도구별 '첫 히트 성공률'을 경험에서 학습해, 조회 순서·우선순위를 정한다.
후회 상계(UCB1: R(T) ≤ 8Σ lnT/Δ + (1+π²/3)ΣΔ)가 탐색-활용 균형을 보증.
학습 상태는 ~/.artes/bandit.json 에 지속(여러 실행에 걸쳐 개선).

이득만 담당한다 — 각 도구 출력의 안전·정확은 워런팅/근거강제가 담당(5권 정합).
"""
from __future__ import annotations

import json
import math
import os
import random
from pathlib import Path


class Bandit:
    def __init__(self, path: str | None = None, mode: str = "ucb1"):
        self.path = Path(path) if path else (Path.home() / ".artes" / "bandit.json")
        self.mode = mode
        self.pulls: dict[str, int] = {}
        self.hits: dict[str, float] = {}
        self._load()

    def _load(self):
        try:
            d = json.loads(self.path.read_text("utf-8"))
            self.pulls = {k: int(v) for k, v in d.get("pulls", {}).items()}
            self.hits = {k: float(v) for k, v in d.get("hits", {}).items()}
        except Exception:
            pass

    def save(self):
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self.path.write_text(json.dumps({"pulls": self.pulls, "hits": self.hits}),
                                 "utf-8")
        except Exception:
            pass

    @property
    def t(self) -> int:
        return sum(self.pulls.values())

    def rate(self, arm: str) -> float:
        n = self.pulls.get(arm, 0)
        return (self.hits.get(arm, 0.0) / n) if n else 0.0

    def _ucb(self, arm: str) -> float:
        n = self.pulls.get(arm, 0)
        if n == 0:
            return float("inf")          # 미시도는 먼저 탐색
        return self.rate(arm) + math.sqrt(2 * math.log(max(2, self.t)) / n)

    def _thompson(self, arm: str) -> float:
        h = self.hits.get(arm, 0.0)
        n = self.pulls.get(arm, 0)
        return random.betavariate(h + 1, (n - h) + 1)

    def score(self, arm: str) -> float:
        return self._thompson(arm) if self.mode == "thompson" else self._ucb(arm)

    def order(self, arms: list[str]) -> list[str]:
        """우선순위 높은 순으로 정렬(같은 병렬 발사여도 첫 배치·자원 우선)."""
        return sorted(arms, key=lambda a: self.score(a), reverse=True)

    def update(self, arm: str, hit: bool) -> None:
        self.pulls[arm] = self.pulls.get(arm, 0) + 1
        self.hits[arm] = self.hits.get(arm, 0.0) + (1.0 if hit else 0.0)

    # 통일 인터페이스(전역 밴딧은 컨텍스트 무시).
    def order_for(self, entity_type: str, value: str, arms: list[str]) -> list[str]:
        return self.order(arms)

    def update_for(self, entity_type: str, value: str, arm: str, hit: bool) -> None:
        self.update(arm, hit)

    def stats(self) -> dict:
        return {a: {"pulls": self.pulls.get(a, 0), "rate": round(self.rate(a), 3)}
                for a in sorted(self.pulls)}


def context_key(entity_type: str, value: str) -> str:
    """표적 특징(feature) — 이 유형엔 이 순서가 첫 히트가 빠르다를 조건별로 학습."""
    import re
    v = (value or "")
    if entity_type == "username":
        dev = any(t in v.lower() for t in ("dev", "code", "git", "hack", "sec", "_"))
        return "username:dev" if dev else "username:plain"
    if entity_type == "phone":
        d = re.sub(r"\D", "", v)
        cc = "82" if d.startswith("82") or v.startswith("+82") else (d[:2] if len(d) > 8 else "??")
        return f"phone:{cc}"
    if entity_type == "domain":
        return "domain"
    return entity_type


class ContextualBandit:
    """조건부 밴딧 — 표적 특징별 별도 학습, 미학습 특징은 전역으로 폴백."""

    def __init__(self, path: str | None = None, mode: str = "ucb1"):
        from pathlib import Path
        self.path = Path(path) if path else (Path.home() / ".artes" / "cbandit.json")
        self.mode = mode
        self.by_ctx: dict[str, Bandit] = {}
        self.global_ = Bandit(path=str(self.path) + ".global", mode=mode)

    def _ctx(self, ctx_key: str) -> Bandit:
        if ctx_key not in self.by_ctx:
            b = Bandit(path=f"{self.path}.{_safe(ctx_key)}", mode=self.mode)
            self.by_ctx[ctx_key] = b
        return self.by_ctx[ctx_key]

    def order(self, ctx_key: str, arms: list[str]) -> list[str]:
        b = self._ctx(ctx_key)
        if b.t < len(arms):                    # 아직 미학습 → 전역으로
            return self.global_.order(arms)
        return b.order(arms)

    def update(self, ctx_key: str, arm: str, hit: bool) -> None:
        self._ctx(ctx_key).update(arm, hit)
        self.global_.update(arm, hit)

    def order_for(self, entity_type: str, value: str, arms: list[str]) -> list[str]:
        return self.order(context_key(entity_type, value), arms)

    def update_for(self, entity_type: str, value: str, arm: str, hit: bool) -> None:
        self.update(context_key(entity_type, value), arm, hit)

    def save(self) -> None:
        self.global_.save()
        for b in self.by_ctx.values():
            b.save()


def _safe(s: str) -> str:
    import re
    return re.sub(r"[^a-zA-Z0-9_]", "_", s)
