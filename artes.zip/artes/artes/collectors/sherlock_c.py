"""sherlock 래퍼 — 아이디로 계정 탐색(키 불필요). maigret와 상호보완."""
from __future__ import annotations

import re

from ..core.model import Entity, Edge, EntityType, Certainty, Evidence
from .base import Collector, CollectorResult
from .proc import which, run_cmd

# sherlock --print-found 는 "[+] Site: https://..." 로 찍는다.
_HIT = re.compile(r"^\[\+\]\s+(.+?):\s+(https?://\S+)")


class Sherlock(Collector):
    name = "sherlock"
    accepts = {EntityType.USERNAME}
    timeout = 60.0

    def available(self) -> bool:
        return which("sherlock") is not None

    async def collect(self, value, entity_type, ctx) -> CollectorResult:
        res = CollectorResult(source=self.name)
        rc, out, err = await run_cmd(
            ["sherlock", value, "--print-found", "--no-color", "--timeout", "20"],
            timeout=self.timeout,
        )
        if rc != 0 and not out:
            res.ok = False
            res.error = err.strip()[:200] or f"rc={rc}"
            return res
        src_key = f"username:{value.lower()}"
        for line in out.splitlines():
            m = _HIT.match(line.strip())
            if not m:
                continue
            site, url = m.group(1).strip(), m.group(2).strip()
            acc = Entity(EntityType.ACCOUNT, f"{site}/{value}", Certainty.CONFIRMED,
                         evidence=[Evidence(self.name, f"{site}에 '{value}'", url=url)],
                         attrs={"site": site, "handle": value, "url": url})
            res.entities.append(acc)
            res.edges.append(Edge(src_key, acc.key, "가진 계정", Certainty.CONFIRMED,
                                  evidence=[Evidence(self.name, "sherlock 확인", url=url)]))
        return res
