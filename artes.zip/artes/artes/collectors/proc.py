"""서브프로세스·HTTP 실행 헬퍼 — 비동기, 타임아웃, 실패 안전."""
from __future__ import annotations

import asyncio
import json as _json
import shutil
import urllib.request


def which(binary: str) -> str | None:
    return shutil.which(binary)


async def run_cmd(cmd: list[str], timeout: float = 30.0,
                  stdin: str | None = None) -> tuple[int, str, str]:
    """(returncode, stdout, stderr). 타임아웃이면 rc=-1, stderr='timeout'."""
    proc = await asyncio.create_subprocess_exec(
        *cmd,
        stdin=asyncio.subprocess.PIPE if stdin is not None else None,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    try:
        out, err = await asyncio.wait_for(
            proc.communicate(stdin.encode() if stdin is not None else None),
            timeout=timeout,
        )
    except asyncio.TimeoutError:
        try:
            proc.kill()
        except ProcessLookupError:
            pass
        await proc.wait()
        return -1, "", "timeout"
    return proc.returncode, out.decode("utf-8", "replace"), err.decode("utf-8", "replace")


def _build_opener(proxy: str | None):
    if not proxy:
        return urllib.request.build_opener()
    if proxy.startswith("socks"):
        try:
            import socks  # PySocks
            from urllib.parse import urlparse as _up
            u = _up(proxy)
            import socket as _s
            socks.set_default_proxy(socks.SOCKS5, u.hostname, u.port or 9050, rdns=True)
            _s.socket = socks.socksocket   # 프로세스 전역(단순화)
            return urllib.request.build_opener()
        except Exception:
            return urllib.request.build_opener()
    return urllib.request.build_opener(
        urllib.request.ProxyHandler({"http": proxy, "https": proxy}))


# 속도 계층(증분 11): 인메모리 TTL 캐시 + 요청 합류(동일 URL in-flight 1회로).
from ..core.adaptive import SingleFlight as _SingleFlight, TTLCache as _TTLCache
_MEMCACHE = _TTLCache(maxsize=8192, ttl=300.0)
_SINGLEFLIGHT = _SingleFlight()


async def get_text(url: str, timeout: float = 30.0,
                   headers: dict | None = None, use_memcache: bool = True) -> str | None:
    """비동기 HTTP GET(텍스트). 메모리캐시→합류→(rate-limit+백오프+프록시) 네트워크.

    고정점 반복이 같은 URL을 반복 조회해도 메모리캐시/합류로 네트워크는 1회만.
    """
    if use_memcache:
        cached = _MEMCACHE.get(url)
        if cached is not None:
            return cached if cached != "\x00None" else None

    from ..core.politeness import POLICY, host_of, with_retry

    def _fetch():
        proxy = POLICY.next_proxy()
        opener = _build_opener(proxy)
        req = urllib.request.Request(url, headers=headers or {"User-Agent": "artes/0.1"})
        try:
            with opener.open(req, timeout=timeout) as r:
                return r.read().decode("utf-8", "replace")
        except Exception:
            return None

    async def _do():
        await POLICY.limiter.acquire(host_of(url))

        async def _once():
            return await asyncio.get_event_loop().run_in_executor(None, _fetch)
        return await with_retry(_once)

    result = await _SINGLEFLIGHT.do(url, _do)
    if use_memcache:
        _MEMCACHE.put(url, result if result is not None else "\x00None")
    return result


async def get_json(url: str, timeout: float = 30.0, headers: dict | None = None):
    """비동기 HTTP GET(JSON). 실패 시 None."""
    txt = await get_text(url, timeout, headers)
    if txt is None:
        return None
    try:
        return _json.loads(txt)
    except Exception:
        return None


async def get_bytes(url: str, timeout: float = 20.0,
                    max_bytes: int = 5_000_000) -> bytes | None:
    """비동기 HTTP GET(바이너리, 이미지 등). 실패 시 None."""
    def _fetch():
        req = urllib.request.Request(url, headers={"User-Agent": "artes/0.1"})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.read(max_bytes)
        except Exception:
            return None
    return await asyncio.get_event_loop().run_in_executor(None, _fetch)
