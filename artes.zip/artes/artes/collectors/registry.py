"""수집기 레지스트리 — 전 축 기본 구성.

축: 표층 · 전화 · 네트워크 · 인프라(RDAP·crt.sh·DNS) · 개발자(GitHub) ·
웹지문(분석ID·파비콘) · 능동확장(순열·Gravatar·이름추정) · 다크웹 · 유출.
real=True 면 실제 도구/HTTP 래퍼(미가용이면 자동 skip),
include_mock=True 면 오프라인 목도(테스트/데모). 다크웹은 enable_darkweb=True.
"""
from __future__ import annotations

from .base import Collector
from .holehe_c import Holehe
from .maigret_c import Maigret
from .sherlock_c import Sherlock
from .blackbird_c import Blackbird
from .theharvester_c import TheHarvester
from .phone_c import PhoneInfoga, Ignorant, Phunter
from .phone2_c import PhoneInfo
from .net_c import Nmap, Wayback
from .net2_c import ReverseDNS, ASNLookup, IPGeo, HTTPHeaders, DoHDNS
from .leak_c import H8mail
from .infra_c import RDAP, CrtSh, DNSEnum
from .dev_c import GitHubDev
from .dev2_c import GitHubKeys, GitHubGists, NpmMaintainer
from .keybase_c import Keybase
from .social_c import Reddit, HackerNews, GitLab, WebFinger
from .social3_c import Bluesky, Mastodon, ChessCom
from .media_c import WebFingerprint
from .web2_c import URLUnshorten, SiteFiles
from .threat_c import ShodanInternetDB, URLScan, CertSpotter
from .enrich_c import PermuteUsernames, EmailInferName, Gravatar, GravatarProfile
from .breach_c import XposedOrNot
from .wmn_c import WhatsMyName
from .recon_c import WaybackCDX, HackerTargetRecon, Psbdmp
from .infra2_c import RIPEstat, OTXPassiveDNS, AnubisSubs, ColumbusSubs, RapidDNS
from .enrich2_c import Nominatim, WikidataEnrich, SECEdgar, GLEIF, OpenPGPKeys
from .threat2_c import FeodoTracker, OpenPhish, BitcoinAddress, ProxyNovaCOMB
from .kali_c import (Subfinder, Assetfinder, Amass, Dnsx, Dnstwist, Gau, Waybackurls,
                     WhatWeb, ExifToolMeta, Nexfil, Mailcat, Zehef)
from .keyed_c import (ShodanFull, HIBP, VirusTotalDomain, GreyNoiseIP, AbuseIPDB,
                      HunterDomain)
from . import mock


def default_collectors(real: bool = True, include_mock: bool = False,
                       enable_darkweb: bool = False) -> list[Collector]:
    out: list[Collector] = []
    if real:
        out += [
            # 표층
            Maigret(), Sherlock(), Blackbird(), WhatsMyName(), Holehe(), TheHarvester(),
            # 소셜·활동
            Reddit(), HackerNews(), GitLab(), WebFinger(),
            Bluesky(), Mastodon(), ChessCom(),
            # 유출 노출(키 없음)
            XposedOrNot(),
            # 전화
            PhoneInfo(), PhoneInfoga(), Ignorant(), Phunter(),
            # 네트워크·IP
            Nmap(), Wayback(), WaybackCDX(), ReverseDNS(), ASNLookup(), IPGeo(),
            HTTPHeaders(), ShodanInternetDB(), HackerTargetRecon(),
            # 인프라
            RDAP(), CrtSh(), CertSpotter(), DNSEnum(), DoHDNS(), URLScan(), Psbdmp(),
            # 개발자·검증 신원
            GitHubDev(), GitHubKeys(), GitHubGists(), NpmMaintainer(), Keybase(),
            # 웹 지문·보강
            WebFingerprint(), URLUnshorten(), SiteFiles(),
            # 능동 확장(순수 코드 위주)
            PermuteUsernames(), EmailInferName(), Gravatar(), GravatarProfile(),
            # 유출(로컬)
            H8mail(),
            # 인프라 심화(키 없는 공개 JSON)
            RIPEstat(), OTXPassiveDNS(), AnubisSubs(), ColumbusSubs(), RapidDNS(),
            # 신원·조직 enrichment(공개 지식/등기)
            Nominatim(), WikidataEnrich(), SECEdgar(), GLEIF(), OpenPGPKeys(),
            # 위협 인텔·암호화폐·자격증명(키 없음)
            FeodoTracker(), OpenPhish(), BitcoinAddress(), ProxyNovaCOMB(),
            # Kali/GitHub CLI 도구(설치 시 동작, 없으면 skip)
            Subfinder(), Assetfinder(), Amass(), Dnsx(), Dnstwist(), Gau(),
            Waybackurls(), WhatWeb(), ExifToolMeta(), Nexfil(), Mailcat(), Zehef(),
            # 선택적 키 수집기(키 있을 때만 활성, 없으면 skip)
            ShodanFull(), HIBP(), VirusTotalDomain(), GreyNoiseIP(), AbuseIPDB(),
            HunterDomain(),
        ]
        if enable_darkweb:
            from ..darkweb.collectors import OnionSearch, Torbot
            out += [OnionSearch(), Torbot()]
    if include_mock:
        out += mock.DEFAULTS
    return out
