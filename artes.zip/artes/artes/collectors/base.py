"""수집기 기반 클래스.

수집기는 전부 일반 코드다 — AI 0회. 각 수집기는:
- 자기가 받는 입력 타입(accepts)을 선언하고,
- 설치/가용 여부(available)를 스스로 판정하고(미설치면 우아하게 skip),
- 근거(Evidence)를 붙인 엔티티/간선만 낸다.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any

from ..core.model import Entity, Edge, EntityType


@dataclass
class CollectorResult:
    source: str
    ok: bool = True
    entities: list[Entity] = field(default_factory=list)
    edges: list[Edge] = field(default_factory=list)
    error: str = ""
    elapsed: float = 0.0
    skipped: bool = False          # 도구 미설치 등으로 건너뜀
    ai_calls: int = 0              # 수집기는 항상 0이어야 한다(감사용)

    def summary(self) -> str:
        if self.skipped:
            return f"{self.source}: 건너뜀({self.error})"
        if not self.ok:
            return f"{self.source}: 실패({self.error})"
        return f"{self.source}: 엔티티 {len(self.entities)} · 간선 {len(self.edges)} · {self.elapsed:.2f}s"


class Collector:
    name: str = "base"
    accepts: set[EntityType] = set()
    timeout: float = 30.0
    needs_network: bool = True

    def available(self) -> bool:
        """이 수집기를 실제로 돌릴 수 있는가(바이너리 설치 등). 기본 True."""
        return True

    def handles(self, entity_type: EntityType) -> bool:
        return entity_type in self.accepts

    async def collect(self, value: str, entity_type: EntityType,
                      ctx: dict[str, Any]) -> CollectorResult:
        """오버라이드 대상. 예외를 던지지 말고 CollectorResult로 감싸 반환한다."""
        raise NotImplementedError

    # 엔진이 부르는 래퍼 — 시간 측정 + 예외 격리.
    async def run(self, value: str, entity_type: EntityType,
                  ctx: dict[str, Any]) -> CollectorResult:
        t0 = time.perf_counter()
        if not self.available():
            return CollectorResult(source=self.name, ok=False, skipped=True,
                                   error="미설치/미가용", elapsed=0.0)
        try:
            res = await self.collect(value, entity_type, ctx)
            res.elapsed = time.perf_counter() - t0
            res.source = self.name
            return res
        except Exception as exc:  # 실패 격리 — 한 도구 실패가 전체를 죽이지 않는다.
            return CollectorResult(source=self.name, ok=False,
                                   error=f"{type(exc).__name__}: {exc}",
                                   elapsed=time.perf_counter() - t0)
