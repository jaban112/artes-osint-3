"""웹 그래프 뷰어 익스포터 — 그래프 JSON을 템플릿에 주입해 단일 HTML로."""
from __future__ import annotations

import json
import os

from ..core.model import Graph

_TEMPLATE = os.path.join(os.path.dirname(__file__), "template.html")


def export(graph: Graph, out_path: str) -> str:
    html = open(_TEMPLATE, encoding="utf-8").read()
    data = json.dumps(graph.to_dict(), ensure_ascii=False)
    html = html.replace("__ARTES_DATA__", data)
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(html)
    return out_path
