#!/usr/bin/env bash
# ARTES 설치 — clone 후 한 번 실행. 도구·Tor·llama.cpp·(선택)모델까지 자립형 번들.
#   ./install.sh            # 코어 + OSINT 도구 + 시스템 의존 + 검증
#   ./install.sh --with-ai  # 위 + llama.cpp CPU 빌드 + 모델(GGUF) 내려받기
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; cd "$ROOT"
WITH_AI=0; MODEL_KEY="dolphin3-qwen2.5-3b"
for a in "$@"; do
  case "$a" in --with-ai) WITH_AI=1;; --model=*) MODEL_KEY="${a#*=}";; esac
done

log(){ printf '\033[1;36m[artes]\033[0m %s\n' "$*"; }
warn(){ printf '\033[1;33m[artes]\033[0m %s\n' "$*"; }
die(){ printf '\033[1;31m[artes]\033[0m %s\n' "$*" >&2; exit 1; }

detect_os(){ case "$(uname -s)" in
  Darwin) echo macos;;
  Linux) if command -v pacman >/dev/null 2>&1; then echo arch
         elif command -v apt-get >/dev/null 2>&1; then echo debian
         else echo linux-other; fi;;
  *) echo unknown;; esac; }

install_system_deps(){ local os="$1"; local pkgs=(git nmap tor cmake gcc)
  log "시스템 의존: ${pkgs[*]} ($os)"
  case "$os" in
    arch)   sudo pacman -Sy --needed --noconfirm "${pkgs[@]}" base-devel || warn "pacman 일부 실패";;
    debian) sudo apt-get update -qq && sudo apt-get install -y "${pkgs[@]}" build-essential || warn "apt 일부 실패";;
    macos)  command -v brew >/dev/null || die "Homebrew 필요"; brew install "${pkgs[@]}" || warn "brew 일부 실패";;
    *)      warn "미지원 OS — 수동 설치 필요: ${pkgs[*]}";;
  esac; }

ensure_uv(){ command -v uv >/dev/null 2>&1 || { log "uv 설치"; curl -LsSf https://astral.sh/uv/install.sh | sh; export PATH="$HOME/.local/bin:$PATH"; }; }

setup_venv(){ log "Python 3.11 venv(uv)"; uv venv --python 3.11 .venv
  # shellcheck disable=SC1091
  source .venv/bin/activate
  log "ARTES + OSINT 도구(키 불필요) 설치"
  uv pip install -e . || die "artes 설치 실패"
  uv pip install maigret holehe sherlock-project theHarvester phonenumbers \
    pillow numpy dnspython pyflakes \
    ignorant nexfil \
    || warn "일부 도구 설치 실패 — 해당 축은 자동 skip"; }

# 증분 13: Kali/GitHub 키 불필요 CLI 도구(있으면 ARTES가 자동 사용, 없으면 skip).
install_recon_tools(){
  log "정찰 CLI 도구(키 불필요) 설치 시도"
  # Kali/apt 계열
  if command -v apt-get >/dev/null 2>&1; then
    sudo apt-get install -y subfinder amass assetfinder dnsx dnstwist \
      whatweb wafw00f dnsrecon dnsenum fierce dmitry exiftool \
      >/dev/null 2>&1 || warn "apt 정찰도구 일부 실패(없어도 자동 skip)"
  fi
  # Go 도구(있으면)
  if command -v go >/dev/null 2>&1; then
    for t in \
      github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest \
      github.com/projectdiscovery/dnsx/cmd/dnsx@latest \
      github.com/projectdiscovery/katana/cmd/katana@latest \
      github.com/tomnomnom/assetfinder@latest \
      github.com/tomnomnom/waybackurls@latest \
      github.com/lc/gau/v2/cmd/gau@latest ; do
      go install "$t" >/dev/null 2>&1 || true
    done
  fi
  # PyPI 사용자 도구
  uv pip install naminter user-scanner >/dev/null 2>&1 || true
  log "정찰 도구 설치 시도 완료(설치된 것만 자동 활성)"; }

build_llama(){ local dir="$HOME/.artes/llama.cpp"
  if [ -x "$dir/build/bin/llama-server" ]; then log "llama.cpp 이미 빌드됨"; return; fi
  log "llama.cpp CPU 빌드(소스)"
  rm -rf "$dir"; git clone --depth 1 https://github.com/ggml-org/llama.cpp "$dir"
  cmake -S "$dir" -B "$dir/build" -DGGML_NATIVE=ON -DLLAMA_CURL=OFF -DCMAKE_BUILD_TYPE=Release
  cmake --build "$dir/build" --target llama-cli llama-server -j"$(nproc 2>/dev/null || echo 2)"
  log "llama.cpp 빌드 완료: $dir/build/bin"; }

download_model(){ local key="$1"
  # shellcheck disable=SC1091
  source .venv/bin/activate
  python - "$key" <<'PY'
import sys, os, urllib.request
from artes.ai.runtime import MODELS
key=sys.argv[1]; spec=MODELS.get(key)
if not spec: raise SystemExit(f"모르는 모델 키: {key} (선택: {list(MODELS)})")
dst=os.path.join(os.path.expanduser('~/.artes/models'), spec['file']); os.makedirs(os.path.dirname(dst),exist_ok=True)
if os.path.exists(dst): print('모델 이미 있음:',dst); raise SystemExit(0)
url=f"https://huggingface.co/{spec['repo']}/resolve/main/{spec['file']}"
print(f"모델 내려받기(~{spec['approx_gb']}GB): {url}")
urllib.request.urlretrieve(url, dst); print('저장:',dst)
PY
}

# 증분 15: RAM에 맞춰 역할별 모델(판정·코더·대화) 자동 선택·다운로드(무검열 GGUF).
download_role_models(){
  # shellcheck disable=SC1091
  source .venv/bin/activate
  python - <<'PY'
import os, urllib.request
from artes.ai.models import ROLE_MODELS, recommend, model_spec, detect_ram_gb
from artes.ai.serving import model_path, draft_path
ram=detect_ram_gb(); print(f"감지 RAM ~{ram}GB — 역할별 최적 모델 선택")
for role in ("judge","coder","chat"):
    name=recommend(role, ram); spec=model_spec(role, name)
    if not spec: continue
    for tag, rp, fp in (("본체", spec["repo"], model_path(spec)),):
        if os.path.exists(fp): print(f"[{role}] {name} 이미 있음"); continue
        os.makedirs(os.path.dirname(fp), exist_ok=True)
        url=f"https://huggingface.co/{spec['repo']}/resolve/main/{spec['file']}"
        print(f"[{role}] {name} (~{spec['approx_gb']}GB) 내려받기: {url}")
        try: urllib.request.urlretrieve(url, fp); print("  저장:", fp)
        except Exception as e: print("  실패(수동 다운로드 필요):", e)
    dp=draft_path(spec)
    if dp and not os.path.exists(dp):
        d=spec["draft"]; url=f"https://huggingface.co/{d['repo']}/resolve/main/{d['file']}"
        os.makedirs(os.path.dirname(dp), exist_ok=True)
        print(f"[{role}] 투기 디코딩 드래프트: {url}")
        try: urllib.request.urlretrieve(url, dp); print("  저장:", dp)
        except Exception as e: print("  드래프트 실패:", e)
# 크롬북 개인용 완전 무검열 Dolphin(로컬, OSINT와 무관).
from artes.ai.models import personal_spec
ps=personal_spec(); pf=os.path.join(os.path.expanduser("~/.artes/models"), ps["file"])
if not os.path.exists(pf) and ram>=ps["min_ram_gb"]:
    url=f"https://huggingface.co/{ps['repo']}/resolve/main/{ps['file']}"
    print(f"[개인용 무검열 Dolphin] {ps['name']} (~{ps['approx_gb']}GB): {url}")
    try: urllib.request.urlretrieve(url, pf); print("  저장:", pf)
    except Exception as e: print("  실패:", e)
PY
}

verify(){ log "검증: 테스트 + 오프라인 스모크"
  # shellcheck disable=SC1091
  source .venv/bin/activate
  uv pip install pytest >/dev/null 2>&1 || true
  python -m pytest -q || die "테스트 실패"
  artes --mock --yes --json "test@example.com" >/dev/null || die "스모크 실패"
  log "완료.  사용: source .venv/bin/activate && artes \"홍길동\" \"hong@gmail.com\""
  [ "$WITH_AI" = "1" ] && log "AI:  artes ai chat  ·  artes ask \"질문\" --load out.json"; }

main(){ local os; os="$(detect_os)"; log "OS: $os"
  [ "$os" = "unknown" ] && die "지원 OS 아님(Arch/Debian·Ubuntu/macOS)"
  install_system_deps "$os"; ensure_uv; setup_venv; install_recon_tools
  if [ "$WITH_AI" = "1" ]; then build_llama
    if [ "${ROLE_MODELS:-1}" = "1" ]; then download_role_models
    else download_model "$MODEL_KEY"; fi
  fi
  verify
  warn "다크웹 축은 Tor 필요(설치됨). Neo4j 승격은 'pip install neo4j' + 로컬 서버(선택)."; }
main "$@"
