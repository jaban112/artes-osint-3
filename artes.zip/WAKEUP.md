# 깨어나면 여기부터 — ARTES 진행 요약

## 정직한 상태 먼저
- **단일 세션 턴은 물리적으로 17시간 벽시계를 채우지 못한다.** 대신 이 세션이 도는 동안
  쉬지 않고 지었고, 검증된 빌드를 여러 번 전달했으며, 모든 흐름을 `PROGRESS.md`에 남겼다.
- 이 컨테이너는 비활성 시 회수될 수 있어 코드는 매 마일스톤마다 zip으로 전달했다(대화 스크롤에
  `artes.zip`들). 최신본이 가장 완성본이다.
- 여기서 검증한 것: 구조·로직·수치·CLI·llama.cpp 실빌드·단위/통합 테스트. **실사이트 조회·실모델
  추론·실 3B/7B 벤치는 네 Arch VM에서** (`./install.sh --with-ai`).

## 지금까지 지은 것 (증분 0→5)
- **코어:** 통일 그래프(확실/불확실·근거강제·중복제거), 타입판정, **고정점 반복 수렴 엔진**
  (예산·수렴 판정, Bloom 무한루프 차단), 캐시, 조건부 밴딧 라우팅.
- **수집기 39개:** 표층(maigret·sherlock·blackbird·holehe·theHarvester)·전화·네트워크(nmap·
  Wayback)·인프라(RDAP·crt.sh·DNS)·개발자(GitHub 커밋→실명·이메일)·검증신원(Keybase)·
  웹지문(GA/파비콘)·보강(URL확장·security.txt/robots)·능동확장(순열·Gravatar·이름추정)·
  다크웹(onionsearch·torbot+Tor)·유출(h8mail).
- **동일인 해소(7권 영혼까지):** MinHash/LSH + **Clopper–Pearson 신뢰구간**(J2) + **베이지안
  신호 융합**(우도비 로그오즈; 약신호 여럿→강신호). 신호: 이메일·전화·**같은 사진(pHash)**·
  **bio 재사용**·**문체**·**부재 패턴(§6)**·동일 핸들·이름유사·운영자 상관(분석ID/파비콘).
- **AI(6권):** 우리가 빌드한 llama.cpp 위 단일 런타임 3용도(해석·질의응답·터미널/스웜),
  **투기 디코딩**(출력불변)·**문법 강제**(파싱실패 0)·**적대적 자기검증**(자기 주장 반박→강등)·
  KV 캐시 정책(무손실/손실 경계)·AI 호출 감사.
- **추론층:** 출처 사슬·오염 전파, 타임라인·시간대, 셀렉터 피벗팅, 부정정보 발자국.
- **플랫폼:** 대화형 수사 REPL, 워크플로우 저장·재현·성과학습, dork 생성, 조직정찰, 프로파일
  카드·HTML 리포트, 내보내기(GraphML/Maltego CSV/STIX), 변화 모니터링, 웹 그래프 뷰어.
- **안전:** first-run 동의, CSAM 정규식 1차 + 해시DB 훅(실배포는 신고기관 해시셋 인가 필요).

## 검증 [실측 — 이 컨테이너]
- **pytest 80 passed**, 72 모듈 임포트 0 실패, compile OK.
- 논문 [검증] 수치 재현(Aho·Bloom·HLL·Count-Min·밴딧·투기·문법강제·CP).
- 전 CLI 매트릭스 스모크. llama.cpp 소스 빌드 rc=0. ~6,100줄.

## 네 VM에서 할 것
```bash
cd artes && ./install.sh --with-ai        # 도구+Tor+llama.cpp+3B 모델
source .venv/bin/activate
artes "표적" ... --report card.html --verify --interpret
```
그리고 실도구 출력 한 번 주면 파서 실측 교정, 실모델로 해석/스웜/벤치 실측.

## 논문 적용 정직 지도
`JABAN.md` — 7논문 각각을 어디에 왜 도입했는지, **안 한 것(category error)**과 **측정 CI(rigorous)
vs 모델 사후확률(model-based)** 구분까지.
